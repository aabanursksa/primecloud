# Home Page Builder للتطبيق

نظام إدارة كامل للصفحة الرئيسية يسمح ببناء سكشنات متنوعة وترتيبها بدون كود، مع نظام بنرات مرن.

## 1. قاعدة البيانات (إضافات آمنة فقط)

### جدول جديد `home_sections`
- `id`, `title_ar`, `title_en`
- `section_type` (enum: hero_carousel, single_banner, banner_grid, products_carousel, products_grid, featured_products, category_products, most_ordered, new_products, offers_products, categories_section, combo_section, banner_with_products)
- `display_style` (enum: carousel, grid, vertical_list, featured_large, compact)
- `sort_order`, `is_active`
- `category_id` (nullable, FK → product_categories)
- `manual_product_ids` (uuid[])
- `products_limit` (int, default 6)
- `show_view_all` (bool), `view_all_url` (text)
- `settings` (jsonb للإعدادات الإضافية)
- `created_at`, `updated_at`

### جدول جديد `home_section_banners` (بنرات داخل السكشنات أو بين السكشنات)
- `id`, `section_id` (nullable - لو null = بنر مستقل بين السكشنات)
- `position` (enum: top_of_page, after_categories, before_section, after_section, inside_section)
- `anchor_section_id` (nullable - للوضع before/after سكشن معين)
- `image_mobile`, `image_tablet`, `image_desktop`
- `title`, `subtitle` (اختياري)
- `link_type` (product/category/offer/page/external/none)
- `link_value`
- `start_date`, `end_date` (nullable)
- `is_active`, `sort_order`

### حقول إضافية اختيارية على `products` (إذا لم تكن موجودة)
- `discount_price` (numeric, nullable) - السعر قبل الخصم
- `is_new` (computed من created_at - لا يحتاج حقل)
- `order_count` (يُحسب من order_items)

### RLS
- قراءة عامة للسكشنات النشطة
- كتابة للمدراء فقط (`is_manager(auth.uid())`)

## 2. لوحة التحكم - صفحة جديدة

### `/dashboard/home-builder`
ملف: `src/routes/dashboard.home-builder.tsx`
- زر "إضافة سكشن جديد" مع اختيار النوع
- قائمة السكشنات مع Drag & Drop للترتيب
- لكل سكشن: تعديل / تفعيل / حذف / معاينة
- محرر السكشن (Dialog):
  - عنوان عربي/إنجليزي
  - نوع السكشن (13 خيار)
  - طريقة العرض (Carousel/Grid/List/Featured/Compact)
  - عدد المنتجات (4/5/6/10/الكل/مخصص)
  - اختيار التصنيف
  - اختيار منتجات يدويًا (مع بحث)
  - زر "عرض الكل" + الرابط
- إدارة بنرات السكشن (داخلي/قبل/بعد)
- زر "معاينة" يفتح `/?preview=1` في تبويب جديد

### إضافة بند "الصفحة الرئيسية" في sidebar الداش بورد
ملف: `src/routes/dashboard.tsx` (إضافة فقط، بدون لمس البقية)

## 3. الصفحة الرئيسية للتطبيق

### تحديث `src/routes/index.tsx`
- استبدال العرض الثابت بـ renderer ديناميكي يقرأ من `home_sections`
- يحافظ على Header/Footer/Cart/Auth بدون أي تغيير
- يجلب البنرات بحسب `position` و`anchor_section_id` ويدمجها بين السكشنات

### مكونات السكشنات الجديدة
مجلد: `src/components/store/home-sections/`
- `HeroBannerCarousel.tsx`
- `SingleBanner.tsx`
- `BannerGrid.tsx`
- `ProductsCarousel.tsx` (سحب أفقي)
- `ProductsGrid.tsx`
- `FeaturedProducts.tsx` (كروت كبيرة)
- `CategoryProducts.tsx`
- `CategoriesSection.tsx`
- `BannerWithProducts.tsx`
- `SectionRenderer.tsx` (يوزع حسب النوع)

### كرت المنتج الموحّد
ملف جديد: `src/components/store/ProductCard.tsx`
- variants: `default | featured | compact`
- يعرض: صورة، اسم، وصف، سعر، سعر قبل الخصم، سعرات، شارة (جديد/الأكثر طلبًا/عرض/مميز/نفد)
- زر إضافة سريع (يستدعي السلة الحالية بدون تعديل منطقها)
- لو فيه variants/addons → ينقل لصفحة المنتج

## 4. الأقسام الذكية التلقائية
- **الأكثر طلبًا**: `SELECT product_id, COUNT(*) FROM order_items GROUP BY product_id ORDER BY COUNT DESC LIMIT N`
- **جديدنا**: `ORDER BY created_at DESC`
- **العروض**: `WHERE discount_price IS NOT NULL AND discount_price < base_price`
- **مميز**: `WHERE is_featured = true`
- يتم الحساب وقت الطلب (لا يحتاج cron)

## 5. ملاحظات الأمان

- **لن يُلمس**: السلة، الطلبات، الدفع، تسجيل الدخول، صفحة المنتج، التصنيفات، الصلاحيات
- **لن تُحذف**: أي حقول أو جداول قائمة (banners الحالي يبقى للتوافق)
- **إضافات فقط**: جداول جديدة + صفحة داش جديدة + تحديث index.tsx + مكونات جديدة
- البنرات القديمة في `banners` ستبقى تعمل، ويُضاف نظام جديد بجانبها

## 6. خطة التنفيذ

1. Migration للجدولين الجديدين + RLS + indexes
2. صفحة الداش `dashboard.home-builder.tsx` + إضافة الرابط في الـ sidebar
3. مكونات السكشنات + ProductCard الموحّد
4. تحديث `index.tsx` ليستهلك السكشنات الديناميكية مع fallback للعرض الحالي إذا لا توجد سكشنات معرّفة
5. إنشاء سكشنات افتراضية (seed) لتظهر تجربة جاهزة من أول مرة
6. اختبار: الرئيسية، السلة، الطلبات، الداش بورد

## تفاصيل تقنية

- Drag & Drop: `@dnd-kit/core` + `@dnd-kit/sortable` (مكتبة خفيفة)
- Carousel: `embla-carousel-react` (موجودة في shadcn) أو scroll أفقي بسيط بـ Tailwind
- البنرات الـ responsive: `<picture>` مع `<source media="...">`
- الأقسام الذكية: استعلامات Supabase مباشرة من المتصفح (RLS تسمح بالقراءة العامة)
- السكشنات الافتراضية: لو الجدول فاضي يستخدم index.tsx العرض الحالي (fallback آمن)
