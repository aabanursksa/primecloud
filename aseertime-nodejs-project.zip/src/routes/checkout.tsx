import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState, useMemo, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { useCart } from "@/lib/cart";
import { toast } from "sonner";
import { Truck, Store as StoreIcon, MapPin } from "lucide-react";
import { useCustomerAuth } from "@/lib/customer-auth";

export const Route = createFileRoute("/checkout")({ component: CheckoutPage });

function CheckoutPage() {
  const { items, subtotal, branchId, setBranchId, customerPhone, setCustomerPhone, clear } = useCart();
  const { customer } = useCustomerAuth();
  const navigate = useNavigate();
  const [orderType, setOrderType] = useState<"delivery" | "pickup">("delivery");
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "online">("cash");
  const [name, setName] = useState(customer?.name || "");
  const [phone, setPhone] = useState(customer?.phone || customerPhone || "");
  const [email, setEmail] = useState("");
  const [zoneId, setZoneId] = useState<string | null>(null);
  const [savedAddressId, setSavedAddressId] = useState<string | null>(null);
  const [city, setCity] = useState("");
  const [district, setDistrict] = useState("");
  const [street, setStreet] = useState("");
  const [building, setBuilding] = useState("");
  const [landmark, setLandmark] = useState("");
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<any | null>(null);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  const { data } = useQuery({
    queryKey: ["checkout-meta"],
    queryFn: async () => {
      const [b, s, zones, integ] = await Promise.all([
        supabase.from("branches").select("*").eq("is_active", true).eq("accepts_orders", true).order("display_order"),
        supabase.from("store_settings").select("*").limit(1).maybeSingle(),
        supabase.from("delivery_zones").select("*").eq("status", "active").order("sort_order"),
        supabase.from("integrations").select("provider, status").eq("status", "published"),
      ]);
      const activeProviders = new Set((integ.data ?? []).map((i: any) => i.provider));
      const onlinePaymentEnabled = ["stripe", "paddle", "tap", "moyasar", "hyperpay", "checkout", "paypal"].some((p) => activeProviders.has(p));
      return { branches: b.data ?? [], settings: s.data, zones: zones.data ?? [], onlinePaymentEnabled };
    },
  });

  // Load saved addresses by phone
  const { data: savedAddresses } = useQuery({
    queryKey: ["customer-addresses", phone],
    queryFn: async () => {
      if (!phone || phone.trim().length < 6) return [];
      const { data } = await supabase.rpc("get_customer_addresses", { _phone: phone.trim() });
      return (data as any[]) ?? [];
    },
    enabled: phone.trim().length >= 6,
  });

  // Block banned customers early
  const { data: isBanned } = useQuery({
    queryKey: ["customer-banned", phone],
    queryFn: async () => {
      const { data } = await supabase.rpc("is_customer_banned", { _phone: phone.trim() });
      return Boolean(data);
    },
    enabled: phone.trim().length >= 6,
  });

  const selectedBranch = useMemo(() => data?.branches.find((b) => b.id === branchId) ?? null, [data, branchId]);
  const branchZones = useMemo(
    () => (data?.zones ?? []).filter((z: any) => !z.branch_id || z.branch_id === branchId),
    [data, branchId]
  );
  const selectedZone = useMemo(() => branchZones.find((z: any) => z.id === zoneId) ?? null, [branchZones, zoneId]);

  // Auto-default cash if online not enabled
  useEffect(() => {
    if (data && !data.onlinePaymentEnabled && paymentMethod === "online") setPaymentMethod("cash");
  }, [data, paymentMethod]);

  const vatPercent = Number(data?.settings?.vat_percent ?? 15);
  const deliveryFee =
    orderType === "delivery"
      ? selectedZone
        ? Number(selectedZone.delivery_fee || 0)
        : Number(selectedBranch?.delivery_fee ?? data?.settings?.delivery_fee ?? 0)
      : 0;

  const discount = useMemo(() => {
    if (!appliedCoupon) return 0;
    if (Number(appliedCoupon.minimum_order || 0) > subtotal) return 0;
    if (appliedCoupon.discount_type === "percent") {
      const v = subtotal * (Number(appliedCoupon.discount_value) / 100);
      return appliedCoupon.maximum_discount ? Math.min(v, Number(appliedCoupon.maximum_discount)) : v;
    }
    if (appliedCoupon.discount_type === "fixed") return Number(appliedCoupon.discount_value);
    return 0;
  }, [appliedCoupon, subtotal]);

  const freeDelivery = appliedCoupon?.discount_type === "free_delivery";
  const finalDelivery = freeDelivery ? 0 : deliveryFee;
  const taxableBase = Math.max(0, subtotal - discount);
  const vat = taxableBase * (vatPercent / 100);
  const total = taxableBase + vat + finalDelivery;

  const applyCoupon = async () => {
    if (!couponCode.trim()) return;
    const { data: c } = await supabase.from("coupons").select("*").eq("code", couponCode.trim()).eq("status", "active").maybeSingle();
    if (!c) { toast.error("كود غير صالح"); return; }
    const now = new Date();
    if (c.start_date && new Date(c.start_date) > now) { toast.error("الكوبون لم يبدأ بعد"); return; }
    if (c.end_date && new Date(c.end_date) < now) { toast.error("انتهت صلاحية الكوبون"); return; }
    if (c.usage_limit != null && Number(c.used_count || 0) >= Number(c.usage_limit)) {
      toast.error("نفذ استخدام هذا الكوبون"); return;
    }
    if (c.branch_id && branchId && c.branch_id !== branchId) {
      toast.error("الكوبون غير صالح لهذا الفرع"); return;
    }
    if (Number(c.minimum_order || 0) > subtotal) {
      toast.error(`الحد الأدنى للطلب ${c.minimum_order} ر.س`); return;
    }
    // per-customer usage check
    if (c.usage_per_customer && phone.trim().length >= 6) {
      const { data: prevOrders } = await supabase.rpc("get_customer_orders", { _phone: phone.trim() });
      const used = ((prevOrders as any[]) ?? []).filter((o: any) => o.coupon_id === c.id).length;
      if (used >= Number(c.usage_per_customer)) {
        toast.error("لقد استخدمت هذا الكوبون من قبل"); return;
      }
    }
    setAppliedCoupon(c);
    toast.success("تم تطبيق الكوبون");
  };

  const minOrder = orderType === "delivery"
    ? Number(selectedZone?.minimum_order || selectedBranch?.min_order_amount || data?.settings?.min_order_amount || 0)
    : 0;

  const submit = async () => {
    if (items.length === 0) { toast.error("السلة فارغة"); return; }
    if (!name.trim() || name.trim().length < 2) { toast.error("الاسم مطلوب"); return; }
    if (!phone.trim() || phone.trim().length < 6) { toast.error("رقم الجوال مطلوب"); return; }
    if (isBanned) { toast.error("لا يمكنك إنشاء طلب حالياً، يرجى التواصل مع خدمة العملاء."); return; }
    if (!branchId) { toast.error("اختر فرعاً"); return; }
    if (orderType === "delivery") {
      if (branchZones.length > 0 && !zoneId) { toast.error("اختر منطقة التوصيل"); return; }
      if (!city || !district || !street) { toast.error("أكمل بيانات العنوان"); return; }
      if (minOrder > 0 && subtotal < minOrder) { toast.error(`الحد الأدنى للطلب ${minOrder} ر.س`); return; }
    }
    if (paymentMethod === "online" && !data?.onlinePaymentEnabled) {
      toast.error("الدفع الإلكتروني غير مفعّل حالياً");
      return;
    }

    setLoading(true);
    try {
      setCustomerPhone(phone.trim());
      const payload = {
        customer: { name: name.trim(), phone: phone.trim(), email: email.trim() || null },
        branch_id: branchId,
        zone_id: zoneId,
        order_type: orderType,
        payment_method: paymentMethod,
        subtotal, vat_amount: vat, delivery_fee: finalDelivery, discount_amount: discount, total_amount: total,
        customer_notes: notes || null,
        coupon_code: appliedCoupon?.code ?? null,
        address: orderType === "delivery" ? { city, district, street, building, landmark } : null,
        items: items.map((it) => ({
          product_id: it.product_id,
          variant_id: it.variant_id,
          product_name: it.product_name,
          variant_name: it.variant_name,
          quantity: it.quantity,
          unit_price: it.unit_price,
          total_price: (Number(it.unit_price) + it.addons.reduce((s, a) => s + Number(a.price), 0)) * it.quantity,
          notes: it.notes,
          addons: it.addons,
        })),
      };
      const { data: result, error } = await supabase.rpc("place_storefront_order", { payload: payload as any });
      if (error) throw error;
      const orderNumber = (result as any)?.order_number;
      clear();
      toast.success("تم إنشاء الطلب بنجاح");
      navigate({ to: "/order-success/$orderNumber", params: { orderNumber } });
    } catch (e: any) {
      toast.error(e?.message || "تعذّر إنشاء الطلب");
    } finally {
      setLoading(false);
    }
  };

  const useSavedAddress = (a: any) => {
    setSavedAddressId(a.id);
    setCity(a.city || "");
    setDistrict(a.district || "");
    setStreet(a.street || "");
    setBuilding(a.building || "");
    setLandmark(a.landmark || "");
  };

  if (items.length === 0) {
    return <StoreLayout><div className="container mx-auto px-4 py-20 text-center">السلة فارغة. <Link to="/menu" className="text-primary">تصفح المنيو</Link></div></StoreLayout>;
  }

  return (
    <StoreLayout>
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">إتمام الطلب</h1>
        {isBanned && (
          <div className="bg-destructive/10 border border-destructive text-destructive rounded-2xl p-4 mb-4 text-sm font-bold">
            لا يمكنك إنشاء طلب حالياً، يرجى التواصل مع خدمة العملاء.
          </div>
        )}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Branch */}
            <section className="bg-card border border-border rounded-2xl p-5">
              <h3 className="font-bold mb-3">اختر الفرع</h3>
              {(data?.branches ?? []).length === 0 ? (
                <div className="text-sm text-muted-foreground">لا توجد فروع تستقبل الطلبات حالياً</div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {data!.branches.map((b) => (
                    <button key={b.id} onClick={() => { setBranchId(b.id); setZoneId(null); }} className={`text-right p-3 rounded-xl border-2 ${branchId === b.id ? "border-primary bg-primary/5" : "border-border"}`}>
                      <div className="font-bold">{b.name}</div>
                      {b.address && <div className="text-xs text-muted-foreground">{b.address}</div>}
                    </button>
                  ))}
                </div>
              )}
            </section>

            {/* Type */}
            <section className="bg-card border border-border rounded-2xl p-5">
              <h3 className="font-bold mb-3">نوع الطلب</h3>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => setOrderType("delivery")} className={`p-3 rounded-xl border-2 flex items-center justify-center gap-2 ${orderType === "delivery" ? "border-primary bg-primary/5" : "border-border"}`}>
                  <Truck className="w-4 h-4" /> توصيل
                </button>
                <button onClick={() => setOrderType("pickup")} className={`p-3 rounded-xl border-2 flex items-center justify-center gap-2 ${orderType === "pickup" ? "border-primary bg-primary/5" : "border-border"}`}>
                  <StoreIcon className="w-4 h-4" /> استلام
                </button>
              </div>
            </section>

            {/* Customer */}
            <section className="bg-card border border-border rounded-2xl p-5">
              <h3 className="font-bold mb-3">بياناتك</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="الاسم *" className="bg-muted rounded-xl px-4 py-2.5 text-sm focus:outline-none" />
                <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="رقم الجوال *" className="bg-muted rounded-xl px-4 py-2.5 text-sm focus:outline-none" />
                <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="البريد (اختياري)" className="bg-muted rounded-xl px-4 py-2.5 text-sm focus:outline-none md:col-span-2" />
              </div>
            </section>

            {/* Address */}
            {orderType === "delivery" && (
              <section className="bg-card border border-border rounded-2xl p-5">
                <h3 className="font-bold mb-3">عنوان التوصيل</h3>

                {(savedAddresses?.length ?? 0) > 0 && (
                  <div className="mb-4">
                    <div className="text-xs text-muted-foreground mb-2">عناوين محفوظة</div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {savedAddresses!.map((a: any) => (
                        <button key={a.id} type="button" onClick={() => useSavedAddress(a)}
                          className={`text-right p-3 rounded-xl border-2 text-sm ${savedAddressId === a.id ? "border-primary bg-primary/5" : "border-border"}`}>
                          <div className="font-bold flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{a.title || a.district || "عنوان"}</div>
                          <div className="text-xs text-muted-foreground mt-0.5 truncate">{[a.city, a.district, a.street].filter(Boolean).join("، ")}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {branchZones.length > 0 && (
                  <div className="mb-4">
                    <div className="text-xs text-muted-foreground mb-2">منطقة التوصيل *</div>
                    <select value={zoneId || ""} onChange={(e) => setZoneId(e.target.value || null)}
                      className="w-full bg-muted rounded-xl px-4 py-2.5 text-sm">
                      <option value="">— اختر المنطقة —</option>
                      {branchZones.map((z: any) => (
                        <option key={z.id} value={z.id}>
                          {z.name} — {Number(z.delivery_fee).toFixed(2)} ر.س{z.minimum_order ? ` (حد أدنى ${z.minimum_order})` : ""}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="المدينة *" className="bg-muted rounded-xl px-4 py-2.5 text-sm" />
                  <input value={district} onChange={(e) => setDistrict(e.target.value)} placeholder="الحي *" className="bg-muted rounded-xl px-4 py-2.5 text-sm" />
                  <input value={street} onChange={(e) => setStreet(e.target.value)} placeholder="الشارع *" className="bg-muted rounded-xl px-4 py-2.5 text-sm" />
                  <input value={building} onChange={(e) => setBuilding(e.target.value)} placeholder="رقم المبنى" className="bg-muted rounded-xl px-4 py-2.5 text-sm" />
                  <input value={landmark} onChange={(e) => setLandmark(e.target.value)} placeholder="علامة مميزة" className="bg-muted rounded-xl px-4 py-2.5 text-sm md:col-span-2" />
                </div>
              </section>
            )}

            {/* Payment */}
            <section className="bg-card border border-border rounded-2xl p-5">
              <h3 className="font-bold mb-3">طريقة الدفع</h3>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => setPaymentMethod("cash")} className={`p-3 rounded-xl border-2 ${paymentMethod === "cash" ? "border-primary bg-primary/5" : "border-border"}`}>دفع عند الاستلام</button>
                <button
                  onClick={() => data?.onlinePaymentEnabled && setPaymentMethod("online")}
                  disabled={!data?.onlinePaymentEnabled}
                  title={data?.onlinePaymentEnabled ? "" : "غير مفعّل حالياً"}
                  className={`p-3 rounded-xl border-2 ${paymentMethod === "online" ? "border-primary bg-primary/5" : "border-border"} ${!data?.onlinePaymentEnabled ? "opacity-50 cursor-not-allowed" : ""}`}
                >
                  دفع إلكتروني{!data?.onlinePaymentEnabled && <span className="block text-[10px] text-muted-foreground">غير مفعّل</span>}
                </button>
              </div>
            </section>

            {/* Notes */}
            <section className="bg-card border border-border rounded-2xl p-5">
              <h3 className="font-bold mb-3">ملاحظات (اختياري)</h3>
              <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} className="w-full bg-muted rounded-xl p-3 text-sm focus:outline-none" />
            </section>
          </div>
          {/* Summary */}
          <div className="lg:sticky lg:top-20 self-start">
            <div className="bg-card border border-border rounded-2xl p-5 space-y-3">
              <h3 className="font-bold">ملخص الطلب</h3>

              <div className="flex gap-2">
                <input value={couponCode} onChange={(e) => setCouponCode(e.target.value)} placeholder="كود الخصم" className="flex-1 bg-muted rounded-xl px-4 py-2 text-sm" />
                <button onClick={applyCoupon} className="bg-primary text-primary-foreground rounded-xl px-4 text-sm font-bold">تطبيق</button>
              </div>

              <div className="space-y-2 text-sm border-t border-border pt-3">
                <div className="flex justify-between"><span>المجموع الفرعي</span><span>{subtotal.toFixed(2)} ر.س</span></div>
                {discount > 0 && <div className="flex justify-between text-success"><span>الخصم</span><span>-{discount.toFixed(2)} ر.س</span></div>}
                <div className="flex justify-between"><span>الضريبة ({vatPercent}%)</span><span>{vat.toFixed(2)} ر.س</span></div>
                {orderType === "delivery" && <div className="flex justify-between"><span>التوصيل</span><span>{finalDelivery.toFixed(2)} ر.س</span></div>}
                <div className="flex justify-between font-bold text-base border-t border-border pt-2"><span>الإجمالي</span><span className="text-primary">{total.toFixed(2)} ر.س</span></div>
              </div>

              <button onClick={submit} disabled={loading} className="w-full bg-primary text-primary-foreground py-3 rounded-xl font-bold disabled:opacity-50">
                {loading ? "جارٍ الإرسال..." : "تأكيد الطلب"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </StoreLayout>
  );
}
