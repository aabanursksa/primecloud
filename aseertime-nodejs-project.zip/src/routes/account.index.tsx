import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AccountLayout } from "@/components/store/AccountLayout";
import { useCustomerAuth } from "@/lib/customer-auth";
import { Package, MapPin, ShoppingBag, Search, User } from "lucide-react";

export const Route = createFileRoute("/account/")({ component: AccountIndex });

const STATUS_LABELS: Record<string, string> = {
  new: "جديد", accepted: "مقبول", preparing: "قيد التحضير", ready: "جاهز",
  on_the_way: "مع السائق", delivered: "تم التسليم", cancelled: "ملغي",
};
const ACTIVE_STATUSES = ["new", "accepted", "preparing", "ready", "on_the_way"];

function AccountIndex() {
  const { customer, isLoggedIn } = useCustomerAuth();

  const { data } = useQuery({
    queryKey: ["account-overview", customer?.phone],
    queryFn: async () => {
      if (!customer) return null;
      const [orders, addrs] = await Promise.all([
        supabase.rpc("get_customer_orders", { _phone: customer.phone }),
        supabase.rpc("get_customer_addresses", { _phone: customer.phone }),
      ]);
      return { orders: (orders.data as any[]) ?? [], addresses: (addrs.data as any[]) ?? [] };
    },
    enabled: isLoggedIn,
  });

  if (!isLoggedIn) return <AccountLayout>{null}</AccountLayout>;

  const orders = data?.orders ?? [];
  const activeOrders = orders.filter((o) => ACTIVE_STATUSES.includes(o.status));
  const lastOrder = orders[0];

  return (
    <AccountLayout>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-xs text-muted-foreground">إجمالي الطلبات</div>
          <div className="text-2xl font-bold mt-1">{orders.length}</div>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-xs text-muted-foreground">طلبات نشطة</div>
          <div className="text-2xl font-bold mt-1 text-primary">{activeOrders.length}</div>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-xs text-muted-foreground">عناوين محفوظة</div>
          <div className="text-2xl font-bold mt-1">{data?.addresses.length ?? 0}</div>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <div className="text-xs text-muted-foreground">آخر طلب</div>
          <div className="text-sm font-bold mt-1 truncate">
            {lastOrder ? new Date(lastOrder.created_at).toLocaleDateString("ar-SA") : "—"}
          </div>
        </div>
      </div>

      {activeOrders.length > 0 && (
        <div className="bg-card border border-border rounded-2xl p-5 mb-4">
          <h3 className="font-bold mb-3">طلباتك النشطة</h3>
          <div className="space-y-2">
            {activeOrders.slice(0, 3).map((o) => (
              <Link key={o.id} to="/account/orders/$orderNumber" params={{ orderNumber: o.order_number }}
                className="flex items-center justify-between p-3 bg-muted/40 hover:bg-muted rounded-xl">
                <div>
                  <div className="font-bold">{o.order_number}</div>
                  <div className="text-xs text-muted-foreground">{o.branch?.name || "—"}</div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] bg-primary/10 text-primary px-2 py-1 rounded-full">{STATUS_LABELS[o.status]}</span>
                  <span className="font-bold text-sm">{Number(o.total_amount).toFixed(2)} ر.س</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Link to="/account/orders" className="bg-card border border-border rounded-2xl p-4 hover:border-primary hover:bg-primary/5 text-center">
          <Package className="w-7 h-7 mx-auto text-primary mb-2" /><div className="text-sm font-bold">طلباتي</div>
        </Link>
        <Link to="/account/addresses" className="bg-card border border-border rounded-2xl p-4 hover:border-primary hover:bg-primary/5 text-center">
          <MapPin className="w-7 h-7 mx-auto text-primary mb-2" /><div className="text-sm font-bold">عناويني</div>
        </Link>
        <Link to="/account/profile" className="bg-card border border-border rounded-2xl p-4 hover:border-primary hover:bg-primary/5 text-center">
          <User className="w-7 h-7 mx-auto text-primary mb-2" /><div className="text-sm font-bold">بياناتي</div>
        </Link>
        <Link to="/menu" className="bg-card border border-border rounded-2xl p-4 hover:border-primary hover:bg-primary/5 text-center">
          <ShoppingBag className="w-7 h-7 mx-auto text-primary mb-2" /><div className="text-sm font-bold">تصفح المنيو</div>
        </Link>
      </div>
    </AccountLayout>
  );
}
