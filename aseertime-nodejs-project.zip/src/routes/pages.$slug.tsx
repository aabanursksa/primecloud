import { createFileRoute, useParams } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { StoreHead } from "@/components/store/StoreHead";
import { BlocksRenderer } from "@/components/store/blocks/BlockRenderer";

export const Route = createFileRoute("/pages/$slug")({
  component: PagePage,
  head: ({ params }) => ({
    meta: [{ title: `${params.slug} — عصير تايم` }],
  }),
});

function PagePage() {
  const { slug } = useParams({ from: "/pages/$slug" });
  const { data, isLoading } = useQuery({
    queryKey: ["page", slug],
    queryFn: async () => {
      const page = (await supabase.from("pages").select("*").eq("slug", slug).eq("status", "published").maybeSingle()).data;
      if (!page) return null;
      const [blocks, seo] = await Promise.all([
        supabase.from("page_blocks").select("*").eq("page_id", page.id).eq("is_active", true).order("sort_order"),
        supabase.from("seo_settings").select("*").eq("entity_type", "page").eq("entity_id", page.id).maybeSingle(),
      ]);
      return { page, blocks: blocks.data || [], seo: seo.data };
    },
  });

  const seo = data?.seo as any;
  const title = seo?.meta_title || data?.page?.title;
  const description = seo?.meta_description || undefined;
  const image = seo?.og_image || data?.page?.featured_image || undefined;
  const canonical = seo?.canonical_url || undefined;

  return (
    <StoreLayout>
      {data && <StoreHead title={title} description={description} image={image} canonical={canonical} />}
      {isLoading ? (
        <div className="text-center text-muted-foreground py-20">جارٍ التحميل...</div>
      ) : !data ? (
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-3xl font-bold mb-2">الصفحة غير موجودة</h1>
          <p className="text-muted-foreground">قد تكون الصفحة محذوفة أو غير منشورة.</p>
        </div>
      ) : (
        <>
          {data.blocks.length > 0 ? (
            <BlocksRenderer blocks={data.blocks as any} />
          ) : (
            <div className="container mx-auto px-4 py-8 max-w-3xl">
              <article className="prose prose-neutral max-w-none rtl">
                <h1 className="text-3xl font-bold mb-6">{data.page.title}</h1>
                {data.page.featured_image && <img src={data.page.featured_image} alt="" className="rounded-2xl mb-6 w-full" />}
                <div className="leading-relaxed whitespace-pre-wrap">{data.page.content}</div>
              </article>
            </div>
          )}
        </>
      )}
    </StoreLayout>
  );
}
