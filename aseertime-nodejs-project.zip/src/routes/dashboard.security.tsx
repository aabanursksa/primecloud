import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ShieldCheck, KeyRound, Bell, LogOut } from "lucide-react";
import { PageHeader } from "@/components/EmptyState";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/security")({ component: SecurityPage });

function SecurityPage() {
  const { user, signOut } = useAuth();
  const qc = useQueryClient();
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [saving, setSaving] = useState(false);

  const { data: settings } = useQuery({
    queryKey: ["notif-settings", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("notification_settings").select("*").eq("user_id", user!.id).maybeSingle();
      return data;
    },
  });

  const { data: sessions = [] } = useQuery({
    queryKey: ["security-sessions", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("security_sessions").select("*").eq("user_id", user!.id).order("last_activity_at", { ascending: false });
      return data ?? [];
    },
  });

  // Record current session
  useEffect(() => {
    if (!user) return;
    const ua = navigator.userAgent;
    supabase.from("security_sessions").insert({
      user_id: user.id,
      user_agent: ua,
      browser: ua.split(" ").slice(-1)[0],
      device: /Mobile/.test(ua) ? "Mobile" : "Desktop",
    }).then(() => qc.invalidateQueries({ queryKey: ["security-sessions"] }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const updatePassword = async () => {
    if (pw.length < 8) return toast.error("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
    if (pw !== pw2) return toast.error("كلمتا المرور غير متطابقتين");
    setSaving(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("تم تحديث كلمة المرور");
    setPw(""); setPw2("");
  };

  const saveNotifSetting = async (patch: Record<string, boolean>) => {
    if (!user) return;
    const payload = { user_id: user.id, ...settings, ...patch };
    delete (payload as { id?: string }).id;
    delete (payload as { created_at?: string }).created_at;
    delete (payload as { updated_at?: string }).updated_at;
    const { error } = await supabase.from("notification_settings").upsert(payload, { onConflict: "user_id" });
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["notif-settings"] });
  };

  const NS = (key: string, label: string) => (
    <div className="flex items-center justify-between py-2">
      <Label className="text-sm">{label}</Label>
      <Switch
        checked={Boolean((settings as Record<string, boolean> | null | undefined)?.[key] ?? true)}
        onCheckedChange={(v) => saveNotifSetting({ [key]: v })}
      />
    </div>
  );

  return (
    <div className="space-y-6 max-w-4xl">
      <PageHeader title="الأمان والإشعارات" description="إدارة كلمة المرور والجلسات وتفضيلات الإشعارات." />

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <KeyRound className="w-5 h-5 text-primary" />
          <h3 className="font-bold">تغيير كلمة المرور</h3>
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <Label>كلمة المرور الجديدة</Label>
            <Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
          </div>
          <div>
            <Label>تأكيد كلمة المرور</Label>
            <Input type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} />
          </div>
        </div>
        <Button onClick={updatePassword} disabled={saving} className="mt-4 bg-gradient-primary text-primary-foreground">
          {saving ? "جارٍ الحفظ..." : "حفظ"}
        </Button>
      </Card>

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Bell className="w-5 h-5 text-primary" />
          <h3 className="font-bold">تفضيلات الإشعارات</h3>
        </div>
        <div className="divide-y divide-border">
          {NS("orders_enabled", "إشعارات الطلبات")}
          {NS("drivers_enabled", "إشعارات السائقين")}
          {NS("inventory_enabled", "إشعارات المخزون")}
          {NS("integrations_enabled", "إشعارات التكاملات")}
          {NS("push_enabled", "إشعارات الموبايل (Push)")}
          {NS("email_enabled", "إشعارات البريد الإلكتروني")}
        </div>
      </Card>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-primary" />
            <h3 className="font-bold">الجلسات النشطة</h3>
          </div>
          <Button onClick={signOut} variant="outline" size="sm" className="gap-2">
            <LogOut className="w-4 h-4" /> تسجيل الخروج
          </Button>
        </div>
        {sessions.length === 0 ? (
          <p className="text-sm text-muted-foreground">لا توجد جلسات مسجلة بعد.</p>
        ) : (
          <div className="divide-y divide-border">
            {sessions.map((s) => (
              <div key={s.id} className="py-3 flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">{s.device ?? "جهاز غير معروف"} · {s.browser ?? ""}</div>
                  <div className="text-xs text-muted-foreground" dir="ltr">
                    آخر نشاط: {new Date(s.last_activity_at).toLocaleString("en-GB")}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
