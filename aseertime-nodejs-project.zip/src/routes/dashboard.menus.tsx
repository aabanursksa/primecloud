import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Menu as MenuIcon, Plus, Pencil, Trash2, ArrowUp, ArrowDown } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { moveSort } from "@/lib/sortable";

export const Route = createFileRoute("/dashboard/menus")({ component: MenusPage });

type Menu = { id: string; name: string; location: "header" | "footer" | "app"; status: "published" | "draft" };
type Item = {
  id: string; menu_id: string; parent_id: string | null; title: string;
  link_type: "page" | "category" | "product" | "external" | "none";
  link_value: string | null; open_in_new_tab: boolean; sort_order: number; status: "published" | "draft";
};

const LOCATIONS: Record<Menu["location"], string> = { header: "الهيدر", footer: "الفوتر", app: "التطبيق" };

function MenusPage() {
  const qc = useQueryClient();
  const { data: menus = [], isLoading } = useQuery({
    queryKey: ["nav_menus"],
    queryFn: async () => (await supabase.from("navigation_menus").select("*").order("created_at")).data ?? [],
  });
  const [activeMenu, setActiveMenu] = useState<Menu | null>(null);
  const [menuDialog, setMenuDialog] = useState<Menu | null>(null);

  const createMenu = () => setMenuDialog({ id: "", name: "", location: "header", status: "published" });
  const saveMenu = async () => {
    if (!menuDialog || !menuDialog.name.trim()) return toast.error("الاسم مطلوب");
    const { id, ...rest } = menuDialog;
    const res = id ? await supabase.from("navigation_menus").update(rest).eq("id", id) : await supabase.from("navigation_menus").insert(rest);
    if (res.error) return toast.error(res.error.message);
    toast.success("تم الحفظ"); setMenuDialog(null); qc.invalidateQueries({ queryKey: ["nav_menus"] });
  };
  const removeMenu = async (id: string) => {
    if (!confirm("حذف القائمة وجميع عناصرها؟")) return;
    await supabase.from("navigation_menu_items").delete().eq("menu_id", id);
    const { error } = await supabase.from("navigation_menus").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("تم الحذف"); if (activeMenu?.id === id) setActiveMenu(null);
    qc.invalidateQueries({ queryKey: ["nav_menus"] });
  };

  if (isLoading) return <Skeleton className="h-96" />;

  return (
    <>
      <PageHeader title="إدارة القوائم" description="قوائم تنقل الموقع والتطبيق" action={
        <Button onClick={createMenu} className="bg-gradient-primary text-primary-foreground gap-2"><Plus className="w-4 h-4" /> قائمة جديدة</Button>
      } />

      {menus.length === 0 ? (
        <EmptyState icon={MenuIcon} title="لا توجد قوائم" description="أنشئ أول قائمة تنقل" actionLabel="قائمة جديدة" onAction={createMenu} />
      ) : (
        <div className="grid lg:grid-cols-[280px_1fr] gap-6">
          <Card className="p-3 space-y-1 h-fit">
            {(menus as Menu[]).map((m) => (
              <div key={m.id} className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer ${activeMenu?.id === m.id ? "bg-gradient-primary text-primary-foreground" : "hover:bg-muted"}`} onClick={() => setActiveMenu(m)}>
                <MenuIcon className="w-4 h-4" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{m.name}</div>
                  <div className={`text-[10px] ${activeMenu?.id === m.id ? "text-primary-foreground/80" : "text-muted-foreground"}`}>{LOCATIONS[m.location]}</div>
                </div>
                <button onClick={(e) => { e.stopPropagation(); setMenuDialog(m); }} className="p-1"><Pencil className="w-3 h-3" /></button>
                <button onClick={(e) => { e.stopPropagation(); removeMenu(m.id); }} className="p-1 text-destructive"><Trash2 className="w-3 h-3" /></button>
              </div>
            ))}
          </Card>

          {activeMenu ? <MenuItems menu={activeMenu} /> : (
            <Card className="p-12 text-center text-muted-foreground">اختر قائمة لإدارة عناصرها</Card>
          )}
        </div>
      )}

      <Dialog open={!!menuDialog} onOpenChange={(o) => !o && setMenuDialog(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{menuDialog?.id ? "تعديل قائمة" : "قائمة جديدة"}</DialogTitle></DialogHeader>
          {menuDialog && (
            <div className="space-y-3">
              <div><Label>الاسم</Label><Input value={menuDialog.name} onChange={(e) => setMenuDialog({ ...menuDialog, name: e.target.value })} /></div>
              <div><Label>الموقع</Label>
                <select className="w-full border border-input rounded-md h-10 px-3 bg-background" value={menuDialog.location} onChange={(e) => setMenuDialog({ ...menuDialog, location: e.target.value as Menu["location"] })}>
                  {Object.entries(LOCATIONS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div className="flex items-center justify-between"><Label>منشورة</Label>
                <Switch checked={menuDialog.status === "published"} onCheckedChange={(v) => setMenuDialog({ ...menuDialog, status: v ? "published" : "draft" })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setMenuDialog(null)}>إلغاء</Button>
            <Button onClick={saveMenu} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function MenuItems({ menu }: { menu: Menu }) {
  const qc = useQueryClient();
  const { data: items = [] } = useQuery({
    queryKey: ["menu_items", menu.id],
    queryFn: async () => (await supabase.from("navigation_menu_items").select("*").eq("menu_id", menu.id).order("sort_order")).data ?? [],
  });
  const [dialog, setDialog] = useState<Item | null>(null);

  const newItem = () => setDialog({
    id: "", menu_id: menu.id, parent_id: null, title: "",
    link_type: "external", link_value: "", open_in_new_tab: false,
    sort_order: (items as Item[]).length, status: "published",
  });

  const save = async () => {
    if (!dialog || !dialog.title.trim()) return toast.error("العنوان مطلوب");
    const { id, ...rest } = dialog;
    const res = id ? await supabase.from("navigation_menu_items").update(rest).eq("id", id) : await supabase.from("navigation_menu_items").insert(rest);
    if (res.error) return toast.error(res.error.message);
    toast.success("تم الحفظ"); setDialog(null);
    qc.invalidateQueries({ queryKey: ["menu_items", menu.id] });
  };

  const remove = async (id: string) => {
    if (!confirm("حذف العنصر؟")) return;
    const { error } = await supabase.from("navigation_menu_items").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("تم الحذف"); qc.invalidateQueries({ queryKey: ["menu_items", menu.id] });
  };

  const move = async (id: string, dir: -1 | 1) => {
    await moveSort("navigation_menu_items", items as Item[], id, dir);
    qc.invalidateQueries({ queryKey: ["menu_items", menu.id] });
  };

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold">{menu.name}</h3>
        <Button onClick={newItem} size="sm" className="bg-gradient-primary text-primary-foreground gap-2"><Plus className="w-4 h-4" /> عنصر جديد</Button>
      </div>
      {(items as Item[]).length === 0 ? (
        <div className="text-center py-12 text-sm text-muted-foreground">لا توجد عناصر</div>
      ) : (
        <div className="space-y-2">
          {(items as Item[]).map((it, i, arr) => (
            <div key={it.id} className="flex items-center gap-2 p-3 border border-border rounded-lg">
              <div className="flex flex-col gap-1">
                <button disabled={i === 0} onClick={() => move(it.id, -1)} className="disabled:opacity-30"><ArrowUp className="w-3 h-3" /></button>
                <button disabled={i === arr.length - 1} onClick={() => move(it.id, 1)} className="disabled:opacity-30"><ArrowDown className="w-3 h-3" /></button>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm">{it.title}</div>
                <div className="text-xs text-muted-foreground truncate">{it.link_value || it.link_type}</div>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded ${it.status === "published" ? "bg-success/10 text-success" : "bg-muted"}`}>{it.status === "published" ? "منشور" : "مسودة"}</span>
              <button onClick={() => setDialog(it)} className="p-2"><Pencil className="w-3 h-3" /></button>
              <button onClick={() => remove(it.id)} className="p-2 text-destructive"><Trash2 className="w-3 h-3" /></button>
            </div>
          ))}
        </div>
      )}

      <Dialog open={!!dialog} onOpenChange={(o) => !o && setDialog(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{dialog?.id ? "تعديل عنصر" : "عنصر جديد"}</DialogTitle></DialogHeader>
          {dialog && (
            <div className="space-y-3">
              <div><Label>العنوان</Label><Input value={dialog.title} onChange={(e) => setDialog({ ...dialog, title: e.target.value })} /></div>
              <div><Label>نوع الرابط</Label>
                <select className="w-full border border-input rounded-md h-10 px-3 bg-background" value={dialog.link_type} onChange={(e) => setDialog({ ...dialog, link_type: e.target.value as Item["link_type"] })}>
                  <option value="external">رابط خارجي</option>
                  <option value="page">صفحة</option>
                  <option value="category">قسم</option>
                  <option value="product">منتج</option>
                  <option value="none">بدون</option>
                </select>
              </div>
              <div><Label>القيمة (URL أو slug أو ID)</Label><Input value={dialog.link_value ?? ""} onChange={(e) => setDialog({ ...dialog, link_value: e.target.value })} /></div>
              <div className="flex items-center justify-between"><Label>فتح في تبويب جديد</Label>
                <Switch checked={dialog.open_in_new_tab} onCheckedChange={(v) => setDialog({ ...dialog, open_in_new_tab: v })} />
              </div>
              <div className="flex items-center justify-between"><Label>منشور</Label>
                <Switch checked={dialog.status === "published"} onCheckedChange={(v) => setDialog({ ...dialog, status: v ? "published" : "draft" })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog(null)}>إلغاء</Button>
            <Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
