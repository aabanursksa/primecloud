import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Users, Plus, KeyRound, Trash2, ShieldAlert, Search, Store } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  createUser, updateUserRole, resetUserPassword, deleteUser,
  updateUserStatus, setUserBranches,
} from "@/lib/users.functions";
import { fetchUsersList } from "@/lib/users-list";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { EmptyState, PageHeader } from "@/components/EmptyState";

export const Route = createFileRoute("/dashboard/users")({ component: UsersPage });

const STATUS_BADGE: Record<string, string> = {
  active: "bg-success/10 text-success",
  inactive: "bg-muted text-muted-foreground",
  suspended: "bg-destructive/10 text-destructive",
};
const STATUS_LABEL: Record<string, string> = {
  active: "نشط", inactive: "غير نشط", suspended: "موقوف",
};

function UsersPage() {
  const { user, role, loading } = useAuth();
  const qc = useQueryClient();
  const isAdmin = role === "admin";

  const createFn = useServerFn(createUser);
  const updateRoleFn = useServerFn(updateUserRole);
  const resetPwFn = useServerFn(resetUserPassword);
  const deleteFn = useServerFn(deleteUser);
  const statusFn = useServerFn(updateUserStatus);
  const branchesFn = useServerFn(setUserBranches);

  const { data: users = [], isLoading } = useQuery({
    queryKey: ["users-list"], queryFn: fetchUsersList, enabled: isAdmin,
  });
  const data = Array.isArray(users) ? users : [];

  const { data: roles = [] } = useQuery({
    queryKey: ["roles-options"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data } = await supabase.from("roles").select("key, name").order("is_system", { ascending: false });
      return data ?? [];
    },
  });

  const { data: branches = [] } = useQuery({
    queryKey: ["branches-options"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data } = await supabase.from("branches").select("id, name").order("name");
      return data ?? [];
    },
  });

  const [openCreate, setOpenCreate] = useState(false);
  const [openPw, setOpenPw] = useState<string | null>(null);
  const [openBranches, setOpenBranches] = useState<string | null>(null);
  const [tempBranches, setTempBranches] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState("");
  const [filterRole, setFilterRole] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const [form, setForm] = useState({
    email: "", password: "", full_name: "", phone: "", role: "staff",
  });
  const [newPw, setNewPw] = useState("");

  const filtered = useMemo(() => {
    return data.filter((u) => {
      const r = u.roles[0] ?? "staff";
      if (filterRole !== "all" && r !== filterRole) return false;
      if (filterStatus !== "all" && u.status !== filterStatus) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!(u.full_name ?? "").toLowerCase().includes(q) && !(u.phone ?? "").includes(q)) return false;
      }
      return true;
    });
  }, [data, search, filterRole, filterStatus]);

  const createMut = useMutation({
    mutationFn: () => createFn({ data: { ...form, phone: form.phone || null, role: form.role as "admin" | "manager" | "staff" } }),
    onSuccess: () => {
      toast.success("تم إنشاء المستخدم");
      setOpenCreate(false);
      setForm({ email: "", password: "", full_name: "", phone: "", role: "staff" });
      qc.invalidateQueries({ queryKey: ["users-list"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const roleMut = useMutation({
    mutationFn: (v: { user_id: string; role: string }) => updateRoleFn({ data: { user_id: v.user_id, role: v.role as "admin" | "manager" | "staff" } }),
    onSuccess: () => { toast.success("تم تحديث الصلاحية"); qc.invalidateQueries({ queryKey: ["users-list"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const statusMut = useMutation({
    mutationFn: (v: { user_id: string; status: "active" | "inactive" | "suspended" }) => statusFn({ data: v }),
    onSuccess: () => { toast.success("تم تحديث الحالة"); qc.invalidateQueries({ queryKey: ["users-list"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const pwMut = useMutation({
    mutationFn: (v: { user_id: string; password: string }) => resetPwFn({ data: v }),
    onSuccess: () => { toast.success("تم تغيير كلمة المرور"); setOpenPw(null); setNewPw(""); },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { user_id: id } }),
    onSuccess: () => { toast.success("تم حذف المستخدم"); qc.invalidateQueries({ queryKey: ["users-list"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const branchesMut = useMutation({
    mutationFn: (v: { user_id: string; branch_ids: string[] }) => branchesFn({ data: v }),
    onSuccess: () => {
      toast.success("تم تحديث الفروع");
      setOpenBranches(null);
      qc.invalidateQueries({ queryKey: ["users-list"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const openBranchesFor = (uid: string) => {
    const u = data.find((x) => x.id === uid);
    setTempBranches(new Set(u?.branch_ids ?? []));
    setOpenBranches(uid);
  };

  if (loading) return <Skeleton className="h-96" />;
  if (!isAdmin) {
    return <EmptyState icon={ShieldAlert} title="صلاحية المسؤول مطلوبة" description="إدارة المستخدمين متاحة لحسابات المسؤول فقط." />;
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="المستخدمون"
        description="إدارة حسابات الفريق والصلاحيات والفروع."
        action={
          <Button onClick={() => setOpenCreate(true)} className="bg-gradient-primary text-primary-foreground shadow-glow gap-1">
            <Plus className="w-4 h-4" /> إضافة مستخدم
          </Button>
        }
      />

      <Card className="p-3 flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث بالاسم أو الجوال" className="pe-10" />
        </div>
        <select value={filterRole} onChange={(e) => setFilterRole(e.target.value)} className="h-10 rounded-md border border-input bg-background px-3 text-sm">
          <option value="all">كل الأدوار</option>
          {roles.map((r) => <option key={r.key} value={r.key}>{r.name}</option>)}
        </select>
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="h-10 rounded-md border border-input bg-background px-3 text-sm">
          <option value="all">كل الحالات</option>
          <option value="active">نشط</option>
          <option value="inactive">غير نشط</option>
          <option value="suspended">موقوف</option>
        </select>
      </Card>

      {isLoading ? (
        <Card className="p-12 text-center text-muted-foreground">جارٍ التحميل…</Card>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Users}
          title={data.length === 0 ? "لا يوجد مستخدمون بعد" : "لا توجد نتائج"}
          description={data.length === 0 ? "ابدأ بإضافة أعضاء فريقك." : "جرّب تعديل الفلاتر."}
          actionLabel={data.length === 0 ? "إضافة مستخدم" : undefined}
          onAction={data.length === 0 ? () => setOpenCreate(true) : undefined}
        />
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full text-sm min-w-[800px]">
            <thead className="bg-muted/50 text-muted-foreground">
              <tr>
                <th className="p-3 text-start font-medium">المستخدم</th>
                <th className="p-3 text-start font-medium">الجوال</th>
                <th className="p-3 text-start font-medium">الدور</th>
                <th className="p-3 text-start font-medium">الحالة</th>
                <th className="p-3 text-start font-medium">الفروع</th>
                <th className="p-3 text-start font-medium">آخر دخول</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => {
                const r = u.roles[0] ?? "staff";
                const isMe = u.id === user?.id;
                return (
                  <tr key={u.id} className="border-t border-border">
                    <td className="p-3">
                      <div className="font-medium">{u.full_name || "بدون اسم"}</div>
                      <div className="text-xs text-muted-foreground font-mono" dir="ltr">{u.id.slice(0, 8)}</div>
                    </td>
                    <td className="p-3 text-muted-foreground" dir="ltr">{u.phone ?? "—"}</td>
                    <td className="p-3">
                      <select
                        value={r}
                        onChange={(e) => roleMut.mutate({ user_id: u.id, role: e.target.value })}
                        className="text-xs px-2 py-1 rounded border border-input bg-background"
                      >
                        {roles.map((rr) => <option key={rr.key} value={rr.key}>{rr.name}</option>)}
                      </select>
                    </td>
                    <td className="p-3">
                      <select
                        value={u.status}
                        onChange={(e) => statusMut.mutate({ user_id: u.id, status: e.target.value as "active" | "inactive" | "suspended" })}
                        className={`text-xs font-medium px-2 py-1 rounded border-0 focus:outline-none ${STATUS_BADGE[u.status]}`}
                      >
                        <option value="active">{STATUS_LABEL.active}</option>
                        <option value="inactive">{STATUS_LABEL.inactive}</option>
                        <option value="suspended">{STATUS_LABEL.suspended}</option>
                      </select>
                    </td>
                    <td className="p-3">
                      <button
                        onClick={() => openBranchesFor(u.id)}
                        className="text-xs px-2 py-1 rounded bg-muted hover:bg-muted/70 inline-flex items-center gap-1"
                      >
                        <Store className="w-3 h-3" />
                        {u.branch_ids.length === 0 ? "كل الفروع" : `${u.branch_ids.length} فرع`}
                      </button>
                    </td>
                    <td className="p-3 text-xs text-muted-foreground" dir="ltr">
                      {u.last_login_at ? new Date(u.last_login_at).toLocaleDateString("en-GB") : "—"}
                    </td>
                    <td className="p-3 flex gap-1 justify-end">
                      <Button size="icon" variant="ghost" title="تغيير كلمة المرور" onClick={() => setOpenPw(u.id)}>
                        <KeyRound className="w-4 h-4" />
                      </Button>
                      <Button
                        size="icon" variant="ghost" disabled={isMe}
                        title={isMe ? "لا يمكن حذف حسابك" : "حذف"}
                        onClick={() => { if (confirm("حذف هذا المستخدم؟")) deleteMut.mutate(u.id); }}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>
      )}

      {/* Create dialog */}
      <Dialog open={openCreate} onOpenChange={setOpenCreate}>
        <DialogContent>
          <DialogHeader><DialogTitle>إضافة مستخدم جديد</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label className="mb-1.5 block">الاسم الكامل</Label>
              <Input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">البريد الإلكتروني</Label>
              <Input type="email" dir="ltr" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">كلمة المرور</Label>
              <Input type="password" dir="ltr" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
              <p className="text-[11px] text-muted-foreground mt-1">8 خانات على الأقل</p></div>
            <div><Label className="mb-1.5 block">رقم الجوال (اختياري)</Label>
              <Input dir="ltr" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الدور</Label>
              <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}
                className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm">
                {roles.map((rr) => <option key={rr.key} value={rr.key}>{rr.name}</option>)}
              </select></div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpenCreate(false)}>إلغاء</Button>
            <Button disabled={createMut.isPending} onClick={() => createMut.mutate()} className="bg-gradient-primary text-primary-foreground">
              {createMut.isPending ? "جارٍ…" : "إنشاء"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset password */}
      <Dialog open={!!openPw} onOpenChange={(o) => !o && setOpenPw(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>تغيير كلمة المرور</DialogTitle></DialogHeader>
          <div>
            <Label className="mb-1.5 block">كلمة المرور الجديدة</Label>
            <Input type="password" dir="ltr" value={newPw} onChange={(e) => setNewPw(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpenPw(null)}>إلغاء</Button>
            <Button disabled={pwMut.isPending || newPw.length < 8} onClick={() => openPw && pwMut.mutate({ user_id: openPw, password: newPw })} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Branches dialog */}
      <Dialog open={!!openBranches} onOpenChange={(o) => !o && setOpenBranches(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>ربط المستخدم بالفروع</DialogTitle></DialogHeader>
          <p className="text-xs text-muted-foreground">إذا لم تختر أي فرع فسيكون له صلاحية على كل الفروع.</p>
          {branches.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4">لا توجد فروع. أضف فروعاً أولاً.</p>
          ) : (
            <div className="space-y-2 max-h-72 overflow-auto">
              {branches.map((b) => {
                const checked = tempBranches.has(b.id);
                return (
                  <label key={b.id} className="flex items-center gap-2 p-2 rounded hover:bg-muted cursor-pointer">
                    <Checkbox checked={checked} onCheckedChange={(v) => {
                      const s = new Set(tempBranches);
                      if (v) s.add(b.id); else s.delete(b.id);
                      setTempBranches(s);
                    }} />
                    <span className="text-sm">{b.name}</span>
                  </label>
                );
              })}
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpenBranches(null)}>إلغاء</Button>
            <Button
              disabled={branchesMut.isPending}
              onClick={() => openBranches && branchesMut.mutate({ user_id: openBranches, branch_ids: Array.from(tempBranches) })}
              className="bg-gradient-primary text-primary-foreground"
            >حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
