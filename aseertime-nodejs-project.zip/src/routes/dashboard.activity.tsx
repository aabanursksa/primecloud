import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import * as XLSX from "xlsx";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from "@/components/ui/sheet";
import { History, Download, Eye } from "lucide-react";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { DateField } from "@/components/DateField";

export const Route = createFileRoute("/dashboard/activity")({ component: ActivityPage });

const ACTION_LABEL: Record<string, string> = {
  create: "إضافة", update: "تعديل", delete: "حذف", import: "استيراد", login: "تسجيل دخول",
  create_product: "إضافة منتج", update_product: "تعديل منتج", delete_product: "حذف منتج",
  create_branch: "إضافة فرع", update_branch: "تعديل فرع", delete_branch: "حذف فرع",
  create_category: "إضافة قسم", update_category: "تعديل قسم", delete_category: "حذف قسم",
  update_settings: "تعديل إعدادات",
  delete_addon_group: "حذف مجموعة إضافات",
  import_excel: "استيراد ملف Excel",
};

const MODULE_LABEL: Record<string, string> = {
  products: "المنتجات", orders: "الطلبات", customers: "العملاء", branches: "الفروع",
  drivers: "السائقين", categories: "الأقسام", settings: "الإعدادات", users: "المستخدمون",
  banners: "البنرات", coupons: "الكوبونات", import: "الاستيراد",
};

type LogRow = {
  id: string;
  action: string;
  entity: string | null;
  entity_id: string | null;
  module: string | null;
  description: string | null;
  user_id: string | null;
  ip_address: string | null;
  user_agent: string | null;
  payload: Record<string, unknown> | null;
  old_values: Record<string, unknown> | null;
  new_values: Record<string, unknown> | null;
  created_at: string;
};

function ActivityPage() {
  const [search, setSearch] = useState("");
  const [moduleFilter, setModuleFilter] = useState("all");
  const [actionFilter, setActionFilter] = useState("all");
  const [userFilter, setUserFilter] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [selected, setSelected] = useState<LogRow | null>(null);

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ["activity-logs"],
    queryFn: async () => {
      const { data, error } = await supabase.from("activity_logs").select("*").order("created_at", { ascending: false }).limit(1000);
      if (error) throw error;
      return (data ?? []) as LogRow[];
    },
  });

  const { data: usersMap = {} } = useQuery({
    queryKey: ["activity-users-map"],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("id, full_name");
      const m: Record<string, string> = {};
      (data ?? []).forEach((u) => { m[u.id] = u.full_name ?? u.id.slice(0, 8); });
      return m;
    },
  });

  const modules = useMemo(() => Array.from(new Set(logs.map((l) => l.module).filter(Boolean))) as string[], [logs]);
  const actions = useMemo(() => Array.from(new Set(logs.map((l) => l.action))), [logs]);
  const users = useMemo(() => {
    const ids = Array.from(new Set(logs.map((l) => l.user_id).filter(Boolean))) as string[];
    return ids.map((id) => ({ id, name: usersMap[id] ?? id.slice(0, 8) }));
  }, [logs, usersMap]);

  const filtered = useMemo(() => {
    return logs.filter((l) => {
      if (moduleFilter !== "all" && l.module !== moduleFilter) return false;
      if (actionFilter !== "all" && l.action !== actionFilter) return false;
      if (userFilter !== "all" && l.user_id !== userFilter) return false;
      if (from && new Date(l.created_at) < new Date(from)) return false;
      if (to && new Date(l.created_at) > new Date(to + "T23:59:59")) return false;
      if (search) {
        const q = search.toLowerCase();
        const hay = `${l.action} ${l.entity ?? ""} ${l.description ?? ""} ${JSON.stringify(l.payload ?? {})}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [logs, search, moduleFilter, actionFilter, userFilter, from, to]);

  const exportExcel = () => {
    const rows = filtered.map((l) => ({
      "التاريخ": new Date(l.created_at).toLocaleString("en-GB"),
      "المستخدم": l.user_id ? usersMap[l.user_id] ?? l.user_id : "النظام",
      "القسم": MODULE_LABEL[l.module ?? ""] ?? l.module ?? "—",
      "الإجراء": ACTION_LABEL[l.action] ?? l.action,
      "الكيان": l.entity ?? "",
      "الوصف": l.description ?? "",
      "IP": l.ip_address ?? "",
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Activity");
    XLSX.writeFile(wb, `activity-${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  return (
    <div>
      <PageHeader
        title="سجل النشاط"
        description="آخر العمليات المنفذة على النظام مع إمكانية الفلترة والتصدير."
        action={
          <Button onClick={exportExcel} disabled={filtered.length === 0} variant="outline" className="gap-1">
            <Download className="w-4 h-4" /> تصدير Excel
          </Button>
        }
      />

      <Card className="p-3 mb-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-6">
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث في الوصف..." className="lg:col-span-2" />
        <select value={moduleFilter} onChange={(e) => setModuleFilter(e.target.value)} className="h-10 rounded-md border border-input bg-background px-3 text-sm">
          <option value="all">كل الأقسام</option>
          {modules.map((m) => <option key={m} value={m}>{MODULE_LABEL[m] ?? m}</option>)}
        </select>
        <select value={actionFilter} onChange={(e) => setActionFilter(e.target.value)} className="h-10 rounded-md border border-input bg-background px-3 text-sm">
          <option value="all">كل الإجراءات</option>
          {actions.map((a) => <option key={a} value={a}>{ACTION_LABEL[a] ?? a}</option>)}
        </select>
        <select value={userFilter} onChange={(e) => setUserFilter(e.target.value)} className="h-10 rounded-md border border-input bg-background px-3 text-sm">
          <option value="all">كل المستخدمين</option>
          {users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
        </select>
        <DateField value={from} onChange={(v) => setFrom(v ?? "")} placeholder="من تاريخ" />
        <DateField value={to} onChange={(v) => setTo(v ?? "")} placeholder="إلى تاريخ" />
      </Card>

      {isLoading ? (
        <Card className="p-12 text-center text-muted-foreground">جارٍ التحميل...</Card>
      ) : filtered.length === 0 ? (
        <EmptyState icon={History} title={logs.length === 0 ? "لا يوجد نشاط بعد" : "لا توجد نتائج"} description={logs.length === 0 ? "ستظهر هنا كل العمليات المهمة." : "جرّب تعديل الفلاتر."} />
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full text-sm min-w-[800px]">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-start p-3">التاريخ</th>
                <th className="text-start p-3">المستخدم</th>
                <th className="text-start p-3">القسم</th>
                <th className="text-start p-3">الإجراء</th>
                <th className="text-start p-3">الكيان</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((l) => (
                <tr key={l.id} className="border-t hover:bg-muted/30">
                  <td className="p-3 text-muted-foreground" dir="ltr">{new Date(l.created_at).toLocaleString("en-GB")}</td>
                  <td className="p-3">{l.user_id ? usersMap[l.user_id] ?? <span className="font-mono text-xs" dir="ltr">{l.user_id.slice(0, 8)}</span> : "النظام"}</td>
                  <td className="p-3 text-muted-foreground">{MODULE_LABEL[l.module ?? ""] ?? l.module ?? "—"}</td>
                  <td className="p-3 font-medium">{ACTION_LABEL[l.action] ?? l.action}</td>
                  <td className="p-3 text-muted-foreground text-xs">{l.entity ?? ""}</td>
                  <td className="p-3">
                    <Button size="icon" variant="ghost" onClick={() => setSelected(l)}>
                      <Eye className="w-4 h-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <SheetContent side="left" className="w-full sm:max-w-lg overflow-y-auto">
          <SheetHeader>
            <SheetTitle>تفاصيل النشاط</SheetTitle>
          </SheetHeader>
          {selected && (
            <div className="mt-4 space-y-4 text-sm">
              <Field label="الإجراء" value={ACTION_LABEL[selected.action] ?? selected.action} />
              <Field label="القسم" value={MODULE_LABEL[selected.module ?? ""] ?? selected.module ?? "—"} />
              <Field label="الكيان" value={`${selected.entity ?? "—"}${selected.entity_id ? ` (${selected.entity_id.slice(0, 8)})` : ""}`} />
              <Field label="المستخدم" value={selected.user_id ? usersMap[selected.user_id] ?? selected.user_id : "النظام"} />
              <Field label="التاريخ" value={new Date(selected.created_at).toLocaleString("en-GB")} ltr />
              {selected.description && <Field label="الوصف" value={selected.description} />}
              {selected.ip_address && <Field label="IP" value={selected.ip_address} ltr />}
              {selected.user_agent && <Field label="المتصفح" value={selected.user_agent} ltr />}
              {selected.old_values && Object.keys(selected.old_values).length > 0 && (
                <JsonBlock label="القيم القديمة" data={selected.old_values} />
              )}
              {selected.new_values && Object.keys(selected.new_values).length > 0 && (
                <JsonBlock label="القيم الجديدة" data={selected.new_values} />
              )}
              {selected.payload && Object.keys(selected.payload).length > 0 && (
                <JsonBlock label="بيانات إضافية" data={selected.payload} />
              )}
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

function Field({ label, value, ltr }: { label: string; value: string; ltr?: boolean }) {
  return (
    <div>
      <div className="text-xs text-muted-foreground mb-1">{label}</div>
      <div className="bg-muted rounded p-2 text-sm break-all" dir={ltr ? "ltr" : undefined}>{value}</div>
    </div>
  );
}

function JsonBlock({ label, data }: { label: string; data: Record<string, unknown> }) {
  return (
    <div>
      <div className="text-xs text-muted-foreground mb-1">{label}</div>
      <pre className="bg-muted rounded p-2 text-xs overflow-auto max-h-48" dir="ltr">{JSON.stringify(data, null, 2)}</pre>
    </div>
  );
}
