import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AccountLayout } from "@/components/store/AccountLayout";
import { useCustomerAuth } from "@/lib/customer-auth";
import { useCart } from "@/lib/cart";
import { Package } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/account/orders/")({ component: AccountOrdersPage });

const STATUS_LABELS: Record<string, string> = {
  new: "جديد", accepted: "مقبول", preparing: "قيد التحضير", ready: "جاهز",
  on_the_way: "مع السائق", delivered: "تم التسليم", cancelled: "ملغي",
};
const ACTIVE = ["new", "accepted", "preparing", "ready", "on_the_way"];
const COMPLETED = ["delivered"];

function AccountOrdersPage() {
  const { customer, isLoggedIn } = useCustomerAuth();
  const { addItem, setBranchId } = useCart();
  const [filter, setFilter] = useState<"all"|"active"|"completed"|"cancelled">("all");

  const { data: orders } = useQuery({
    queryKey: ["account-orders", customer?.phone],
    queryFn: async () => {
      if (!customer) return [];
      const { data } = await supabase.rpc("get_customer_orders", { _phone: customer.phone });
      return (data as any[]) ?? [];
    },
    enabled: isLoggedIn,
  });

  const filtered = useMemo(() => {
    const list = orders ?? [];
    if (filter === "active") return list.filter((o) => ACTIVE.includes(o.status));
    if (filter === "completed") return list.filter((o) => COMPLETED.includes(o.status));
    if (filter === "cancelled") return list.filter((o) => o.status === "cancelled");
    return list;
  }, [orders, filter]);

  const reorder = async (order: any) => {
    let added = 0, skipped = 0;
    let unavail = new Set<string>();
    if (order.branch_id) {
      const { data: pb } = await supabase.from("product_branches")
        .select("product_id").eq("branch_id", order.branch_id).eq("is_available", false);
      unavail = new Set((pb ?? []).map((r: any) => r.product_id));
    }
    for (const it of order.items || []) {
      const { data: prod } = await supabase.from("products").select("*").eq("id", it.product_id).maybeSingle();
      if (!prod || prod.is_archived || !prod.show_in_store || !prod.is_available || unavail.has(prod.id)) { skipped++; continue; }
      const currentPrice = Number(prod.base_price);
      addItem({
        product_id: prod.id, product_name: prod.name_ar, product_image: prod.image_url,
        variant_id: it.variant_id, variant_name: it.variant_name,
        unit_price: it.variant_id ? Number(it.unit_price) : currentPrice,
        quantity: it.quantity, addons: it.addons || [], notes: it.notes,
      });
      added++;
    }
    if (order.branch_id) setBranchId(order.branch_id);
    if (added > 0) toast.success(`تمت إضافة ${added} منتج${skipped ? ` (تم تخطي ${skipped} غير متاح)` : ""}`);
    else toast.error("لا توجد منتجات متاحة لإعادة الطلب");
  };

  if (!isLoggedIn) return <AccountLayout>{null}</AccountLayout>;

  return (
    <AccountLayout>
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <h2 className="text-xl font-bold">طلباتي</h2>
        <div className="flex gap-1 bg-muted p-1 rounded-xl text-xs overflow-x-auto">
          {([
            ["all", "الكل"], ["active", "نشطة"], ["completed", "مكتملة"], ["cancelled", "ملغية"],
          ] as const).map(([k, l]) => (
            <button key={k} onClick={() => setFilter(k)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap ${filter === k ? "bg-card font-bold" : ""}`}>{l}</button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-card border border-border rounded-2xl p-10 text-center">
          <Package className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
          <p className="text-muted-foreground">لا توجد طلبات</p>
          <Link to="/menu" className="inline-block mt-4 bg-primary text-primary-foreground px-6 py-2.5 rounded-xl font-bold text-sm">تصفح المنيو</Link>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((o) => (
            <div key={o.id} className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <div className="font-bold">{o.order_number}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {new Date(o.created_at).toLocaleString("ar-SA")} • {o.branch?.name || "—"} • {o.order_type === "pickup" ? "استلام" : "توصيل"}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] bg-muted px-2 py-1 rounded-full">{STATUS_LABELS[o.status] || o.status}</span>
                  <span className="font-bold text-primary">{Number(o.total_amount).toFixed(2)} ر.س</span>
                </div>
              </div>
              <div className="mt-3 text-sm text-muted-foreground">
                {(o.items || []).slice(0, 3).map((it: any, i: number) => (
                  <div key={i}>• {it.product_name}{it.variant_name ? ` (${it.variant_name})` : ""} × {it.quantity}</div>
                ))}
                {(o.items?.length ?? 0) > 3 && <div className="text-xs">+ {o.items.length - 3} منتج</div>}
              </div>
              <div className="mt-3 flex gap-2 flex-wrap">
                <Link to="/account/orders/$orderNumber" params={{ orderNumber: o.order_number }}
                  className="bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-bold">عرض التفاصيل</Link>
                <button onClick={() => reorder(o)} className="bg-muted px-4 py-2 rounded-lg text-sm font-bold">إعادة الطلب</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </AccountLayout>
  );
}
