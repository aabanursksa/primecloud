import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { AuthProvider } from "@/lib/auth";
import { CartProvider } from "@/lib/cart";
import { CustomerAuthProvider } from "@/lib/customer-auth";
import { CartUIProvider } from "@/components/store/CartDrawer";
import { QuickViewProvider } from "@/components/store/QuickView";
import { Toaster } from "sonner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold">الصفحة غير موجودة</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          الصفحة التي تبحث عنها غير موجودة أو تم نقلها.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            العودة للرئيسية
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">حدث خطأ غير متوقع</h1>
        <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
        <div className="mt-6 flex justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            إعادة المحاولة
          </button>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "عصير تايم | عصائر طازجة وحلويات وميلك شيك" },
      { name: "description", content: "عصير تايم يقدم عصائر طازجة، ميلك شيك، آيس كريم وحلويات لذيذة بجودة عالية وتجربة طلب سهلة وسريعة." },
      { property: "og:title", content: "عصير تايم | عصائر طازجة وحلويات وميلك شيك" },
      { name: "twitter:title", content: "عصير تايم | عصائر طازجة وحلويات وميلك شيك" },
      { property: "og:description", content: "عصير تايم يقدم عصائر طازجة، ميلك شيك، آيس كريم وحلويات لذيذة بجودة عالية وتجربة طلب سهلة وسريعة." },
      { name: "twitter:description", content: "عصير تايم يقدم عصائر طازجة، ميلك شيك، آيس كريم وحلويات لذيذة بجودة عالية وتجربة طلب سهلة وسريعة." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/k2pMo3qWp1hc8u8gxj0ifxf9EBQ2/social-images/social-1778320973546-عصير_تام.webp" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/k2pMo3qWp1hc8u8gxj0ifxf9EBQ2/social-images/social-1778320973546-عصير_تام.webp" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CustomerAuthProvider>
          <CartProvider>
            <CartUIProvider>
              <QuickViewProvider>
                <Outlet />
                <Toaster position="top-center" richColors closeButton dir="rtl" />
              </QuickViewProvider>
            </CartUIProvider>
          </CartProvider>
        </CustomerAuthProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}
