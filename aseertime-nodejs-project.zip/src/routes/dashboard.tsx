import { createFileRoute, Link, Outlet, useLocation, useNavigate, redirect } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Package,
  Layers,
  PlusCircle,
  Store,
  Upload,
  Settings,
  History,
  LogOut,
  Menu,
  X,
  Bell,
  Search,
  ShoppingBag,
  Users,
  Bike,
  MapPin,
  Tag,
  BarChart3,
  UserCog,
  ShieldCheck,
  Image as ImageIcon,
  Sparkles,
  PanelTop,
  PanelBottom,
  FileText,
  HelpCircle,
  Plug,
  Smartphone,
  Globe,
} from "lucide-react";
import { useAuth } from "@/lib/auth";
import { usePermissions } from "@/lib/permissions";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import logo from "@/assets/aseertime_logo.svg";

export const Route = createFileRoute("/dashboard")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
  },
  component: DashboardLayout,
});

type NavItem = {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
  exact?: boolean;
  permission?: string;
};
const nav: NavItem[] = [
  { to: "/dashboard", label: "الرئيسية", icon: LayoutDashboard, exact: true, permission: "dashboard.view" },
  { to: "/dashboard/orders", label: "الطلبات", icon: ShoppingBag, permission: "orders.view" },
  { to: "/dashboard/customers", label: "العملاء", icon: Users, permission: "customers.view" },
  { to: "/dashboard/drivers", label: "السائقين", icon: Bike, permission: "drivers.view" },
  { to: "/dashboard/zones", label: "مناطق التوصيل", icon: MapPin, permission: "branches.view" },
  { to: "/dashboard/coupons", label: "الكوبونات", icon: Tag, permission: "coupons.view" },
  { to: "/dashboard/products", label: "المنتجات", icon: Package, permission: "products.view" },
  { to: "/dashboard/categories", label: "الأقسام", icon: Layers, permission: "categories.view" },
  { to: "/dashboard/addons", label: "الإضافات", icon: PlusCircle, permission: "addons.view" },
  { to: "/dashboard/branches", label: "الفروع", icon: Store, permission: "branches.view" },
  { to: "/dashboard/reports", label: "التقارير", icon: BarChart3, permission: "reports.view" },
  { to: "/dashboard/banners", label: "البنرات", icon: ImageIcon, permission: "banners.view" },
  { to: "/dashboard/hero", label: "الهيرو", icon: Sparkles, permission: "banners.view" },
  { to: "/dashboard/header", label: "الهيدر", icon: PanelTop, permission: "content.header" },
  { to: "/dashboard/footer", label: "الفوتر", icon: PanelBottom, permission: "content.footer" },
  { to: "/dashboard/menus", label: "القوائم", icon: Menu, permission: "content.menus" },
  { to: "/dashboard/pages", label: "الصفحات", icon: FileText, permission: "content.pages" },
  { to: "/dashboard/legal-pages", label: "الصفحات القانونية", icon: ShieldCheck, permission: "content.pages" },
  { to: "/dashboard/home-builder", label: "الصفحة الرئيسية للتطبيق", icon: Layers, permission: "content.pages" },
  { to: "/dashboard/page-builder", label: "Page Builder", icon: Layers, permission: "content.pages" },
  { to: "/dashboard/faqs", label: "الأسئلة الشائعة", icon: HelpCircle, permission: "content.faq" },
  { to: "/dashboard/seo", label: "SEO", icon: Search, permission: "seo.view" },
  { to: "/dashboard/integrations", label: "التكاملات", icon: Plug, permission: "integrations.view" },
  { to: "/dashboard/app-settings", label: "إعدادات التطبيق", icon: Smartphone, permission: "settings.app" },
  { to: "/dashboard/domain-health", label: "حالة الدومين", icon: Globe },
  { to: "/dashboard/import", label: "استيراد المنيو", icon: Upload, permission: "products.import" },
  { to: "/dashboard/users", label: "المستخدمون", icon: UserCog, permission: "users.view" },
  { to: "/dashboard/permissions", label: "الأدوار والصلاحيات", icon: ShieldCheck, permission: "users.permissions" },
  { to: "/dashboard/security", label: "الأمان", icon: ShieldCheck },
  { to: "/dashboard/notifications", label: "الإشعارات", icon: Bell },
  { to: "/dashboard/settings", label: "إعدادات المتجر", icon: Settings, permission: "settings.view" },
  { to: "/dashboard/activity", label: "سجل النشاط", icon: History, permission: "activity.view" },
];

function DashboardLayout() {
  const { user, role, signOut, loading } = useAuth();
  const perms = usePermissions();
  const navigate = useNavigate();
  const location = useLocation();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  const isActive = (to: string, exact?: boolean) =>
    exact ? location.pathname === to : location.pathname === to || location.pathname.startsWith(to + "/");

  // Route-level permission gate (redirect to forbidden if missing)
  useEffect(() => {
    if (perms.isLoading) return;
    const match = nav.find((i) => i.permission && (i.exact ? location.pathname === i.to : location.pathname === i.to || location.pathname.startsWith(i.to + "/")));
    if (match?.permission && !perms.has(match.permission) && location.pathname !== "/dashboard/forbidden") {
      navigate({ to: "/dashboard/forbidden" });
    }
  }, [location.pathname, perms.isLoading, perms, navigate]);

  return (
    <div className="min-h-screen bg-muted/30 flex">
      {/* Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 right-0 z-40 w-64 bg-sidebar border-l border-sidebar-border flex flex-col transition-transform ${
          open ? "translate-x-0" : "translate-x-full lg:translate-x-0"
        }`}
      >
        <div className="h-16 flex items-center justify-between px-4 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <img src={logo} alt="" className="w-9 h-9" />
            <div>
              <div className="text-sm font-bold leading-tight">عصير تايم</div>
              <div className="text-[10px] text-muted-foreground">لوحة التحكم</div>
            </div>
          </div>
          <button onClick={() => setOpen(false)} className="lg:hidden p-2">
            <X className="w-5 h-5" />
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {nav.filter((i) => !i.permission || perms.has(i.permission)).map((item) => {
            const Icon = item.icon;
            const active = isActive(item.to, item.exact);
            return (
              <Link
                key={item.to}
                to={item.to as "/dashboard"}
                onClick={() => setOpen(false)}
                className={`flex items-center gap-3 px-3 py-3 rounded-lg text-sm font-medium transition min-h-[44px] ${
                  active
                    ? "bg-gradient-primary text-primary-foreground shadow-glow"
                    : "text-sidebar-foreground hover:bg-sidebar-accent"
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-sidebar-border">
          <div className="flex items-center gap-2 mb-2 px-2">
            <div className="w-9 h-9 rounded-full bg-gradient-primary flex items-center justify-center text-primary-foreground font-bold">
              {(user?.email ?? "U").charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-medium truncate">{user?.email}</div>
              <div className="text-[10px] text-muted-foreground">
                {role === "admin" ? "مدير النظام" : role === "manager" ? "مدير" : "موظف"}
              </div>
            </div>
          </div>
          <Button onClick={signOut} variant="ghost" size="sm" className="w-full justify-start gap-2 text-muted-foreground">
            <LogOut className="w-4 h-4" />
            تسجيل الخروج
          </Button>
        </div>
      </aside>

      {open && <div className="fixed inset-0 bg-black/40 z-30 lg:hidden" onClick={() => setOpen(false)} />}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-14 sm:h-16 bg-card border-b border-border flex items-center px-3 sm:px-4 lg:px-6 gap-2 sm:gap-3 sticky top-0 z-20">
          <button onClick={() => setOpen(true)} aria-label="القائمة" className="lg:hidden p-2.5 -mr-1 rounded-lg hover:bg-muted">
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex-1 max-w-xl relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="search"
              placeholder="ابحث هنا..."
              className="w-full bg-muted rounded-lg pe-10 ps-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring h-10"
            />
          </div>
          <NotificationsBell />
        </header>

        <main className="flex-1 p-3 sm:p-4 lg:p-6 min-w-0 overflow-x-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

function NotificationsBell() {
  const [open, setOpen] = useState(false);
  const { data = [] } = useQuery({
    queryKey: ["notifications-bell"],
    queryFn: async () => (await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(15)).data ?? [],
    refetchInterval: 30000,
  });
  const unread = data.filter((n) => !n.is_read).length;

  const markAll = async () => {
    await supabase.from("notifications").update({ is_read: true }).eq("is_read", false);
  };

  return (
    <div className="relative">
      <button onClick={() => setOpen((o) => !o)} className="relative p-2 rounded-lg hover:bg-muted">
        <Bell className="w-5 h-5" />
        {unread > 0 && <span className="absolute top-1 left-1 bg-primary text-primary-foreground text-[10px] rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">{unread}</span>}
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute end-0 mt-2 w-80 bg-card border border-border rounded-xl shadow-lg z-50 overflow-hidden">
            <div className="flex items-center justify-between p-3 border-b border-border">
              <span className="font-semibold text-sm">الإشعارات</span>
              {unread > 0 && <button onClick={markAll} className="text-xs text-primary">تعليم الكل كمقروء</button>}
            </div>
            <div className="max-h-96 overflow-y-auto">
              {data.length === 0 ? (
                <div className="p-6 text-center text-sm text-muted-foreground">لا توجد إشعارات</div>
              ) : data.map((n) => (
                <Link key={n.id} to={(n.action_url as "/dashboard") ?? "/dashboard"} onClick={() => setOpen(false)} className={`block p-3 border-b border-border last:border-0 hover:bg-muted ${!n.is_read ? "bg-primary/5" : ""}`}>
                  <div className="text-sm font-medium">{n.title}</div>
                  {n.message && <div className="text-xs text-muted-foreground mt-1">{n.message}</div>}
                  <div className="text-[10px] text-muted-foreground mt-1">{new Date(n.created_at).toLocaleString("en-GB")}</div>
                </Link>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
