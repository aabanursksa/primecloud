import { createFileRoute } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/api/public/sitemap")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const origin = new URL(request.url).origin;
        const [pages, products, cats] = await Promise.all([
          supabase.from("pages").select("slug, updated_at").eq("status", "published"),
          supabase.from("products").select("id, updated_at").eq("show_in_store", true).eq("is_archived", false),
          supabase.from("product_categories").select("id, updated_at").eq("is_active", true).eq("show_in_store", true),
        ]);
        const urls: string[] = [
          `${origin}/`,
          `${origin}/menu`,
          `${origin}/branches`,
          `${origin}/offers`,
          `${origin}/track-order`,
        ];
        const items: { loc: string; lastmod?: string }[] = urls.map((u) => ({ loc: u }));
        (pages.data || []).forEach((p: any) => items.push({ loc: `${origin}/pages/${p.slug}`, lastmod: p.updated_at }));
        (cats.data || []).forEach((c: any) => items.push({ loc: `${origin}/menu/${c.id}`, lastmod: c.updated_at }));
        (products.data || []).forEach((p: any) => items.push({ loc: `${origin}/product/${p.id}`, lastmod: p.updated_at }));

        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${items.map((i) => `<url><loc>${i.loc}</loc>${i.lastmod ? `<lastmod>${new Date(i.lastmod).toISOString()}</lastmod>` : ""}</url>`).join("\n")}
</urlset>`;
        return new Response(xml, { headers: { "content-type": "application/xml; charset=utf-8" } });
      },
    },
  },
});
