import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/robots")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const origin = new URL(request.url).origin;
        const body = `User-agent: *\nAllow: /\nDisallow: /dashboard\nDisallow: /api\nSitemap: ${origin}/api/public/sitemap\n`;
        return new Response(body, { headers: { "content-type": "text/plain; charset=utf-8" } });
      },
    },
  },
});
