import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Save, ExternalLink, Scale, Shield, RotateCcw, Truck, Cookie } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { PageHeader } from "@/components/EmptyState";

export const Route = createFileRoute("/dashboard/legal-pages")({ component: LegalPagesAdmin });

const LEGAL = [
  { slug: "terms", title: "الشروط والأحكام", icon: Scale },
  { slug: "privacy", title: "سياسة الخصوصية", icon: Shield },
  { slug: "refund", title: "سياسة الاسترجاع والاستبدال", icon: RotateCcw },
  { slug: "shipping", title: "سياسة التوصيل", icon: Truck },
  { slug: "cookies", title: "سياسة ملفات تعريف الارتباط", icon: Cookie },
];

function LegalPagesAdmin() {
  const [active, setActive] = useState(LEGAL[0].slug);
  return (
    <>
      <PageHeader
        title="الصفحات القانونية"
        description="إدارة محتوى وSEO الصفحات القانونية الخمس مع روابط مباشرة"
      />

      <div className="grid lg:grid-cols-[280px_1fr] gap-6">
        <Card className="p-3 h-fit">
          <div className="space-y-1">
            {LEGAL.map((p) => {
              const Icon = p.icon;
              const isActive = active === p.slug;
              return (
                <div key={p.slug} className="flex items-center gap-1">
                  <button
                    onClick={() => setActive(p.slug)}
                    className={`flex-1 flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition ${
                      isActive ? "bg-primary text-primary-foreground" : "hover:bg-muted"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="truncate">{p.title}</span>
                  </button>
                  <Link
                    to="/pages/$slug"
                    params={{ slug: p.slug }}
                    target="_blank"
                    className="p-2 rounded-lg hover:bg-muted text-muted-foreground"
                    title="فتح الصفحة"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Link>
                </div>
              );
            })}
          </div>
        </Card>

        <LegalEditor slug={active} key={active} />
      </div>
    </>
  );
}

function LegalEditor({ slug }: { slug: string }) {
  const qc = useQueryClient();
  const meta = LEGAL.find((p) => p.slug === slug)!;

  const { data, isLoading } = useQuery({
    queryKey: ["legal-page", slug],
    queryFn: async () => {
      const page = (await supabase.from("pages").select("*").eq("slug", slug).maybeSingle()).data;
      const seo = page
        ? (await supabase.from("seo_settings").select("*").eq("entity_type", "page").eq("entity_id", page.id).maybeSingle()).data
        : null;
      return { page, seo };
    },
  });

  const [page, setPage] = useState<any>(null);
  const [seo, setSeo] = useState<any>(null);

  useEffect(() => {
    if (!data) return;
    setPage(
      data.page ?? {
        slug,
        title: meta.title,
        content: "",
        status: "published",
        show_in_footer: true,
        sort_order: 0,
      },
    );
    setSeo(
      data.seo ?? {
        entity_type: "page",
        entity_id: data.page?.id,
        meta_title: meta.title,
        meta_description: "",
        canonical_url: "",
        og_title: "",
        og_description: "",
        og_image: "",
        robots_index: true,
        robots_follow: true,
        sitemap_enabled: true,
      },
    );
  }, [data, slug, meta.title]);

  const save = async () => {
    if (!page) return;
    let pageId = page.id as string | undefined;
    const pagePayload = { ...page };
    delete pagePayload.id;
    delete pagePayload.created_at;
    delete pagePayload.updated_at;

    if (pageId) {
      const r = await supabase.from("pages").update(pagePayload).eq("id", pageId);
      if (r.error) return toast.error(r.error.message);
    } else {
      const r = await supabase.from("pages").insert(pagePayload).select("id").maybeSingle();
      if (r.error) return toast.error(r.error.message);
      pageId = r.data?.id;
    }

    if (seo && pageId) {
      const seoPayload = { ...seo, entity_type: "page", entity_id: pageId };
      delete seoPayload.id;
      delete seoPayload.created_at;
      delete seoPayload.updated_at;
      const r = seo.id
        ? await supabase.from("seo_settings").update(seoPayload).eq("id", seo.id)
        : await supabase.from("seo_settings").insert(seoPayload);
      if (r.error) return toast.error(r.error.message);
    }

    // Sync footer menu item visibility based on show_in_footer
    const footerMenu = (await supabase
      .from("navigation_menus")
      .select("id")
      .eq("location", "footer")
      .maybeSingle()).data;
    if (footerMenu?.id) {
      const existing = (await supabase
        .from("navigation_menu_items")
        .select("id")
        .eq("menu_id", footerMenu.id)
        .eq("link_type", "page")
        .eq("link_value", slug)
        .maybeSingle()).data;
      const desiredStatus = page.show_in_footer ? "published" : "draft";
      if (existing?.id) {
        await supabase.from("navigation_menu_items").update({ status: desiredStatus }).eq("id", existing.id);
      } else if (page.show_in_footer) {
        await supabase.from("navigation_menu_items").insert({
          menu_id: footerMenu.id,
          title: page.title || meta.title,
          link_type: "page",
          link_value: slug,
          status: "published",
          sort_order: 99,
        });
      }
    }

    toast.success("تم الحفظ");
    qc.invalidateQueries({ queryKey: ["legal-page", slug] });
    qc.invalidateQueries({ queryKey: ["store-header"] });
  };

  if (isLoading || !page || !seo) return <Skeleton className="h-96" />;
  const setP = (k: string, v: any) => setPage({ ...page, [k]: v });
  const setS = (k: string, v: any) => setSeo({ ...seo, [k]: v });

  return (
    <Card className="p-6 space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h2 className="text-xl font-bold">{meta.title}</h2>
          <Link
            to="/pages/$slug"
            params={{ slug }}
            target="_blank"
            className="text-xs text-primary inline-flex items-center gap-1 mt-1"
          >
            <ExternalLink className="w-3 h-3" /> /pages/{slug}
          </Link>
        </div>
        <Button onClick={save} className="gap-2"><Save className="w-4 h-4" /> حفظ</Button>
      </div>

      <Tabs defaultValue="content">
        <TabsList>
          <TabsTrigger value="content">المحتوى</TabsTrigger>
          <TabsTrigger value="seo">SEO</TabsTrigger>
        </TabsList>

        <TabsContent value="content" className="space-y-4 pt-4">
          <div>
            <Label>عنوان الصفحة</Label>
            <Input value={page.title ?? ""} onChange={(e) => setP("title", e.target.value)} />
          </div>
          <div>
            <Label>المحتوى</Label>
            <Textarea
              value={page.content ?? ""}
              onChange={(e) => setP("content", e.target.value)}
              className="min-h-[400px] font-mono text-sm"
            />
          </div>
          <div className="flex items-center gap-6">
            <label className="flex items-center gap-2 text-sm">
              <Switch
                checked={page.status === "published"}
                onCheckedChange={(v) => setP("status", v ? "published" : "draft")}
              />
              منشورة
            </label>
            <label className="flex items-center gap-2 text-sm">
              <Switch
                checked={!!page.show_in_footer}
                onCheckedChange={(v) => setP("show_in_footer", v)}
              />
              عرض في الفوتر
            </label>
          </div>
        </TabsContent>

        <TabsContent value="seo" className="space-y-4 pt-4">
          <div>
            <Label>Meta Title</Label>
            <Input maxLength={60} value={seo.meta_title ?? ""} onChange={(e) => setS("meta_title", e.target.value)} />
            <p className="text-xs text-muted-foreground mt-1">{(seo.meta_title ?? "").length}/60</p>
          </div>
          <div>
            <Label>Meta Description</Label>
            <Textarea
              maxLength={160}
              value={seo.meta_description ?? ""}
              onChange={(e) => setS("meta_description", e.target.value)}
            />
            <p className="text-xs text-muted-foreground mt-1">{(seo.meta_description ?? "").length}/160</p>
          </div>
          <div>
            <Label>Canonical URL</Label>
            <Input
              value={seo.canonical_url ?? ""}
              onChange={(e) => setS("canonical_url", e.target.value)}
              placeholder={`https://yoursite.com/pages/${slug}`}
            />
          </div>
          <div>
            <Label>OG Title</Label>
            <Input value={seo.og_title ?? ""} onChange={(e) => setS("og_title", e.target.value)} />
          </div>
          <div>
            <Label>OG Description</Label>
            <Textarea value={seo.og_description ?? ""} onChange={(e) => setS("og_description", e.target.value)} />
          </div>
          <div>
            <Label>OG Image URL</Label>
            <Input value={seo.og_image ?? ""} onChange={(e) => setS("og_image", e.target.value)} />
          </div>
          <div className="flex items-center gap-6 flex-wrap">
            <label className="flex items-center gap-2 text-sm">
              <Switch checked={!!seo.robots_index} onCheckedChange={(v) => setS("robots_index", v)} />
              فهرسة (index)
            </label>
            <label className="flex items-center gap-2 text-sm">
              <Switch checked={!!seo.robots_follow} onCheckedChange={(v) => setS("robots_follow", v)} />
              متابعة الروابط (follow)
            </label>
            <label className="flex items-center gap-2 text-sm">
              <Switch checked={!!seo.sitemap_enabled} onCheckedChange={(v) => setS("sitemap_enabled", v)} />
              تضمين في sitemap
            </label>
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
}
