import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/dashboard/forbidden")({ component: Forbidden });

function Forbidden() {
  return (
    <div className="min-h-[60vh] flex items-center justify-center">
      <div className="text-center max-w-md">
        <div className="mx-auto w-16 h-16 rounded-full bg-destructive/10 text-destructive flex items-center justify-center mb-4">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-bold mb-2">ليس لديك صلاحية للوصول</h1>
        <p className="text-muted-foreground mb-6">تواصل مع المسؤول لطلب صلاحية الدخول لهذه الصفحة.</p>
        <Link to="/dashboard"><Button>العودة للرئيسية</Button></Link>
      </div>
    </div>
  );
}
