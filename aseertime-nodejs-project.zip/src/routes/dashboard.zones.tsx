import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { MapPin, Plus, Pencil, Trash2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";

export const Route = createFileRoute("/dashboard/zones")({ component: ZonesPage });

type Z = { id?: string; name: string; branch_id: string | null; delivery_fee: number; minimum_order: number; estimated_time_minutes: number; status: "active"|"inactive"; sort_order: number; notes: string };
const empty: Z = { name: "", branch_id: null, delivery_fee: 0, minimum_order: 0, estimated_time_minutes: 30, status: "active", sort_order: 0, notes: "" };

function ZonesPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Z>(empty);

  const { data: zones = [], isLoading } = useQuery({
    queryKey: ["zones"],
    queryFn: async () => (await supabase.from("delivery_zones").select("*, branch:branches(name)").order("sort_order")).data ?? [],
  });
  const { data: branches = [] } = useQuery({
    queryKey: ["branches-list"],
    queryFn: async () => (await supabase.from("branches").select("id,name").order("display_order")).data ?? [],
  });

  const save = async () => {
    if (!form.name) return toast.error("اسم المنطقة مطلوب");
    try {
      const payload = { ...form, notes: form.notes || null };
      if (form.id) {
        const { error } = await supabase.from("delivery_zones").update(payload).eq("id", form.id);
        if (error) throw error;
        await logActivity("update_zone", "delivery_zones", form.id);
      } else {
        const { id: _i, ...ins } = payload; void _i;
        const { data, error } = await supabase.from("delivery_zones").insert(ins).select().single();
        if (error) throw error;
        await logActivity("create_zone", "delivery_zones", data.id);
      }
      toast.success("تم الحفظ");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["zones"] });
    } catch (e) { toast.error(e instanceof Error ? e.message : "فشل"); }
  };

  const remove = async (z: typeof zones[number]) => {
    if (!confirm(`حذف "${z.name}"؟`)) return;
    const { error } = await supabase.from("delivery_zones").delete().eq("id", z.id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["zones"] });
  };

  return (
    <div>
      <PageHeader title="مناطق التوصيل" description="حدد المناطق ورسوم التوصيل لكل فرع." action={
        <Button onClick={() => { setForm(empty); setOpen(true); }} className="bg-gradient-primary text-primary-foreground gap-2 shadow-glow"><Plus className="w-4 h-4" />إضافة منطقة</Button>
      } />

      {isLoading ? <div className="text-muted-foreground">جارٍ التحميل...</div> :
       zones.length === 0 ? (
        <EmptyState icon={MapPin} title="لا توجد مناطق توصيل" description="أضف المناطق التي يصلها كل فرع مع تحديد الرسوم والحد الأدنى." actionLabel="إضافة منطقة" onAction={() => { setForm(empty); setOpen(true); }} />
      ) : (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50"><tr>
              <th className="text-start p-3">المنطقة</th><th className="text-start p-3">الفرع</th><th className="text-start p-3">رسوم التوصيل</th><th className="text-start p-3">الحد الأدنى</th><th className="text-start p-3">الوقت المتوقع</th><th className="text-start p-3">الحالة</th><th></th>
            </tr></thead>
            <tbody>{zones.map((z) => {
              const branch = (z as { branch?: { name?: string } | null }).branch;
              return (
                <tr key={z.id} className="border-t hover:bg-muted/30">
                  <td className="p-3 font-medium">{z.name}</td>
                  <td className="p-3 text-muted-foreground">{branch?.name ?? "—"}</td>
                  <td className="p-3">{Number(z.delivery_fee).toFixed(2)} ر.س</td>
                  <td className="p-3">{Number(z.minimum_order).toFixed(2)} ر.س</td>
                  <td className="p-3">{z.estimated_time_minutes} دقيقة</td>
                  <td className="p-3">{z.status === "active" ? <span className="text-xs bg-success/10 text-success px-2 py-1 rounded">نشطة</span> : <span className="text-xs bg-muted px-2 py-1 rounded">معطّلة</span>}</td>
                  <td className="p-3 flex gap-1 justify-end">
                    <Button size="icon" variant="ghost" onClick={() => { setForm({ id: z.id, name: z.name, branch_id: z.branch_id, delivery_fee: Number(z.delivery_fee), minimum_order: Number(z.minimum_order), estimated_time_minutes: z.estimated_time_minutes ?? 30, status: z.status, sort_order: z.sort_order, notes: z.notes ?? "" }); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(z)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </td>
                </tr>);
            })}
            </tbody>
          </table>
        </Card>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent dir="rtl">
          <DialogHeader><DialogTitle>{form.id ? "تعديل منطقة" : "إضافة منطقة"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2"><Label className="mb-1.5 block">اسم المنطقة</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="col-span-2"><Label className="mb-1.5 block">الفرع</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.branch_id ?? ""} onChange={(e) => setForm({ ...form, branch_id: e.target.value || null })}>
                <option value="">— كل الفروع —</option>
                {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div><Label className="mb-1.5 block">رسوم التوصيل</Label><Input type="number" step="0.01" value={form.delivery_fee} onChange={(e) => setForm({ ...form, delivery_fee: parseFloat(e.target.value) || 0 })} /></div>
            <div><Label className="mb-1.5 block">الحد الأدنى للطلب</Label><Input type="number" step="0.01" value={form.minimum_order} onChange={(e) => setForm({ ...form, minimum_order: parseFloat(e.target.value) || 0 })} /></div>
            <div><Label className="mb-1.5 block">الوقت المتوقع (دقيقة)</Label><Input type="number" value={form.estimated_time_minutes} onChange={(e) => setForm({ ...form, estimated_time_minutes: parseInt(e.target.value) || 0 })} /></div>
            <div><Label className="mb-1.5 block">ترتيب الظهور</Label><Input type="number" value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: parseInt(e.target.value) || 0 })} /></div>
            <div><Label className="mb-1.5 block">الحالة</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Z["status"] })}>
                <option value="active">نشطة</option>
                <option value="inactive">معطّلة</option>
              </select>
            </div>
            <div className="col-span-2"><Label className="mb-1.5 block">ملاحظات</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-4"><Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button><Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button></div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
