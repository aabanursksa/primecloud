import { createFileRoute, useParams, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AccountLayout } from "@/components/store/AccountLayout";
import { useCustomerAuth } from "@/lib/customer-auth";
import { useCart } from "@/lib/cart";
import { CheckCircle2, Circle, ArrowRight, MapPin, Phone, Truck, Store as StoreIcon } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/account/orders/$orderNumber")({ component: OrderDetailPage });

const STATUS_LABELS: Record<string, string> = {
  new: "تم استلام الطلب", accepted: "مقبول", preparing: "قيد التحضير",
  ready: "جاهز", on_the_way: "مع السائق", delivered: "تم التسليم", cancelled: "ملغي",
};
const TIMELINE = ["new", "accepted", "preparing", "ready", "on_the_way", "delivered"];

function OrderDetailPage() {
  const { orderNumber } = useParams({ from: "/account/orders/$orderNumber" });
  const { customer, isLoggedIn } = useCustomerAuth();
  const { addItem, setBranchId } = useCart();

  const { data: order, isLoading } = useQuery({
    queryKey: ["account-order", orderNumber, customer?.phone],
    queryFn: async () => {
      if (!customer) return null;
      const { data, error } = await supabase.rpc("get_customer_order", {
        _order_number: orderNumber, _phone: customer.phone,
      });
      if (error) throw error;
      return data as any;
    },
    enabled: isLoggedIn,
  });

  const reorder = async () => {
    if (!order) return;
    let added = 0, skipped = 0, priceChanged = 0;
    let unavail = new Set<string>();
    if (order.branch_id) {
      const { data: pb } = await supabase.from("product_branches")
        .select("product_id").eq("branch_id", order.branch_id).eq("is_available", false);
      unavail = new Set((pb ?? []).map((r: any) => r.product_id));
    }
    for (const it of order.items || []) {
      const { data: prod } = await supabase.from("products").select("*").eq("id", it.product_id).maybeSingle();
      if (!prod || prod.is_archived || !prod.show_in_store || !prod.is_available || unavail.has(prod.id)) { skipped++; continue; }
      // Use current variant price if available, else current product base_price
      let currentUnit = Number(prod.base_price);
      if (it.variant_id) {
        const { data: v } = await supabase.from("product_variants").select("price,is_available").eq("id", it.variant_id).maybeSingle();
        if (!v || !v.is_available) { skipped++; continue; }
        currentUnit = Number(v.price);
      }
      if (currentUnit !== Number(it.unit_price)) priceChanged++;
      addItem({
        product_id: prod.id, product_name: prod.name_ar, product_image: prod.image_url,
        variant_id: it.variant_id, variant_name: it.variant_name,
        unit_price: currentUnit, quantity: it.quantity, addons: it.addons || [], notes: it.notes,
      });
      added++;
    }
    if (order.branch_id) setBranchId(order.branch_id);
    if (added > 0) {
      let msg = `تمت إضافة ${added}`;
      if (skipped) msg += ` (تم تخطي ${skipped} غير متوفر)`;
      if (priceChanged) msg += ` — تنبيه: تغيّرت أسعار ${priceChanged} منتج`;
      toast.success(msg);
    } else toast.error("لا توجد منتجات متاحة");
  };

  if (!isLoggedIn) return <AccountLayout>{null}</AccountLayout>;

  if (isLoading) return <AccountLayout><div className="text-muted-foreground">جارٍ التحميل...</div></AccountLayout>;

  if (!order) {
    return (
      <AccountLayout>
        <div className="bg-card border border-border rounded-2xl p-10 text-center">
          <p className="font-bold text-lg">الطلب غير موجود</p>
          <p className="text-sm text-muted-foreground mt-2">لا تملك صلاحية عرض هذا الطلب أو رقم الطلب غير صحيح.</p>
          <Link to="/account/orders" className="inline-block mt-4 bg-primary text-primary-foreground px-6 py-2.5 rounded-xl font-bold text-sm">العودة لطلباتي</Link>
        </div>
      </AccountLayout>
    );
  }

  const cancelled = order.status === "cancelled";
  const currentIdx = TIMELINE.indexOf(order.status);

  return (
    <AccountLayout>
      <Link to="/account/orders" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary mb-4">
        <ArrowRight className="w-4 h-4" />العودة للطلبات
      </Link>

      <div className="bg-card border border-border rounded-2xl p-5 mb-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <div className="text-xs text-muted-foreground">رقم الطلب</div>
            <div className="text-2xl font-bold">{order.order_number}</div>
            <div className="text-xs text-muted-foreground mt-1">{new Date(order.created_at).toLocaleString("ar-SA")}</div>
          </div>
          <div className="text-right">
            <span className={`text-xs px-3 py-1.5 rounded-full font-bold ${cancelled ? "bg-destructive/10 text-destructive" : "bg-primary/10 text-primary"}`}>
              {STATUS_LABELS[order.status] || order.status}
            </span>
            <div className="text-2xl font-bold text-primary mt-2">{Number(order.total_amount).toFixed(2)} ر.س</div>
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="bg-card border border-border rounded-2xl p-5 mb-4">
        <h3 className="font-bold mb-4">حالة الطلب</h3>
        <div className="space-y-3">
          {TIMELINE.map((s, i) => {
            const done = !cancelled && i <= currentIdx;
            return (
              <div key={s} className="flex items-center gap-3">
                {done ? <CheckCircle2 className="w-5 h-5 text-success" /> : <Circle className="w-5 h-5 text-muted-foreground" />}
                <span className={done ? "font-bold" : "text-muted-foreground"}>{STATUS_LABELS[s]}</span>
              </div>
            );
          })}
          {cancelled && <div className="text-destructive font-bold">تم إلغاء الطلب</div>}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4 mb-4">
        {order.branch && (
          <div className="bg-card border border-border rounded-2xl p-5">
            <h3 className="font-bold mb-2 flex items-center gap-1"><MapPin className="w-4 h-4" />الفرع</h3>
            <div className="text-sm">{order.branch.name}</div>
            {order.branch.address && <div className="text-xs text-muted-foreground mt-1">{order.branch.address}</div>}
            {order.branch.phone && (
              <a href={`tel:${order.branch.phone}`} className="inline-flex items-center gap-1 mt-2 text-primary text-sm">
                <Phone className="w-3.5 h-3.5" />{order.branch.phone}
              </a>
            )}
          </div>
        )}

        <div className="bg-card border border-border rounded-2xl p-5">
          <h3 className="font-bold mb-2 flex items-center gap-1">
            {order.order_type === "pickup" ? <StoreIcon className="w-4 h-4" /> : <Truck className="w-4 h-4" />}
            {order.order_type === "pickup" ? "استلام من الفرع" : "توصيل"}
          </h3>
          {order.address ? (
            <div className="text-sm text-muted-foreground">
              {[order.address.city, order.address.district, order.address.street, order.address.building].filter(Boolean).join("، ")}
              {order.address.landmark && <div className="text-xs mt-1">📍 {order.address.landmark}</div>}
            </div>
          ) : <div className="text-sm text-muted-foreground">—</div>}
        </div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-5 mb-4">
        <h3 className="font-bold mb-3">المنتجات</h3>
        <div className="space-y-3">
          {(order.items || []).map((it: any, i: number) => (
            <div key={i} className="flex items-start justify-between gap-2 pb-3 border-b border-border last:border-0 last:pb-0">
              <div className="flex-1">
                <div className="font-medium">{it.product_name}{it.variant_name ? ` (${it.variant_name})` : ""}</div>
                {it.addons?.length > 0 && (
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {it.addons.map((a: any) => a.addon_name).join("، ")}
                  </div>
                )}
                {it.notes && <div className="text-xs text-muted-foreground mt-0.5">📝 {it.notes}</div>}
                <div className="text-xs text-muted-foreground mt-0.5">× {it.quantity}</div>
              </div>
              <div className="font-bold text-sm">{Number(it.total_price).toFixed(2)} ر.س</div>
            </div>
          ))}
        </div>
        <div className="border-t border-border mt-3 pt-3 space-y-1.5 text-sm">
          <div className="flex justify-between"><span>المجموع</span><span>{Number(order.subtotal).toFixed(2)} ر.س</span></div>
          {Number(order.discount_amount) > 0 && <div className="flex justify-between text-success"><span>الخصم</span><span>-{Number(order.discount_amount).toFixed(2)} ر.س</span></div>}
          <div className="flex justify-between"><span>الضريبة</span><span>{Number(order.vat_amount).toFixed(2)} ر.س</span></div>
          {Number(order.delivery_fee) > 0 && <div className="flex justify-between"><span>التوصيل</span><span>{Number(order.delivery_fee).toFixed(2)} ر.س</span></div>}
          <div className="flex justify-between font-bold text-base border-t border-border pt-2">
            <span>الإجمالي</span><span className="text-primary">{Number(order.total_amount).toFixed(2)} ر.س</span>
          </div>
          <div className="flex justify-between text-xs text-muted-foreground pt-1">
            <span>طريقة الدفع</span><span>{order.payment_method === "cash" ? "كاش" : order.payment_method}</span>
          </div>
        </div>
      </div>

      {order.customer_notes && (
        <div className="bg-card border border-border rounded-2xl p-5 mb-4">
          <h3 className="font-bold mb-2">ملاحظات</h3>
          <p className="text-sm text-muted-foreground">{order.customer_notes}</p>
        </div>
      )}

      <button onClick={reorder} className="w-full bg-primary text-primary-foreground py-3 rounded-xl font-bold">إعادة الطلب</button>
    </AccountLayout>
  );
}
