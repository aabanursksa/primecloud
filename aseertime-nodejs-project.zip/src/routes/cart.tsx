import { createFileRoute, Link } from "@tanstack/react-router";
import { StoreLayout } from "@/components/store/StoreLayout";
import { useCart } from "@/lib/cart";
import { Trash2, Minus, Plus, ShoppingBag } from "lucide-react";

export const Route = createFileRoute("/cart")({ component: CartPage });

function CartPage() {
  const { items, updateQty, removeItem, subtotal } = useCart();

  if (items.length === 0) {
    return (
      <StoreLayout>
        <div className="container mx-auto px-4 py-20 text-center">
          <ShoppingBag className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-xl font-bold">سلتك فارغة</h2>
          <p className="text-muted-foreground mt-2">تصفّح المنيو وأضف ما تحب</p>
          <Link to="/menu" className="inline-block mt-6 bg-primary text-primary-foreground px-6 py-3 rounded-xl font-bold">تصفح المنيو</Link>
        </div>
      </StoreLayout>
    );
  }

  return (
    <StoreLayout>
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">سلة التسوق</h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-3">
            {items.map((it) => {
              const addonsTotal = it.addons.reduce((s, a) => s + Number(a.price), 0);
              const lineTotal = (Number(it.unit_price) + addonsTotal) * it.quantity;
              return (
                <div key={it.id} className="bg-card border border-border rounded-2xl p-4 flex gap-4">
                  <div className="w-20 h-20 rounded-xl bg-muted overflow-hidden shrink-0">
                    {it.product_image && <img src={it.product_image} alt="" className="w-full h-full object-cover" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold">{it.product_name}</div>
                    {it.variant_name && <div className="text-xs text-muted-foreground">{it.variant_name}</div>}
                    {it.addons.length > 0 && (
                      <div className="text-xs text-muted-foreground mt-1">{it.addons.map((a) => a.addon_name).join("، ")}</div>
                    )}
                    {it.notes && <div className="text-xs text-muted-foreground mt-1">ملاحظة: {it.notes}</div>}
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center bg-muted rounded-lg">
                        <button onClick={() => updateQty(it.id, it.quantity - 1)} className="w-8 h-8 flex items-center justify-center"><Minus className="w-3 h-3" /></button>
                        <span className="w-8 text-center text-sm font-bold">{it.quantity}</span>
                        <button onClick={() => updateQty(it.id, it.quantity + 1)} className="w-8 h-8 flex items-center justify-center"><Plus className="w-3 h-3" /></button>
                      </div>
                      <div className="font-bold text-primary">{lineTotal.toFixed(2)} ر.س</div>
                    </div>
                  </div>
                  <button onClick={() => { if (confirm("حذف من السلة؟")) removeItem(it.id); }} className="text-destructive p-2 self-start">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
          <div className="lg:sticky lg:top-20 self-start">
            <div className="bg-card border border-border rounded-2xl p-5">
              <h3 className="font-bold mb-4">ملخص الطلب</h3>
              <div className="flex justify-between text-sm py-2 border-t border-border">
                <span>المجموع الفرعي</span>
                <span className="font-bold">{subtotal.toFixed(2)} ر.س</span>
              </div>
              <Link to="/checkout" className="block w-full mt-4 bg-primary text-primary-foreground py-3 rounded-xl font-bold text-center hover:bg-primary/90">
                إتمام الطلب
              </Link>
            </div>
          </div>
        </div>
      </div>
    </StoreLayout>
  );
}
