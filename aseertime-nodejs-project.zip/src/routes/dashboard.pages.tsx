import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { FileText, Plus, Pencil, Trash2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { SingleImageUpload } from "@/components/ImageUpload";

export const Route = createFileRoute("/dashboard/pages")({ component: PagesPage });

type Page = {
  id: string; title: string; slug: string; content: string | null;
  featured_image: string | null; status: "published" | "draft" | "inactive";
  show_in_header: boolean; show_in_footer: boolean; sort_order: number;
};

const slugify = (s: string) => s.trim().toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]+/g, "-").replace(/^-|-$/g, "");

function PagesPage() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({
    queryKey: ["pages"],
    queryFn: async () => (await supabase.from("pages").select("*").order("sort_order")).data ?? [],
  });
  const [dialog, setDialog] = useState<Page | null>(null);

  const create = () => setDialog({
    id: "", title: "", slug: "", content: "", featured_image: "",
    status: "draft", show_in_header: false, show_in_footer: false, sort_order: data.length,
  });

  const save = async () => {
    if (!dialog) return;
    if (!dialog.title.trim()) return toast.error("العنوان مطلوب");
    const slug = dialog.slug.trim() || slugify(dialog.title);
    const { id, ...rest } = { ...dialog, slug };
    const res = id ? await supabase.from("pages").update(rest).eq("id", id) : await supabase.from("pages").insert(rest);
    if (res.error) return toast.error(res.error.message);
    toast.success("تم الحفظ"); setDialog(null);
    qc.invalidateQueries({ queryKey: ["pages"] });
  };

  const remove = async (id: string) => {
    if (!confirm("حذف الصفحة؟")) return;
    const { error } = await supabase.from("pages").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("تم الحذف"); qc.invalidateQueries({ queryKey: ["pages"] });
  };

  if (isLoading) return <Skeleton className="h-96" />;

  return (
    <>
      <PageHeader title="الصفحات" description="إدارة الصفحات الثابتة" action={
        <Button onClick={create} className="bg-gradient-primary text-primary-foreground gap-2"><Plus className="w-4 h-4" /> صفحة جديدة</Button>
      } />

      {data.length === 0 ? (
        <EmptyState icon={FileText} title="لا توجد صفحات" description="أنشئ أول صفحة ثابتة (عن المتجر، سياسة الخصوصية...)" actionLabel="صفحة جديدة" onAction={create} />
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs">
              <tr><th className="text-start p-3">العنوان</th><th className="text-start p-3">Slug</th><th className="p-3">الحالة</th><th className="p-3">هيدر</th><th className="p-3">فوتر</th><th className="p-3"></th></tr>
            </thead>
            <tbody>
              {(data as Page[]).map((p) => (
                <tr key={p.id} className="border-t border-border">
                  <td className="p-3 font-medium">{p.title}</td>
                  <td className="p-3 text-muted-foreground font-mono text-xs">/{p.slug}</td>
                  <td className="p-3 text-center"><span className={`text-[10px] px-2 py-0.5 rounded ${p.status === "published" ? "bg-success/10 text-success" : "bg-muted"}`}>{p.status === "published" ? "منشور" : "مسودة"}</span></td>
                  <td className="p-3 text-center">{p.show_in_header ? "✓" : "—"}</td>
                  <td className="p-3 text-center">{p.show_in_footer ? "✓" : "—"}</td>
                  <td className="p-3 flex gap-1 justify-end">
                    <button onClick={() => setDialog(p)} className="p-2"><Pencil className="w-3 h-3" /></button>
                    <button onClick={() => remove(p.id)} className="p-2 text-destructive"><Trash2 className="w-3 h-3" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Dialog open={!!dialog} onOpenChange={(o) => !o && setDialog(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{dialog?.id ? "تعديل صفحة" : "صفحة جديدة"}</DialogTitle></DialogHeader>
          {dialog && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div><Label>العنوان</Label><Input value={dialog.title} onChange={(e) => setDialog({ ...dialog, title: e.target.value })} /></div>
                <div><Label>Slug</Label><Input value={dialog.slug} onChange={(e) => setDialog({ ...dialog, slug: e.target.value })} placeholder="auto" /></div>
              </div>
              <div><Label>صورة مميزة</Label><SingleImageUpload value={dialog.featured_image ?? ""} onChange={(u) => setDialog({ ...dialog, featured_image: u })} folder="pages" /></div>
              <div><Label>المحتوى (HTML / Markdown)</Label>
                <Textarea rows={14} className="font-mono text-sm" value={dialog.content ?? ""} onChange={(e) => setDialog({ ...dialog, content: e.target.value })} placeholder="<h2>عنوان</h2>\n<p>نص...</p>" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="flex items-center justify-between p-3 border rounded-lg"><Label>منشورة</Label>
                  <Switch checked={dialog.status === "published"} onCheckedChange={(v) => setDialog({ ...dialog, status: v ? "published" : "draft" })} />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg"><Label>الهيدر</Label>
                  <Switch checked={dialog.show_in_header} onCheckedChange={(v) => setDialog({ ...dialog, show_in_header: v })} />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg"><Label>الفوتر</Label>
                  <Switch checked={dialog.show_in_footer} onCheckedChange={(v) => setDialog({ ...dialog, show_in_footer: v })} />
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog(null)}>إلغاء</Button>
            <Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
