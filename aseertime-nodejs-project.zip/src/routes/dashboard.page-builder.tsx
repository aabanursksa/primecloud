import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Trash2, ChevronUp, ChevronDown, Edit3 } from "lucide-react";

export const Route = createFileRoute("/dashboard/page-builder")({ component: PageBuilderPage });

const BLOCK_TYPES = [
  { v: "hero", l: "Hero بانر" },
  { v: "text", l: "نص" },
  { v: "image_text", l: "صورة + نص" },
  { v: "cards", l: "كروت" },
  { v: "vision_mission", l: "رؤية ورسالة" },
  { v: "why_us", l: "لماذا نحن" },
  { v: "stats", l: "إحصائيات" },
  { v: "features", l: "مميزات" },
  { v: "services", l: "خدمات" },
  { v: "faq", l: "أسئلة شائعة" },
  { v: "gallery", l: "معرض صور" },
  { v: "testimonials", l: "آراء العملاء" },
  { v: "cta", l: "زر دعوة CTA" },
  { v: "branches", l: "الفروع" },
  { v: "products", l: "منتجات" },
  { v: "offers", l: "عروض" },
  { v: "contact", l: "تواصل" },
  { v: "map", l: "خريطة" },
  { v: "video", l: "فيديو" },
  { v: "divider", l: "فاصل" },
];

function PageBuilderPage() {
  const qc = useQueryClient();
  const { data: pages } = useQuery({
    queryKey: ["pb-pages"],
    queryFn: async () => (await supabase.from("pages").select("id, title, slug").order("created_at")).data || [],
  });
  const [target, setTarget] = useState<{ kind: "home" } | { kind: "page"; id: string }>({ kind: "home" });

  const filter = target.kind === "home" ? { location: "home" } : { page_id: target.id };
  const { data: blocks, refetch } = useQuery({
    queryKey: ["pb-blocks", target],
    queryFn: async () => {
      let q = supabase.from("page_blocks").select("*").order("sort_order");
      if (target.kind === "home") q = q.eq("location", "home").is("page_id", null);
      else q = q.eq("page_id", target.id);
      return (await q).data || [];
    },
  });

  const addBlock = useMutation({
    mutationFn: async (block_type: string) => {
      const next = (blocks?.length || 0);
      const row: any = { block_type, sort_order: next, settings: {}, ...filter };
      const { error } = await supabase.from("page_blocks").insert(row);
      if (error) throw error;
    },
    onSuccess: () => { refetch(); toast.success("تمت الإضافة"); },
    onError: (e: any) => toast.error(e.message),
  });

  const update = async (id: string, patch: any) => {
    const { error } = await supabase.from("page_blocks").update(patch).eq("id", id);
    if (error) toast.error(error.message); else refetch();
  };
  const del = async (id: string) => {
    if (!confirm("حذف البلوك؟")) return;
    await supabase.from("page_blocks").delete().eq("id", id);
    refetch();
  };
  const move = async (idx: number, dir: -1 | 1) => {
    if (!blocks) return;
    const a = blocks[idx], b = blocks[idx + dir];
    if (!b) return;
    await Promise.all([
      supabase.from("page_blocks").update({ sort_order: b.sort_order }).eq("id", a.id),
      supabase.from("page_blocks").update({ sort_order: a.sort_order }).eq("id", b.id),
    ]);
    refetch();
  };

  const [editing, setEditing] = useState<string | null>(null);

  return (
    <div className="container mx-auto p-4 max-w-5xl" dir="rtl">
      <h1 className="text-2xl font-bold mb-4">Page Builder</h1>

      <div className="bg-card border border-border rounded-xl p-4 mb-4 flex flex-wrap items-center gap-3">
        <label className="text-sm font-bold">المكان:</label>
        <select
          value={target.kind === "home" ? "home" : target.id}
          onChange={(e) => setTarget(e.target.value === "home" ? { kind: "home" } : { kind: "page", id: e.target.value })}
          className="bg-muted rounded-lg px-3 py-2 text-sm"
        >
          <option value="home">الصفحة الرئيسية</option>
          {pages?.map((p) => <option key={p.id} value={p.id}>{p.title} ({p.slug})</option>)}
        </select>
        <select onChange={(e) => { if (e.target.value) { addBlock.mutate(e.target.value); e.target.value = ""; } }} className="bg-primary text-primary-foreground rounded-lg px-3 py-2 text-sm font-bold mr-auto">
          <option value="">+ إضافة بلوك</option>
          {BLOCK_TYPES.map((t) => <option key={t.v} value={t.v}>{t.l}</option>)}
        </select>
      </div>

      <div className="space-y-3">
        {(blocks || []).map((b: any, idx: number) => (
          <div key={b.id} className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center gap-2">
              <span className="font-bold">{BLOCK_TYPES.find((t) => t.v === b.block_type)?.l || b.block_type}</span>
              <label className="flex items-center gap-1 text-xs"><input type="checkbox" checked={b.is_active} onChange={(e) => update(b.id, { is_active: e.target.checked })} /> مفعّل</label>
              <div className="mr-auto flex items-center gap-1">
                <button onClick={() => move(idx, -1)} disabled={idx === 0} className="p-1.5 hover:bg-muted rounded disabled:opacity-30"><ChevronUp className="w-4 h-4" /></button>
                <button onClick={() => move(idx, 1)} disabled={idx === (blocks!.length - 1)} className="p-1.5 hover:bg-muted rounded disabled:opacity-30"><ChevronDown className="w-4 h-4" /></button>
                <button onClick={() => setEditing(editing === b.id ? null : b.id)} className="p-1.5 hover:bg-muted rounded"><Edit3 className="w-4 h-4" /></button>
                <button onClick={() => del(b.id)} className="p-1.5 text-destructive hover:bg-destructive/10 rounded"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
            {editing === b.id && (
              <div className="mt-3">
                <textarea
                  defaultValue={JSON.stringify(b.settings || {}, null, 2)}
                  onBlur={(e) => { try { update(b.id, { settings: JSON.parse(e.target.value) }); } catch { toast.error("JSON غير صحيح"); } }}
                  className="w-full bg-muted rounded-lg p-3 font-mono text-xs min-h-[200px]"
                  dir="ltr"
                />
                <p className="text-xs text-muted-foreground mt-1">عدّل إعدادات البلوك بصيغة JSON. مثال: {"{ title, subtitle, image_url, items: [...] }"}</p>
              </div>
            )}
          </div>
        ))}
        {(!blocks || blocks.length === 0) && <div className="text-center py-12 text-muted-foreground">لا توجد بلوكات بعد. أضف من الزر أعلاه.</div>}
      </div>
    </div>
  );
}
