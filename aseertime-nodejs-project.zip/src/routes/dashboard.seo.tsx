import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Save, Search, Globe, Twitter } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/EmptyState";
import { SingleImageUpload } from "@/components/ImageUpload";

export const Route = createFileRoute("/dashboard/seo")({ component: SeoPage });

type Seo = {
  id?: string; entity_type: "site" | "page" | "product" | "category";
  meta_title: string | null; meta_description: string | null; meta_keywords: string | null;
  canonical_url: string | null;
  og_title: string | null; og_description: string | null; og_image: string | null;
  twitter_title: string | null; twitter_description: string | null; twitter_image: string | null;
  default_og_image: string | null; default_twitter_image: string | null;
  google_verification: string | null;
  robots_index: boolean; robots_follow: boolean; sitemap_enabled: boolean;
};

function SeoPage() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["seo_global"],
    queryFn: async () => (await supabase.from("seo_settings").select("*").eq("entity_type", "site").maybeSingle()).data,
  });
  const [form, setForm] = useState<Seo | null>(null);
  useEffect(() => {
    if (data) setForm(data as Seo);
    else if (!isLoading) setForm({
      entity_type: "site", meta_title: "", meta_description: "", meta_keywords: "", canonical_url: "",
      og_title: "", og_description: "", og_image: "", twitter_title: "", twitter_description: "", twitter_image: "",
      default_og_image: "", default_twitter_image: "", google_verification: "",
      robots_index: true, robots_follow: true, sitemap_enabled: true,
    });
  }, [data, isLoading]);

  const save = async () => {
    if (!form) return;
    const res = form.id
      ? await supabase.from("seo_settings").update(form).eq("id", form.id)
      : await supabase.from("seo_settings").insert(form);
    if (res.error) return toast.error(res.error.message);
    toast.success("تم حفظ إعدادات SEO");
    qc.invalidateQueries({ queryKey: ["seo_global"] });
  };

  if (isLoading || !form) return <Skeleton className="h-96" />;
  const set = <K extends keyof Seo>(k: K, v: Seo[K]) => setForm({ ...form, [k]: v });

  return (
    <>
      <PageHeader title="إعدادات SEO" description="تحسين الظهور في محركات البحث ومنصات التواصل" action={
        <Button onClick={save} className="bg-gradient-primary text-primary-foreground gap-2"><Save className="w-4 h-4" /> حفظ</Button>
      } />

      <div className="grid lg:grid-cols-[1fr_400px] gap-6">
        <Tabs defaultValue="general">
          <TabsList>
            <TabsTrigger value="general"><Search className="w-4 h-4 ms-1" /> عام</TabsTrigger>
            <TabsTrigger value="og"><Globe className="w-4 h-4 ms-1" /> Open Graph</TabsTrigger>
            <TabsTrigger value="twitter"><Twitter className="w-4 h-4 ms-1" /> Twitter</TabsTrigger>
            <TabsTrigger value="advanced">متقدم</TabsTrigger>
          </TabsList>

          <TabsContent value="general">
            <Card className="p-6 space-y-4">
              <div><Label>Meta Title</Label><Input maxLength={60} value={form.meta_title ?? ""} onChange={(e) => set("meta_title", e.target.value)} />
                <p className="text-xs text-muted-foreground mt-1">{(form.meta_title ?? "").length}/60</p>
              </div>
              <div><Label>Meta Description</Label><Textarea rows={3} maxLength={160} value={form.meta_description ?? ""} onChange={(e) => set("meta_description", e.target.value)} />
                <p className="text-xs text-muted-foreground mt-1">{(form.meta_description ?? "").length}/160</p>
              </div>
              <div><Label>Meta Keywords</Label><Input value={form.meta_keywords ?? ""} onChange={(e) => set("meta_keywords", e.target.value)} placeholder="عصير, توصيل, الرياض" /></div>
              <div><Label>Canonical URL</Label><Input value={form.canonical_url ?? ""} onChange={(e) => set("canonical_url", e.target.value)} placeholder="https://..." /></div>
            </Card>
          </TabsContent>

          <TabsContent value="og">
            <Card className="p-6 space-y-4">
              <div><Label>OG Title</Label><Input value={form.og_title ?? ""} onChange={(e) => set("og_title", e.target.value)} /></div>
              <div><Label>OG Description</Label><Textarea rows={3} value={form.og_description ?? ""} onChange={(e) => set("og_description", e.target.value)} /></div>
              <div><Label>OG Image</Label><SingleImageUpload value={form.og_image ?? ""} onChange={(u) => set("og_image", u)} folder="seo" /></div>
              <div><Label>OG Image الافتراضية</Label><SingleImageUpload value={form.default_og_image ?? ""} onChange={(u) => set("default_og_image", u)} folder="seo" /></div>
            </Card>
          </TabsContent>

          <TabsContent value="twitter">
            <Card className="p-6 space-y-4">
              <div><Label>Twitter Title</Label><Input value={form.twitter_title ?? ""} onChange={(e) => set("twitter_title", e.target.value)} /></div>
              <div><Label>Twitter Description</Label><Textarea rows={3} value={form.twitter_description ?? ""} onChange={(e) => set("twitter_description", e.target.value)} /></div>
              <div><Label>Twitter Image</Label><SingleImageUpload value={form.twitter_image ?? ""} onChange={(u) => set("twitter_image", u)} folder="seo" /></div>
              <div><Label>Twitter Image الافتراضية</Label><SingleImageUpload value={form.default_twitter_image ?? ""} onChange={(u) => set("default_twitter_image", u)} folder="seo" /></div>
            </Card>
          </TabsContent>

          <TabsContent value="advanced">
            <Card className="p-6 space-y-4">
              <div><Label>Google Site Verification</Label><Input value={form.google_verification ?? ""} onChange={(e) => set("google_verification", e.target.value)} /></div>
              <div className="flex items-center justify-between"><Label>السماح بالأرشفة (index)</Label>
                <Switch checked={form.robots_index} onCheckedChange={(v) => set("robots_index", v)} />
              </div>
              <div className="flex items-center justify-between"><Label>تتبع الروابط (follow)</Label>
                <Switch checked={form.robots_follow} onCheckedChange={(v) => set("robots_follow", v)} />
              </div>
              <div className="flex items-center justify-between"><Label>تفعيل Sitemap</Label>
                <Switch checked={form.sitemap_enabled} onCheckedChange={(v) => set("sitemap_enabled", v)} />
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="space-y-4">
          <Card className="p-4">
            <h4 className="text-xs font-semibold text-muted-foreground mb-3">معاينة Google</h4>
            <div className="space-y-1">
              <div className="text-xs text-muted-foreground">{form.canonical_url || "https://example.com"}</div>
              <div className="text-lg text-blue-700 truncate">{form.meta_title || "عنوان الصفحة"}</div>
              <div className="text-sm text-muted-foreground line-clamp-2">{form.meta_description || "وصف الصفحة سيظهر هنا في نتائج البحث."}</div>
            </div>
          </Card>
          <Card className="p-4">
            <h4 className="text-xs font-semibold text-muted-foreground mb-3">معاينة المشاركة (OG)</h4>
            <div className="border rounded-lg overflow-hidden">
              {form.og_image && <img src={form.og_image} alt="" className="w-full h-40 object-cover" />}
              <div className="p-3 bg-muted/30">
                <div className="text-[10px] uppercase text-muted-foreground">{(form.canonical_url || "example.com").replace(/^https?:\/\//, "").split("/")[0]}</div>
                <div className="font-semibold text-sm mt-1 line-clamp-1">{form.og_title || form.meta_title || "العنوان"}</div>
                <div className="text-xs text-muted-foreground line-clamp-2 mt-1">{form.og_description || form.meta_description}</div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}
