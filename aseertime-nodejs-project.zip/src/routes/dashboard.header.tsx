import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { LayoutPanelTop, Save } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/EmptyState";
import { SingleImageUpload } from "@/components/ImageUpload";

export const Route = createFileRoute("/dashboard/header")({ component: HeaderPage });

type Header = {
  id?: string;
  logo_url: string | null;
  show_logo: boolean;
  show_search: boolean;
  show_cart: boolean;
  show_login: boolean;
  show_branch_selector: boolean;
  show_cta: boolean;
  cta_text: string | null;
  cta_url: string | null;
  contact_phone: string | null;
};

function HeaderPage() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["header_settings"],
    queryFn: async () => (await supabase.from("header_settings").select("*").maybeSingle()).data,
  });
  const [form, setForm] = useState<Header | null>(null);
  useEffect(() => {
    if (data) setForm(data as Header);
    else if (!isLoading) setForm({
      logo_url: "", show_logo: true, show_search: true, show_cart: true, show_login: true,
      show_branch_selector: true, show_cta: true, cta_text: "اطلب الآن", cta_url: "/menu", contact_phone: "",
    });
  }, [data, isLoading]);

  const save = async () => {
    if (!form) return;
    const payload = { ...form };
    const res = form.id
      ? await supabase.from("header_settings").update(payload).eq("id", form.id)
      : await supabase.from("header_settings").insert(payload);
    if (res.error) return toast.error(res.error.message);
    toast.success("تم حفظ إعدادات الهيدر");
    qc.invalidateQueries({ queryKey: ["header_settings"] });
  };

  if (isLoading || !form) return <Skeleton className="h-96" />;

  const set = <K extends keyof Header>(k: K, v: Header[K]) => setForm({ ...form, [k]: v });

  return (
    <>
      <PageHeader title="إدارة الهيدر" description="عناصر تظهر في رأس الموقع والتطبيق" action={
        <Button onClick={save} className="bg-gradient-primary text-primary-foreground gap-2">
          <Save className="w-4 h-4" /> حفظ
        </Button>
      } />
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="p-6 space-y-4">
          <h3 className="font-bold flex items-center gap-2"><LayoutPanelTop className="w-4 h-4" /> الشعار والاتصال</h3>
          <div>
            <Label>شعار الهيدر</Label>
            <SingleImageUpload value={form.logo_url ?? ""} onChange={(u) => set("logo_url", u)} folder="header" />
          </div>
          <div>
            <Label>رقم التواصل</Label>
            <Input value={form.contact_phone ?? ""} onChange={(e) => set("contact_phone", e.target.value)} />
          </div>
          <div>
            <Label>نص زر CTA</Label>
            <Input value={form.cta_text ?? ""} onChange={(e) => set("cta_text", e.target.value)} />
          </div>
          <div>
            <Label>رابط زر CTA</Label>
            <Input value={form.cta_url ?? ""} onChange={(e) => set("cta_url", e.target.value)} />
          </div>
        </Card>
        <Card className="p-6 space-y-4">
          <h3 className="font-bold">العناصر الظاهرة</h3>
          {[
            ["show_logo", "إظهار الشعار"],
            ["show_search", "إظهار البحث"],
            ["show_cart", "إظهار السلة"],
            ["show_login", "إظهار تسجيل الدخول"],
            ["show_branch_selector", "إظهار اختيار الفرع"],
            ["show_cta", "إظهار زر CTA"],
          ].map(([k, label]) => (
            <div key={k} className="flex items-center justify-between">
              <Label htmlFor={k}>{label}</Label>
              <Switch id={k} checked={form[k as keyof Header] as boolean} onCheckedChange={(v) => set(k as keyof Header, v as never)} />
            </div>
          ))}
        </Card>
      </div>
    </>
  );
}
