import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, CheckCheck } from "lucide-react";
import { EmptyState, PageHeader } from "@/components/EmptyState";

export const Route = createFileRoute("/dashboard/notifications")({ component: NotificationsPage });

function NotificationsPage() {
  const qc = useQueryClient();
  const { data: items = [], isLoading } = useQuery({
    queryKey: ["notifications-page"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("notifications")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      return data ?? [];
    },
  });

  const unread = items.filter((n) => !n.is_read).length;

  const markAll = async () => {
    await supabase.from("notifications").update({ is_read: true }).eq("is_read", false);
    qc.invalidateQueries({ queryKey: ["notifications-page"] });
    qc.invalidateQueries({ queryKey: ["notifications-bell"] });
  };

  const markOne = async (id: string) => {
    await supabase.from("notifications").update({ is_read: true }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["notifications-page"] });
    qc.invalidateQueries({ queryKey: ["notifications-bell"] });
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <PageHeader title="الإشعارات" description={`لديك ${unread} إشعار غير مقروء.`} />
        {unread > 0 && (
          <Button onClick={markAll} variant="outline" className="gap-2">
            <CheckCheck className="w-4 h-4" />
            تعليم الكل كمقروء
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="text-muted-foreground">جارٍ التحميل...</div>
      ) : items.length === 0 ? (
        <EmptyState icon={Bell} title="لا توجد إشعارات" description="ستظهر هنا إشعارات الطلبات والعمليات المهمة." />
      ) : (
        <Card className="divide-y divide-border">
          {items.map((n) => (
            <div key={n.id} className={`p-4 flex items-start justify-between gap-3 ${!n.is_read ? "bg-primary/5" : ""}`}>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm">{n.title}</div>
                {n.message && <div className="text-xs text-muted-foreground mt-1">{n.message}</div>}
                <div className="text-[10px] text-muted-foreground mt-1" dir="ltr">
                  {new Date(n.created_at).toLocaleString("en-GB")}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {n.action_url && (
                  <Link to={n.action_url as "/dashboard"} className="text-xs text-primary">فتح</Link>
                )}
                {!n.is_read && (
                  <button onClick={() => markOne(n.id)} className="text-xs text-muted-foreground hover:text-primary">
                    مقروء
                  </button>
                )}
              </div>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}
