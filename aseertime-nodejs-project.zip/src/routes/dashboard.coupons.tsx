import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Tag, Plus, Pencil, Trash2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { COUPON_TYPE_LABEL } from "@/lib/orders";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";
import { DateField } from "@/components/DateField";

export const Route = createFileRoute("/dashboard/coupons")({ component: CouponsPage });

type Cp = {
  id?: string; name: string; code: string; discount_type: "fixed"|"percent"|"free_delivery";
  discount_value: number; minimum_order: number; maximum_discount: number | null;
  start_date: string; end_date: string; usage_limit: number | null; usage_per_customer: number | null;
  status: "active"|"inactive"; branch_id: string | null;
};
const empty: Cp = { name: "", code: "", discount_type: "fixed", discount_value: 0, minimum_order: 0, maximum_discount: null, start_date: "", end_date: "", usage_limit: null, usage_per_customer: 1, status: "active", branch_id: null };

function CouponsPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Cp>(empty);

  const { data: coupons = [], isLoading } = useQuery({
    queryKey: ["coupons"],
    queryFn: async () => (await supabase.from("coupons").select("*, branch:branches(name)").order("created_at", { ascending: false })).data ?? [],
  });
  const { data: branches = [] } = useQuery({
    queryKey: ["branches-list"],
    queryFn: async () => (await supabase.from("branches").select("id,name").order("display_order")).data ?? [],
  });

  const save = async () => {
    if (!form.name || !form.code) return toast.error("الاسم والكود مطلوبان");
    try {
      const payload = {
        ...form,
        start_date: form.start_date || null,
        end_date: form.end_date || null,
      };
      if (form.id) {
        const { error } = await supabase.from("coupons").update(payload).eq("id", form.id);
        if (error) throw error;
        await logActivity("update_coupon", "coupons", form.id);
      } else {
        const { id: _i, ...ins } = payload; void _i;
        const { data, error } = await supabase.from("coupons").insert(ins).select().single();
        if (error) throw error;
        await logActivity("create_coupon", "coupons", data.id);
      }
      toast.success("تم الحفظ");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["coupons"] });
    } catch (e) { toast.error(e instanceof Error ? e.message : "فشل"); }
  };

  const remove = async (c: typeof coupons[number]) => {
    if (!confirm(`حذف "${c.name}"؟`)) return;
    const { error } = await supabase.from("coupons").delete().eq("id", c.id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["coupons"] });
  };

  const stateOf = (c: typeof coupons[number]) => {
    const now = Date.now();
    if (c.status !== "active") return { label: "غير نشط", cls: "bg-muted text-muted-foreground" };
    if (c.end_date && new Date(c.end_date).getTime() < now) return { label: "منتهي", cls: "bg-destructive/10 text-destructive" };
    if (c.usage_limit && c.used_count >= c.usage_limit) return { label: "مستخدم بالكامل", cls: "bg-warning/10 text-warning" };
    return { label: "نشط", cls: "bg-success/10 text-success" };
  };

  return (
    <div>
      <PageHeader title="الكوبونات والعروض" description="إدارة كوبونات الخصم والعروض الترويجية." action={
        <Button onClick={() => { setForm(empty); setOpen(true); }} className="bg-gradient-primary text-primary-foreground gap-2 shadow-glow"><Plus className="w-4 h-4" />إضافة كوبون</Button>
      } />

      {isLoading ? <div className="text-muted-foreground">جارٍ التحميل...</div> :
       coupons.length === 0 ? (
        <EmptyState icon={Tag} title="لا توجد كوبونات" description="أنشئ كوبون خصم أو عرض ترويجي لجذب المزيد من العملاء." actionLabel="إضافة كوبون" onAction={() => { setForm(empty); setOpen(true); }} />
      ) : (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50"><tr>
              <th className="text-start p-3">الكود</th><th className="text-start p-3">الاسم</th><th className="text-start p-3">نوع الخصم</th><th className="text-start p-3">القيمة</th><th className="text-start p-3">المدة</th><th className="text-start p-3">الاستخدام</th><th className="text-start p-3">الحالة</th><th></th>
            </tr></thead>
            <tbody>{coupons.map((c) => {
              const st = stateOf(c);
              return (
                <tr key={c.id} className="border-t hover:bg-muted/30">
                  <td className="p-3 font-mono font-medium" dir="ltr">{c.code}</td>
                  <td className="p-3">{c.name}</td>
                  <td className="p-3">{COUPON_TYPE_LABEL[c.discount_type]}</td>
                  <td className="p-3">{c.discount_type === "percent" ? `${c.discount_value}%` : c.discount_type === "free_delivery" ? "—" : `${c.discount_value} ر.س`}</td>
                  <td className="p-3 text-xs text-muted-foreground">{c.start_date ? new Date(c.start_date).toLocaleDateString("en-GB") : "—"} → {c.end_date ? new Date(c.end_date).toLocaleDateString("en-GB") : "—"}</td>
                  <td className="p-3">{c.used_count}{c.usage_limit ? ` / ${c.usage_limit}` : ""}</td>
                  <td className="p-3"><span className={`text-xs px-2 py-1 rounded font-medium ${st.cls}`}>{st.label}</span></td>
                  <td className="p-3 flex gap-1 justify-end">
                    <Button size="icon" variant="ghost" onClick={() => { setForm({ id: c.id, name: c.name, code: c.code, discount_type: c.discount_type, discount_value: Number(c.discount_value), minimum_order: Number(c.minimum_order), maximum_discount: c.maximum_discount ? Number(c.maximum_discount) : null, start_date: c.start_date ? c.start_date.slice(0,10) : "", end_date: c.end_date ? c.end_date.slice(0,10) : "", usage_limit: c.usage_limit, usage_per_customer: c.usage_per_customer, status: c.status, branch_id: c.branch_id }); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(c)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </td>
                </tr>);
            })}
            </tbody>
          </table>
        </Card>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader><DialogTitle>{form.id ? "تعديل كوبون" : "إضافة كوبون"}</DialogTitle></DialogHeader>
          <div className="grid md:grid-cols-2 gap-4">
            <div><Label className="mb-1.5 block">الاسم</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الكود</Label><Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} dir="ltr" /></div>
            <div><Label className="mb-1.5 block">نوع الخصم</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.discount_type} onChange={(e) => setForm({ ...form, discount_type: e.target.value as Cp["discount_type"] })}>
                {Object.entries(COUPON_TYPE_LABEL).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div><Label className="mb-1.5 block">قيمة الخصم</Label><Input type="number" step="0.01" value={form.discount_value} onChange={(e) => setForm({ ...form, discount_value: parseFloat(e.target.value) || 0 })} disabled={form.discount_type === "free_delivery"} /></div>
            <div><Label className="mb-1.5 block">الحد الأدنى للطلب</Label><Input type="number" step="0.01" value={form.minimum_order} onChange={(e) => setForm({ ...form, minimum_order: parseFloat(e.target.value) || 0 })} /></div>
            <div><Label className="mb-1.5 block">الحد الأقصى للخصم</Label><Input type="number" step="0.01" value={form.maximum_discount ?? ""} onChange={(e) => setForm({ ...form, maximum_discount: e.target.value ? parseFloat(e.target.value) : null })} /></div>
            <div><Label className="mb-1.5 block">تاريخ البداية</Label><DateField value={form.start_date} onChange={(v) => setForm({ ...form, start_date: v ?? "" })} /></div>
            <div><Label className="mb-1.5 block">تاريخ النهاية</Label><DateField value={form.end_date} onChange={(v) => setForm({ ...form, end_date: v ?? "" })} /></div>
            <div><Label className="mb-1.5 block">إجمالي مرات الاستخدام</Label><Input type="number" value={form.usage_limit ?? ""} onChange={(e) => setForm({ ...form, usage_limit: e.target.value ? parseInt(e.target.value) : null })} /></div>
            <div><Label className="mb-1.5 block">للعميل الواحد</Label><Input type="number" value={form.usage_per_customer ?? ""} onChange={(e) => setForm({ ...form, usage_per_customer: e.target.value ? parseInt(e.target.value) : null })} /></div>
            <div><Label className="mb-1.5 block">الفرع</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.branch_id ?? ""} onChange={(e) => setForm({ ...form, branch_id: e.target.value || null })}>
                <option value="">— كل الفروع —</option>
                {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div><Label className="mb-1.5 block">الحالة</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Cp["status"] })}>
                <option value="active">نشط</option>
                <option value="inactive">غير نشط</option>
              </select>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-4"><Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button><Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button></div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
