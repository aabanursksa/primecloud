import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { useCustomerAuth } from "@/lib/customer-auth";
import { toast } from "sonner";
import { CheckCircle2, Circle } from "lucide-react";

export const Route = createFileRoute("/track-order")({
  validateSearch: (s: Record<string, unknown>) => ({ order: typeof s.order === "string" ? s.order : "" }),
  component: TrackPage,
});

const STATUS_ORDER_DELIVERY = ["new", "accepted", "preparing", "awaiting_driver", "with_driver", "delivered"];
const STATUS_ORDER_PICKUP = ["new", "accepted", "preparing", "ready", "delivered"];
const STATUS_LABELS: Record<string, string> = {
  new: "تم استلام الطلب",
  accepted: "مقبول",
  preparing: "قيد التحضير",
  ready: "جاهز للاستلام",
  awaiting_driver: "بانتظار السائق",
  with_driver: "مع السائق",
  delivered: "تم التسليم",
  cancelled: "ملغي",
  refunded: "مسترجع",
};

function TrackPage() {
  const { customer, isLoggedIn } = useCustomerAuth();
  const { order: prefillOrder } = Route.useSearch();
  const [orderNumber, setOrderNumber] = useState(prefillOrder || "");
  const [phone, setPhone] = useState("");
  const [result, setResult] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);

  // Auto-fill phone for logged-in customers
  useEffect(() => { if (isLoggedIn && customer) setPhone(customer.phone); }, [isLoggedIn, customer]);

  const search = async (overrideNumber?: string) => {
    const num = (overrideNumber ?? orderNumber).trim();
    const ph = phone.trim();
    if (!num || !ph) { toast.error("أدخل رقم الطلب ورقم الجوال"); return; }
    setLoading(true);
    try {
      const { data, error } = await supabase.rpc("track_order", { _order_number: num, _phone: ph });
      if (error) throw error;
      if (!data) { toast.error("لم يتم العثور على الطلب"); setResult(null); }
      else setResult(data);
    } catch (e: any) {
      toast.error(e?.message || "خطأ");
    } finally { setLoading(false); }
  };

  // For logged-in users with prefilled order, auto-search
  useEffect(() => {
    if (isLoggedIn && customer && prefillOrder && !result) {
      search(prefillOrder);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoggedIn, customer, prefillOrder]);

  const STATUS_ORDER = result?.order_type === "pickup" ? STATUS_ORDER_PICKUP : STATUS_ORDER_DELIVERY;
  const currentIdx = result ? STATUS_ORDER.indexOf(result.status) : -1;

  return (
    <StoreLayout>
      <div className="container mx-auto px-4 py-6 max-w-2xl">
        <h1 className="text-2xl font-bold mb-2">تتبع طلبك</h1>
        {isLoggedIn && (
          <p className="text-sm text-muted-foreground mb-4">
            أنت مسجّل دخولك. يمكنك أيضاً عرض كل طلباتك في{" "}
            <Link to="/account/orders" className="text-primary font-bold">طلباتي</Link>.
          </p>
        )}

        <div className="bg-card border border-border rounded-2xl p-5 space-y-3">
          <input value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} placeholder="رقم الطلب (مثال: ORD-1)" className="w-full bg-muted rounded-xl px-4 py-3 text-base" />
          <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="رقم الجوال" dir="ltr" inputMode="tel" disabled={isLoggedIn} className="w-full bg-muted rounded-xl px-4 py-3 text-base disabled:opacity-70" />
          <button onClick={() => search()} disabled={loading} className="w-full bg-primary text-primary-foreground py-3.5 rounded-xl font-bold disabled:opacity-50 min-h-[48px]">
            {loading ? "جارٍ البحث..." : "تتبع الطلب"}
          </button>
        </div>

        {result && (
          <div className="bg-card border border-border rounded-2xl p-5 mt-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="font-bold">{result.order_number}</div>
              <div className="text-primary font-bold">{Number(result.total_amount).toFixed(2)} ر.س</div>
            </div>
            {result.branch && <div className="text-sm text-muted-foreground mt-1">فرع: {result.branch.name}</div>}

            <div className="mt-6 space-y-3">
              {STATUS_ORDER.map((s: string, i: number) => {
                const done = result.status === "cancelled" ? false : i <= currentIdx;
                return (
                  <div key={s} className="flex items-center gap-3">
                    {done ? <CheckCircle2 className="w-5 h-5 text-success" /> : <Circle className="w-5 h-5 text-muted-foreground" />}
                    <span className={done ? "font-bold" : "text-muted-foreground"}>{STATUS_LABELS[s]}</span>
                  </div>
                );
              })}
              {result.status === "cancelled" && <div className="text-destructive font-bold">تم إلغاء الطلب</div>}
            </div>

            {result.items?.length > 0 && (
              <div className="mt-6 border-t border-border pt-4 space-y-2">
                {result.items.map((it: any, i: number) => (
                  <div key={i} className="flex justify-between text-sm">
                    <span>{it.product_name} {it.variant_name ? `(${it.variant_name})` : ""} × {it.quantity}</span>
                    <span>{Number(it.total_price).toFixed(2)} ر.س</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </StoreLayout>
  );
}
