import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Users, Plus, Pencil, Eye } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { CUSTOMER_STATUS_LABEL, CUSTOMER_STATUS_COLOR, StatusBadge } from "@/lib/orders";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";

export const Route = createFileRoute("/dashboard/customers/")({ component: CustomersPage });

type C = { id?: string; name: string; phone: string; email: string; status: "active"|"inactive"|"banned"; notes: string };
const empty: C = { name: "", phone: "", email: "", status: "active", notes: "" };

function CustomersPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<C>(empty);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("");

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ["customers"],
    queryFn: async () => {
      const { data, error } = await supabase.from("customers").select("*, orders:orders(id,total_amount,created_at,status)").order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const enriched = customers.map((c) => {
    const orders = (c as { orders?: Array<{ total_amount: number; created_at: string; status: string }> }).orders ?? [];
    const completed = orders.filter((o) => o.status !== "cancelled");
    return {
      ...c,
      order_count: completed.length,
      total_spent: completed.reduce((s, o) => s + Number(o.total_amount), 0),
      last_order: orders.length > 0 ? orders.map((o) => o.created_at).sort().reverse()[0] : null,
    };
  });

  const filtered = enriched.filter((c) => {
    if (filter === "top" && c.order_count < 3) return false;
    if (filter === "new") {
      const d = new Date(c.created_at); const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 30);
      if (d < cutoff) return false;
    }
    if (filter === "inactive" && c.order_count > 0) return false;
    if (filter === "banned" && c.status !== "banned") return false;
    if (!search) return true;
    const s = search.toLowerCase();
    return c.name.toLowerCase().includes(s) || c.phone.includes(s) || (c.email ?? "").toLowerCase().includes(s);
  });

  const save = async () => {
    if (!form.name || !form.phone) return toast.error("الاسم والجوال مطلوبان");
    try {
      const payload = { ...form, email: form.email || null, notes: form.notes || null };
      if (form.id) {
        const { error } = await supabase.from("customers").update(payload).eq("id", form.id);
        if (error) throw error;
        await logActivity("update_customer", "customers", form.id);
      } else {
        const { id: _i, ...ins } = payload; void _i;
        const { data, error } = await supabase.from("customers").insert(ins).select().single();
        if (error) throw error;
        await logActivity("create_customer", "customers", data.id);
      }
      toast.success("تم الحفظ");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["customers"] });
    } catch (e) { toast.error(e instanceof Error ? e.message : "فشل"); }
  };

  return (
    <div>
      <PageHeader title="العملاء" description="إدارة قاعدة عملائك." action={
        <Button onClick={() => { setForm(empty); setOpen(true); }} className="bg-gradient-primary text-primary-foreground gap-2 shadow-glow"><Plus className="w-4 h-4" />إضافة عميل</Button>
      } />

      <Card className="p-4 mb-4">
        <div className="grid md:grid-cols-3 gap-2">
          <Input placeholder="بحث بالاسم أو الجوال أو البريد" value={search} onChange={(e) => setSearch(e.target.value)} />
          <select className="h-9 rounded-md border border-input bg-background px-2 text-sm" value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="">كل العملاء</option>
            <option value="top">الأكثر طلباً (3+)</option>
            <option value="new">العملاء الجدد (آخر 30 يوم)</option>
            <option value="inactive">غير نشطين (لا طلبات)</option>
            <option value="banned">المحظورين</option>
          </select>
        </div>
      </Card>

      {isLoading ? <div className="text-muted-foreground">جارٍ التحميل...</div> :
       customers.length === 0 ? (
        <EmptyState icon={Users} title="لا يوجد عملاء بعد" description="سيتم تسجيل العملاء تلقائياً عند أول طلب، أو يمكنك إضافتهم يدوياً." actionLabel="إضافة عميل" onAction={() => { setForm(empty); setOpen(true); }} />
      ) : (
        <Card className="overflow-hidden">
         <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[760px]">
            <thead className="bg-muted/50"><tr>
              <th className="text-start p-3">الاسم</th><th className="text-start p-3">الجوال</th><th className="text-start p-3">الطلبات</th><th className="text-start p-3">الإنفاق</th><th className="text-start p-3">آخر طلب</th><th className="text-start p-3">الحالة</th><th className="text-start p-3">التسجيل</th><th></th>
            </tr></thead>
            <tbody>{filtered.map((c) => (
              <tr key={c.id} className="border-t hover:bg-muted/30">
                <td className="p-3 font-medium whitespace-nowrap">{c.name}</td>
                <td className="p-3 text-muted-foreground whitespace-nowrap" dir="ltr">{c.phone}</td>
                <td className="p-3">{c.order_count}</td>
                <td className="p-3 whitespace-nowrap">{c.total_spent.toFixed(2)} ر.س</td>
                <td className="p-3 text-xs text-muted-foreground whitespace-nowrap">{c.last_order ? new Date(c.last_order).toLocaleDateString("en-GB") : "—"}</td>
                <td className="p-3"><StatusBadge status={c.status} map={CUSTOMER_STATUS_LABEL} color={CUSTOMER_STATUS_COLOR} /></td>
                <td className="p-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(c.created_at).toLocaleDateString("en-GB")}</td>
                <td className="p-3 flex gap-1 justify-end">
                  <Button asChild size="icon" variant="ghost"><Link to="/dashboard/customers/$customerId" params={{ customerId: c.id! }}><Eye className="w-4 h-4" /></Link></Button>
                  <Button size="icon" variant="ghost" onClick={() => { setForm({ id: c.id, name: c.name, phone: c.phone, email: c.email ?? "", status: c.status, notes: c.notes ?? "" }); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                </td>
              </tr>))}
            </tbody>
          </table>
         </div>
        </Card>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent dir="rtl">
          <DialogHeader><DialogTitle>{form.id ? "تعديل عميل" : "إضافة عميل"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2"><Label className="mb-1.5 block">الاسم</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الجوال</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} dir="ltr" /></div>
            <div><Label className="mb-1.5 block">البريد</Label><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} dir="ltr" /></div>
            <div className="col-span-2"><Label className="mb-1.5 block">الحالة</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as C["status"] })}>
                {Object.entries(CUSTOMER_STATUS_LABEL).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div className="col-span-2"><Label className="mb-1.5 block">ملاحظات إدارية</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-4"><Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button><Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button></div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
