import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Sparkles, Plus, Pencil, Trash2, ArrowUp, ArrowDown } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { EmptyState } from "@/components/EmptyState";
import { SingleImageUpload } from "@/components/ImageUpload";
import { moveSort } from "@/lib/sortable";
import { DateField } from "@/components/DateField";

export const Route = createFileRoute("/dashboard/hero")({ component: HeroPage });

type Hero = {
  id: string; title: string; subtitle: string | null; image_url: string | null;
  cta_text: string | null; cta_url: string | null; platform: "store" | "app" | "both";
  text_color: string | null; text_alignment: "start" | "center" | "end";
  status: "active" | "inactive" | "scheduled" | "expired";
  start_date: string | null; end_date: string | null; sort_order: number;
  image_only: boolean;
};

type FormState = {
  title: string; subtitle: string; image_url: string; cta_text: string; cta_url: string;
  platform: "store" | "app" | "both"; text_color: string;
  text_alignment: "start" | "center" | "end";
  status: "active" | "inactive" | "scheduled" | "expired";
  start_date: string | null; end_date: string | null;
  image_only: boolean;
};
const empty: FormState = {
  title: "", subtitle: "", image_url: "", cta_text: "", cta_url: "",
  platform: "both", text_color: "#ffffff", text_alignment: "start",
  status: "active", start_date: null, end_date: null,
  image_only: false,
};

function HeroPage() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({
    queryKey: ["hero_slides"],
    queryFn: async () => (await supabase.from("hero_slides").select("*").order("sort_order")).data ?? [],
  });
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<{ id?: string } & typeof empty>({ ...empty });

  const save = async () => {
    if (!form.image_only && !form.title.trim()) return toast.error("العنوان مطلوب");
    const payload: any = { ...form, start_date: form.start_date || null, end_date: form.end_date || null };
    if (form.id) {
      const { error } = await supabase.from("hero_slides").update(payload).eq("id", form.id);
      if (error) return toast.error(error.message);
      toast.success("تم التحديث");
    } else {
      payload.sort_order = data.reduce((m, h) => Math.max(m, h.sort_order), 0) + 1;
      const { error } = await supabase.from("hero_slides").insert(payload);
      if (error) return toast.error(error.message);
      toast.success("تم الإضافة");
    }
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["hero_slides"] });
  };

  const remove = async (h: Hero) => {
    if (!confirm("حذف السلايد؟")) return;
    await supabase.from("hero_slides").delete().eq("id", h.id);
    qc.invalidateQueries({ queryKey: ["hero_slides"] });
    toast.success("تم الحذف");
  };
  const toggle = async (h: Hero) => {
    await supabase.from("hero_slides").update({ status: h.status === "active" ? "inactive" : "active" }).eq("id", h.id);
    qc.invalidateQueries({ queryKey: ["hero_slides"] });
  };
  const move = async (id: string, dir: -1 | 1) => {
    await moveSort("hero_slides", data, id, dir);
    qc.invalidateQueries({ queryKey: ["hero_slides"] });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">الهيرو Hero</h1>
          <p className="text-sm text-muted-foreground">سلايدات الصفحة الرئيسية للمتجر والتطبيق</p>
        </div>
        <Button onClick={() => { setForm({ ...empty }); setOpen(true); }} className="bg-gradient-primary text-primary-foreground shadow-glow">
          <Plus className="w-4 h-4 me-1" /> إضافة سلايد
        </Button>
      </div>

      {isLoading ? (
        <Card className="p-12 text-center text-muted-foreground">جارٍ التحميل…</Card>
      ) : data.length === 0 ? (
        <EmptyState icon={Sparkles} title="لا توجد سلايدات" description="أضف أول سلايد لقسم الهيرو." actionLabel="إضافة سلايد" onAction={() => { setForm({ ...empty }); setOpen(true); }} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {data.map((h: Hero) => (
            <Card key={h.id} className="overflow-hidden">
              <div className="relative aspect-[16/7] bg-muted">
                {h.image_url && <img src={h.image_url} alt="" className="w-full h-full object-cover" />}
                {!h.image_only && (
                  <div className={`absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col justify-end p-4 text-${h.text_alignment === "center" ? "center" : h.text_alignment === "end" ? "end" : "start"}`} style={{ color: h.text_color ?? "#fff" }}>
                    <div className="font-bold text-lg">{h.title}</div>
                    {h.subtitle && <div className="text-xs opacity-90">{h.subtitle}</div>}
                  </div>
                )}
                <span className={`absolute top-2 end-2 text-[10px] px-2 py-1 rounded font-medium ${h.status === "active" ? "bg-success/90 text-white" : "bg-muted text-foreground"}`}>{h.status === "active" ? "نشط" : "غير نشط"}</span>
                {h.image_only && <span className="absolute top-2 start-2 text-[10px] px-2 py-1 rounded font-medium bg-primary/90 text-white">صورة فقط</span>}
              </div>
              <div className="p-3 flex items-center justify-between gap-2">
                <div className="flex gap-1">
                  <button onClick={() => move(h.id, -1)} className="p-1 hover:bg-muted rounded"><ArrowUp className="w-4 h-4" /></button>
                  <button onClick={() => move(h.id, 1)} className="p-1 hover:bg-muted rounded"><ArrowDown className="w-4 h-4" /></button>
                  <span className="text-xs text-muted-foreground self-center">#{h.sort_order}</span>
                </div>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" onClick={() => toggle(h)}>{h.status === "active" ? "تعطيل" : "تفعيل"}</Button>
                  <Button size="icon" variant="ghost" onClick={() => { setForm({ id: h.id, title: h.title, subtitle: h.subtitle ?? "", image_url: h.image_url ?? "", cta_text: h.cta_text ?? "", cta_url: h.cta_url ?? "", platform: h.platform, text_color: h.text_color ?? "#ffffff", text_alignment: h.text_alignment, status: h.status, start_date: h.start_date?.slice(0, 10) ?? null, end_date: h.end_date?.slice(0, 10) ?? null, image_only: !!h.image_only }); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => remove(h)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form.id ? "تعديل سلايد" : "إضافة سلايد"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <SingleImageUpload value={form.image_url ?? ""} onChange={(v) => setForm({ ...form, image_url: v })} folder="hero" label="صورة الخلفية" />
            <div className="flex items-center justify-between rounded-md border p-3">
              <div>
                <Label className="block">صورة فقط (إخفاء العنوان والزر)</Label>
                <p className="text-xs text-muted-foreground mt-0.5">يعرض السلايد كصورة فقط بدون نصوص أو أزرار.</p>
              </div>
              <Switch checked={form.image_only} onCheckedChange={(v) => setForm({ ...form, image_only: v })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label className="mb-1.5 block">العنوان الرئيسي</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
              <div className="col-span-2"><Label className="mb-1.5 block">العنوان الفرعي</Label><Textarea rows={2} value={form.subtitle ?? ""} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">نص الزر</Label><Input value={form.cta_text ?? ""} onChange={(e) => setForm({ ...form, cta_text: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">رابط الزر</Label><Input dir="ltr" value={form.cta_url ?? ""} onChange={(e) => setForm({ ...form, cta_url: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">المنصة</Label>
                <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.platform} onChange={(e) => setForm({ ...form, platform: e.target.value as any })}>
                  <option value="both">الكل</option><option value="store">المتجر</option><option value="app">التطبيق</option>
                </select>
              </div>
              <div><Label className="mb-1.5 block">المحاذاة</Label>
                <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.text_alignment} onChange={(e) => setForm({ ...form, text_alignment: e.target.value as any })}>
                  <option value="start">يمين</option><option value="center">وسط</option><option value="end">يسار</option>
                </select>
              </div>
              <div><Label className="mb-1.5 block">لون النص</Label><Input type="color" value={form.text_color ?? "#ffffff"} onChange={(e) => setForm({ ...form, text_color: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">الحالة</Label>
                <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as any })}>
                  <option value="active">نشط</option><option value="inactive">غير نشط</option><option value="scheduled">مجدول</option>
                </select>
              </div>
              <div><Label className="mb-1.5 block">تاريخ البداية</Label><DateField value={form.start_date} onChange={(v) => setForm({ ...form, start_date: v })} /></div>
              <div><Label className="mb-1.5 block">تاريخ النهاية</Label><DateField value={form.end_date} onChange={(v) => setForm({ ...form, end_date: v })} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
