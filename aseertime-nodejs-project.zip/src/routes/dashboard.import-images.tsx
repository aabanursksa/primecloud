import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { scrapeMenuImages, applyProductImages } from "@/lib/scrape-images.functions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { PageHeader } from "@/components/EmptyState";
import { Download, ImageIcon, Loader2, ArrowRight } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/import-images")({ component: ImportImagesPage });

type Match = {
  product_id: string;
  product_name: string;
  current_image: string | null;
  scraped_name: string | null;
  scraped_image: string | null;
};

const DEFAULT_URL =
  "https://hungerstation.com/sa-ar/restaurant/%D8%A7%D9%84%D8%AF%D9%85%D8%A7%D9%85/%D8%B6%D8%A7%D8%AD%D9%8A%D8%A9-%D8%A7%D9%84%D9%85%D9%84%D9%83-%D9%81%D9%87%D8%AF/58627";

function ImportImagesPage() {
  const [url, setUrl] = useState(DEFAULT_URL);
  const [matches, setMatches] = useState<Match[]>([]);
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [onlyMissing, setOnlyMissing] = useState(true);

  const scrapeFn = useServerFn(scrapeMenuImages);
  const applyFn = useServerFn(applyProductImages);

  const scrape = useMutation({
    mutationFn: async () => scrapeFn({ data: { url } }),
    onSuccess: (res) => {
      setMatches(res.matches);
      const sel: Record<string, boolean> = {};
      for (const m of res.matches) {
        if (m.scraped_image && !m.current_image) sel[m.product_id] = true;
      }
      setSelected(sel);
      toast.success(`تم استخراج ${res.scraped_count} منتج من الموقع`);
    },
    onError: (e: any) => toast.error(e?.message || "فشل الجلب"),
  });

  const apply = useMutation({
    mutationFn: async () => {
      const updates = matches
        .filter((m) => selected[m.product_id] && m.scraped_image)
        .map((m) => ({ product_id: m.product_id, image_url: m.scraped_image! }));
      if (updates.length === 0) throw new Error("لم يتم اختيار أي منتج");
      return applyFn({ data: { updates } });
    },
    onSuccess: (res) => {
      toast.success(`تم تحديث ${res.updated} صورة`);
      setMatches([]);
      setSelected({});
    },
    onError: (e: any) => toast.error(e?.message || "فشل الحفظ"),
  });

  const visible = matches.filter((m) => {
    if (!m.scraped_image) return !onlyMissing ? true : false;
    if (onlyMissing && m.current_image) return false;
    return true;
  });

  const selectedCount = Object.values(selected).filter(Boolean).length;

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="استيراد صور المنتجات"
        description="اجلب صور المنتجات من رابط خارجي وطابقها مع منتجاتك"
        action={
          <Button asChild variant="outline">
            <Link to="/dashboard/products">
              <ArrowRight className="ml-2 h-4 w-4" /> رجوع للمنتجات
            </Link>
          </Button>
        }
      />

      <Card className="p-4 space-y-3">
        <Label>رابط صفحة المطعم (HungerStation أو مشابه)</Label>
        <div className="flex gap-2">
          <Input value={url} onChange={(e) => setUrl(e.target.value)} dir="ltr" />
          <Button onClick={() => scrape.mutate()} disabled={scrape.isPending || !url}>
            {scrape.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
            <span className="mr-2">جلب الصور</span>
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          ملاحظة: استخدم هذه الميزة فقط مع محتوى تملك حقوق استخدامه.
        </p>
      </Card>

      {matches.length > 0 && (
        <Card className="p-4 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-3">
              <Checkbox id="onlyMissing" checked={onlyMissing} onCheckedChange={(v) => setOnlyMissing(!!v)} />
              <Label htmlFor="onlyMissing">إظهار المنتجات التي تنقصها صورة فقط</Label>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">{selectedCount} مختارة</span>
              <Button onClick={() => apply.mutate()} disabled={apply.isPending || selectedCount === 0}>
                {apply.isPending && <Loader2 className="h-4 w-4 animate-spin ml-2" />}
                تطبيق على {selectedCount} منتج
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {visible.map((m) => (
              <div key={m.product_id} className="border rounded-lg p-3 flex gap-3 items-start">
                <Checkbox
                  checked={!!selected[m.product_id]}
                  disabled={!m.scraped_image}
                  onCheckedChange={(v) => setSelected((s) => ({ ...s, [m.product_id]: !!v }))}
                />
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{m.product_name}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {m.scraped_name ? `مطابقة: ${m.scraped_name}` : "لا توجد مطابقة"}
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <div>
                      <div className="text-[10px] text-muted-foreground mb-1">الحالية</div>
                      {m.current_image ? (
                        <img src={m.current_image} alt="" className="w-full h-20 object-cover rounded" />
                      ) : (
                        <div className="w-full h-20 rounded bg-muted flex items-center justify-center text-xs text-muted-foreground">
                          لا يوجد
                        </div>
                      )}
                    </div>
                    <div>
                      <div className="text-[10px] text-muted-foreground mb-1">الجديدة</div>
                      {m.scraped_image ? (
                        <img src={m.scraped_image} alt="" className="w-full h-20 object-cover rounded" />
                      ) : (
                        <div className="w-full h-20 rounded bg-muted flex items-center justify-center text-xs text-muted-foreground">
                          —
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          {visible.length === 0 && (
            <div className="text-center text-sm text-muted-foreground py-6">لا توجد عناصر للعرض</div>
          )}
        </Card>
      )}
    </div>
  );
}
