import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Package, Plus, Pencil, Trash2, Star, LayoutGrid, List, Image as ImageIcon, Eye, Download } from "lucide-react";
import * as XLSX from "xlsx";
import { DetailDrawer, useDetailDrawer } from "@/components/DetailDrawer";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { SingleImageUpload, MultiImageUpload } from "@/components/ImageUpload";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";

export const Route = createFileRoute("/dashboard/products")({ component: ProductsPage });

type Prod = {
  id?: string;
  name_ar: string; name_en: string; description_ar: string; description_en: string;
  image_url: string; gallery_urls: string[]; category_id: string | null;
  base_price: number; calories: number | null; prep_time_minutes: number | null;
  is_available: boolean; display_order: number; show_in_app: boolean; show_in_store: boolean;
  is_featured: boolean; is_archived: boolean;
};
const empty: Prod = {
  name_ar: "", name_en: "", description_ar: "", description_en: "", image_url: "", gallery_urls: [],
  category_id: null, base_price: 0, calories: null, prep_time_minutes: null,
  is_available: true, display_order: 0, show_in_app: true, show_in_store: true,
  is_featured: false, is_archived: false,
};

type Cat = { id: string; name_ar: string; parent_id: string | null };

function ProductsPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Prod>(empty);
  const [search, setSearch] = useState("");
  const [view, setView] = useState<"grid" | "list">(() => (typeof localStorage !== "undefined" && (localStorage.getItem("products_view") as "grid" | "list")) || "list");
  const [catOpen, setCatOpen] = useState(false);
  const [catForm, setCatForm] = useState<{ name_ar: string; name_en: string; parent_id: string | null }>({ name_ar: "", name_en: "", parent_id: null });
  const detail = useDetailDrawer();

  const setViewMode = (v: "grid" | "list") => { setView(v); try { localStorage.setItem("products_view", v); } catch { /* ignore */ } };

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["products"],
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("*, category:product_categories(name_ar)").order("display_order");
      if (error) throw error;
      return data ?? [];
    },
  });
  const { data: cats = [] } = useQuery<Cat[]>({
    queryKey: ["categories-list"],
    queryFn: async () => ((await supabase.from("product_categories").select("id, name_ar, parent_id").order("display_order")).data ?? []) as Cat[],
  });

  const filtered = products.filter((p) => !search || p.name_ar.includes(search) || p.name_en?.includes(search));

  const save = async () => {
    try {
      const payload = { ...form };
      if (form.id) {
        const { error } = await supabase.from("products").update(payload).eq("id", form.id);
        if (error) throw error;
        await logActivity("update_product", "products", form.id, { name: form.name_ar });
      } else {
        const { id: _i, ...ins } = payload; void _i;
        const { data, error } = await supabase.from("products").insert(ins).select().single();
        if (error) throw error;
        await logActivity("create_product", "products", data.id, { name: form.name_ar });
      }
      toast.success("تم الحفظ");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["products"] });
    } catch (e) { toast.error(e instanceof Error ? e.message : "فشل"); }
  };

  const remove = async (p: typeof products[number]) => {
    if (!confirm(`حذف "${p.name_ar}"؟`)) return;
    const { error } = await supabase.from("products").delete().eq("id", p.id);
    if (error) return toast.error(error.message);
    await logActivity("delete_product", "products", p.id, { name: p.name_ar });
    qc.invalidateQueries({ queryKey: ["products"] });
  };

  const saveCategory = async (selectAfter = false) => {
    if (!catForm.name_ar.trim()) return toast.error("أدخل اسم التصنيف");
    try {
      const { data, error } = await supabase.from("product_categories")
        .insert({ name_ar: catForm.name_ar, name_en: catForm.name_en || "", parent_id: catForm.parent_id })
        .select().single();
      if (error) throw error;
      await logActivity("create_category", "product_categories", data.id, { name: catForm.name_ar });
      toast.success("تم إضافة التصنيف");
      qc.invalidateQueries({ queryKey: ["categories-list"] });
      qc.invalidateQueries({ queryKey: ["categories"] });
      if (selectAfter) setForm((f) => ({ ...f, category_id: data.id }));
      setCatOpen(false);
      setCatForm({ name_ar: "", name_en: "", parent_id: null });
    } catch (e) { toast.error(e instanceof Error ? e.message : "فشل"); }
  };

  const handleExport = async () => {
    try {
      toast.loading("جارٍ تجهيز الملف...", { id: "exp" });
      const [{ data: prods, error: e1 }, { data: variants, error: e2 }] = await Promise.all([
        supabase.from("products").select("*, category:product_categories(name_ar, name_en)").order("display_order"),
        supabase.from("product_variants").select("*").order("display_order"),
      ]);
      if (e1) throw e1; if (e2) throw e2;
      const variantsByProd = new Map<string, typeof variants>();
      (variants ?? []).forEach((v) => {
        const arr = variantsByProd.get(v.product_id) ?? [];
        arr.push(v); variantsByProd.set(v.product_id, arr);
      });
      const rows = (prods ?? []).map((p) => {
        const cat = (p as { category?: { name_ar?: string; name_en?: string } | null }).category;
        const vs = variantsByProd.get(p.id) ?? [];
        return {
          "المعرف": p.id,
          "الاسم العربي": p.name_ar,
          "الاسم الإنجليزي": p.name_en ?? "",
          "الوصف العربي": p.description_ar ?? "",
          "الوصف الإنجليزي": p.description_en ?? "",
          "القسم": cat?.name_ar ?? "",
          "القسم (EN)": cat?.name_en ?? "",
          "السعر الأساسي": p.base_price,
          "سعر الخصم": p.discount_price ?? "",
          "السعرات": p.calories ?? "",
          "وقت التحضير (دقيقة)": p.prep_time_minutes ?? "",
          "متوفر": p.is_available ? "نعم" : "لا",
          "مميز": p.is_featured ? "نعم" : "لا",
          "يظهر في المتجر": p.show_in_store ? "نعم" : "لا",
          "يظهر في التطبيق": p.show_in_app ? "نعم" : "لا",
          "مؤرشف": p.is_archived ? "نعم" : "لا",
          "ترتيب الظهور": p.display_order,
          "الصورة الرئيسية": p.image_url ?? "",
          "صور إضافية": Array.isArray(p.gallery_urls) ? p.gallery_urls.join(" | ") : "",
          "المتغيرات (الاسم - السعر - السعرات)": vs.map((v) => `${v.name_ar}: ${v.price} ر.س${v.calories ? ` (${v.calories} سعرة)` : ""}`).join(" | "),
          "تاريخ الإنشاء": p.created_at,
        };
      });
      const ws = XLSX.utils.json_to_sheet(rows);
      ws["!cols"] = Object.keys(rows[0] ?? {}).map(() => ({ wch: 22 }));
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "المنتجات");
      const today = new Date().toISOString().slice(0, 10);
      XLSX.writeFile(wb, `products-${today}.xlsx`);
      toast.success(`تم تصدير ${rows.length} منتج`, { id: "exp" });
    } catch (e) { toast.error(e instanceof Error ? e.message : "فشل التصدير", { id: "exp" }); }
  };

  return (
    <div>
      <PageHeader title="المنتجات" description="إدارة منتجات المتجر." action={
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={handleExport} className="gap-2"><Download className="w-4 h-4" />تصدير Excel</Button>
          <Button asChild variant="outline" className="gap-2"><Link to="/dashboard/import-images"><ImageIcon className="w-4 h-4" />استيراد صور</Link></Button>
          <Button variant="outline" onClick={() => { setCatForm({ name_ar: "", name_en: "", parent_id: null }); setCatOpen(true); }} className="gap-2"><Plus className="w-4 h-4" />إضافة تصنيف</Button>
          <Button onClick={() => { setForm(empty); setOpen(true); }} className="bg-gradient-primary text-primary-foreground gap-2 shadow-glow"><Plus className="w-4 h-4" />إضافة منتج</Button>
        </div>
      } />

      {products.length > 0 && (
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <Input placeholder="ابحث عن منتج..." value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-md" />
          <div className="ms-auto inline-flex rounded-md border bg-card p-1">
            <Button size="sm" variant={view === "list" ? "default" : "ghost"} onClick={() => setViewMode("list")} className="h-8 gap-1.5"><List className="w-4 h-4" />قائمة</Button>
            <Button size="sm" variant={view === "grid" ? "default" : "ghost"} onClick={() => setViewMode("grid")} className="h-8 gap-1.5"><LayoutGrid className="w-4 h-4" />شبكة</Button>
          </div>
        </div>
      )}

      {isLoading ? <div className="text-muted-foreground">جارٍ التحميل...</div> :
       products.length === 0 ? <EmptyState icon={Package} title="لا توجد منتجات" description="أضف منتجاً يدوياً أو استورد من ملف Excel." actionLabel="أضف منتجاً" onAction={() => { setForm(empty); setOpen(true); }} /> :
       view === "list" ? (
       <Card className="overflow-hidden">
        <div className="overflow-x-auto">
         <table className="w-full text-sm min-w-[720px]">
           <thead className="bg-muted/50"><tr>
             <th className="w-16 p-3"></th>
             <th className="text-start p-3">المنتج</th><th className="text-start p-3">القسم</th><th className="text-start p-3">السعر</th><th className="text-start p-3">السعرات</th><th className="text-start p-3">الحالة</th><th></th>
           </tr></thead>
           <tbody>{filtered.map((p) => (
             <tr key={p.id} className="border-t hover:bg-muted/30">
               <td className="p-3">
                 {p.image_url ? (
                   <img src={p.image_url} alt={p.name_ar} loading="lazy" className="w-12 h-12 rounded-lg object-cover border" />
                 ) : (
                   <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center text-muted-foreground"><ImageIcon className="w-5 h-5" /></div>
                 )}
               </td>
               <td className="p-3 font-medium">
                 <div className="flex items-center gap-2">
                   {p.is_featured && <Star className="w-4 h-4 text-warning fill-warning shrink-0" />}
                   <div>
                     <div>{p.name_ar}</div>
                     {p.name_en && <div className="text-xs text-muted-foreground" dir="ltr">{p.name_en}</div>}
                   </div>
                 </div>
               </td>
               <td className="p-3 text-muted-foreground">{(p as { category?: { name_ar: string } | null }).category?.name_ar ?? "—"}</td>
               <td className="p-3 whitespace-nowrap">{p.base_price} ر.س</td>
               <td className="p-3">{p.calories ?? "—"}</td>
               <td className="p-3">{p.is_available ? <span className="text-xs bg-success/10 text-success px-2 py-1 rounded">متوفر</span> : <span className="text-xs bg-muted px-2 py-1 rounded">غير متوفر</span>}</td>
                <td className="p-3 flex gap-1 justify-end">
                  <Button size="icon" variant="ghost" onClick={() => p.id && detail.openDetails("products", p.id)}><Eye className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => { const n = Object.fromEntries(Object.entries(p).filter(([k])=>k!=="category").map(([k,v])=>[k, v ?? (typeof empty[k as keyof Prod] === "string" ? "" : v)])) as unknown as Prod; setForm({ ...empty, ...n, gallery_urls: Array.isArray(n.gallery_urls) ? n.gallery_urls : [] }); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => remove(p)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                </td>
             </tr>))}
           </tbody>
         </table>
        </div>
       </Card>
       ) : (
         <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-3">
           {filtered.map((p) => (
             <Card key={p.id} className="overflow-hidden flex flex-col group">
               <div className="aspect-square bg-muted relative">
                 {p.image_url ? (
                   <img src={p.image_url} alt={p.name_ar} loading="lazy" className="w-full h-full object-cover" />
                 ) : (
                   <div className="w-full h-full flex items-center justify-center text-muted-foreground"><ImageIcon className="w-8 h-8" /></div>
                 )}
                 {p.is_featured && <span className="absolute top-2 start-2 bg-warning text-warning-foreground text-xs px-2 py-1 rounded-full flex items-center gap-1"><Star className="w-3 h-3 fill-current" />مميز</span>}
                 {!p.is_available && <span className="absolute top-2 end-2 bg-muted text-muted-foreground text-xs px-2 py-1 rounded-full">غير متوفر</span>}
               </div>
               <div className="p-3 flex-1 flex flex-col">
                 <div className="font-medium text-sm line-clamp-1">{p.name_ar}</div>
                 <div className="text-xs text-muted-foreground line-clamp-1">{(p as { category?: { name_ar: string } | null }).category?.name_ar ?? "بدون قسم"}</div>
                 <div className="mt-2 font-bold text-sm">{p.base_price} ر.س</div>
                  <div className="mt-3 flex gap-1 justify-end">
                    <Button size="icon" variant="ghost" onClick={() => p.id && detail.openDetails("products", p.id)}><Eye className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => { const n = Object.fromEntries(Object.entries(p).filter(([k])=>k!=="category").map(([k,v])=>[k, v ?? (typeof empty[k as keyof Prod] === "string" ? "" : v)])) as unknown as Prod; setForm({ ...empty, ...n, gallery_urls: Array.isArray(n.gallery_urls) ? n.gallery_urls : [] }); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(p)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </div>
               </div>
             </Card>
           ))}
         </div>
       )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader><DialogTitle>{form.id ? "تعديل منتج" : "إضافة منتج"}</DialogTitle></DialogHeader>
          <div className="grid md:grid-cols-2 gap-4">
            <FF label="الصورة الرئيسية" full>
              <SingleImageUpload value={form.image_url} onChange={(url) => setForm({ ...form, image_url: url })} folder="products" />
            </FF>
            <FF label="معرض الصور (صور إضافية)" full>
              <MultiImageUpload values={form.gallery_urls} onChange={(urls) => setForm({ ...form, gallery_urls: urls })} folder="products" max={6} />
            </FF>
            <FF label="الاسم العربي"><Input value={form.name_ar} onChange={(e) => setForm({ ...form, name_ar: e.target.value })} /></FF>
            <FF label="الاسم الإنجليزي"><Input value={form.name_en} onChange={(e) => setForm({ ...form, name_en: e.target.value })} dir="ltr" /></FF>
            <FF label="الوصف العربي" full><Textarea value={form.description_ar} onChange={(e) => setForm({ ...form, description_ar: e.target.value })} /></FF>
            <FF label="الوصف الإنجليزي" full><Textarea value={form.description_en} onChange={(e) => setForm({ ...form, description_en: e.target.value })} dir="ltr" /></FF>
            <FF label="القسم" full>
              <div className="flex gap-2">
                <select className="flex-1 h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.category_id ?? ""} onChange={(e) => setForm({ ...form, category_id: e.target.value || null })}>
                  <option value="">— لا يوجد —</option>
                  {cats.map((c) => <option key={c.id} value={c.id}>{c.parent_id ? "— " : ""}{c.name_ar}</option>)}
                </select>
                <Button type="button" variant="outline" className="gap-1.5 shrink-0" onClick={() => { setCatForm({ name_ar: "", name_en: "", parent_id: null }); setCatOpen(true); }}><Plus className="w-4 h-4" />تصنيف جديد</Button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">يمكنك إضافة تصنيف رئيسي أو فرعي مباشرة وسيُحفظ ضمن قائمة التصنيفات.</p>
            </FF>
            <FF label="السعر الأساسي"><Input type="number" step="0.01" value={form.base_price} onChange={(e) => setForm({ ...form, base_price: parseFloat(e.target.value) || 0 })} /></FF>
            <FF label="السعرات"><Input type="number" value={form.calories ?? ""} onChange={(e) => setForm({ ...form, calories: e.target.value ? parseInt(e.target.value) : null })} /></FF>
            <FF label="وقت التحضير (دقيقة)"><Input type="number" value={form.prep_time_minutes ?? ""} onChange={(e) => setForm({ ...form, prep_time_minutes: e.target.value ? parseInt(e.target.value) : null })} /></FF>
            <FF label="ترتيب الظهور"><Input type="number" value={form.display_order} onChange={(e) => setForm({ ...form, display_order: parseInt(e.target.value) || 0 })} /></FF>
            <Toggle label="متوفر" v={form.is_available} on={(v) => setForm({ ...form, is_available: v })} />
            <Toggle label="مميز" v={form.is_featured} on={(v) => setForm({ ...form, is_featured: v })} />
            <Toggle label="يظهر في التطبيق" v={form.show_in_app} on={(v) => setForm({ ...form, show_in_app: v })} />
            <Toggle label="يظهر في المتجر" v={form.show_in_store} on={(v) => setForm({ ...form, show_in_store: v })} />
            <Toggle label="مؤرشف" v={form.is_archived} on={(v) => setForm({ ...form, is_archived: v })} />
          </div>
          <div className="flex justify-end gap-2 pt-4"><Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button><Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button></div>
        </DialogContent>
      </Dialog>

      <Dialog open={catOpen} onOpenChange={setCatOpen}>
        <DialogContent dir="rtl">
          <DialogHeader><DialogTitle>إضافة تصنيف</DialogTitle></DialogHeader>
          <div className="grid gap-4">
            <div><Label className="mb-1.5 block">الاسم العربي</Label><Input value={catForm.name_ar} onChange={(e) => setCatForm({ ...catForm, name_ar: e.target.value })} autoFocus /></div>
            <div><Label className="mb-1.5 block">الاسم الإنجليزي</Label><Input value={catForm.name_en} onChange={(e) => setCatForm({ ...catForm, name_en: e.target.value })} dir="ltr" /></div>
            <div>
              <Label className="mb-1.5 block">التصنيف الأب (اتركه فارغاً ليكون رئيسياً)</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={catForm.parent_id ?? ""} onChange={(e) => setCatForm({ ...catForm, parent_id: e.target.value || null })}>
                <option value="">— تصنيف رئيسي —</option>
                {cats.filter((c) => !c.parent_id).map((c) => <option key={c.id} value={c.id}>{c.name_ar}</option>)}
              </select>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="ghost" onClick={() => setCatOpen(false)}>إلغاء</Button>
            <Button onClick={() => saveCategory(open)} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </div>
        </DialogContent>
      </Dialog>
      <DetailDrawer entity="products" recordId={detail.id} open={detail.open} onOpenChange={detail.setOpen} />
    </div>
  );
}

function FF({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return <div className={full ? "md:col-span-2" : ""}><Label className="mb-1.5 block">{label}</Label>{children}</div>;
}
function Toggle({ label, v, on }: { label: string; v: boolean; on: (b: boolean) => void }) {
  return <div className="flex items-center justify-between p-3 bg-muted/40 rounded-lg"><span className="text-sm">{label}</span><Switch checked={v} onCheckedChange={on} /></div>;
}
