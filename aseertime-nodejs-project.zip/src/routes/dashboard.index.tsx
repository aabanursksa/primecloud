import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Store, Package, Layers, PlusCircle, Settings, Upload, CheckCircle2, Circle,
  ShoppingBag, Users, Bike, TrendingUp, Clock, AlertCircle,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/lib/auth";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from "recharts";

export const Route = createFileRoute("/dashboard/")({
  component: DashboardHome,
});

const STATUS_COLORS: Record<string, string> = {
  new: "#F97316",
  preparing: "#EAB308",
  ready: "#3B82F6",
  on_the_way: "#8B5CF6",
  delivered: "#22C55E",
  cancelled: "#EF4444",
};
const STATUS_LABELS: Record<string, string> = {
  new: "جديد",
  preparing: "قيد التحضير",
  ready: "جاهز",
  on_the_way: "في الطريق",
  delivered: "تم التسليم",
  cancelled: "ملغي",
};

function DashboardHome() {
  const { user } = useAuth();

  const { data, isLoading } = useQuery({
    queryKey: ["dashboard-home"],
    queryFn: async () => {
      const since = new Date();
      since.setDate(since.getDate() - 13);
      const sinceIso = since.toISOString();

      const [settingsR, branchesR, productsR, categoriesR, addonsR, ordersR, customersR, driversR, recentR] = await Promise.all([
        supabase.from("store_settings").select("id").limit(1).maybeSingle(),
        supabase.from("branches").select("id, is_active"),
        supabase.from("products").select("id"),
        supabase.from("product_categories").select("id"),
        supabase.from("addon_groups").select("id"),
        supabase.from("orders").select("id, status, total_amount, created_at").gte("created_at", sinceIso),
        supabase.from("customers").select("id"),
        supabase.from("drivers").select("id, status"),
        supabase.from("orders").select("id, order_number, total_amount, status, created_at").order("created_at", { ascending: false }).limit(5),
      ]);

      const orders = ordersR.data ?? [];
      const today = new Date(); today.setHours(0, 0, 0, 0);
      const todayOrders = orders.filter((o) => new Date(o.created_at) >= today);
      const todayRevenue = todayOrders.filter((o) => o.status !== "cancelled").reduce((s, o) => s + Number(o.total_amount || 0), 0);
      const totalRevenue = orders.filter((o) => o.status !== "cancelled").reduce((s, o) => s + Number(o.total_amount || 0), 0);

      // Build 14-day series
      const days: { date: string; label: string; orders: number; revenue: number }[] = [];
      for (let i = 13; i >= 0; i--) {
        const d = new Date(); d.setDate(d.getDate() - i); d.setHours(0, 0, 0, 0);
        const next = new Date(d); next.setDate(next.getDate() + 1);
        const dayOrders = orders.filter((o) => {
          const t = new Date(o.created_at);
          return t >= d && t < next;
        });
        days.push({
          date: d.toISOString().slice(0, 10),
          label: d.toLocaleDateString("en-GB", { day: "2-digit", month: "2-digit" }),
          orders: dayOrders.length,
          revenue: dayOrders.filter((o) => o.status !== "cancelled").reduce((s, o) => s + Number(o.total_amount || 0), 0),
        });
      }

      // Status breakdown
      const statusMap = new Map<string, number>();
      orders.forEach((o) => statusMap.set(o.status, (statusMap.get(o.status) ?? 0) + 1));
      const statusData = Array.from(statusMap.entries()).map(([name, value]) => ({ name, value }));

      const drivers = driversR.data ?? [];
      const onlineDrivers = drivers.filter((d) => d.status !== "offline").length;

      const branches = branchesR.data ?? [];
      return {
        hasSettings: !!settingsR.data,
        branchCount: branches.length,
        activeBranches: branches.filter((b) => b.is_active).length,
        productCount: productsR.data?.length ?? 0,
        categoryCount: categoriesR.data?.length ?? 0,
        addonCount: addonsR.data?.length ?? 0,
        customerCount: customersR.data?.length ?? 0,
        driverCount: drivers.length,
        onlineDrivers,
        totalOrders: orders.length,
        todayOrders: todayOrders.length,
        todayRevenue,
        totalRevenue,
        days,
        statusData,
        recent: recentR.data ?? [],
      };
    },
    refetchInterval: 60_000,
  });

  if (isLoading || !data) return <div className="text-muted-foreground">جارٍ التحميل...</div>;

  const isEmpty = !data.hasSettings && data.branchCount === 0 && data.productCount === 0;

  if (isEmpty) {
    const steps = [
      { done: data.hasSettings, label: "إعداد بيانات المتجر", to: "/dashboard/settings", icon: Settings },
      { done: data.branchCount > 0, label: "إضافة أول فرع", to: "/dashboard/branches", icon: Store },
      { done: data.productCount > 0, label: "استيراد ملف المنيو Excel", to: "/dashboard/import", icon: Upload },
    ] as const;
    return (
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold">مرحباً بك في عصير تايم 👋</h1>
          <p className="text-muted-foreground mt-2">لنبدأ بإعداد متجرك في خطوات بسيطة</p>
        </div>
        <Card className="p-2">
          {steps.map((s, i) => (
            <Link key={s.to} to={s.to} className="flex items-center gap-4 p-4 rounded-xl hover:bg-muted transition group">
              {s.done ? <CheckCircle2 className="w-7 h-7 text-success flex-shrink-0" /> : <Circle className="w-7 h-7 text-muted-foreground flex-shrink-0" />}
              <div className="flex-1">
                <div className="text-xs text-muted-foreground">الخطوة {i + 1}</div>
                <div className={`font-semibold ${s.done ? "line-through text-muted-foreground" : ""}`}>{s.label}</div>
              </div>
              <s.icon className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
            </Link>
          ))}
        </Card>
      </div>
    );
  }

  const kpis = [
    { label: "طلبات اليوم", value: data.todayOrders, icon: ShoppingBag, color: "text-primary", bg: "bg-primary/10" },
    { label: "مبيعات اليوم", value: `${data.todayRevenue.toFixed(2)} ر.س`, icon: TrendingUp, color: "text-success", bg: "bg-success/10" },
    { label: "العملاء", value: data.customerCount, icon: Users, color: "text-info", bg: "bg-info/10" },
    { label: "السائقون النشطون", value: `${data.onlineDrivers} / ${data.driverCount}`, icon: Bike, color: "text-warning", bg: "bg-warning/10" },
  ];

  const subKpis = [
    { label: "الفروع النشطة", value: `${data.activeBranches} / ${data.branchCount}`, icon: Store },
    { label: "المنتجات", value: data.productCount, icon: Package },
    { label: "الأقسام", value: data.categoryCount, icon: Layers },
    { label: "مجموعات الإضافات", value: data.addonCount, icon: PlusCircle },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">مرحباً بك، {user?.email?.split("@")[0]} 👋</h1>
        <p className="text-sm text-muted-foreground mt-1">نظرة عامة على متجرك خلال آخر 14 يوماً.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((c) => (
          <Card key={c.label} className="p-5">
            <div className="flex items-center justify-between">
              <div className="min-w-0">
                <div className="text-sm text-muted-foreground">{c.label}</div>
                <div className="text-2xl font-bold mt-2 truncate">{c.value}</div>
              </div>
              <div className={`w-12 h-12 rounded-xl ${c.bg} flex items-center justify-center ${c.color} flex-shrink-0`}>
                <c.icon className="w-6 h-6" />
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold">المبيعات والطلبات (14 يوماً)</h3>
            <span className="text-xs text-muted-foreground">إجمالي: {data.totalRevenue.toFixed(2)} ر.س</span>
          </div>
          {data.totalOrders === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-muted-foreground">
              <AlertCircle className="w-10 h-10 mb-2 opacity-50" />
              <span className="text-sm">لا توجد طلبات بعد</span>
            </div>
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.days}>
                  <defs>
                    <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#ED1C24" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="#ED1C24" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip contentStyle={{ direction: "rtl", fontSize: 12 }} />
                  <Area type="monotone" dataKey="revenue" name="المبيعات" stroke="#ED1C24" strokeWidth={2} fill="url(#rev)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>

        <Card className="p-5">
          <h3 className="font-bold mb-4">حالات الطلبات</h3>
          {data.statusData.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-muted-foreground">
              <AlertCircle className="w-10 h-10 mb-2 opacity-50" />
              <span className="text-sm">لا توجد بيانات</span>
            </div>
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={data.statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label={(e) => STATUS_LABELS[e.name] ?? e.name}>
                    {data.statusData.map((entry, i) => (
                      <Cell key={i} fill={STATUS_COLORS[entry.name] ?? "#94A3B8"} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v: number, n: string) => [v, STATUS_LABELS[n] ?? n]} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {subKpis.map((c) => (
          <Card key={c.label} className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                <c.icon className="w-5 h-5 text-muted-foreground" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">{c.label}</div>
                <div className="text-lg font-bold">{c.value}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold">آخر الطلبات</h3>
          <Link to="/dashboard/orders" className="text-xs text-primary">عرض الكل</Link>
        </div>
        {data.recent.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground">
            <Clock className="w-10 h-10 mx-auto mb-2 opacity-50" />
            <div className="text-sm">لا توجد طلبات حديثة</div>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {data.recent.map((o) => (
              <Link key={o.id} to="/dashboard/orders/$orderId" params={{ orderId: o.id }} className="flex items-center justify-between py-3 hover:bg-muted/50 px-2 rounded">
                <div>
                  <div className="font-medium text-sm">{o.order_number}</div>
                  <div className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString("en-GB")}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs px-2 py-1 rounded-full" style={{ background: `${STATUS_COLORS[o.status] ?? "#94A3B8"}20`, color: STATUS_COLORS[o.status] ?? "#94A3B8" }}>
                    {STATUS_LABELS[o.status] ?? o.status}
                  </span>
                  <span className="font-bold text-sm">{Number(o.total_amount).toFixed(2)} ر.س</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
