import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { ShieldAlert, Plus, Save, Trash2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/permissions")({ component: PermissionsPage });

const MODULE_LABEL: Record<string, string> = {
  dashboard: "الرئيسية", orders: "الطلبات", customers: "العملاء", drivers: "السائقين",
  products: "المنتجات", categories: "الأقسام", addons: "الإضافات", branches: "الفروع",
  coupons: "الكوبونات", reports: "التقارير", banners: "البنرات والهيرو",
  content: "المحتوى", seo: "SEO", integrations: "التكاملات", settings: "الإعدادات",
  users: "المستخدمون", activity: "سجل النشاط",
};

type Role = { id: string; key: string; name: string; description: string | null; is_system: boolean };
type Perm = { key: string; name: string; module: string };

function PermissionsPage() {
  const { role, loading } = useAuth();
  const qc = useQueryClient();
  const isAdmin = role === "admin";

  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);
  const [openNew, setOpenNew] = useState(false);
  const [newRole, setNewRole] = useState({ key: "", name: "", description: "" });

  const { data: roles = [], isLoading: rolesLoading } = useQuery({
    queryKey: ["roles-all"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data, error } = await supabase.from("roles").select("*").order("is_system", { ascending: false }).order("name");
      if (error) throw error;
      return (data ?? []) as Role[];
    },
  });

  const { data: perms = [] } = useQuery({
    queryKey: ["perms-all"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data, error } = await supabase.from("permissions").select("key, name, module").order("module").order("key");
      if (error) throw error;
      return (data ?? []) as Perm[];
    },
  });

  const activeRole = roles.find((r) => r.id === selectedRoleId) ?? roles[0];
  const activeId = activeRole?.id;

  const { data: rolePerms = [] } = useQuery({
    queryKey: ["role-perms", activeId],
    enabled: !!activeId,
    queryFn: async () => {
      const { data, error } = await supabase.from("role_permissions").select("permission_key").eq("role_id", activeId!);
      if (error) throw error;
      return (data ?? []).map((x) => x.permission_key as string);
    },
  });

  const [pending, setPending] = useState<Set<string> | null>(null);
  const current = pending ?? new Set(rolePerms);

  const toggle = (key: string) => {
    const s = new Set(pending ?? rolePerms);
    if (s.has(key)) s.delete(key); else s.add(key);
    setPending(s);
  };

  const toggleModule = (module: string, on: boolean) => {
    const s = new Set(pending ?? rolePerms);
    perms.filter((p) => p.module === module).forEach((p) => { on ? s.add(p.key) : s.delete(p.key); });
    setPending(s);
  };

  const saveMut = useMutation({
    mutationFn: async () => {
      if (!activeId || !pending) return;
      await supabase.from("role_permissions").delete().eq("role_id", activeId);
      const rows = Array.from(pending).map((k) => ({ role_id: activeId, permission_key: k }));
      if (rows.length > 0) {
        const { error } = await supabase.from("role_permissions").insert(rows);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success("تم حفظ الصلاحيات");
      setPending(null);
      qc.invalidateQueries({ queryKey: ["role-perms"] });
      qc.invalidateQueries({ queryKey: ["my-permissions"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const createRoleMut = useMutation({
    mutationFn: async () => {
      if (!newRole.key || !newRole.name) throw new Error("المعرّف والاسم مطلوبان");
      const key = newRole.key.toLowerCase().replace(/[^a-z0-9_]/g, "_");
      const { error } = await supabase.from("roles").insert({ key, name: newRole.name, description: newRole.description || null, is_system: false });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("تم إنشاء الدور");
      setOpenNew(false);
      setNewRole({ key: "", name: "", description: "" });
      qc.invalidateQueries({ queryKey: ["roles-all"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteRoleMut = useMutation({
    mutationFn: async () => {
      if (!activeRole) return;
      if (activeRole.is_system) throw new Error("لا يمكن حذف دور نظام");
      const { error } = await supabase.from("roles").delete().eq("id", activeRole.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("تم الحذف");
      setSelectedRoleId(null);
      qc.invalidateQueries({ queryKey: ["roles-all"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (loading || rolesLoading) return <Skeleton className="h-96" />;
  if (!isAdmin) return <EmptyState icon={ShieldAlert} title="صلاحية المسؤول مطلوبة" description="إدارة الصلاحيات متاحة لحسابات المسؤول فقط." />;

  const grouped = perms.reduce<Record<string, Perm[]>>((acc, p) => {
    (acc[p.module] ??= []).push(p); return acc;
  }, {});

  return (
    <div className="space-y-6">
      <PageHeader
        title="الأدوار والصلاحيات"
        description="إدارة أدوار المستخدمين وتحديد الصلاحيات لكل دور."
        action={
          <Button onClick={() => setOpenNew(true)} className="bg-gradient-primary text-primary-foreground gap-1">
            <Plus className="w-4 h-4" /> دور جديد
          </Button>
        }
      />

      <div className="grid lg:grid-cols-[260px_1fr] gap-6">
        {/* Roles list */}
        <Card className="p-2 h-fit">
          {roles.length === 0 ? (
            <p className="p-4 text-sm text-muted-foreground">لا توجد أدوار</p>
          ) : (
            <ul className="space-y-1">
              {roles.map((r) => {
                const active = r.id === activeId;
                return (
                  <li key={r.id}>
                    <button
                      onClick={() => { setSelectedRoleId(r.id); setPending(null); }}
                      className={`w-full text-start p-3 rounded-lg flex items-center gap-2 transition ${active ? "bg-gradient-primary text-primary-foreground" : "hover:bg-muted"}`}
                    >
                      <ShieldCheck className="w-4 h-4 shrink-0" />
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium truncate">{r.name}</div>
                        <div className={`text-[10px] truncate ${active ? "opacity-80" : "text-muted-foreground"}`}>
                          {r.is_system ? "دور نظام" : "دور مخصص"} · {r.key}
                        </div>
                      </div>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        {/* Permission matrix */}
        {!activeRole ? (
          <Card className="p-12 text-center text-muted-foreground">اختر دوراً لعرض صلاحياته.</Card>
        ) : (
          <div className="space-y-4">
            <Card className="p-4 flex items-center justify-between flex-wrap gap-3">
              <div>
                <div className="font-bold">{activeRole.name}</div>
                <div className="text-xs text-muted-foreground">{activeRole.description || "—"}</div>
              </div>
              <div className="flex gap-2">
                {!activeRole.is_system && (
                  <Button variant="outline" onClick={() => { if (confirm("حذف هذا الدور؟")) deleteRoleMut.mutate(); }} className="gap-1">
                    <Trash2 className="w-4 h-4 text-destructive" /> حذف
                  </Button>
                )}
                <Button
                  disabled={!pending || saveMut.isPending}
                  onClick={() => saveMut.mutate()}
                  className="bg-gradient-primary text-primary-foreground gap-1"
                >
                  <Save className="w-4 h-4" /> {saveMut.isPending ? "جارٍ الحفظ..." : "حفظ التغييرات"}
                </Button>
              </div>
            </Card>

            {Object.entries(grouped).map(([module, list]) => {
              const allOn = list.every((p) => current.has(p.key));
              const someOn = list.some((p) => current.has(p.key));
              return (
                <Card key={module} className="overflow-hidden">
                  <div className="flex items-center justify-between p-3 bg-muted/40 border-b border-border">
                    <h3 className="font-bold text-sm">{MODULE_LABEL[module] ?? module}</h3>
                    <label className="flex items-center gap-2 text-xs cursor-pointer">
                      <Checkbox
                        checked={allOn ? true : someOn ? "indeterminate" : false}
                        onCheckedChange={(v) => toggleModule(module, !!v)}
                      />
                      تحديد الكل
                    </label>
                  </div>
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border">
                    {list.map((p) => {
                      const on = current.has(p.key);
                      return (
                        <label key={p.key} className="flex items-center gap-2 p-3 bg-card cursor-pointer hover:bg-muted/30">
                          <Checkbox checked={on} onCheckedChange={() => toggle(p.key)} />
                          <div className="min-w-0">
                            <div className="text-sm">{p.name}</div>
                            <div className="text-[10px] text-muted-foreground font-mono" dir="ltr">{p.key}</div>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <Dialog open={openNew} onOpenChange={setOpenNew}>
        <DialogContent>
          <DialogHeader><DialogTitle>إنشاء دور جديد</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label className="mb-1.5 block">المعرّف (إنجليزي بدون مسافات)</Label>
              <Input dir="ltr" value={newRole.key} onChange={(e) => setNewRole({ ...newRole, key: e.target.value })} placeholder="cashier" />
            </div>
            <div>
              <Label className="mb-1.5 block">اسم العرض</Label>
              <Input value={newRole.name} onChange={(e) => setNewRole({ ...newRole, name: e.target.value })} placeholder="كاشير" />
            </div>
            <div>
              <Label className="mb-1.5 block">الوصف (اختياري)</Label>
              <Input value={newRole.description} onChange={(e) => setNewRole({ ...newRole, description: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpenNew(false)}>إلغاء</Button>
            <Button disabled={createRoleMut.isPending} onClick={() => createRoleMut.mutate()} className="bg-gradient-primary text-primary-foreground">
              {createRoleMut.isPending ? "جارٍ..." : "إنشاء"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
