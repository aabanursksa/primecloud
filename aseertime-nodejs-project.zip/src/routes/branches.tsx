import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { useCart } from "@/lib/cart";
import { MapPin, Phone, Clock, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/branches")({
  component: BranchesPage,
});

function BranchesPage() {
  const { branchId, setBranchId } = useCart();
  const { data, isLoading } = useQuery({
    queryKey: ["public-branches"],
    queryFn: async () => (await supabase.from("branches").select("*").eq("is_active", true).order("display_order")).data ?? [],
  });

  return (
    <StoreLayout>
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">فروعنا</h1>
        {isLoading ? (
          <div className="text-center text-muted-foreground py-20">جارٍ التحميل...</div>
        ) : !data || data.length === 0 ? (
          <div className="text-center py-20">
            <MapPin className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <h3 className="font-bold">لا توجد فروع متاحة حالياً</h3>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.map((b) => {
              const selected = branchId === b.id;
              return (
                <div key={b.id} className={`bg-card border-2 rounded-2xl p-5 transition ${selected ? "border-primary" : "border-border"}`}>
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-bold text-lg">{b.name}</h3>
                      {b.address && <p className="text-sm text-muted-foreground mt-1 flex items-start gap-1"><MapPin className="w-4 h-4 mt-0.5 shrink-0" />{b.address}</p>}
                    </div>
                    {selected && <CheckCircle2 className="w-5 h-5 text-primary" />}
                  </div>
                  <div className="mt-4 space-y-2 text-sm">
                    {b.phone && <div className="flex items-center gap-2"><Phone className="w-4 h-4 text-muted-foreground" />{b.phone}</div>}
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <span className={b.accepts_orders ? "text-success" : "text-destructive"}>
                        {b.accepts_orders ? "● يستقبل الطلبات" : "● لا يستقبل الطلبات حالياً"}
                      </span>
                    </div>
                    {Number(b.delivery_fee) > 0 && (
                      <div className="text-xs text-muted-foreground">رسوم التوصيل: {Number(b.delivery_fee).toFixed(2)} ر.س</div>
                    )}
                    {Number(b.min_order_amount) > 0 && (
                      <div className="text-xs text-muted-foreground">الحد الأدنى: {Number(b.min_order_amount).toFixed(2)} ر.س</div>
                    )}
                  </div>
                  <button
                    onClick={() => {
                      setBranchId(selected ? null : b.id);
                      toast.success(selected ? "تم إلغاء اختيار الفرع" : `تم اختيار فرع ${b.name}`);
                    }}
                    className={`w-full mt-4 rounded-xl py-2 font-bold transition ${selected ? "bg-muted" : "bg-primary text-primary-foreground hover:bg-primary/90"}`}
                  >
                    {selected ? "إلغاء الاختيار" : "اختر هذا الفرع"}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </StoreLayout>
  );
}
