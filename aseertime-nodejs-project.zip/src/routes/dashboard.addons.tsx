import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PlusCircle, Plus, Pencil, Trash2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";

export const Route = createFileRoute("/dashboard/addons")({ component: AddonsPage });

type Group = { id?: string; name_ar: string; name_en: string; is_required: boolean; min_select: number; max_select: number; display_order: number };
const emptyGroup: Group = { name_ar: "", name_en: "", is_required: false, min_select: 0, max_select: 1, display_order: 0 };

type Option = { id?: string; group_id: string; name_ar: string; name_en: string; price: number; is_available: boolean; display_order: number };

function AddonsPage() {
  const qc = useQueryClient();
  const [openGroup, setOpenGroup] = useState(false);
  const [groupForm, setGroupForm] = useState<Group>(emptyGroup);
  const [openOpt, setOpenOpt] = useState(false);
  const [optForm, setOptForm] = useState<Option>({ group_id: "", name_ar: "", name_en: "", price: 0, is_available: true, display_order: 0 });

  const { data: groups = [], isLoading } = useQuery({
    queryKey: ["addon_groups"],
    queryFn: async () => {
      const { data, error } = await supabase.from("addon_groups").select("*, options:product_addons(*)").order("display_order");
      if (error) throw error;
      return data ?? [];
    },
  });

  const saveGroup = async () => {
    try {
      if (groupForm.id) {
        const { error } = await supabase.from("addon_groups").update(groupForm).eq("id", groupForm.id);
        if (error) throw error;
      } else {
        const { id: _i, ...ins } = groupForm; void _i;
        const { error } = await supabase.from("addon_groups").insert(ins);
        if (error) throw error;
      }
      toast.success("تم الحفظ");
      setOpenGroup(false);
      qc.invalidateQueries({ queryKey: ["addon_groups"] });
    } catch (e) { toast.error(e instanceof Error ? e.message : "فشل"); }
  };

  const saveOpt = async () => {
    try {
      if (optForm.id) {
        const { error } = await supabase.from("product_addons").update(optForm).eq("id", optForm.id);
        if (error) throw error;
      } else {
        const { id: _i, ...ins } = optForm; void _i;
        const { error } = await supabase.from("product_addons").insert(ins);
        if (error) throw error;
      }
      toast.success("تم الحفظ");
      setOpenOpt(false);
      qc.invalidateQueries({ queryKey: ["addon_groups"] });
    } catch (e) { toast.error(e instanceof Error ? e.message : "فشل"); }
  };

  const removeGroup = async (g: { id: string; name_ar: string }) => {
    if (!confirm(`حذف مجموعة "${g.name_ar}" وكل خياراتها؟`)) return;
    const { error } = await supabase.from("addon_groups").delete().eq("id", g.id);
    if (error) return toast.error(error.message);
    await logActivity("delete_addon_group", "addon_groups", g.id, { name: g.name_ar });
    qc.invalidateQueries({ queryKey: ["addon_groups"] });
  };
  const removeOpt = async (o: { id: string }) => {
    const { error } = await supabase.from("product_addons").delete().eq("id", o.id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["addon_groups"] });
  };

  return (
    <div>
      <PageHeader title="الإضافات" description="مجموعات الإضافات وخياراتها." action={
        <Button onClick={() => { setGroupForm(emptyGroup); setOpenGroup(true); }} className="bg-gradient-primary text-primary-foreground gap-2 shadow-glow"><Plus className="w-4 h-4" />إضافة مجموعة</Button>
      } />

      {isLoading ? <div className="text-muted-foreground">جارٍ التحميل...</div> :
       groups.length === 0 ? <EmptyState icon={PlusCircle} title="لا توجد إضافات" description="ابدأ بإنشاء مجموعة إضافات (مثل: حجم، إضافات فواكه...)." actionLabel="أضف مجموعة" onAction={() => { setGroupForm(emptyGroup); setOpenGroup(true); }} /> :
       <div className="space-y-4">{groups.map((g) => (
         <Card key={g.id} className="p-5">
           <div className="flex items-center justify-between mb-3">
             <div>
               <h3 className="font-bold">{g.name_ar} {g.name_en && <span className="text-xs text-muted-foreground" dir="ltr">({g.name_en})</span>}</h3>
               <div className="text-xs text-muted-foreground mt-1">
                 {g.is_required ? "إلزامي" : "اختياري"} · اختيار من {g.min_select} إلى {g.max_select}
               </div>
             </div>
             <div className="flex gap-1">
               <Button size="sm" variant="outline" onClick={() => { setOptForm({ group_id: g.id, name_ar: "", name_en: "", price: 0, is_available: true, display_order: 0 }); setOpenOpt(true); }}><Plus className="w-4 h-4 me-1" />خيار</Button>
               <Button size="icon" variant="ghost" onClick={() => { setGroupForm({ ...emptyGroup, ...g, name_en: g.name_en ?? "" }); setOpenGroup(true); }}><Pencil className="w-4 h-4" /></Button>
               <Button size="icon" variant="ghost" onClick={() => removeGroup(g)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
             </div>
           </div>
           <div className="grid md:grid-cols-2 gap-2">
             {(g.options ?? []).length === 0 ? <div className="text-sm text-muted-foreground col-span-2">لا توجد خيارات بعد.</div> :
              (g.options ?? []).map((o) => (
                <div key={o.id} className="flex items-center justify-between p-3 bg-muted/40 rounded-lg">
                  <div>
                    <div className="font-medium text-sm">{o.name_ar}</div>
                    <div className="text-xs text-muted-foreground">+{o.price} ر.س</div>
                  </div>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" onClick={() => { setOptForm({ ...o, name_en: o.name_en ?? "", group_id: g.id }); setOpenOpt(true); }}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => removeOpt(o)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </div>
                </div>))}
           </div>
         </Card>))}
       </div>}

      <Dialog open={openGroup} onOpenChange={setOpenGroup}>
        <DialogContent dir="rtl">
          <DialogHeader><DialogTitle>{groupForm.id ? "تعديل مجموعة" : "إضافة مجموعة"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label className="mb-1.5 block">الاسم العربي</Label><Input value={groupForm.name_ar} onChange={(e) => setGroupForm({ ...groupForm, name_ar: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الاسم الإنجليزي</Label><Input value={groupForm.name_en} onChange={(e) => setGroupForm({ ...groupForm, name_en: e.target.value })} dir="ltr" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label className="mb-1.5 block">الحد الأدنى</Label><Input type="number" value={groupForm.min_select} onChange={(e) => setGroupForm({ ...groupForm, min_select: parseInt(e.target.value) || 0 })} /></div>
              <div><Label className="mb-1.5 block">الحد الأعلى</Label><Input type="number" value={groupForm.max_select} onChange={(e) => setGroupForm({ ...groupForm, max_select: parseInt(e.target.value) || 1 })} /></div>
            </div>
            <div className="flex items-center gap-2"><Switch checked={groupForm.is_required} onCheckedChange={(v) => setGroupForm({ ...groupForm, is_required: v })} /><span className="text-sm">إلزامي</span></div>
          </div>
          <div className="flex justify-end gap-2 pt-4"><Button variant="ghost" onClick={() => setOpenGroup(false)}>إلغاء</Button><Button onClick={saveGroup} className="bg-gradient-primary text-primary-foreground">حفظ</Button></div>
        </DialogContent>
      </Dialog>

      <Dialog open={openOpt} onOpenChange={setOpenOpt}>
        <DialogContent dir="rtl">
          <DialogHeader><DialogTitle>{optForm.id ? "تعديل خيار" : "إضافة خيار"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label className="mb-1.5 block">الاسم العربي</Label><Input value={optForm.name_ar} onChange={(e) => setOptForm({ ...optForm, name_ar: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الاسم الإنجليزي</Label><Input value={optForm.name_en} onChange={(e) => setOptForm({ ...optForm, name_en: e.target.value })} dir="ltr" /></div>
            <div><Label className="mb-1.5 block">السعر</Label><Input type="number" step="0.01" value={optForm.price} onChange={(e) => setOptForm({ ...optForm, price: parseFloat(e.target.value) || 0 })} /></div>
            <div className="flex items-center gap-2"><Switch checked={optForm.is_available} onCheckedChange={(v) => setOptForm({ ...optForm, is_available: v })} /><span className="text-sm">متوفر</span></div>
          </div>
          <div className="flex justify-end gap-2 pt-4"><Button variant="ghost" onClick={() => setOpenOpt(false)}>إلغاء</Button><Button onClick={saveOpt} className="bg-gradient-primary text-primary-foreground">حفظ</Button></div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
