import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Image as ImageIcon, Plus, Pencil, Trash2, ArrowUp, ArrowDown, Eye } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { EmptyState } from "@/components/EmptyState";
import { SingleImageUpload } from "@/components/ImageUpload";
import { moveSort } from "@/lib/sortable";
import { DateField } from "@/components/DateField";

export const Route = createFileRoute("/dashboard/banners")({ component: BannersPage });

type Banner = {
  id: string;
  title: string;
  subtitle: string | null;
  image_url: string | null;
  cta_text: string | null;
  cta_url: string | null;
  link_type: "page" | "category" | "product" | "external" | "none";
  link_value: string | null;
  placement: "home" | "categories" | "product" | "offers" | "all";
  platform: "store" | "app" | "both";
  status: "active" | "inactive" | "scheduled" | "expired";
  start_date: string | null;
  end_date: string | null;
  sort_order: number;
  image_only: boolean;
};

const empty: Omit<Banner, "id" | "sort_order"> = {
  title: "", subtitle: "", image_url: "", cta_text: "", cta_url: "",
  link_type: "none", link_value: "", placement: "home", platform: "both",
  status: "active", start_date: null, end_date: null,
  image_only: false,
};

const PLACEMENT_LABEL: Record<Banner["placement"], string> = {
  home: "الرئيسية", categories: "الأقسام", product: "المنتج", offers: "العروض", all: "الكل",
};
const PLATFORM_LABEL: Record<Banner["platform"], string> = { store: "المتجر", app: "التطبيق", both: "الكل" };
const STATUS_LABEL: Record<Banner["status"], string> = {
  active: "نشط", inactive: "غير نشط", scheduled: "مجدول", expired: "منتهي",
};
const STATUS_CLS: Record<Banner["status"], string> = {
  active: "bg-success/10 text-success", inactive: "bg-muted text-foreground",
  scheduled: "bg-warning/10 text-warning", expired: "bg-destructive/10 text-destructive",
};

function BannersPage() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({
    queryKey: ["banners"],
    queryFn: async () => (await supabase.from("banners").select("*").order("sort_order")).data ?? [],
  });

  const [open, setOpen] = useState(false);
  const [preview, setPreview] = useState<Banner | null>(null);
  const [form, setForm] = useState<{ id?: string } & typeof empty>({ ...empty });

  const save = async () => {
    if (!form.image_only && !form.title.trim()) return toast.error("العنوان مطلوب");
    const payload: any = { ...form, start_date: form.start_date || null, end_date: form.end_date || null };
    if (form.id) {
      const { error } = await supabase.from("banners").update(payload).eq("id", form.id);
      if (error) return toast.error(error.message);
      toast.success("تم التحديث");
    } else {
      const max = data.reduce((m, b) => Math.max(m, b.sort_order), 0);
      payload.sort_order = max + 1;
      const { error } = await supabase.from("banners").insert(payload);
      if (error) return toast.error(error.message);
      toast.success("تم الإضافة");
    }
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["banners"] });
  };

  const remove = async (b: Banner) => {
    if (!confirm(`حذف "${b.title}"؟`)) return;
    const { error } = await supabase.from("banners").delete().eq("id", b.id);
    if (error) return toast.error(error.message);
    toast.success("تم الحذف");
    qc.invalidateQueries({ queryKey: ["banners"] });
  };

  const toggle = async (b: Banner) => {
    const next = b.status === "active" ? "inactive" : "active";
    const { error } = await supabase.from("banners").update({ status: next }).eq("id", b.id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["banners"] });
  };

  const move = async (id: string, dir: -1 | 1) => {
    await moveSort("banners", data, id, dir);
    qc.invalidateQueries({ queryKey: ["banners"] });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">البنرات</h1>
          <p className="text-sm text-muted-foreground">البنرات الترويجية في المتجر والتطبيق</p>
        </div>
        <Button onClick={() => { setForm({ ...empty }); setOpen(true); }} className="bg-gradient-primary text-primary-foreground shadow-glow">
          <Plus className="w-4 h-4 me-1" /> إضافة بنر
        </Button>
      </div>

      {isLoading ? (
        <Card className="p-12 text-center text-muted-foreground">جارٍ التحميل…</Card>
      ) : data.length === 0 ? (
        <EmptyState icon={ImageIcon} title="لا توجد بنرات بعد" description="ابدأ بإضافة أول بنر ترويجي." actionLabel="إضافة بنر" onAction={() => { setForm({ ...empty }); setOpen(true); }} />
      ) : (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-muted-foreground">
              <tr>
                <th className="p-3 text-start font-medium w-20">الترتيب</th>
                <th className="p-3 text-start font-medium">البنر</th>
                <th className="p-3 text-start font-medium">الموقع</th>
                <th className="p-3 text-start font-medium">المنصة</th>
                <th className="p-3 text-start font-medium">الحالة</th>
                <th className="p-3 text-start font-medium">التاريخ</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {data.map((b: Banner) => (
                <tr key={b.id} className="border-t border-border">
                  <td className="p-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => move(b.id, -1)} className="p-1 hover:bg-muted rounded"><ArrowUp className="w-3 h-3" /></button>
                      <span className="text-xs">{b.sort_order}</span>
                      <button onClick={() => move(b.id, 1)} className="p-1 hover:bg-muted rounded"><ArrowDown className="w-3 h-3" /></button>
                    </div>
                  </td>
                  <td className="p-3">
                    <div className="flex items-center gap-3">
                      {b.image_url ? <img src={b.image_url} alt="" className="w-16 h-10 rounded object-cover" /> : <div className="w-16 h-10 rounded bg-muted flex items-center justify-center"><ImageIcon className="w-4 h-4 text-muted-foreground" /></div>}
                      <div>
                        <div className="font-medium">{b.title}</div>
                        {b.subtitle && <div className="text-xs text-muted-foreground line-clamp-1">{b.subtitle}</div>}
                      </div>
                    </div>
                  </td>
                  <td className="p-3 text-xs">{PLACEMENT_LABEL[b.placement]}</td>
                  <td className="p-3 text-xs">{PLATFORM_LABEL[b.platform]}</td>
                  <td className="p-3"><button onClick={() => toggle(b)} className={`text-xs px-2 py-1 rounded font-medium ${STATUS_CLS[b.status]}`}>{STATUS_LABEL[b.status]}</button></td>
                  <td className="p-3 text-xs text-muted-foreground">
                    {b.start_date ? new Date(b.start_date).toLocaleDateString("en-GB") : "—"}<br />
                    {b.end_date ? new Date(b.end_date).toLocaleDateString("en-GB") : "—"}
                  </td>
                  <td className="p-3 flex gap-1 justify-end">
                    <Button size="icon" variant="ghost" onClick={() => setPreview(b)}><Eye className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => { setForm({ id: b.id, title: b.title, subtitle: b.subtitle ?? "", image_url: b.image_url ?? "", cta_text: b.cta_text ?? "", cta_url: b.cta_url ?? "", link_type: b.link_type, link_value: b.link_value ?? "", placement: b.placement, platform: b.platform, status: b.status, start_date: b.start_date?.slice(0, 10) ?? null, end_date: b.end_date?.slice(0, 10) ?? null, image_only: !!b.image_only }); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(b)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form.id ? "تعديل بنر" : "إضافة بنر"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <SingleImageUpload value={form.image_url ?? ""} onChange={(v) => setForm({ ...form, image_url: v })} folder="banners" label="صورة البنر (المقاس الموصى به: 1800×600px)" />
            <div className="flex items-center justify-between rounded-md border p-3">
              <div>
                <Label className="block">صورة فقط (إخفاء العنوان والزر)</Label>
                <p className="text-xs text-muted-foreground mt-0.5">يعرض البنر كصورة فقط بدون نصوص أو أزرار.</p>
              </div>
              <Switch checked={form.image_only} onCheckedChange={(v) => setForm({ ...form, image_only: v })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label className="mb-1.5 block">العنوان</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
              <div className="col-span-2"><Label className="mb-1.5 block">العنوان الفرعي</Label><Textarea rows={2} value={form.subtitle ?? ""} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">نص الزر CTA</Label><Input value={form.cta_text ?? ""} onChange={(e) => setForm({ ...form, cta_text: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">رابط الزر</Label><Input dir="ltr" value={form.cta_url ?? ""} onChange={(e) => setForm({ ...form, cta_url: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">نوع الرابط</Label>
                <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.link_type} onChange={(e) => setForm({ ...form, link_type: e.target.value as any })}>
                  <option value="none">— لا يوجد —</option>
                  <option value="page">صفحة</option>
                  <option value="category">قسم</option>
                  <option value="product">منتج</option>
                  <option value="external">خارجي</option>
                </select>
              </div>
              <div><Label className="mb-1.5 block">مكان الظهور</Label>
                <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.placement} onChange={(e) => setForm({ ...form, placement: e.target.value as any })}>
                  {Object.entries(PLACEMENT_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div><Label className="mb-1.5 block">المنصة</Label>
                <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.platform} onChange={(e) => setForm({ ...form, platform: e.target.value as any })}>
                  {Object.entries(PLATFORM_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div><Label className="mb-1.5 block">الحالة</Label>
                <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as any })}>
                  {Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div><Label className="mb-1.5 block">تاريخ البداية</Label><DateField value={form.start_date} onChange={(v) => setForm({ ...form, start_date: v })} /></div>
              <div><Label className="mb-1.5 block">تاريخ النهاية</Label><DateField value={form.end_date} onChange={(v) => setForm({ ...form, end_date: v })} /></div>
            </div>
            {form.image_url && (
              <div>
                <Label className="mb-1.5 block">معاينة</Label>
                <div className="relative rounded-xl overflow-hidden bg-muted aspect-[3/1]">
                  <img src={form.image_url} alt="" className="w-full h-full object-cover" />
                  {!form.image_only && (
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col justify-end p-4 text-white">
                      <div className="font-bold text-lg">{form.title || "العنوان"}</div>
                      {form.subtitle && <div className="text-sm opacity-90">{form.subtitle}</div>}
                      {form.cta_text && <button className="mt-2 self-start bg-primary px-3 py-1.5 rounded text-xs">{form.cta_text}</button>}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle>معاينة البنر</DialogTitle></DialogHeader>
          {preview && (
            <div className="relative rounded-xl overflow-hidden bg-muted aspect-[3/1]">
              {preview.image_url && <img src={preview.image_url} alt="" className="w-full h-full object-cover" />}
              {!preview.image_only && (
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col justify-end p-6 text-white">
                  <div className="font-bold text-2xl">{preview.title}</div>
                  {preview.subtitle && <div className="text-sm opacity-90 mt-1">{preview.subtitle}</div>}
                  {preview.cta_text && <button className="mt-3 self-start bg-primary px-4 py-2 rounded">{preview.cta_text}</button>}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
