import { createFileRoute, useSearch } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { ProductCard } from "@/components/store/ProductCard";
import { BranchSelector } from "@/components/store/BranchSelector";
import { Search, MapPin, X, UtensilsCrossed } from "lucide-react";
import { useCart } from "@/lib/cart";
import { useBranchUnavailableProducts } from "@/lib/branch-availability";

export const Route = createFileRoute("/menu")({
  validateSearch: (s: Record<string, unknown>) => ({ q: (s.q as string) || "" }),
  component: MenuPage,
});

function MenuPage() {
  const { q } = useSearch({ from: "/menu" });
  const [search, setSearch] = useState(q || "");
  const [activeCat, setActiveCat] = useState<string | null>(null);
  const [branchOpen, setBranchOpen] = useState(false);
  const { branchId } = useCart();
  const { data: unavailable } = useBranchUnavailableProducts(branchId);

  const { data, isLoading } = useQuery({
    queryKey: ["menu-all-v2"],
    queryFn: async () => {
      const [cats, prods, vars] = await Promise.all([
        supabase.from("product_categories").select("*").eq("show_in_store", true).eq("is_active", true).order("display_order"),
        supabase.from("products").select("*").eq("show_in_store", true).eq("is_archived", false),
        supabase.from("product_variants").select("product_id, price, is_available"),
      ]);
      // Build variant aggregates per product
      const variantAgg = new Map<string, { count: number; min: number }>();
      (vars.data ?? []).forEach((v: any) => {
        if (!v.is_available) return;
        const cur = variantAgg.get(v.product_id) || { count: 0, min: Infinity };
        cur.count += 1;
        cur.min = Math.min(cur.min, Number(v.price ?? 0));
        variantAgg.set(v.product_id, cur);
      });
      return { categories: cats.data ?? [], products: prods.data ?? [], variantAgg };
    },
  });

  const branchName = useQuery({
    queryKey: ["branch-name", branchId],
    queryFn: async () => {
      if (!branchId) return null;
      const { data } = await supabase.from("branches").select("name").eq("id", branchId).maybeSingle();
      return data?.name ?? null;
    },
  });

  // Sort: featured first, then display_order, then created_at desc
  const sortedProducts = useMemo(() => {
    const list = [...(data?.products ?? [])];
    list.sort((a: any, b: any) => {
      if ((b.is_featured ? 1 : 0) !== (a.is_featured ? 1 : 0)) return (b.is_featured ? 1 : 0) - (a.is_featured ? 1 : 0);
      const ao = a.display_order ?? 0, bo = b.display_order ?? 0;
      if (ao !== bo) return ao - bo;
      return new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime();
    });
    return list;
  }, [data?.products]);

  // Build category lookup for search-by-category
  const catNameById = useMemo(() => {
    const m = new Map<string, string>();
    (data?.categories ?? []).forEach((c: any) => m.set(c.id, c.name_ar?.toLowerCase() || ""));
    return m;
  }, [data?.categories]);

  // Counts per category (after branch filter, before search/cat filter)
  const countsByCat = useMemo(() => {
    const m = new Map<string, number>();
    sortedProducts.forEach((p: any) => {
      if (unavailable?.has(p.id)) return; // exclude unavailable in branch
      m.set(p.category_id, (m.get(p.category_id) || 0) + 1);
    });
    return m;
  }, [sortedProducts, unavailable]);

  const totalCount = useMemo(
    () => sortedProducts.filter((p: any) => !unavailable?.has(p.id)).length,
    [sortedProducts, unavailable]
  );

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    return sortedProducts.filter((p: any) => {
      // Hide products explicitly unavailable at the chosen branch
      if (branchId && unavailable?.has(p.id)) return false;
      if (activeCat && p.category_id !== activeCat) return false;
      if (s) {
        const catName = catNameById.get(p.category_id) || "";
        return (
          p.name_ar?.toLowerCase().includes(s) ||
          p.name_en?.toLowerCase().includes(s) ||
          p.description_ar?.toLowerCase().includes(s) ||
          p.description_en?.toLowerCase().includes(s) ||
          catName.includes(s)
        );
      }
      return true;
    });
  }, [sortedProducts, activeCat, search, branchId, unavailable, catNameById]);

  const cats = data?.categories ?? [];

  return (
    <StoreLayout>
      <BranchSelector open={branchOpen} onClose={() => setBranchOpen(false)} />

      <div className="container mx-auto px-4 py-6">
        {/* Header */}
        <div className="mb-5">
          <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
            <UtensilsCrossed className="w-6 h-6 text-primary" />
            المنيو
          </h1>
          <p className="text-sm text-muted-foreground mt-1">اختر من تشكيلتنا الطازجة من العصائر والمشروبات</p>
        </div>

        {/* Branch banner */}
        {!branchId ? (
          <button
            onClick={() => setBranchOpen(true)}
            className="w-full mb-5 flex items-center justify-between gap-3 bg-gradient-to-l from-primary/10 to-primary/5 border border-primary/30 rounded-2xl p-4 hover:border-primary transition text-right"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-full bg-primary/15 flex items-center justify-center text-primary shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-sm">اختر الفرع لعرض المنتجات المتاحة</div>
                <div className="text-xs text-muted-foreground">المنتجات قد تختلف حسب الفرع</div>
              </div>
            </div>
            <span className="shrink-0 bg-primary text-primary-foreground text-xs font-bold px-3 py-1.5 rounded-full">اختيار</span>
          </button>
        ) : (
          <button
            onClick={() => setBranchOpen(true)}
            className="w-full mb-5 flex items-center justify-between gap-3 bg-card border border-border rounded-2xl p-3 hover:border-primary/50 transition text-right"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-full bg-success/10 flex items-center justify-center text-success shrink-0">
                <MapPin className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="text-[11px] text-muted-foreground">الفرع المختار</div>
                <div className="font-bold text-sm truncate">{branchName.data || "..."}</div>
              </div>
            </div>
            <span className="shrink-0 text-xs text-primary font-medium">تغيير</span>
          </button>
        )}

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث عن منتج، قسم، أو نكهة..."
            className="w-full bg-card border border-border rounded-xl pe-10 ps-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute left-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-muted hover:bg-muted-foreground/20 flex items-center justify-center"
              aria-label="مسح البحث"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Sticky category chips */}
        {cats.length > 0 && (
          <div className="sticky top-14 sm:top-16 z-30 -mx-4 px-4 py-3 bg-background/85 backdrop-blur-md border-b border-border mb-5">
            <div className="flex gap-2 overflow-x-auto scrollbar-hide -mx-1 px-1">
              <button
                onClick={() => setActiveCat(null)}
                className={`shrink-0 px-4 py-2 rounded-full text-sm font-medium border transition ${
                  !activeCat
                    ? "bg-gradient-primary text-primary-foreground border-transparent shadow-sm"
                    : "bg-card border-border hover:border-primary/40"
                }`}
              >
                الكل
                <span className={`ms-1.5 text-[10px] ${!activeCat ? "opacity-90" : "text-muted-foreground"}`}>
                  ({totalCount})
                </span>
              </button>
              {cats.map((c: any) => {
                const count = countsByCat.get(c.id) || 0;
                if (count === 0 && branchId) return null; // hide empty cats when a branch filter is on
                const active = activeCat === c.id;
                return (
                  <button
                    key={c.id}
                    onClick={() => setActiveCat(c.id)}
                    className={`shrink-0 px-4 py-2 rounded-full text-sm font-medium border transition ${
                      active
                        ? "bg-gradient-primary text-primary-foreground border-transparent shadow-sm"
                        : "bg-card border-border hover:border-primary/40"
                    }`}
                  >
                    {c.name_ar}
                    <span className={`ms-1.5 text-[10px] ${active ? "opacity-90" : "text-muted-foreground"}`}>
                      ({count})
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Content */}
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-card border border-border rounded-2xl overflow-hidden">
                <div className="aspect-square bg-muted animate-pulse" />
                <div className="p-3 space-y-2">
                  <div className="h-4 bg-muted rounded animate-pulse" />
                  <div className="h-3 bg-muted rounded w-2/3 animate-pulse" />
                  <div className="h-8 bg-muted rounded animate-pulse mt-3" />
                </div>
              </div>
            ))}
          </div>
        ) : cats.length === 0 ? (
          <EmptyMessage title="لا توجد أقسام متاحة حالياً" subtitle="ستظهر الأقسام هنا فور إضافتها." />
        ) : filtered.length === 0 ? (
          <EmptyMessage
            title={
              search
                ? "لا توجد نتائج مطابقة"
                : activeCat
                ? "لا توجد منتجات في هذا القسم حالياً"
                : "لا توجد منتجات متاحة حالياً"
            }
            subtitle={search ? "جرّب كلمة أخرى أو تصفح الأقسام" : ""}
          />
        ) : (
          <>
            <div className="text-xs text-muted-foreground mb-3">
              {filtered.length} منتج
              {activeCat && cats.find((c: any) => c.id === activeCat) ? ` في "${(cats.find((c: any) => c.id === activeCat) as any).name_ar}"` : ""}
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
              {filtered.map((p: any) => {
                const agg = data?.variantAgg.get(p.id);
                return (
                  <ProductCard
                    key={p.id}
                    product={p}
                    unavailableInBranch={branchId ? unavailable?.has(p.id) : false}
                    minVariantPrice={agg?.min}
                    variantCount={agg?.count ?? 0}
                  />
                );
              })}
            </div>
          </>
        )}
      </div>
    </StoreLayout>
  );
}

function EmptyMessage({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="text-center py-20 bg-card/50 border border-dashed border-border rounded-2xl">
      <div className="w-16 h-16 rounded-full bg-muted mx-auto flex items-center justify-center text-muted-foreground mb-4">
        <UtensilsCrossed className="w-7 h-7" />
      </div>
      <h3 className="font-bold text-base">{title}</h3>
      {subtitle && <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>}
    </div>
  );
}
