import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { PageHeader } from "@/components/EmptyState";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";

export const Route = createFileRoute("/dashboard/settings")({ component: SettingsPage });

type StoreForm = {
  id?: string;
  name: string;
  logo_url: string;
  primary_color: string;
  secondary_color: string;
  phone: string;
  email: string;
  address: string;
  currency: string;
  vat_percent: number;
  delivery_fee: number;
  min_order_amount: number;
  accepting_orders: boolean;
};

const initial: StoreForm = {
  name: "", logo_url: "", primary_color: "#ED1C24", secondary_color: "#F97316",
  phone: "", email: "", address: "", currency: "SAR",
  vat_percent: 15, delivery_fee: 0, min_order_amount: 0, accepting_orders: true,
};

function SettingsPage() {
  const qc = useQueryClient();
  const [form, setForm] = useState<StoreForm>(initial);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["store_settings"],
    queryFn: async () => {
      const { data } = await supabase.from("store_settings").select("*").limit(1).maybeSingle();
      return data;
    },
  });

  useEffect(() => {
    if (data) {
      const norm = Object.fromEntries(Object.entries(data).map(([k, v]) => [k, v ?? ""])) as unknown as StoreForm;
      setForm({ ...initial, ...norm });
    }
  }, [data]);

  const set = <K extends keyof StoreForm>(k: K, v: StoreForm[K]) => setForm((f) => ({ ...f, [k]: v }));

  const handleLogo = async (file: File) => {
    setUploading(true);
    try {
      const ext = file.name.split(".").pop();
      const path = `logo/${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from("store-assets").upload(path, file, { upsert: true });
      if (error) throw error;
      const { data } = supabase.storage.from("store-assets").getPublicUrl(path);
      set("logo_url", data.publicUrl);
      toast.success("تم رفع الشعار");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل الرفع");
    } finally {
      setUploading(false);
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      const payload = { ...form };
      if (form.id) {
        const { error } = await supabase.from("store_settings").update(payload).eq("id", form.id);
        if (error) throw error;
      } else {
        const { id: _ignore, ...insertPayload } = payload;
        void _ignore;
        const { error } = await supabase.from("store_settings").insert(insertPayload);
        if (error) throw error;
      }
      await logActivity("update_settings", "store_settings", form.id, { name: form.name });
      toast.success("تم حفظ الإعدادات");
      qc.invalidateQueries({ queryKey: ["store_settings"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل الحفظ");
    } finally {
      setSaving(false);
    }
  };

  if (isLoading) return <div className="text-muted-foreground">جارٍ التحميل...</div>;

  return (
    <div className="max-w-4xl">
      <PageHeader title="إعدادات المتجر" description="إعدادات عامة للمتجر تظهر في التطبيق والمتجر الإلكتروني." />
      <Card className="p-6 space-y-6">
        <Section title="معلومات أساسية">
          <div className="grid md:grid-cols-2 gap-4">
            <Field label="اسم المتجر"><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></Field>
            <Field label="رقم الجوال"><Input value={form.phone} onChange={(e) => set("phone", e.target.value)} dir="ltr" /></Field>
            <Field label="البريد الإلكتروني"><Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} dir="ltr" /></Field>
            <Field label="العنوان"><Input value={form.address} onChange={(e) => set("address", e.target.value)} /></Field>
          </div>
        </Section>

        <Section title="الشعار والألوان">
          <div className="grid md:grid-cols-3 gap-4 items-end">
            <Field label="الشعار">
              <div className="flex items-center gap-3">
                {form.logo_url && <img src={form.logo_url} alt="" className="w-14 h-14 rounded-lg border" />}
                <input type="file" accept="image/*" onChange={(e) => e.target.files?.[0] && handleLogo(e.target.files[0])} disabled={uploading} className="text-sm" />
              </div>
            </Field>
            <Field label="اللون الأساسي"><Input type="color" value={form.primary_color} onChange={(e) => set("primary_color", e.target.value)} className="h-10" /></Field>
            <Field label="اللون الثانوي"><Input type="color" value={form.secondary_color} onChange={(e) => set("secondary_color", e.target.value)} className="h-10" /></Field>
          </div>
        </Section>

        <Section title="الإعدادات المالية">
          <div className="grid md:grid-cols-4 gap-4">
            <Field label="العملة"><Input value={form.currency} onChange={(e) => set("currency", e.target.value)} /></Field>
            <Field label="الضريبة %"><Input type="number" step="0.01" value={form.vat_percent} onChange={(e) => set("vat_percent", parseFloat(e.target.value) || 0)} /></Field>
            <Field label="رسوم التوصيل"><Input type="number" step="0.01" value={form.delivery_fee} onChange={(e) => set("delivery_fee", parseFloat(e.target.value) || 0)} /></Field>
            <Field label="الحد الأدنى للطلب"><Input type="number" step="0.01" value={form.min_order_amount} onChange={(e) => set("min_order_amount", parseFloat(e.target.value) || 0)} /></Field>
          </div>
        </Section>

        <Section title="استقبال الطلبات">
          <div className="flex items-center justify-between p-4 bg-muted/50 rounded-xl">
            <div>
              <div className="font-medium">المتجر يستقبل الطلبات</div>
              <div className="text-xs text-muted-foreground">عند الإيقاف لن يتمكن العملاء من إنشاء طلبات جديدة.</div>
            </div>
            <Switch checked={form.accepting_orders} onCheckedChange={(v) => set("accepting_orders", v)} />
          </div>
        </Section>

        <div className="flex justify-end pt-4 border-t">
          <Button onClick={save} disabled={saving} className="bg-gradient-primary text-primary-foreground shadow-glow">
            {saving ? "جارٍ الحفظ..." : "حفظ الإعدادات"}
          </Button>
        </div>
      </Card>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="text-sm font-bold text-muted-foreground mb-3">{title}</h3>
      {children}
    </div>
  );
}
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><Label className="mb-1.5 block">{label}</Label>{children}</div>;
}
// silence unused import warning for Textarea kept for future
void Textarea;
