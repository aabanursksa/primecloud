import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ArrowRight, Printer, Bell, X, CheckCircle2, Circle, Save } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { PageHeader } from "@/components/EmptyState";
import {
  ORDER_STATUS_LABEL,
  ORDER_STATUS_COLOR,
  ORDER_TYPE_LABEL,
  PAYMENT_LABEL,
  PAYMENT_STATUS_LABEL,
  DRIVER_STATUS_LABEL,
  DRIVER_STATUS_COLOR,
  StatusBadge,
} from "@/lib/orders";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";

export const Route = createFileRoute("/dashboard/orders/$orderId")({ component: OrderDetailPage });

// Allowed transitions per order_type. Keys are existing DB enum values.
const FLOW_PICKUP = ["new", "accepted", "preparing", "ready", "delivered"] as const;
const FLOW_DELIVERY = ["new", "accepted", "preparing", "ready", "awaiting_driver", "with_driver", "delivered"] as const;

function nextActions(status: string, type: "delivery" | "pickup", hasDriver: boolean): { to: string; label: string; variant?: "default" | "outline" }[] {
  if (type === "pickup") {
    switch (status) {
      case "new": return [{ to: "accepted", label: "قبول الطلب" }];
      case "accepted": return [{ to: "preparing", label: "بدء التجهيز" }];
      case "preparing": return [{ to: "ready", label: "جاهز للاستلام" }];
      case "ready": return [{ to: "delivered", label: "تم الاستلام / مكتمل" }];
      default: return [];
    }
  }
  // delivery
  switch (status) {
    case "new": return [{ to: "accepted", label: "قبول الطلب" }];
    case "accepted": return [{ to: "preparing", label: "بدء التجهيز" }];
    case "preparing": return [{ to: "ready", label: "تم التجهيز" }];
    case "ready": return [{ to: "awaiting_driver", label: "بانتظار السائق" }];
    case "awaiting_driver":
      return hasDriver
        ? [{ to: "with_driver", label: "السائق متجه للعميل" }]
        : []; // need driver first
    case "with_driver": return [{ to: "delivered", label: "تم التسليم" }];
    default: return [];
  }
}

function OrderDetailPage() {
  const { orderId } = Route.useParams();
  const qc = useQueryClient();
  const [pendingStatus, setPendingStatus] = useState<{ to: string; label: string } | null>(null);
  const [pendingNote, setPendingNote] = useState("");
  const [adminNotes, setAdminNotes] = useState<string>("");
  const [adminNotesDirty, setAdminNotesDirty] = useState(false);

  const { data: order, isLoading, error } = useQuery({
    queryKey: ["order", orderId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("*, customer:customers(*), branch:branches(*), driver:drivers(*), address:customer_addresses(*), items:order_items(*, addons:order_item_addons(*))")
        .eq("id", orderId)
        .maybeSingle();
      if (error) throw error;
      if (!data) throw new Error("not_found");
      // sync admin_notes locally
      setAdminNotes((data as { admin_notes?: string | null }).admin_notes ?? "");
      setAdminNotesDirty(false);
      return data;
    },
  });

  const { data: logs = [] } = useQuery({
    queryKey: ["order-logs", orderId],
    queryFn: async () =>
      (await supabase.from("order_status_logs").select("*").eq("order_id", orderId).order("created_at", { ascending: true })).data ?? [],
  });

  const { data: drivers = [] } = useQuery({
    queryKey: ["drivers-available", order?.branch_id],
    queryFn: async () => {
      let q = supabase.from("drivers").select("id,name,phone,status,branch_id,is_active").eq("is_active", true);
      if (order?.branch_id) q = q.or(`branch_id.eq.${order.branch_id},branch_id.is.null`);
      return (await q).data ?? [];
    },
    enabled: !!order,
  });

  const { data: customerOrdersCount = 0 } = useQuery({
    queryKey: ["customer-orders-count", order?.customer_id],
    queryFn: async () => {
      if (!order?.customer_id) return 0;
      const { count } = await supabase.from("orders").select("id", { count: "exact", head: true }).eq("customer_id", order.customer_id);
      return count ?? 0;
    },
    enabled: !!order?.customer_id,
  });

  useEffect(() => {
    if (error) {
      const msg = error instanceof Error ? error.message : "حدث خطأ";
      toast.error(msg === "not_found" ? "الطلب غير موجود" : `تعذّر تحميل الطلب: ${msg}`);
    }
  }, [error]);

  if (isLoading) return <div className="text-muted-foreground">جارٍ التحميل...</div>;
  if (error || !order) {
    return (
      <Card className="p-8 text-center">
        <h3 className="text-lg font-bold mb-2">الطلب غير موجود</h3>
        <Button asChild variant="outline" className="mt-4 gap-2">
          <Link to="/dashboard/orders"><ArrowRight className="w-4 h-4" />العودة للطلبات</Link>
        </Button>
      </Card>
    );
  }

  const o = order as typeof order & {
    customer: { id: string; name: string; phone: string; email: string | null } | null;
    branch: { name: string; phone: string | null; address: string | null } | null;
    driver: { id: string; name: string; phone: string; status: string } | null;
    address: { city: string | null; district: string | null; street: string | null; building: string | null; landmark: string | null; driver_notes: string | null } | null;
    items: Array<{ id: string; product_name: string; product_image: string | null; variant_name: string | null; quantity: number; unit_price: number; total_price: number; notes: string | null; addons: Array<{ id: string; addon_name: string; price: number }> }>;
    admin_notes: string | null;
  };

  const flow: readonly string[] = o.order_type === "pickup" ? FLOW_PICKUP : FLOW_DELIVERY;
  const currentIdx = flow.indexOf(o.status);
  const isTerminal = o.status === "delivered" || o.status === "cancelled" || o.status === "refunded";
  const actions = nextActions(o.status, o.order_type, !!o.driver_id);

  const applyStatus = async () => {
    if (!pendingStatus) return;
    const newStatus = pendingStatus.to;
    const updates: { status: string; admin_notes?: string } = { status: newStatus };
    if (pendingNote.trim()) {
      updates.admin_notes = `${o.admin_notes ? o.admin_notes + "\n" : ""}[${ORDER_STATUS_LABEL[newStatus]}] ${pendingNote.trim()}`;
    }
    const { error } = await supabase.from("orders").update(updates as never).eq("id", orderId);
    if (error) { toast.error(error.message); return; }
    // Insert status log explicitly with note (trigger may also insert one without note)
    if (pendingNote.trim()) {
      await supabase.from("order_status_logs").insert({ order_id: orderId, old_status: o.status as never, new_status: newStatus as never, note: pendingNote.trim() });
    }
    await logActivity("order_status_change", "orders", orderId, { from: o.status, to: newStatus, note: pendingNote || null });
    toast.success("تم تحديث حالة الطلب بنجاح");
    setPendingStatus(null);
    setPendingNote("");
    qc.invalidateQueries({ queryKey: ["order", orderId] });
    qc.invalidateQueries({ queryKey: ["order-logs", orderId] });
    qc.invalidateQueries({ queryKey: ["orders"] });
  };

  const assignDriver = async (driverId: string | null) => {
    const updates: { driver_id: string | null; status?: string } = { driver_id: driverId };
    // Auto-advance from awaiting_driver when assigning
    if (driverId && o.status === "awaiting_driver") {
      // keep status as awaiting_driver; admin will press "السائق متجه للعميل"
    }
    const { error } = await supabase.from("orders").update(updates as never).eq("id", orderId);
    if (error) { toast.error(error.message); return; }
    await logActivity(driverId ? "assign_driver" : "remove_driver", "orders", orderId, { driver_id: driverId });
    toast.success(driverId ? "تم تعيين السائق" : "تم إزالة السائق");
    qc.invalidateQueries({ queryKey: ["order", orderId] });
  };

  const cancel = () => setPendingStatus({ to: "cancelled", label: "إلغاء الطلب" });

  const sendNotification = async () => {
    await supabase.from("notifications").insert({
      title: "تحديث طلبك",
      message: `طلبك ${o.order_number} - ${ORDER_STATUS_LABEL[o.status]}`,
      type: "customer",
      action_url: `/track-order?order=${o.order_number}`,
    });
    toast.success("تم إرسال الإشعار");
  };

  const saveAdminNotes = async () => {
    const { error } = await supabase.from("orders").update({ admin_notes: adminNotes } as never).eq("id", orderId);
    if (error) { toast.error(error.message); return; }
    setAdminNotesDirty(false);
    toast.success("تم حفظ الملاحظة الإدارية");
    qc.invalidateQueries({ queryKey: ["order", orderId] });
  };

  return (
    <div>
      <PageHeader
        title={`الطلب ${o.order_number}`}
        description={new Date(o.created_at).toLocaleString("en-GB")}
        action={
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="ghost" size="sm" className="gap-2"><Link to="/dashboard/orders"><ArrowRight className="w-4 h-4" />العودة</Link></Button>
            <Button variant="outline" size="sm" className="gap-2" onClick={() => window.print()}><Printer className="w-4 h-4" />طباعة</Button>
            <Button variant="outline" size="sm" className="gap-2" onClick={sendNotification}><Bell className="w-4 h-4" />إرسال إشعار</Button>
            {!isTerminal && (
              <Button variant="outline" size="sm" className="gap-2 text-destructive" onClick={cancel}><X className="w-4 h-4" />إلغاء الطلب</Button>
            )}
          </div>
        }
      />

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          {/* Order Flow Stepper */}
          <Card className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold">مراحل الطلب</h3>
              <StatusBadge status={o.status} map={ORDER_STATUS_LABEL} color={ORDER_STATUS_COLOR} />
            </div>
            {o.status === "cancelled" ? (
              <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm font-medium">تم إلغاء الطلب</div>
            ) : (
              <div className="flex items-center gap-1 overflow-x-auto pb-2">
                {flow.map((s, i) => {
                  const done = i <= currentIdx;
                  return (
                    <div key={s} className="flex items-center gap-1 shrink-0">
                      <div className="flex flex-col items-center gap-1 min-w-[80px]">
                        {done ? <CheckCircle2 className="w-6 h-6 text-success" /> : <Circle className="w-6 h-6 text-muted-foreground" />}
                        <span className={`text-[11px] text-center ${done ? "font-bold" : "text-muted-foreground"}`}>{ORDER_STATUS_LABEL[s]}</span>
                      </div>
                      {i < flow.length - 1 && <div className={`h-0.5 w-6 ${i < currentIdx ? "bg-success" : "bg-border"}`} />}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Action buttons */}
            {!isTerminal && (
              <div className="flex flex-wrap gap-2 mt-5 pt-4 border-t border-border">
                {actions.length === 0 && o.order_type === "delivery" && o.status === "awaiting_driver" && !o.driver_id && (
                  <div className="text-sm text-warning bg-warning/10 px-3 py-2 rounded-lg">يجب تعيين سائق أولاً</div>
                )}
                {actions.map((a) => (
                  <Button key={a.to} onClick={() => { setPendingStatus(a); setPendingNote(""); }} className="gap-2">
                    {a.label}
                  </Button>
                ))}
              </div>
            )}
          </Card>

          {/* Items */}
          <Card className="p-5">
            <h3 className="font-bold mb-4">المنتجات</h3>
            <div className="divide-y divide-border">
              {o.items.map((it) => (
                <div key={it.id} className="py-3 flex gap-3">
                  {it.product_image && <img src={it.product_image} alt="" className="w-14 h-14 rounded-lg object-cover shrink-0" />}
                  <div className="flex-1 flex justify-between items-start gap-2">
                    <div className="min-w-0">
                      <div className="font-medium">{it.product_name}{it.variant_name && <span className="text-xs text-muted-foreground"> — {it.variant_name}</span>}</div>
                      {it.notes && <div className="text-xs text-muted-foreground mt-1">ملاحظة: {it.notes}</div>}
                      {it.addons.length > 0 && (
                        <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
                          {it.addons.map((a) => <li key={a.id}>+ {a.addon_name} ({Number(a.price).toFixed(2)} ر.س)</li>)}
                        </ul>
                      )}
                    </div>
                    <div className="text-end shrink-0">
                      <div className="text-sm">{it.quantity} × {Number(it.unit_price).toFixed(2)}</div>
                      <div className="font-bold">{Number(it.total_price).toFixed(2)} ر.س</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t pt-4 mt-4 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">المجموع الفرعي</span><span>{Number(o.subtotal).toFixed(2)} ر.س</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">الضريبة</span><span>{Number(o.vat_amount).toFixed(2)} ر.س</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">رسوم التوصيل</span><span>{Number(o.delivery_fee).toFixed(2)} ر.س</span></div>
              {Number(o.discount_amount) > 0 && <div className="flex justify-between text-success"><span>الخصم</span><span>-{Number(o.discount_amount).toFixed(2)} ر.س</span></div>}
              <div className="flex justify-between font-bold text-base border-t pt-2"><span>الإجمالي</span><span>{Number(o.total_amount).toFixed(2)} ر.س</span></div>
            </div>
            {o.customer_notes && <div className="mt-4 p-3 bg-muted/40 rounded-lg text-sm"><strong>ملاحظات العميل:</strong> {o.customer_notes}</div>}
          </Card>

          {/* Status Log Timeline */}
          <Card className="p-5">
            <h3 className="font-bold mb-4">سجل الحالات</h3>
            <div className="space-y-3">
              {logs.length === 0 ? <div className="text-sm text-muted-foreground">لا يوجد سجل بعد.</div> :
                logs.map((l) => (
                  <div key={l.id} className="flex items-start gap-3">
                    <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                    <div className="flex-1">
                      <div className="text-sm">
                        {l.old_status ? `${ORDER_STATUS_LABEL[l.old_status]} → ` : ""}<strong>{ORDER_STATUS_LABEL[l.new_status]}</strong>
                      </div>
                      {l.note && <div className="text-xs text-muted-foreground mt-1">{l.note}</div>}
                      <div className="text-xs text-muted-foreground">{new Date(l.created_at).toLocaleString("en-GB")}</div>
                    </div>
                  </div>
                ))}
            </div>
          </Card>

          {/* Admin notes */}
          <Card className="p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold">ملاحظات إدارية <span className="text-xs text-muted-foreground font-normal">(لا تظهر للعميل)</span></h3>
              <Button size="sm" variant="outline" className="gap-2" disabled={!adminNotesDirty} onClick={saveAdminNotes}>
                <Save className="w-4 h-4" />حفظ
              </Button>
            </div>
            <Textarea
              value={adminNotes}
              onChange={(e) => { setAdminNotes(e.target.value); setAdminNotesDirty(true); }}
              placeholder="أضف ملاحظة إدارية..."
              rows={3}
            />
          </Card>
        </div>

        <div className="space-y-4">
          {/* Customer */}
          <Card className="p-5">
            <h3 className="font-bold mb-3">العميل</h3>
            {o.customer ? (
              <div className="space-y-1 text-sm">
                <div className="font-medium">{o.customer.name}</div>
                <div className="text-muted-foreground" dir="ltr">{o.customer.phone}</div>
                {o.customer.email && <div className="text-muted-foreground" dir="ltr">{o.customer.email}</div>}
                <div className="text-xs text-muted-foreground pt-1">عدد الطلبات السابقة: {customerOrdersCount}</div>
                <Button asChild variant="link" size="sm" className="px-0">
                  <Link to="/dashboard/customers/$customerId" params={{ customerId: o.customer.id }}>عرض ملف العميل</Link>
                </Button>
              </div>
            ) : <div className="text-sm text-muted-foreground">{o.customer_name || "—"}</div>}
          </Card>

          {/* Branch & address */}
          <Card className="p-5">
            <h3 className="font-bold mb-3">الفرع والتوصيل</h3>
            <div className="space-y-2 text-sm">
              <div><span className="text-muted-foreground">الفرع: </span>{o.branch?.name ?? o.branch_name ?? "—"}</div>
              <div><span className="text-muted-foreground">النوع: </span>{ORDER_TYPE_LABEL[o.order_type]}</div>
              {o.order_type === "delivery" && o.address && (
                <div className="p-3 bg-muted/40 rounded-lg">
                  <div>{[o.address.city, o.address.district, o.address.street, o.address.building].filter(Boolean).join("، ")}</div>
                  {o.address.landmark && <div className="text-xs text-muted-foreground mt-1">المعلم: {o.address.landmark}</div>}
                  {o.address.driver_notes && <div className="text-xs text-muted-foreground mt-1">ملاحظات للسائق: {o.address.driver_notes}</div>}
                </div>
              )}
            </div>
          </Card>

          {/* Payment */}
          <Card className="p-5">
            <h3 className="font-bold mb-3">الدفع</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">طريقة</span><span>{PAYMENT_LABEL[o.payment_method]}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">الحالة</span><span>{PAYMENT_STATUS_LABEL[o.payment_status]}</span></div>
            </div>
          </Card>

          {/* Driver assignment */}
          {o.order_type === "delivery" && (
            <Card className="p-5">
              <h3 className="font-bold mb-3">السائق</h3>
              {o.driver ? (
                <div className="mb-3 p-3 bg-muted/40 rounded-lg flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm">{o.driver.name}</div>
                    <div className="text-xs text-muted-foreground" dir="ltr">{o.driver.phone}</div>
                    <div className="mt-1"><StatusBadge status={o.driver.status} map={DRIVER_STATUS_LABEL} color={DRIVER_STATUS_COLOR} /></div>
                  </div>
                  {!isTerminal && o.status !== "with_driver" && (
                    <Button size="sm" variant="ghost" onClick={() => assignDriver(null)}>إزالة</Button>
                  )}
                </div>
              ) : (
                <div className="text-sm text-muted-foreground mb-2">لا يوجد سائق معيّن</div>
              )}
              {!isTerminal && (
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {drivers.filter((d) => d.id !== o.driver?.id && d.status !== "suspended").map((d) => (
                    <button key={d.id} onClick={() => assignDriver(d.id)} className="w-full p-3 rounded-lg border border-border hover:bg-muted text-start flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">{d.name}</div>
                        <div className="text-xs text-muted-foreground" dir="ltr">{d.phone}</div>
                      </div>
                      <StatusBadge status={d.status} map={DRIVER_STATUS_LABEL} color={DRIVER_STATUS_COLOR} />
                    </button>
                  ))}
                  {drivers.length === 0 && <div className="text-sm text-muted-foreground text-center py-4">لا يوجد سائقون متاحون</div>}
                </div>
              )}
            </Card>
          )}
        </div>
      </div>

      {/* Confirm dialog */}
      <AlertDialog open={!!pendingStatus} onOpenChange={(open) => { if (!open) { setPendingStatus(null); setPendingNote(""); } }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد تغيير حالة الطلب</AlertDialogTitle>
            <AlertDialogDescription>
              هل تريد تغيير حالة الطلب من <strong>{ORDER_STATUS_LABEL[o.status]}</strong> إلى <strong>{pendingStatus ? ORDER_STATUS_LABEL[pendingStatus.to] ?? pendingStatus.label : ""}</strong>؟
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Textarea
            placeholder="ملاحظة (اختياري) — تظهر في سجل الحالات"
            value={pendingNote}
            onChange={(e) => setPendingNote(e.target.value)}
            rows={3}
          />
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={applyStatus}>تأكيد</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
