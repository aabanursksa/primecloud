import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plug, Plus, Pencil, Trash2, Webhook as WebhookIcon, CheckCircle2, AlertCircle, Send } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState, PageHeader } from "@/components/EmptyState";

export const Route = createFileRoute("/dashboard/integrations")({ component: IntegrationsPage });

type Integration = {
  id: string; name: string; provider: string;
  status: "published" | "inactive" | "draft";
  config: Record<string, string>;
  last_test_status: "success" | "failed" | "untested";
  last_tested_at: string | null;
  last_test_message: string | null;
};

type Webhook = {
  id: string; name: string; url: string; secret: string | null;
  events: string[]; status: "active" | "inactive";
};

const PROVIDERS = [
  { id: "tabby", name: "Tabby", fields: ["public_key", "secret_key"] },
  { id: "tamara", name: "Tamara", fields: ["api_token", "merchant_url"] },
  { id: "stcpay", name: "STC Pay", fields: ["merchant_id", "api_key"] },
  { id: "moyasar", name: "Moyasar", fields: ["publishable_key", "secret_key"] },
  { id: "mada", name: "Mada", fields: ["merchant_id", "terminal_id"] },
  { id: "twilio", name: "Twilio SMS", fields: ["account_sid", "auth_token", "from_number"] },
  { id: "unifonic", name: "Unifonic", fields: ["app_sid", "sender_name"] },
  { id: "google_maps", name: "Google Maps", fields: ["api_key"] },
  { id: "ga4", name: "Google Analytics 4", fields: ["measurement_id"] },
  { id: "meta_pixel", name: "Meta Pixel", fields: ["pixel_id"] },
  { id: "fcm", name: "Firebase Push", fields: ["server_key", "sender_id"] },
];

const EVENTS = ["order.created", "order.updated", "order.cancelled", "order.delivered", "customer.created", "coupon.used"];

function IntegrationsPage() {
  return (
    <>
      <PageHeader title="التكاملات و Webhooks" description="ربط خدمات خارجية واستقبال أحداث" />
      <Tabs defaultValue="integrations">
        <TabsList>
          <TabsTrigger value="integrations"><Plug className="w-4 h-4 ms-1" /> التكاملات</TabsTrigger>
          <TabsTrigger value="webhooks"><WebhookIcon className="w-4 h-4 ms-1" /> Webhooks</TabsTrigger>
        </TabsList>
        <TabsContent value="integrations"><IntegrationsTab /></TabsContent>
        <TabsContent value="webhooks"><WebhooksTab /></TabsContent>
      </Tabs>
    </>
  );
}

function IntegrationsTab() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({
    queryKey: ["integrations"],
    queryFn: async () => (await supabase.from("integrations").select("*").order("created_at")).data ?? [],
  });
  const [dialog, setDialog] = useState<Integration | null>(null);

  const create = () => setDialog({
    id: "", name: "", provider: PROVIDERS[0].id, status: "inactive",
    config: {}, last_test_status: "untested", last_tested_at: null, last_test_message: null,
  });

  const save = async () => {
    if (!dialog) return;
    if (!dialog.name.trim()) return toast.error("الاسم مطلوب");
    const { id, last_test_status, last_tested_at, last_test_message, ...rest } = dialog;
    const res = id
      ? await supabase.from("integrations").update(rest).eq("id", id)
      : await supabase.from("integrations").insert(rest);
    if (res.error) return toast.error(res.error.message);
    toast.success("تم الحفظ"); setDialog(null); qc.invalidateQueries({ queryKey: ["integrations"] });
  };
  const remove = async (id: string) => {
    if (!confirm("حذف التكامل؟")) return;
    const { error } = await supabase.from("integrations").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("تم الحذف"); qc.invalidateQueries({ queryKey: ["integrations"] });
  };
  const test = async (it: Integration) => {
    const provider = PROVIDERS.find((p) => p.id === it.provider);
    const ok = !!provider && provider.fields.every((f) => it.config?.[f]?.trim());
    const status = ok ? "success" : "failed";
    const message = ok ? "تم التحقق من الحقول المطلوبة" : "حقول مطلوبة ناقصة";
    await supabase.from("integrations").update({
      last_test_status: status, last_tested_at: new Date().toISOString(), last_test_message: message,
    }).eq("id", it.id);
    ok ? toast.success(message) : toast.error(message);
    qc.invalidateQueries({ queryKey: ["integrations"] });
  };

  if (isLoading) return <Skeleton className="h-96" />;

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={create} className="bg-gradient-primary text-primary-foreground gap-2"><Plus className="w-4 h-4" /> تكامل جديد</Button>
      </div>
      {data.length === 0 ? (
        <EmptyState icon={Plug} title="لا توجد تكاملات" description="أضف تكاملات الدفع، الإشعارات، أو التحليلات" actionLabel="تكامل جديد" onAction={create} />
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {(data as Integration[]).map((it) => {
            const provider = PROVIDERS.find((p) => p.id === it.provider);
            return (
              <Card key={it.id} className="p-5 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-bold">{it.name}</div>
                    <div className="text-xs text-muted-foreground">{provider?.name ?? it.provider}</div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded ${it.status === "published" ? "bg-success/10 text-success" : "bg-muted"}`}>
                    {it.status === "published" ? "نشط" : "غير نشط"}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  {it.last_test_status === "success" && <><CheckCircle2 className="w-3 h-3 text-success" /> <span className="text-success">اختبار ناجح</span></>}
                  {it.last_test_status === "failed" && <><AlertCircle className="w-3 h-3 text-destructive" /> <span className="text-destructive">{it.last_test_message}</span></>}
                  {it.last_test_status === "untested" && <span className="text-muted-foreground">لم يتم الاختبار</span>}
                  {it.last_tested_at && <span className="text-muted-foreground">— {new Date(it.last_tested_at).toLocaleString("en-GB")}</span>}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => test(it)} className="gap-1"><Send className="w-3 h-3" /> اختبار</Button>
                  <Button size="sm" variant="outline" onClick={() => setDialog(it)}><Pencil className="w-3 h-3" /></Button>
                  <Button size="sm" variant="outline" onClick={() => remove(it.id)} className="text-destructive"><Trash2 className="w-3 h-3" /></Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={!!dialog} onOpenChange={(o) => !o && setDialog(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{dialog?.id ? "تعديل تكامل" : "تكامل جديد"}</DialogTitle></DialogHeader>
          {dialog && (
            <div className="space-y-3">
              <div><Label>الاسم</Label><Input value={dialog.name} onChange={(e) => setDialog({ ...dialog, name: e.target.value })} /></div>
              <div><Label>المزود</Label>
                <select className="w-full border border-input rounded-md h-10 px-3 bg-background" value={dialog.provider} onChange={(e) => setDialog({ ...dialog, provider: e.target.value, config: {} })}>
                  {PROVIDERS.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              {(PROVIDERS.find((p) => p.id === dialog.provider)?.fields ?? []).map((f) => (
                <div key={f}><Label>{f}</Label>
                  <Input type={f.includes("secret") || f.includes("token") || f.includes("key") ? "password" : "text"}
                    value={dialog.config[f] ?? ""}
                    onChange={(e) => setDialog({ ...dialog, config: { ...dialog.config, [f]: e.target.value } })} />
                </div>
              ))}
              <div className="flex items-center justify-between"><Label>تفعيل</Label>
                <Switch checked={dialog.status === "published"} onCheckedChange={(v) => setDialog({ ...dialog, status: v ? "published" : "inactive" })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog(null)}>إلغاء</Button>
            <Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function WebhooksTab() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({
    queryKey: ["webhooks"],
    queryFn: async () => (await supabase.from("webhooks").select("*").order("created_at")).data ?? [],
  });
  const { data: logs = [] } = useQuery({
    queryKey: ["webhook_logs"],
    queryFn: async () => (await supabase.from("webhook_logs").select("*").order("created_at", { ascending: false }).limit(20)).data ?? [],
  });
  const [dialog, setDialog] = useState<Webhook | null>(null);

  const create = () => setDialog({ id: "", name: "", url: "", secret: "", events: [], status: "active" });
  const save = async () => {
    if (!dialog || !dialog.name.trim() || !dialog.url.trim()) return toast.error("الاسم والرابط مطلوبان");
    const { id, ...rest } = dialog;
    const res = id ? await supabase.from("webhooks").update(rest).eq("id", id) : await supabase.from("webhooks").insert(rest);
    if (res.error) return toast.error(res.error.message);
    toast.success("تم الحفظ"); setDialog(null); qc.invalidateQueries({ queryKey: ["webhooks"] });
  };
  const remove = async (id: string) => {
    if (!confirm("حذف الـ webhook؟")) return;
    await supabase.from("webhook_logs").delete().eq("webhook_id", id);
    const { error } = await supabase.from("webhooks").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("تم الحذف"); qc.invalidateQueries({ queryKey: ["webhooks"] });
  };

  if (isLoading) return <Skeleton className="h-96" />;

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={create} className="bg-gradient-primary text-primary-foreground gap-2"><Plus className="w-4 h-4" /> Webhook جديد</Button>
      </div>
      {data.length === 0 ? (
        <EmptyState icon={WebhookIcon} title="لا توجد Webhooks" description="استقبل أحداث الطلبات في خدمات خارجية" actionLabel="إضافة" onAction={create} />
      ) : (
        <div className="space-y-2">
          {(data as Webhook[]).map((w) => (
            <Card key={w.id} className="p-4 flex items-center gap-3">
              <WebhookIcon className="w-5 h-5 text-primary" />
              <div className="flex-1 min-w-0">
                <div className="font-medium">{w.name}</div>
                <div className="text-xs text-muted-foreground truncate font-mono">{w.url}</div>
                <div className="flex gap-1 mt-1 flex-wrap">
                  {w.events.map((e) => <span key={e} className="text-[10px] px-1.5 py-0.5 rounded bg-muted">{e}</span>)}
                </div>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded ${w.status === "active" ? "bg-success/10 text-success" : "bg-muted"}`}>{w.status === "active" ? "نشط" : "متوقف"}</span>
              <button onClick={() => setDialog(w)} className="p-2"><Pencil className="w-3 h-3" /></button>
              <button onClick={() => remove(w.id)} className="p-2 text-destructive"><Trash2 className="w-3 h-3" /></button>
            </Card>
          ))}
        </div>
      )}

      {logs.length > 0 && (
        <Card className="p-4">
          <h3 className="font-bold mb-3">آخر السجلات</h3>
          <div className="space-y-1 text-sm">
            {(logs as any[]).map((l) => (
              <div key={l.id} className="flex items-center gap-3 p-2 border-b last:border-0 text-xs">
                <span className={`px-2 py-0.5 rounded ${l.response_status && l.response_status < 400 ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"}`}>{l.response_status ?? "—"}</span>
                <span className="font-mono">{l.event}</span>
                <span className="text-muted-foreground ms-auto">{new Date(l.created_at).toLocaleString("en-GB")}</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Dialog open={!!dialog} onOpenChange={(o) => !o && setDialog(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{dialog?.id ? "تعديل Webhook" : "Webhook جديد"}</DialogTitle></DialogHeader>
          {dialog && (
            <div className="space-y-3">
              <div><Label>الاسم</Label><Input value={dialog.name} onChange={(e) => setDialog({ ...dialog, name: e.target.value })} /></div>
              <div><Label>الرابط (URL)</Label><Input value={dialog.url} onChange={(e) => setDialog({ ...dialog, url: e.target.value })} placeholder="https://..." /></div>
              <div><Label>السر (Signing secret)</Label><Input type="password" value={dialog.secret ?? ""} onChange={(e) => setDialog({ ...dialog, secret: e.target.value })} /></div>
              <div>
                <Label>الأحداث</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {EVENTS.map((e) => (
                    <label key={e} className="flex items-center gap-2 text-sm p-2 border rounded">
                      <input type="checkbox" checked={dialog.events.includes(e)} onChange={(ev) => setDialog({
                        ...dialog,
                        events: ev.target.checked ? [...dialog.events, e] : dialog.events.filter((x) => x !== e),
                      })} />
                      <span className="font-mono text-xs">{e}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-between"><Label>نشط</Label>
                <Switch checked={dialog.status === "active"} onCheckedChange={(v) => setDialog({ ...dialog, status: v ? "active" : "inactive" })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog(null)}>إلغاء</Button>
            <Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
