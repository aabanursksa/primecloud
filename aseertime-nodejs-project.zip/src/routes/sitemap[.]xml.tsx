import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const origin = `${url.protocol}//${url.host}`;

        const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
        const supabaseKey = process.env.VITE_SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_PUBLISHABLE_KEY || "";
        const supabase = createClient(supabaseUrl!, supabaseKey);

        const [pages, categories, products, seos] = await Promise.all([
          supabase.from("pages").select("slug, updated_at").eq("status", "published"),
          supabase.from("product_categories").select("id, updated_at").eq("show_in_store", true).eq("is_active", true),
          supabase.from("products").select("id, updated_at").eq("show_in_store", true).eq("is_archived", false),
          supabase.from("seo_settings").select("entity_type, entity_id, sitemap_enabled, robots_index"),
        ]);

        const seoMap = new Map<string, { sitemap_enabled: boolean; robots_index: boolean }>();
        (seos.data ?? []).forEach((s: any) => {
          if (s.entity_id) seoMap.set(`${s.entity_type}:${s.entity_id}`, s);
        });

        const entries: { loc: string; lastmod?: string }[] = [];
        entries.push({ loc: `${origin}/` });
        entries.push({ loc: `${origin}/menu` });

        (pages.data ?? []).forEach((p: any) => {
          const seo = (seos.data ?? []).find((s: any) => s.entity_type === "page" && s.slug === p.slug);
          if (seo && (seo.sitemap_enabled === false || seo.robots_index === false)) return;
          entries.push({ loc: `${origin}/pages/${p.slug}`, lastmod: p.updated_at });
        });
        (categories.data ?? []).forEach((c: any) => {
          const seo = seoMap.get(`category:${c.id}`);
          if (seo && (seo.sitemap_enabled === false || seo.robots_index === false)) return;
          entries.push({ loc: `${origin}/menu/${c.id}`, lastmod: c.updated_at });
        });
        (products.data ?? []).forEach((pr: any) => {
          const seo = seoMap.get(`product:${pr.id}`);
          if (seo && (seo.sitemap_enabled === false || seo.robots_index === false)) return;
          entries.push({ loc: `${origin}/product/${pr.id}`, lastmod: pr.updated_at });
        });

        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${entries
  .map(
    (e) =>
      `  <url><loc>${e.loc}</loc>${e.lastmod ? `<lastmod>${new Date(e.lastmod).toISOString()}</lastmod>` : ""}</url>`,
  )
  .join("\n")}
</urlset>`;

        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml; charset=utf-8",
            "Cache-Control": "public, max-age=300",
          },
        });
      },
    },
  },
});
