import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Save } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/EmptyState";
import { SingleImageUpload } from "@/components/ImageUpload";

export const Route = createFileRoute("/dashboard/footer")({ component: FooterPage });

type Footer = {
  id?: string;
  logo_url: string | null;
  about_text: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  working_hours: string | null;
  app_store_url: string | null;
  google_play_url: string | null;
  copyright_text: string | null;
  social_links: Record<string, string>;
  visible_sections: { about: boolean; links: boolean; contact: boolean; social: boolean; apps: boolean };
};

const SOCIALS = ["instagram", "twitter", "facebook", "tiktok", "snapchat", "youtube"] as const;

function FooterPage() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["footer_settings"],
    queryFn: async () => (await supabase.from("footer_settings").select("*").maybeSingle()).data,
  });
  const [form, setForm] = useState<Footer | null>(null);
  useEffect(() => {
    if (data) setForm({ ...(data as any), social_links: (data as any).social_links ?? {}, visible_sections: (data as any).visible_sections ?? { about: true, links: true, contact: true, social: true, apps: true } });
    else if (!isLoading) setForm({
      logo_url: "", about_text: "", phone: "", email: "", address: "", working_hours: "",
      app_store_url: "", google_play_url: "", copyright_text: "", social_links: {},
      visible_sections: { about: true, links: true, contact: true, social: true, apps: true },
    });
  }, [data, isLoading]);

  const save = async () => {
    if (!form) return;
    const res = form.id
      ? await supabase.from("footer_settings").update(form).eq("id", form.id)
      : await supabase.from("footer_settings").insert(form);
    if (res.error) return toast.error(res.error.message);
    toast.success("تم حفظ الفوتر");
    qc.invalidateQueries({ queryKey: ["footer_settings"] });
  };

  if (isLoading || !form) return <Skeleton className="h-96" />;

  return (
    <>
      <PageHeader title="إدارة الفوتر" description="معلومات تظهر أسفل صفحات الموقع" action={
        <Button onClick={save} className="bg-gradient-primary text-primary-foreground gap-2"><Save className="w-4 h-4" /> حفظ</Button>
      } />
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="p-6 space-y-4">
          <h3 className="font-bold">المعلومات الأساسية</h3>
          <div><Label>شعار الفوتر</Label><SingleImageUpload value={form.logo_url ?? ""} onChange={(u) => setForm({ ...form, logo_url: u })} folder="footer" /></div>
          <div><Label>نبذة عنا</Label><Textarea rows={3} value={form.about_text ?? ""} onChange={(e) => setForm({ ...form, about_text: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>الهاتف</Label><Input value={form.phone ?? ""} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div><Label>البريد</Label><Input value={form.email ?? ""} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
          </div>
          <div><Label>العنوان</Label><Input value={form.address ?? ""} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
          <div><Label>ساعات العمل</Label><Input value={form.working_hours ?? ""} onChange={(e) => setForm({ ...form, working_hours: e.target.value })} /></div>
          <div><Label>نص حقوق النشر</Label><Input value={form.copyright_text ?? ""} onChange={(e) => setForm({ ...form, copyright_text: e.target.value })} /></div>
        </Card>

        <div className="space-y-6">
          <Card className="p-6 space-y-4">
            <h3 className="font-bold">الأقسام الظاهرة</h3>
            {(Object.keys(form.visible_sections) as (keyof Footer["visible_sections"])[]).map((k) => (
              <div key={k} className="flex items-center justify-between">
                <Label>{({ about: "نبذة", links: "روابط", contact: "تواصل", social: "السوشيال", apps: "روابط التطبيقات" } as const)[k]}</Label>
                <Switch checked={form.visible_sections[k]} onCheckedChange={(v) => setForm({ ...form, visible_sections: { ...form.visible_sections, [k]: v } })} />
              </div>
            ))}
          </Card>

          <Card className="p-6 space-y-4">
            <h3 className="font-bold">روابط السوشيال</h3>
            {SOCIALS.map((s) => (
              <div key={s}>
                <Label className="capitalize">{s}</Label>
                <Input value={form.social_links[s] ?? ""} onChange={(e) => setForm({ ...form, social_links: { ...form.social_links, [s]: e.target.value } })} />
              </div>
            ))}
          </Card>

          <Card className="p-6 space-y-4">
            <h3 className="font-bold">روابط التطبيقات</h3>
            <div><Label>App Store</Label><Input value={form.app_store_url ?? ""} onChange={(e) => setForm({ ...form, app_store_url: e.target.value })} /></div>
            <div><Label>Google Play</Label><Input value={form.google_play_url ?? ""} onChange={(e) => setForm({ ...form, google_play_url: e.target.value })} /></div>
          </Card>
        </div>
      </div>
    </>
  );
}
