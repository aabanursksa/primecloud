import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import * as XLSX from "xlsx";
import { Upload, FileSpreadsheet, CheckCircle2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/EmptyState";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";

export const Route = createFileRoute("/dashboard/import")({ component: ImportPage });

type Row = Record<string, unknown>;
type Parsed = { sheets: { name: string; rows: Row[] }[]; filename: string };

const COL = {
  nameAr: ["Name in Arabic", "اسم المنتج", "Name AR"],
  nameEn: ["Name in English", "Name EN"],
  descAr: ["Description Arabic", "الوصف"],
  descEn: ["Description English"],
  calories: ["Calories", "السعرات"],
  price: ["APP Price with VAT", "السعر", "Price"],
  options: ["Options or Add ons", "Add ons", "Options"],
  optPrices: ["Prices for add ons", "Add on Prices"],
  category: ["Category", "القسم"],
  prepTime: ["Preparation Time", "وقت التحضير"],
};

function pick(row: Row, keys: string[]): string {
  for (const k of keys) {
    const found = Object.keys(row).find((rk) => rk.trim().toLowerCase() === k.trim().toLowerCase());
    if (found && row[found] != null && String(row[found]).trim() !== "") return String(row[found]).trim();
  }
  return "";
}

function ImportPage() {
  const [parsed, setParsed] = useState<Parsed | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ created: number; updated: number; categoriesCreated: number; addons: number; errors: string[] } | null>(null);

  const onFile = async (file: File) => {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array" });
    const sheets = wb.SheetNames.map((name) => ({
      name,
      rows: XLSX.utils.sheet_to_json<Row>(wb.Sheets[name], { defval: "" }),
    }));
    setParsed({ sheets, filename: file.name });
    setResult(null);
  };

  const runImport = async () => {
    if (!parsed) return;
    setBusy(true);
    const errors: string[] = [];
    let created = 0, updated = 0, categoriesCreated = 0, addonsCount = 0;

    try {
      // 1. Categories: from sheet name (excluding EXTRA) or Category column
      const catNames = new Set<string>();
      for (const s of parsed.sheets) {
        if (s.name.toUpperCase() === "EXTRA") continue;
        for (const r of s.rows) {
          const cat = pick(r, COL.category) || s.name;
          if (cat) catNames.add(cat);
        }
      }

      // Existing cats
      const { data: existingCats } = await supabase.from("product_categories").select("id, name_ar");
      const catMap = new Map<string, string>();
      (existingCats ?? []).forEach((c) => catMap.set(c.name_ar.toLowerCase(), c.id));

      for (const name of catNames) {
        if (!catMap.has(name.toLowerCase())) {
          const { data, error } = await supabase.from("product_categories").insert({ name_ar: name, display_order: 0 }).select().single();
          if (error) errors.push(`قسم "${name}": ${error.message}`);
          else { catMap.set(name.toLowerCase(), data.id); categoriesCreated++; }
        }
      }

      // 2. Products
      for (const s of parsed.sheets) {
        if (s.name.toUpperCase() === "EXTRA") continue;
        for (const r of s.rows) {
          const nameAr = pick(r, COL.nameAr);
          if (!nameAr) continue;
          const catName = pick(r, COL.category) || s.name;
          const cat_id = catMap.get(catName.toLowerCase()) ?? null;

          const payload = {
            name_ar: nameAr,
            name_en: pick(r, COL.nameEn) || null,
            description_ar: pick(r, COL.descAr) || null,
            description_en: pick(r, COL.descEn) || null,
            calories: parseInt(pick(r, COL.calories)) || null,
            base_price: parseFloat(pick(r, COL.price)) || 0,
            prep_time_minutes: parseInt(pick(r, COL.prepTime)) || null,
            category_id: cat_id,
          };

          const baseQuery = supabase.from("products").select("id").eq("name_ar", nameAr);
          const { data: existing } = await (cat_id ? baseQuery.eq("category_id", cat_id) : baseQuery.is("category_id", null)).maybeSingle();

          if (existing) {
            const { error } = await supabase.from("products").update(payload).eq("id", existing.id);
            if (error) errors.push(`منتج "${nameAr}": ${error.message}`);
            else updated++;
          } else {
            const { error } = await supabase.from("products").insert(payload);
            if (error) errors.push(`منتج "${nameAr}": ${error.message}`);
            else created++;
          }
        }
      }

      // 3. EXTRA sheet → addon group + options
      const extra = parsed.sheets.find((s) => s.name.toUpperCase() === "EXTRA");
      if (extra && extra.rows.length > 0) {
        const groupName = "إضافات عامة";
        const { data: existGroup } = await supabase.from("addon_groups").select("id").eq("name_ar", groupName).maybeSingle();
        let groupId = existGroup?.id;
        if (!groupId) {
          const { data: g, error } = await supabase.from("addon_groups").insert({ name_ar: groupName, min_select: 0, max_select: 99 }).select().single();
          if (error) errors.push(`مجموعة الإضافات: ${error.message}`);
          else groupId = g.id;
        }
        if (groupId) {
          for (const r of extra.rows) {
            const nm = pick(r, [...COL.options, ...COL.nameAr]);
            const pr = parseFloat(pick(r, [...COL.optPrices, ...COL.price])) || 0;
            if (!nm) continue;
            const { data: existOpt } = await supabase.from("product_addons").select("id").eq("group_id", groupId).eq("name_ar", nm).maybeSingle();
            if (existOpt) {
              await supabase.from("product_addons").update({ price: pr }).eq("id", existOpt.id);
            } else {
              await supabase.from("product_addons").insert({ group_id: groupId, name_ar: nm, price: pr });
              addonsCount++;
            }
          }
        }
      }

      const summary = { created, updated, categoriesCreated, addons: addonsCount, errors };
      await supabase.from("import_logs").insert({
        filename: parsed.filename,
        summary,
        errors,
        user_id: (await supabase.auth.getUser()).data.user?.id ?? null,
      });
      await logActivity("import_excel", "import_logs", null, summary);
      setResult(summary);
      toast.success(`تم: ${created} منتج جديد، ${updated} تحديث`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل الاستيراد");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <PageHeader title="استيراد المنيو من Excel" description="ارفع ملف Excel لاستيراد المنتجات والأقسام والإضافات." />

      {!parsed && (
        <Card className="p-12">
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-soft flex items-center justify-center mb-4">
              <Upload className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-lg font-bold mb-2">اختر ملف Excel</h3>
            <p className="text-sm text-muted-foreground mb-5 max-w-md">
              الأعمدة المتوقعة: Name in Arabic, Name in English, Calories, APP Price with VAT, Category, Preparation Time…
            </p>
            <label className="cursor-pointer">
              <input type="file" accept=".xlsx,.xls" className="hidden" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} />
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-gradient-primary text-primary-foreground shadow-glow text-sm font-medium">
                <Upload className="w-4 h-4" /> اختر ملف
              </span>
            </label>
          </div>
        </Card>
      )}

      {parsed && (
        <div className="space-y-4">
          <Card className="p-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileSpreadsheet className="w-8 h-8 text-primary" />
              <div>
                <div className="font-bold">{parsed.filename}</div>
                <div className="text-xs text-muted-foreground">{parsed.sheets.length} شيت · {parsed.sheets.reduce((s, sh) => s + sh.rows.length, 0)} صف</div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={() => { setParsed(null); setResult(null); }}>تغيير الملف</Button>
              <Button onClick={runImport} disabled={busy} className="bg-gradient-primary text-primary-foreground shadow-glow">
                {busy ? "جارٍ الاستيراد..." : "بدء الاستيراد"}
              </Button>
            </div>
          </Card>

          {parsed.sheets.map((s) => (
            <Card key={s.name} className="overflow-hidden">
              <div className="p-3 bg-muted/50 font-bold text-sm">{s.name} <span className="text-muted-foreground">({s.rows.length})</span></div>
              {s.rows.length > 0 && (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead><tr>{Object.keys(s.rows[0]).slice(0, 8).map((k) => <th key={k} className="text-start p-2 border-b">{k}</th>)}</tr></thead>
                    <tbody>{s.rows.slice(0, 5).map((r, i) => (
                      <tr key={i} className="border-b">{Object.keys(s.rows[0]).slice(0, 8).map((k) => <td key={k} className="p-2 text-muted-foreground">{String(r[k] ?? "")}</td>)}</tr>
                    ))}</tbody>
                  </table>
                  {s.rows.length > 5 && <div className="p-2 text-xs text-muted-foreground text-center">…و {s.rows.length - 5} صف آخر</div>}
                </div>
              )}
            </Card>
          ))}

          {result && (
            <Card className="p-5 border-success/30 bg-success/5">
              <div className="flex items-center gap-3 mb-3">
                <CheckCircle2 className="w-6 h-6 text-success" />
                <div className="font-bold">اكتمل الاستيراد</div>
              </div>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>منتجات جديدة: {result.created}</li>
                <li>منتجات محدثة: {result.updated}</li>
                <li>أقسام جديدة: {result.categoriesCreated}</li>
                <li>إضافات جديدة: {result.addons}</li>
                {result.errors.length > 0 && <li className="text-destructive">أخطاء: {result.errors.length}</li>}
              </ul>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
