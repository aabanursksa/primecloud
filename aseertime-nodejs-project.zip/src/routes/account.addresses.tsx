import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AccountLayout } from "@/components/store/AccountLayout";
import { useCustomerAuth } from "@/lib/customer-auth";
import { toast } from "sonner";
import { MapPin, Plus, Pencil, Trash2, Star } from "lucide-react";

export const Route = createFileRoute("/account/addresses")({ component: AddressesPage });

type Addr = {
  id?: string; title: string; city: string; district: string; street: string;
  building: string; floor: string; apartment: string; landmark: string; driver_notes: string; is_default: boolean;
};
const empty: Addr = { title: "", city: "", district: "", street: "", building: "", floor: "", apartment: "", landmark: "", driver_notes: "", is_default: false };

function AddressesPage() {
  const { customer, isLoggedIn } = useCustomerAuth();
  const qc = useQueryClient();
  const [form, setForm] = useState<Addr | null>(null);

  const { data: addresses } = useQuery({
    queryKey: ["account-addresses", customer?.phone],
    queryFn: async () => {
      if (!customer) return [];
      const { data } = await supabase.rpc("get_customer_addresses", { _phone: customer.phone });
      return (data as any[]) ?? [];
    },
    enabled: isLoggedIn,
  });

  const save = async () => {
    if (!customer || !form) return;
    if (!form.city || !form.district || !form.street) { toast.error("أكمل بيانات العنوان"); return; }
    const { error } = await supabase.rpc("upsert_customer_address", {
      _phone: customer.phone,
      _address: form as any,
    });
    if (error) { toast.error(error.message); return; }
    toast.success("تم الحفظ");
    setForm(null);
    qc.invalidateQueries({ queryKey: ["account-addresses"] });
  };

  const remove = async (id: string) => {
    if (!customer) return;
    if (!confirm("حذف العنوان؟")) return;
    const { error } = await supabase.rpc("delete_customer_address", { _phone: customer.phone, _address_id: id });
    if (error) { toast.error(error.message); return; }
    toast.success("تم الحذف");
    qc.invalidateQueries({ queryKey: ["account-addresses"] });
  };

  const setDefault = async (a: any) => {
    if (!customer) return;
    const { error } = await supabase.rpc("upsert_customer_address", {
      _phone: customer.phone,
      _address: { ...a, is_default: true } as any,
    });
    if (error) { toast.error(error.message); return; }
    toast.success("تم تعيين العنوان الافتراضي");
    qc.invalidateQueries({ queryKey: ["account-addresses"] });
  };

  if (!isLoggedIn) return <AccountLayout>{null}</AccountLayout>;

  return (
    <AccountLayout>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold">عناويني</h2>
        <button onClick={() => setForm(empty)} className="bg-primary text-primary-foreground px-4 py-2 rounded-xl font-bold flex items-center gap-1">
          <Plus className="w-4 h-4" />إضافة
        </button>
      </div>

      {(addresses?.length ?? 0) === 0 ? (
        <div className="bg-card border border-border rounded-2xl p-10 text-center">
          <MapPin className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
          <p className="text-muted-foreground">لا توجد عناوين محفوظة</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-3">
          {addresses!.map((a: any) => (
            <div key={a.id} className="bg-card border border-border rounded-2xl p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1">
                  <div className="font-bold flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-primary" />
                    {a.title || "عنوان"}
                    {a.is_default && <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full">افتراضي</span>}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">{[a.city, a.district, a.street, a.building].filter(Boolean).join("، ")}</div>
                  {a.landmark && <div className="text-xs text-muted-foreground mt-1">📍 {a.landmark}</div>}
                </div>
              </div>
              <div className="flex gap-1 mt-3">
                {!a.is_default && (
                  <button onClick={() => setDefault(a)} className="text-xs bg-muted hover:bg-muted/70 px-3 py-1.5 rounded-lg flex items-center gap-1">
                    <Star className="w-3 h-3" />افتراضي
                  </button>
                )}
                <button onClick={() => setForm({
                  id: a.id, title: a.title || "", city: a.city || "", district: a.district || "",
                  street: a.street || "", building: a.building || "", floor: a.floor || "", apartment: a.apartment || "",
                  landmark: a.landmark || "", driver_notes: a.driver_notes || "",
                  is_default: !!a.is_default,
                })} className="text-xs bg-muted hover:bg-muted/70 px-3 py-1.5 rounded-lg flex items-center gap-1">
                  <Pencil className="w-3 h-3" />تعديل
                </button>
                <button onClick={() => remove(a.id)} className="text-xs bg-destructive/10 text-destructive hover:bg-destructive/20 px-3 py-1.5 rounded-lg flex items-center gap-1">
                  <Trash2 className="w-3 h-3" />حذف
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {form && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setForm(null)}>
          <div className="bg-card rounded-2xl p-5 max-w-lg w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold mb-4">{form.id ? "تعديل عنوان" : "إضافة عنوان"}</h3>
            <div className="grid grid-cols-2 gap-3">
              <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="اسم العنوان (البيت/العمل)" className="col-span-2 bg-muted rounded-xl px-4 py-2.5 text-sm" />
              <input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} placeholder="المدينة *" className="bg-muted rounded-xl px-4 py-2.5 text-sm" />
              <input value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} placeholder="الحي *" className="bg-muted rounded-xl px-4 py-2.5 text-sm" />
              <input value={form.street} onChange={(e) => setForm({ ...form, street: e.target.value })} placeholder="الشارع *" className="bg-muted rounded-xl px-4 py-2.5 text-sm" />
              <input value={form.building} onChange={(e) => setForm({ ...form, building: e.target.value })} placeholder="رقم المبنى" className="bg-muted rounded-xl px-4 py-2.5 text-sm" />
              <input value={form.floor} onChange={(e) => setForm({ ...form, floor: e.target.value })} placeholder="الدور" className="bg-muted rounded-xl px-4 py-2.5 text-sm" />
              <input value={form.apartment} onChange={(e) => setForm({ ...form, apartment: e.target.value })} placeholder="رقم الشقة" className="bg-muted rounded-xl px-4 py-2.5 text-sm" />
              <input value={form.landmark} onChange={(e) => setForm({ ...form, landmark: e.target.value })} placeholder="علامة مميزة" className="col-span-2 bg-muted rounded-xl px-4 py-2.5 text-sm" />
              <textarea value={form.driver_notes} onChange={(e) => setForm({ ...form, driver_notes: e.target.value })} placeholder="ملاحظات للسائق" rows={2} className="col-span-2 bg-muted rounded-xl px-4 py-2.5 text-sm" />
              <label className="col-span-2 flex items-center gap-2 text-sm">
                <input type="checkbox" checked={form.is_default} onChange={(e) => setForm({ ...form, is_default: e.target.checked })} />
                تعيين كعنوان افتراضي
              </label>
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={() => setForm(null)} className="flex-1 bg-muted py-2.5 rounded-xl font-bold">إلغاء</button>
              <button onClick={save} className="flex-1 bg-primary text-primary-foreground py-2.5 rounded-xl font-bold">حفظ</button>
            </div>
          </div>
        </div>
      )}
    </AccountLayout>
  );
}
