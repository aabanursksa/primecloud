import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Bike, Plus, Pencil, Trash2, Star } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { SingleImageUpload } from "@/components/ImageUpload";
import { DRIVER_STATUS_LABEL, DRIVER_STATUS_COLOR, StatusBadge } from "@/lib/orders";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";

export const Route = createFileRoute("/dashboard/drivers")({ component: DriversPage });

type D = {
  id?: string; name: string; phone: string; email: string; avatar_url: string;
  branch_id: string | null; national_id: string; vehicle_type: string; plate_number: string;
  status: "available"|"busy"|"offline"|"suspended"; is_active: boolean; notes: string;
};
const empty: D = { name: "", phone: "", email: "", avatar_url: "", branch_id: null, national_id: "", vehicle_type: "", plate_number: "", status: "offline", is_active: true, notes: "" };

function DriversPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<D>(empty);

  const { data: drivers = [], isLoading } = useQuery({
    queryKey: ["drivers"],
    queryFn: async () => {
      const { data, error } = await supabase.from("drivers").select("*, branch:branches(name), orders:orders(id,status)").order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
  const { data: branches = [] } = useQuery({
    queryKey: ["branches-list"],
    queryFn: async () => (await supabase.from("branches").select("id,name").order("display_order")).data ?? [],
  });

  const save = async () => {
    if (!form.name || !form.phone) return toast.error("الاسم والجوال مطلوبان");
    try {
      const payload = { ...form, email: form.email || null, national_id: form.national_id || null, vehicle_type: form.vehicle_type || null, plate_number: form.plate_number || null, avatar_url: form.avatar_url || null, notes: form.notes || null };
      if (form.id) {
        const { error } = await supabase.from("drivers").update(payload).eq("id", form.id);
        if (error) throw error;
        await logActivity("update_driver", "drivers", form.id);
      } else {
        const { id: _i, ...ins } = payload; void _i;
        const { data, error } = await supabase.from("drivers").insert(ins).select().single();
        if (error) throw error;
        await logActivity("create_driver", "drivers", data.id);
      }
      toast.success("تم الحفظ");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["drivers"] });
    } catch (e) { toast.error(e instanceof Error ? e.message : "فشل"); }
  };

  const remove = async (d: typeof drivers[number]) => {
    if (!confirm(`حذف "${d.name}"؟`)) return;
    const { error } = await supabase.from("drivers").delete().eq("id", d.id);
    if (error) return toast.error(error.message);
    await logActivity("delete_driver", "drivers", d.id);
    qc.invalidateQueries({ queryKey: ["drivers"] });
  };

  return (
    <div>
      <PageHeader title="السائقون" description="إدارة فريق التوصيل." action={
        <Button onClick={() => { setForm(empty); setOpen(true); }} className="bg-gradient-primary text-primary-foreground gap-2 shadow-glow"><Plus className="w-4 h-4" />إضافة سائق</Button>
      } />

      {isLoading ? <div className="text-muted-foreground">جارٍ التحميل...</div> :
       drivers.length === 0 ? (
        <EmptyState icon={Bike} title="لا يوجد سائقون بعد" description="أضف سائقاً ليتمكن من استلام الطلبات وتوصيلها." actionLabel="إضافة سائق" onAction={() => { setForm(empty); setOpen(true); }} />
      ) : (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50"><tr>
              <th className="text-start p-3">السائق</th><th className="text-start p-3">الجوال</th><th className="text-start p-3">الفرع</th><th className="text-start p-3">الحالة</th><th className="text-start p-3">طلبات حالية</th><th className="text-start p-3">طلبات مسلمة</th><th className="text-start p-3">التقييم</th><th></th>
            </tr></thead>
            <tbody>{drivers.map((d) => {
              const orders = (d as { orders?: Array<{ status: string }> }).orders ?? [];
              const current = orders.filter((o) => ["with_driver","awaiting_driver"].includes(o.status)).length;
              const delivered = orders.filter((o) => o.status === "delivered").length;
              const branch = (d as { branch?: { name?: string } | null }).branch;
              return (
                <tr key={d.id} className="border-t hover:bg-muted/30">
                  <td className="p-3 flex items-center gap-2">
                    {d.avatar_url ? <img src={d.avatar_url} className="w-9 h-9 rounded-full object-cover" alt="" /> : <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center text-xs font-bold">{d.name.charAt(0)}</div>}
                    <span className="font-medium">{d.name}</span>
                  </td>
                  <td className="p-3 text-muted-foreground" dir="ltr">{d.phone}</td>
                  <td className="p-3 text-muted-foreground">{branch?.name ?? "—"}</td>
                  <td className="p-3"><StatusBadge status={d.status} map={DRIVER_STATUS_LABEL} color={DRIVER_STATUS_COLOR} /></td>
                  <td className="p-3">{current}</td>
                  <td className="p-3">{delivered}</td>
                  <td className="p-3 flex items-center gap-1"><Star className="w-3 h-3 text-warning fill-warning" />{Number(d.rating).toFixed(1)}</td>
                  <td className="p-3 flex gap-1 justify-end">
                    <Button size="icon" variant="ghost" onClick={() => { setForm({ id: d.id, name: d.name, phone: d.phone, email: d.email ?? "", avatar_url: d.avatar_url ?? "", branch_id: d.branch_id, national_id: d.national_id ?? "", vehicle_type: d.vehicle_type ?? "", plate_number: d.plate_number ?? "", status: d.status, is_active: d.is_active, notes: d.notes ?? "" }); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(d)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </td>
                </tr>);
            })}
            </tbody>
          </table>
        </Card>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader><DialogTitle>{form.id ? "تعديل سائق" : "إضافة سائق"}</DialogTitle></DialogHeader>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="md:col-span-2"><Label className="mb-1.5 block">صورة السائق</Label><SingleImageUpload value={form.avatar_url} onChange={(url) => setForm({ ...form, avatar_url: url })} folder="drivers" /></div>
            <div><Label className="mb-1.5 block">الاسم</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الجوال</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} dir="ltr" /></div>
            <div><Label className="mb-1.5 block">البريد (اختياري)</Label><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} dir="ltr" /></div>
            <div><Label className="mb-1.5 block">الفرع</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.branch_id ?? ""} onChange={(e) => setForm({ ...form, branch_id: e.target.value || null })}>
                <option value="">— غير مرتبط —</option>
                {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div><Label className="mb-1.5 block">رقم الهوية (اختياري)</Label><Input value={form.national_id} onChange={(e) => setForm({ ...form, national_id: e.target.value })} dir="ltr" /></div>
            <div><Label className="mb-1.5 block">نوع المركبة</Label><Input value={form.vehicle_type} onChange={(e) => setForm({ ...form, vehicle_type: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">رقم اللوحة</Label><Input value={form.plate_number} onChange={(e) => setForm({ ...form, plate_number: e.target.value })} dir="ltr" /></div>
            <div><Label className="mb-1.5 block">الحالة</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as D["status"] })}>
                {Object.entries(DRIVER_STATUS_LABEL).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div className="md:col-span-2"><Label className="mb-1.5 block">ملاحظات</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
            <div className="md:col-span-2 flex items-center gap-2"><Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} /><span className="text-sm">{form.is_active ? "مفعّل" : "موقوف"}</span></div>
          </div>
          <div className="flex justify-end gap-2 pt-4"><Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button><Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button></div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
