import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ArrowRight, Ban, CheckCircle, Bell } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/EmptyState";
import { CUSTOMER_STATUS_LABEL, CUSTOMER_STATUS_COLOR, ORDER_STATUS_LABEL, ORDER_STATUS_COLOR, StatusBadge } from "@/lib/orders";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";

export const Route = createFileRoute("/dashboard/customers/$customerId")({ component: CustomerDetailPage });

function CustomerDetailPage() {
  const { customerId } = Route.useParams();
  const qc = useQueryClient();

  const { data: customer, isLoading, error } = useQuery({
    queryKey: ["customer", customerId],
    queryFn: async () => {
      const { data, error } = await supabase.from("customers").select("*, addresses:customer_addresses(*), orders:orders(*)").eq("id", customerId).maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!customerId,
  });

  useEffect(() => {
    if (error) toast.error(`تعذّر تحميل العميل: ${error instanceof Error ? error.message : "خطأ"}`);
  }, [error]);

  if (isLoading) return <div className="text-muted-foreground p-6">جارٍ التحميل...</div>;
  if (error || !customer) {
    return (
      <Card className="p-8 text-center">
        <h3 className="text-lg font-bold mb-2">العميل غير موجود</h3>
        <Button asChild variant="outline" className="mt-4 gap-2">
          <Link to="/dashboard/customers"><ArrowRight className="w-4 h-4" />العودة للعملاء</Link>
        </Button>
      </Card>
    );
  }

  const c = customer as typeof customer & {
    addresses: Array<{ id: string; title: string | null; city: string | null; district: string | null; street: string | null; building: string | null; landmark: string | null; is_default: boolean }>;
    orders: Array<{ id: string; order_number: string; status: string; total_amount: number; created_at: string }>;
  };

  const completed = c.orders.filter((o) => o.status !== "cancelled");
  const totalSpent = completed.reduce((s, o) => s + Number(o.total_amount), 0);
  const avg = completed.length ? totalSpent / completed.length : 0;
  const last = c.orders.length ? c.orders.map((o) => o.created_at).sort().reverse()[0] : null;

  const setStatus = async (s: "active"|"inactive"|"banned") => {
    const { error } = await supabase.from("customers").update({ status: s }).eq("id", customerId);
    if (error) return toast.error(error.message);
    await logActivity("customer_status_change", "customers", customerId, { status: s });
    toast.success("تم التحديث");
    qc.invalidateQueries({ queryKey: ["customer", customerId] });
  };

  const notify = async () => {
    await supabase.from("notifications").insert({ title: `رسالة لـ ${c.name}`, message: "تم إرسال إشعار للعميل", type: "customer" });
    toast.success("تم إرسال الإشعار");
  };

  return (
    <div>
      <PageHeader
        title={c.name}
        description={c.phone}
        action={
          <div className="flex gap-2 flex-wrap">
            <Button asChild variant="ghost" size="sm" className="gap-2"><Link to="/dashboard/customers"><ArrowRight className="w-4 h-4" />العودة</Link></Button>
            <Button variant="outline" size="sm" onClick={notify} className="gap-2"><Bell className="w-4 h-4" />إرسال إشعار</Button>
            {c.status !== "banned" ? (
              <Button variant="outline" size="sm" className="gap-2 text-destructive" onClick={() => setStatus("banned")}><Ban className="w-4 h-4" />حظر</Button>
            ) : (
              <Button variant="outline" size="sm" className="gap-2 text-success" onClick={() => setStatus("active")}><CheckCircle className="w-4 h-4" />إلغاء الحظر</Button>
            )}
          </div>
        }
      />

      <div className="grid lg:grid-cols-3 gap-4 mb-4">
        <Card className="p-5"><div className="text-xs text-muted-foreground">إجمالي الطلبات</div><div className="text-2xl font-bold mt-1">{completed.length}</div></Card>
        <Card className="p-5"><div className="text-xs text-muted-foreground">إجمالي الإنفاق</div><div className="text-2xl font-bold mt-1">{totalSpent.toFixed(2)} ر.س</div></Card>
        <Card className="p-5"><div className="text-xs text-muted-foreground">متوسط الطلب</div><div className="text-2xl font-bold mt-1">{avg.toFixed(2)} ر.س</div></Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="p-5">
          <h3 className="font-bold mb-3">بيانات العميل</h3>
          <div className="space-y-2 text-sm">
            <div><span className="text-muted-foreground">الاسم: </span>{c.name}</div>
            <div><span className="text-muted-foreground">الجوال: </span><span dir="ltr">{c.phone}</span></div>
            {c.email && <div><span className="text-muted-foreground">البريد: </span><span dir="ltr">{c.email}</span></div>}
            <div><span className="text-muted-foreground">الحالة: </span><StatusBadge status={c.status} map={CUSTOMER_STATUS_LABEL} color={CUSTOMER_STATUS_COLOR} /></div>
            <div><span className="text-muted-foreground">آخر طلب: </span>{last ? new Date(last).toLocaleString("en-GB") : "—"}</div>
            {c.notes && <div className="p-3 bg-muted/40 rounded-lg mt-2"><strong>ملاحظات:</strong> {c.notes}</div>}
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="font-bold mb-3">العناوين المحفوظة</h3>
          {c.addresses.length === 0 ? <div className="text-sm text-muted-foreground">لا توجد عناوين</div> :
            <div className="space-y-2">
              {c.addresses.map((a) => (
                <div key={a.id} className="p-3 rounded-lg border border-border text-sm">
                  {a.title && <div className="font-medium mb-1">{a.title} {a.is_default && <span className="text-xs text-primary">(افتراضي)</span>}</div>}
                  <div>{[a.city, a.district, a.street, a.building].filter(Boolean).join("، ")}</div>
                  {a.landmark && <div className="text-xs text-muted-foreground mt-1">{a.landmark}</div>}
                </div>
              ))}
            </div>}
        </Card>

        <Card className="p-5 lg:col-span-3">
          <h3 className="font-bold mb-3">سجل الطلبات</h3>
          {c.orders.length === 0 ? <div className="text-sm text-muted-foreground">لا توجد طلبات</div> : (
            <table className="w-full text-sm">
              <thead className="bg-muted/50"><tr>
                <th className="text-start p-2">رقم الطلب</th><th className="text-start p-2">الحالة</th><th className="text-start p-2">الإجمالي</th><th className="text-start p-2">التاريخ</th><th></th>
              </tr></thead>
              <tbody>{c.orders.sort((a,b) => b.created_at.localeCompare(a.created_at)).map((o) => (
                <tr key={o.id} className="border-t">
                  <td className="p-2 font-mono">{o.order_number}</td>
                  <td className="p-2"><StatusBadge status={o.status} map={ORDER_STATUS_LABEL} color={ORDER_STATUS_COLOR} /></td>
                  <td className="p-2">{Number(o.total_amount).toFixed(2)} ر.س</td>
                  <td className="p-2 text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString("en-GB")}</td>
                  <td className="p-2"><Button asChild size="sm" variant="ghost"><Link to="/dashboard/orders/$orderId" params={{ orderId: o.id }}>عرض</Link></Button></td>
                </tr>))}
              </tbody>
            </table>
          )}
        </Card>
      </div>
    </div>
  );
}
