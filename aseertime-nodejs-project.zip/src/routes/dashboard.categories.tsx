import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Layers, Plus, Pencil, Trash2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { SingleImageUpload } from "@/components/ImageUpload";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";

export const Route = createFileRoute("/dashboard/categories")({ component: CategoriesPage });

type Cat = { id?: string; name_ar: string; name_en: string; icon: string; image_url: string; display_order: number; is_active: boolean; parent_id: string | null };
const empty: Cat = { name_ar: "", name_en: "", icon: "", image_url: "", display_order: 0, is_active: true, parent_id: null };

function CategoriesPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Cat>(empty);

  const { data: cats = [], isLoading } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data, error } = await supabase.from("product_categories").select("*").order("display_order");
      if (error) throw error;
      return data ?? [];
    },
  });

  const save = async () => {
    try {
      const payload: Cat = { ...form, name_en: form.name_en || "", icon: form.icon || "" };
      if (form.id) {
        const { error } = await supabase.from("product_categories").update(payload).eq("id", form.id);
        if (error) throw error;
        await logActivity("update_category", "product_categories", form.id, { name: form.name_ar });
      } else {
        const { id: _i, ...ins } = payload; void _i;
        const { data, error } = await supabase.from("product_categories").insert(ins).select().single();
        if (error) throw error;
        await logActivity("create_category", "product_categories", data.id, { name: form.name_ar });
      }
      toast.success("تم الحفظ");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["categories"] });
    } catch (e) { toast.error(e instanceof Error ? e.message : "فشل"); }
  };

  const remove = async (c: typeof cats[number]) => {
    if (!confirm(`حذف "${c.name_ar}"؟`)) return;
    const { error } = await supabase.from("product_categories").delete().eq("id", c.id);
    if (error) return toast.error(error.message);
    await logActivity("delete_category", "product_categories", c.id, { name: c.name_ar });
    qc.invalidateQueries({ queryKey: ["categories"] });
  };

  return (
    <div>
      <PageHeader title="الأقسام" description="إدارة أقسام المنيو." action={
        <Button onClick={() => { setForm(empty); setOpen(true); }} className="bg-gradient-primary text-primary-foreground gap-2 shadow-glow"><Plus className="w-4 h-4" />إضافة قسم</Button>
      } />
      {isLoading ? <div className="text-muted-foreground">جارٍ التحميل...</div> :
       cats.length === 0 ? <EmptyState icon={Layers} title="لا توجد أقسام" description="أضف أقساماً لتنظيم منتجاتك أو استورد من ملف Excel." actionLabel="أضف قسماً" onAction={() => { setForm(empty); setOpen(true); }} /> :
       <Card className="overflow-hidden">
         <table className="w-full text-sm">
           <thead className="bg-muted/50"><tr>
             <th className="w-16 p-3"></th><th className="text-start p-3">الاسم العربي</th><th className="text-start p-3">الاسم الإنجليزي</th><th className="text-start p-3">الترتيب</th><th className="text-start p-3">الحالة</th><th></th>
           </tr></thead>
           <tbody>{cats.map((c) => (
             <tr key={c.id} className="border-t">
               <td className="p-3">{c.image_url ? <img src={c.image_url} alt="" className="w-10 h-10 rounded-lg object-cover" /> : <div className="w-10 h-10 rounded-lg bg-muted" />}</td>
               <td className="p-3 font-medium">{c.name_ar}</td>
               <td className="p-3 text-muted-foreground" dir="ltr">{c.name_en}</td>
               <td className="p-3">{c.display_order}</td>
               <td className="p-3">{c.is_active ? <span className="text-xs bg-success/10 text-success px-2 py-1 rounded">نشط</span> : <span className="text-xs bg-muted px-2 py-1 rounded">معطّل</span>}</td>
               <td className="p-3 flex gap-1 justify-end">
                 <Button size="icon" variant="ghost" onClick={() => { setForm({ id: c.id, name_ar: c.name_ar ?? "", name_en: c.name_en ?? "", icon: c.icon ?? "", image_url: c.image_url ?? "", display_order: c.display_order ?? 0, is_active: c.is_active ?? true, parent_id: c.parent_id ?? null }); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                 <Button size="icon" variant="ghost" onClick={() => remove(c)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
               </td>
             </tr>))}
           </tbody>
         </table>
       </Card>}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent dir="rtl">
          <DialogHeader><DialogTitle>{form.id ? "تعديل قسم" : "إضافة قسم"}</DialogTitle></DialogHeader>
           <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2"><Label className="mb-1.5 block">صورة القسم</Label><SingleImageUpload value={form.image_url} onChange={(url) => setForm({ ...form, image_url: url })} folder="categories" /></div>
            <div className="col-span-2"><Label className="mb-1.5 block">الاسم العربي</Label><Input value={form.name_ar} onChange={(e) => setForm({ ...form, name_ar: e.target.value })} /></div>
            <div className="col-span-2"><Label className="mb-1.5 block">الاسم الإنجليزي</Label><Input value={form.name_en} onChange={(e) => setForm({ ...form, name_en: e.target.value })} dir="ltr" /></div>
            <div><Label className="mb-1.5 block">الترتيب</Label><Input type="number" value={form.display_order} onChange={(e) => setForm({ ...form, display_order: parseInt(e.target.value) || 0 })} /></div>
            <div><Label className="mb-1.5 block">القسم الأب</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.parent_id ?? ""} onChange={(e) => setForm({ ...form, parent_id: e.target.value || null })}>
                <option value="">— لا يوجد —</option>
                {cats.filter((c) => c.id !== form.id).map((c) => <option key={c.id} value={c.id}>{c.name_ar}</option>)}
              </select>
            </div>
            <div className="col-span-2 flex items-center gap-2"><Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} /><span className="text-sm">{form.is_active ? "نشط" : "معطّل"}</span></div>
          </div>
          <div className="flex justify-end gap-2 pt-4"><Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button><Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button></div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
