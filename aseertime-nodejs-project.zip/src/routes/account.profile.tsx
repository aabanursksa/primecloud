import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AccountLayout } from "@/components/store/AccountLayout";
import { useCustomerAuth } from "@/lib/customer-auth";
import { toast } from "sonner";

export const Route = createFileRoute("/account/profile")({ component: ProfilePage });

function ProfilePage() {
  const { customer, isLoggedIn } = useCustomerAuth();
  const [name, setName] = useState(customer?.name || "");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);

  const save = async () => {
    if (!customer) return;
    if (name.trim().length < 2) { toast.error("الاسم مطلوب"); return; }
    setBusy(true);
    try {
      const { error } = await supabase.rpc("update_customer_profile", {
        _phone: customer.phone, _name: name.trim(), _email: email.trim() || ""
      });
      if (error) throw error;
      toast.success("تم حفظ بياناتك");
      try {
        const raw = localStorage.getItem("jt_customer_v1");
        if (raw) {
          const c = JSON.parse(raw);
          c.name = name.trim();
          c.email = email.trim();
          localStorage.setItem("jt_customer_v1", JSON.stringify(c));
        }
      } catch {}
    } catch (e: any) { toast.error(e?.message || "خطأ"); }
    finally { setBusy(false); }
  };

  if (!isLoggedIn) return <AccountLayout>{null}</AccountLayout>;

  return (
    <AccountLayout>
      <div className="bg-card border border-border rounded-2xl p-5 max-w-xl">
        <h2 className="text-xl font-bold mb-4">بياناتي</h2>
        <div className="space-y-3">
          <div>
            <label className="text-xs font-bold mb-1.5 block">رقم الجوال</label>
            <input value={customer!.phone} disabled dir="ltr"
              className="w-full bg-muted/50 rounded-xl px-4 py-2.5 text-sm cursor-not-allowed" />
            <div className="text-[11px] text-muted-foreground mt-1">لا يمكن تعديل رقم الجوال (يحتاج تحقق OTP).</div>
          </div>
          <div>
            <label className="text-xs font-bold mb-1.5 block">الاسم *</label>
            <input value={name} onChange={(e) => setName(e.target.value)}
              className="w-full bg-muted rounded-xl px-4 py-2.5 text-sm" />
          </div>
          <div>
            <label className="text-xs font-bold mb-1.5 block">البريد الإلكتروني (اختياري)</label>
            <input value={email} onChange={(e) => setEmail(e.target.value)} dir="ltr"
              className="w-full bg-muted rounded-xl px-4 py-2.5 text-sm" />
          </div>
          <button onClick={save} disabled={busy}
            className="bg-primary text-primary-foreground px-6 py-2.5 rounded-xl font-bold disabled:opacity-50">
            {busy ? "..." : "حفظ"}
          </button>
        </div>
      </div>
    </AccountLayout>
  );
}
