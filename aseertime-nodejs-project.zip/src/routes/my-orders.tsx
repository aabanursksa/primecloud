import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { useCart } from "@/lib/cart";
import { Package, Phone } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/my-orders")({ component: MyOrdersPage });

const STATUS_LABELS: Record<string, string> = {
  new: "جديد", accepted: "مقبول", preparing: "قيد التحضير", ready: "جاهز",
  on_the_way: "مع السائق", delivered: "تم التسليم", cancelled: "ملغي",
};

function MyOrdersPage() {
  const { customerPhone, setCustomerPhone, addItem, setBranchId } = useCart();
  const [phone, setPhone] = useState(customerPhone || "");
  const [orders, setOrders] = useState<any[] | null>(null);
  const [loading, setLoading] = useState(false);

  const load = async (p?: string) => {
    const ph = (p ?? phone).trim();
    if (ph.length < 6) { toast.error("رقم الجوال غير صحيح"); return; }
    setLoading(true);
    try {
      const { data, error } = await supabase.rpc("get_customer_orders", { _phone: ph });
      if (error) throw error;
      setOrders((data as any[]) ?? []);
      setCustomerPhone(ph);
    } catch (e: any) { toast.error(e?.message || "خطأ"); }
    finally { setLoading(false); }
  };

  const reorder = async (order: any) => {
    let added = 0, skipped = 0;
    // Pre-fetch branch unavailability if branch known
    let branchUnavailable = new Set<string>();
    if (order.branch_id) {
      const { data: pb } = await supabase
        .from("product_branches")
        .select("product_id, is_available")
        .eq("branch_id", order.branch_id)
        .eq("is_available", false);
      branchUnavailable = new Set((pb ?? []).map((r: any) => r.product_id));
    }
    for (const it of order.items || []) {
      const { data: prod } = await supabase.from("products").select("*").eq("id", it.product_id).maybeSingle();
      if (!prod || prod.is_archived || !prod.show_in_store || !prod.is_available) { skipped++; continue; }
      if (branchUnavailable.has(prod.id)) { skipped++; continue; }
      addItem({
        product_id: prod.id,
        product_name: prod.name_ar,
        product_image: prod.image_url,
        variant_id: it.variant_id,
        variant_name: it.variant_name,
        unit_price: Number(it.unit_price),
        quantity: it.quantity,
        addons: it.addons || [],
        notes: it.notes,
      });
      added++;
    }
    if (order.branch_id) setBranchId(order.branch_id);
    if (added > 0) toast.success(`تمت إضافة ${added} منتج${skipped > 0 ? ` (تم تخطي ${skipped} غير متاح)` : ""}`);
    else toast.error("لا توجد منتجات متاحة لإعادة الطلب");
  };

  return (
    <StoreLayout>
      <div className="container mx-auto px-4 py-6 max-w-3xl">
        <h1 className="text-2xl font-bold mb-6">طلباتي</h1>

        <div className="bg-card border border-border rounded-2xl p-5 mb-6">
          <label className="text-sm font-bold mb-2 block">أدخل رقم جوالك لعرض طلباتك</label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="05xxxxxxxx"
                className="w-full bg-muted rounded-xl pe-10 ps-4 py-2.5 text-sm"
              />
            </div>
            <button onClick={() => load()} disabled={loading} className="bg-primary text-primary-foreground px-6 rounded-xl font-bold disabled:opacity-50">
              {loading ? "..." : "عرض"}
            </button>
          </div>
        </div>

        {orders === null ? null : orders.length === 0 ? (
          <div className="text-center py-16">
            <Package className="w-16 h-16 mx-auto text-muted-foreground mb-3" />
            <h3 className="font-bold">لا توجد طلبات سابقة</h3>
            <p className="text-sm text-muted-foreground mt-1">ابدأ أول طلب لك الآن</p>
            <Link to="/menu" className="inline-block mt-5 bg-primary text-primary-foreground px-6 py-3 rounded-xl font-bold">تصفح المنيو</Link>
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map((o) => (
              <div key={o.id} className="bg-card border border-border rounded-2xl p-4">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <div className="font-bold">{o.order_number}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {new Date(o.created_at).toLocaleString("ar-SA")} • {o.branch?.name || "—"}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] bg-muted px-2 py-1 rounded-full">{STATUS_LABELS[o.status] || o.status}</span>
                    <span className="font-bold text-primary">{Number(o.total_amount).toFixed(2)} ر.س</span>
                  </div>
                </div>
                <div className="mt-3 text-sm text-muted-foreground">
                  {(o.items || []).map((it: any, i: number) => (
                    <div key={i}>• {it.product_name}{it.variant_name ? ` (${it.variant_name})` : ""} × {it.quantity}</div>
                  ))}
                </div>
                <div className="mt-3 flex gap-2">
                  <button onClick={() => reorder(o)} className="bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-bold">إعادة الطلب</button>
                  <Link to="/track-order" className="bg-muted px-4 py-2 rounded-lg text-sm font-bold">تتبع</Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </StoreLayout>
  );
}
