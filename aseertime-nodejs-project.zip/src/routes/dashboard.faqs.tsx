import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { HelpCircle, Plus, Pencil, Trash2, ArrowUp, ArrowDown } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { moveSort } from "@/lib/sortable";

export const Route = createFileRoute("/dashboard/faqs")({ component: FaqsPage });

type Faq = {
  id: string; question: string; answer: string; category: string | null;
  status: "published" | "draft"; show_in_faq: boolean; show_in_product: boolean; sort_order: number;
};

function FaqsPage() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({
    queryKey: ["faqs"],
    queryFn: async () => (await supabase.from("faqs").select("*").order("sort_order")).data ?? [],
  });
  const [dialog, setDialog] = useState<Faq | null>(null);

  const create = () => setDialog({
    id: "", question: "", answer: "", category: "",
    status: "published", show_in_faq: true, show_in_product: false, sort_order: data.length,
  });
  const save = async () => {
    if (!dialog) return;
    if (!dialog.question.trim() || !dialog.answer.trim()) return toast.error("السؤال والإجابة مطلوبان");
    const { id, ...rest } = dialog;
    const res = id ? await supabase.from("faqs").update(rest).eq("id", id) : await supabase.from("faqs").insert(rest);
    if (res.error) return toast.error(res.error.message);
    toast.success("تم الحفظ"); setDialog(null); qc.invalidateQueries({ queryKey: ["faqs"] });
  };
  const remove = async (id: string) => {
    if (!confirm("حذف السؤال؟")) return;
    const { error } = await supabase.from("faqs").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("تم الحذف"); qc.invalidateQueries({ queryKey: ["faqs"] });
  };
  const move = async (id: string, dir: -1 | 1) => {
    await moveSort("faqs", data as Faq[], id, dir);
    qc.invalidateQueries({ queryKey: ["faqs"] });
  };

  if (isLoading) return <Skeleton className="h-96" />;

  return (
    <>
      <PageHeader title="الأسئلة الشائعة" description="أسئلة وأجوبة تظهر للزوار" action={
        <Button onClick={create} className="bg-gradient-primary text-primary-foreground gap-2"><Plus className="w-4 h-4" /> سؤال جديد</Button>
      } />

      {data.length === 0 ? (
        <EmptyState icon={HelpCircle} title="لا توجد أسئلة" description="أضف أول سؤال شائع" actionLabel="سؤال جديد" onAction={create} />
      ) : (
        <div className="space-y-2">
          {(data as Faq[]).map((f, i, arr) => (
            <Card key={f.id} className="p-4 flex items-start gap-3">
              <div className="flex flex-col gap-1 mt-1">
                <button disabled={i === 0} onClick={() => move(f.id, -1)} className="disabled:opacity-30"><ArrowUp className="w-3 h-3" /></button>
                <button disabled={i === arr.length - 1} onClick={() => move(f.id, 1)} className="disabled:opacity-30"><ArrowDown className="w-3 h-3" /></button>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium">{f.question}</div>
                <div className="text-sm text-muted-foreground mt-1 line-clamp-2">{f.answer}</div>
                <div className="flex gap-2 mt-2 flex-wrap">
                  {f.category && <span className="text-[10px] px-2 py-0.5 rounded bg-muted">{f.category}</span>}
                  <span className={`text-[10px] px-2 py-0.5 rounded ${f.status === "published" ? "bg-success/10 text-success" : "bg-muted"}`}>{f.status === "published" ? "منشور" : "مسودة"}</span>
                  {f.show_in_product && <span className="text-[10px] px-2 py-0.5 rounded bg-primary/10 text-primary">يظهر في صفحة المنتج</span>}
                </div>
              </div>
              <button onClick={() => setDialog(f)} className="p-2"><Pencil className="w-3 h-3" /></button>
              <button onClick={() => remove(f.id)} className="p-2 text-destructive"><Trash2 className="w-3 h-3" /></button>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!dialog} onOpenChange={(o) => !o && setDialog(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{dialog?.id ? "تعديل سؤال" : "سؤال جديد"}</DialogTitle></DialogHeader>
          {dialog && (
            <div className="space-y-3">
              <div><Label>السؤال</Label><Input value={dialog.question} onChange={(e) => setDialog({ ...dialog, question: e.target.value })} /></div>
              <div><Label>الإجابة</Label><Textarea rows={5} value={dialog.answer} onChange={(e) => setDialog({ ...dialog, answer: e.target.value })} /></div>
              <div><Label>التصنيف (اختياري)</Label><Input value={dialog.category ?? ""} onChange={(e) => setDialog({ ...dialog, category: e.target.value })} placeholder="عام، التوصيل، الدفع..." /></div>
              <div className="flex items-center justify-between"><Label>منشور</Label>
                <Switch checked={dialog.status === "published"} onCheckedChange={(v) => setDialog({ ...dialog, status: v ? "published" : "draft" })} />
              </div>
              <div className="flex items-center justify-between"><Label>إظهار في صفحة الأسئلة</Label>
                <Switch checked={dialog.show_in_faq} onCheckedChange={(v) => setDialog({ ...dialog, show_in_faq: v })} />
              </div>
              <div className="flex items-center justify-between"><Label>إظهار في صفحة المنتج</Label>
                <Switch checked={dialog.show_in_product} onCheckedChange={(v) => setDialog({ ...dialog, show_in_product: v })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog(null)}>إلغاء</Button>
            <Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
