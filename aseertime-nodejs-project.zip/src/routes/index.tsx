import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { ProductCard } from "@/components/store/ProductCard";
import { CategoryPill } from "@/components/store/CategoryPill";
import { ChevronLeft, ChevronRight, MapPin, Tag } from "lucide-react";
import { BlocksRenderer } from "@/components/store/blocks/BlockRenderer";
import { SectionRenderer, ResponsiveBanner } from "@/components/store/home-sections/SectionRenderer";
import { LogoLoader } from "@/components/store/LogoLoader";

function BuilderHome({ arranged, productsBySection, categories, heroSlides, builderBanners }: { arranged: any[]; productsBySection: Record<string, any[]>; categories: any[]; heroSlides: any[]; builderBanners: any[] }) {
  return (
    <>
      {arranged.map((item, i) => {
        if (item.kind === "banner") {
          return <section key={`b-${item.data.id}-${i}`} className="container mx-auto px-4"><ResponsiveBanner b={item.data} /></section>;
        }
        const s = item.data;
        // Hero carousel pulls from existing hero_slides
        if (s.section_type === "hero_carousel") {
          if (!heroSlides || heroSlides.length === 0) return null;
          return <HeroSlider key={`s-${s.id}`} slides={heroSlides} />;
        }
        return (
          <SectionRenderer
            key={`s-${s.id}`}
            section={s}
            products={productsBySection[s.id] || []}
            banners={builderBanners}
            categories={categories}
          />
        );
      })}
    </>
  );
}

function HeroSlider({ slides }: { slides: any[] }) {
  const [idx, setIdx] = useState(0);
  const count = slides.length;

  useEffect(() => {
    if (count <= 1) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % count), 5000);
    return () => clearInterval(t);
  }, [count]);

  const go = (n: number) => setIdx((n + count) % count);

  return (
    <section className="relative">
      <div className="container mx-auto px-4 pt-4">
        <div className="relative overflow-hidden rounded-2xl md:rounded-3xl bg-gradient-primary text-primary-foreground w-full aspect-[1600/920]">
          {slides.map((s, i) => (
            <div
              key={s.id}
              className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
                i === idx ? "opacity-100 z-10" : "opacity-0 z-0"
              }`}
              aria-hidden={i !== idx}
            >
              {s.image_url && (
                <img
                  src={s.image_url}
                  alt={s.title || ""}
                  className="absolute inset-0 w-full h-full object-cover"
                />
              )}
              {!s.image_only && (
                <>
                  {/* Dark gradient overlay only on desktop where text overlays the image */}
                  <div className="hidden md:block absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-black/10" />
                  <div className="hidden md:flex relative z-10 h-full w-full p-6 md:p-12 items-center">
                    <div className="max-w-xl" style={{ textAlign: (s.text_alignment as any) || "right" }}>
                      <h1
                        className="text-3xl md:text-5xl font-bold leading-tight drop-shadow"
                        style={{ color: s.text_color || "#fff" }}
                      >
                        {s.title}
                      </h1>
                      {s.subtitle && (
                        <p
                          className="mt-3 md:mt-4 text-base md:text-lg opacity-95 drop-shadow"
                          style={{ color: s.text_color || "#fff" }}
                        >
                          {s.subtitle}
                        </p>
                      )}
                      {s.cta_text && s.cta_url && (
                        <Link
                          to={s.cta_url as "/menu"}
                          className="inline-flex items-center gap-2 mt-5 bg-white text-primary font-bold px-6 py-3 rounded-xl hover:scale-105 transition"
                        >
                          {s.cta_text}
                          <ChevronLeft className="w-4 h-4" />
                        </Link>
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>
          ))}
          {count > 1 && (
            <>
              <button
                onClick={() => go(idx - 1)}
                aria-label="السابق"
                className="hidden sm:flex absolute right-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 items-center justify-center rounded-full bg-white/80 hover:bg-white text-primary shadow"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
              <button
                onClick={() => go(idx + 1)}
                aria-label="التالي"
                className="hidden sm:flex absolute left-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 items-center justify-center rounded-full bg-white/80 hover:bg-white text-primary shadow"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-20 flex gap-2">
                {slides.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => go(i)}
                    aria-label={`شريحة ${i + 1}`}
                    className={`h-2 rounded-full transition-all ${
                      i === idx ? "bg-white w-6" : "bg-white/50 w-2"
                    }`}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
}

export const Route = createFileRoute("/")({
  component: HomePage,
});

function HomePage() {
  const { data, isLoading } = useQuery({
    queryKey: ["storefront-home", "v2"],
    queryFn: async () => {
      const [hero, banners, cats, branches, coupons, homeBlocks, hSections, hBanners] = await Promise.all([
        supabase.from("hero_slides").select("*").eq("status", "active").order("sort_order"),
        supabase.from("banners").select("*").eq("status", "active").eq("placement", "home").order("sort_order"),
        supabase.from("product_categories").select("*").eq("show_in_store", true).eq("is_active", true).order("display_order"),
        supabase.from("branches").select("*").eq("is_active", true).order("display_order").limit(6),
        supabase.from("coupons").select("*").eq("status", "active").limit(3),
        supabase.from("page_blocks").select("*").eq("location", "home").eq("is_active", true).order("sort_order"),
        supabase.from("home_sections").select("*").eq("is_active", true).order("sort_order"),
        supabase.from("home_section_banners").select("*").eq("is_active", true).order("sort_order"),
      ]);
      const categories = cats.data ?? [];
      const homeCats = categories.filter((c: any) => c.show_on_home !== false);
      const productsByCat = await Promise.all(
        homeCats.map((c: any) =>
          supabase.from("products").select("*").eq("category_id", c.id).eq("show_in_store", true).eq("is_archived", false).order("display_order").limit(c.home_product_limit || 8).then((r) => ({ category: c, products: r.data ?? [] }))
        )
      );
      // Fetch products for builder sections
      const { fetchSectionsData, arrangeSectionsWithBanners } = await import("@/lib/home-builder");
      const sectionsList = (hSections.data ?? []) as any;
      const sectionProducts = sectionsList.length > 0 ? await fetchSectionsData(sectionsList) : {};
      const arranged = arrangeSectionsWithBanners(sectionsList, (hBanners.data ?? []) as any);
      return {
        hero: hero.data ?? [],
        banners: banners.data ?? [],
        categories,
        sections: productsByCat.filter((s) => s.products.length > 0),
        branches: branches.data ?? [],
        coupons: coupons.data ?? [],
        homeBlocks: homeBlocks.data ?? [],
        builderSections: sectionsList,
        builderBanners: (hBanners.data ?? []) as any,
        builderProducts: sectionProducts,
        builderArranged: arranged,
      };
    },
  });

  return (
    <StoreLayout>
      {isLoading ? (
        <LogoLoader />
      ) : !data ? null : (
       <div className="space-y-10 pb-12">
          {data.homeBlocks.length > 0 && <BlocksRenderer blocks={data.homeBlocks as any} />}

          {data.builderSections && data.builderSections.length > 0 ? (
            <BuilderHome
              arranged={data.builderArranged}
              productsBySection={data.builderProducts}
              categories={data.categories}
              heroSlides={data.hero}
              builderBanners={data.builderBanners}
            />
          ) : (
            <>
              {data.hero.length > 0 && <HeroSlider slides={data.hero} />}

              {data.categories.length > 0 && (
                <section className="container mx-auto px-4">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">تصفح الأقسام</h2>
                    <Link to="/menu" className="text-sm text-primary">الكل</Link>
                  </div>
                  <div className="flex gap-4 overflow-x-auto pb-3 scrollbar-hide snap-x snap-mandatory scroll-px-4 -mx-4 px-4">
                    {data.categories.map((c) => (
                      <CategoryPill key={c.id} category={c} />
                    ))}
                  </div>
                </section>
              )}

              {data.banners.length > 0 && (
                <section className="container mx-auto px-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {data.banners.slice(0, 2).map((b) => {
                      const inner = (
                        <div className="relative overflow-hidden rounded-2xl bg-muted aspect-[3/1]">
                          {b.image_url && <img src={b.image_url} alt={b.title} className="absolute inset-0 w-full h-full object-cover" />}
                          {!b.image_only && (b.title || b.subtitle) && (
                            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-5">
                              <div className="text-white">
                                <div className="font-bold text-lg">{b.title}</div>
                                {b.subtitle && <div className="text-sm opacity-90">{b.subtitle}</div>}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                      return b.cta_url ? (
                        <a key={b.id} href={b.cta_url}>{inner}</a>
                      ) : (
                        <div key={b.id}>{inner}</div>
                      );
                    })}
                  </div>
                </section>
              )}

              {data.sections.map(({ category, products }) => (
                <section key={category.id} className="container mx-auto px-4">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">{category.name_ar}</h2>
                    <Link to="/menu/$categoryId" params={{ categoryId: category.id }} className="text-sm text-primary">عرض الكل</Link>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {products.map((p: any) => <ProductCard key={p.id} product={p} />)}
                  </div>
                </section>
              ))}
            </>
          )}

          {/* Coupons */}
          {data.coupons.length > 0 && (
            <section className="container mx-auto px-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">العروض والكوبونات</h2>
                <Link to="/offers" className="text-sm text-primary">الكل</Link>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {data.coupons.map((c) => (
                  <div key={c.id} className="border-2 border-dashed border-primary/40 rounded-2xl p-5 bg-primary/5">
                    <div className="flex items-center gap-2 text-primary font-bold">
                      <Tag className="w-4 h-4" />
                      {c.name}
                    </div>
                    <div className="mt-2 text-2xl font-bold">{c.code}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      خصم {c.discount_type === "percent" ? `${c.discount_value}%` : c.discount_type === "free_delivery" ? "توصيل مجاني" : `${c.discount_value} ر.س`}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Branches */}
          {data.branches.length > 0 && (
            <section className="container mx-auto px-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">فروعنا</h2>
                <Link to="/branches" className="text-sm text-primary">الكل</Link>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {data.branches.slice(0, 3).map((b) => (
                  <div key={b.id} className="bg-card border border-border rounded-2xl p-5">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                        <MapPin className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="font-bold">{b.name}</div>
                        {b.address && <div className="text-xs text-muted-foreground mt-1">{b.address}</div>}
                        {b.phone && <div className="text-xs mt-2">{b.phone}</div>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Empty state */}
          {data.hero.length === 0 && data.categories.length === 0 && data.sections.length === 0 && data.branches.length === 0 && (
            <div className="container mx-auto px-4 py-20 text-center">
              <h1 className="text-3xl font-bold">مرحباً بك في عصير تايم</h1>
              <p className="text-muted-foreground mt-3">يتم إعداد المتجر حالياً، تابعنا قريباً.</p>
            </div>
          )}
        </div>
      )}
    </StoreLayout>
  );
}
