import { createFileRoute, useParams, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { ProductCard } from "@/components/store/ProductCard";
import { useCart } from "@/lib/cart";
import { useBranchUnavailableProducts } from "@/lib/branch-availability";
import { ChevronRight, UtensilsCrossed } from "lucide-react";
import { useMemo } from "react";

export const Route = createFileRoute("/menu/$categoryId")({
  component: CategoryPage,
});

function CategoryPage() {
  const { categoryId } = useParams({ from: "/menu/$categoryId" });
  const { branchId } = useCart();
  const { data: unavailable } = useBranchUnavailableProducts(branchId);

  const { data, isLoading } = useQuery({
    queryKey: ["category-v2", categoryId],
    queryFn: async () => {
      const [cat, prods, vars] = await Promise.all([
        supabase.from("product_categories").select("*").eq("id", categoryId).maybeSingle(),
        supabase.from("products").select("*").eq("category_id", categoryId).eq("show_in_store", true).eq("is_archived", false),
        supabase.from("product_variants").select("product_id, price, is_available"),
      ]);
      const variantAgg = new Map<string, { count: number; min: number }>();
      (vars.data ?? []).forEach((v: any) => {
        if (!v.is_available) return;
        const cur = variantAgg.get(v.product_id) || { count: 0, min: Infinity };
        cur.count += 1;
        cur.min = Math.min(cur.min, Number(v.price ?? 0));
        variantAgg.set(v.product_id, cur);
      });
      return { category: cat.data, products: prods.data ?? [], variantAgg };
    },
  });

  const sorted = useMemo(() => {
    const list = [...(data?.products ?? [])];
    list.sort((a: any, b: any) => {
      if ((b.is_featured ? 1 : 0) !== (a.is_featured ? 1 : 0)) return (b.is_featured ? 1 : 0) - (a.is_featured ? 1 : 0);
      const ao = a.display_order ?? 0, bo = b.display_order ?? 0;
      if (ao !== bo) return ao - bo;
      return new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime();
    });
    return list;
  }, [data?.products]);

  return (
    <StoreLayout>
      <div className="container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-card border border-border rounded-2xl overflow-hidden">
                <div className="aspect-square bg-muted animate-pulse" />
                <div className="p-3 space-y-2">
                  <div className="h-4 bg-muted rounded animate-pulse" />
                  <div className="h-8 bg-muted rounded animate-pulse mt-3" />
                </div>
              </div>
            ))}
          </div>
        ) : !data?.category ? (
          <div className="text-center py-20">
            <h3 className="font-bold">القسم غير موجود</h3>
            <Link to="/menu" className="text-primary text-sm mt-2 inline-block">العودة للمنيو</Link>
          </div>
        ) : (
          <>
            <nav className="flex items-center gap-1 text-xs text-muted-foreground mb-3">
              <Link to="/menu" className="hover:text-primary">المنيو</Link>
              <ChevronRight className="w-3 h-3 rotate-180" />
              <span className="text-foreground font-medium">{data.category.name_ar}</span>
            </nav>
            <div className="mb-5 flex items-center gap-3">
              {data.category.image_url && (
                <img src={data.category.image_url} alt={data.category.name_ar} className="w-14 h-14 rounded-2xl object-cover" />
              )}
              <div>
                <h1 className="text-2xl font-bold">{data.category.name_ar}</h1>
                <div className="text-xs text-muted-foreground mt-0.5">{sorted.length} منتج</div>
              </div>
            </div>
            {sorted.length === 0 ? (
              <div className="text-center py-20 bg-card/50 border border-dashed border-border rounded-2xl">
                <div className="w-16 h-16 rounded-full bg-muted mx-auto flex items-center justify-center text-muted-foreground mb-4">
                  <UtensilsCrossed className="w-7 h-7" />
                </div>
                <h3 className="font-bold">لا توجد منتجات في هذا القسم حالياً</h3>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                {sorted.map((p: any) => {
                  const agg = data.variantAgg.get(p.id);
                  return (
                    <ProductCard
                      key={p.id}
                      product={p}
                      unavailableInBranch={branchId ? unavailable?.has(p.id) : false}
                      minVariantPrice={agg?.min}
                      variantCount={agg?.count ?? 0}
                    />
                  );
                })}
              </div>
            )}
          </>
        )}
      </div>
    </StoreLayout>
  );
}
