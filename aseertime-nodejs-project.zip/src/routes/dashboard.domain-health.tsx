import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { Globe, RefreshCw, CheckCircle2, XCircle, ArrowRight, Clock, Server } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/EmptyState";
import { checkDomainHealth } from "@/lib/domain-check.functions";

export const Route = createFileRoute("/dashboard/domain-health")({ component: DomainHealthPage });

const STORAGE_KEY = "domain-health-last-check";

function DomainHealthPage() {
  const run = useServerFn(checkDomainHealth);
  const [domain, setDomain] = useState(() => {
    if (typeof window === "undefined") return "aseertimeastern.com";
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      return saved?.domain ?? "aseertimeastern.com";
    } catch { return "aseertimeastern.com"; }
  });

  const [lastResult, setLastResult] = useState<any>(() => {
    if (typeof window === "undefined") return null;
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "null"); } catch { return null; }
  });

  const mut = useMutation({
    mutationFn: (d: string) => run({ data: { domain: d } }),
    onSuccess: (data) => {
      setLastResult(data);
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch {}
    },
  });

  const ok = lastResult?.results?.some((r: any) => r.ok);

  return (
    <div className="space-y-6 max-w-5xl">
      <PageHeader
        title="حالة الدومين"
        description="افحص اتصال الموقع، التحويلات، وزمن الاستجابة على الدومين الرئيسي و www و http."
      />

      <Card className="p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row gap-3 sm:items-end">
          <div className="flex-1">
            <Label className="mb-2 block">الدومين</Label>
            <Input
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              placeholder="example.com"
              dir="ltr"
              className="text-left"
            />
          </div>
          <Button onClick={() => mut.mutate(domain)} disabled={mut.isPending} className="gap-2">
            <RefreshCw className={`w-4 h-4 ${mut.isPending ? "animate-spin" : ""}`} />
            {mut.isPending ? "جاري الفحص..." : "فحص الآن"}
          </Button>
        </div>
        {mut.isError && (
          <div className="text-sm text-destructive mt-3">{(mut.error as Error).message}</div>
        )}
      </Card>

      {lastResult && (
        <>
          <div className="flex flex-wrap items-center gap-3 text-sm">
            <Badge variant={ok ? "default" : "destructive"} className="gap-1.5">
              {ok ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
              {ok ? "الموقع متاح" : "الموقع غير متاح"}
            </Badge>
            <span className="text-muted-foreground inline-flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              آخر فحص: {new Date(lastResult.checkedAt).toLocaleString("ar-SA")}
            </span>
          </div>

          <div className="grid gap-3">
            {lastResult.results.map((r: any) => (
              <Card key={r.url} className="p-4 sm:p-5">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="min-w-0 flex-1">
                    <div className="font-mono text-sm font-bold break-all" dir="ltr">{r.url}</div>
                    <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-muted-foreground">
                      {r.status != null && (
                        <span className="inline-flex items-center gap-1">
                          الحالة: <span className={`font-bold ${r.ok ? "text-success" : "text-destructive"}`}>{r.status}</span>
                        </span>
                      )}
                      {r.responseTimeMs != null && (
                        <span className="inline-flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {r.responseTimeMs}ms
                        </span>
                      )}
                      {r.server && (
                        <span className="inline-flex items-center gap-1">
                          <Server className="w-3 h-3" /> {r.server}
                        </span>
                      )}
                      {r.redirected && <Badge variant="outline" className="gap-1"><ArrowRight className="w-3 h-3" /> تحويل</Badge>}
                    </div>
                  </div>
                  <Badge variant={r.ok ? "default" : "destructive"} className="shrink-0">
                    {r.ok ? "يعمل" : r.error ? "خطأ" : "فشل"}
                  </Badge>
                </div>

                {r.redirectChain?.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-border">
                    <div className="text-xs font-semibold mb-1.5">سلسلة التحويلات</div>
                    <div className="space-y-1">
                      {r.redirectChain.map((c: string, i: number) => (
                        <div key={i} className="font-mono text-xs text-muted-foreground break-all" dir="ltr">{c}</div>
                      ))}
                      {r.finalUrl && <div className="font-mono text-xs break-all" dir="ltr">→ {r.finalUrl}</div>}
                    </div>
                  </div>
                )}

                {r.error && (
                  <div className="mt-3 pt-3 border-t border-border text-xs text-destructive">
                    {r.error}
                  </div>
                )}
              </Card>
            ))}
          </div>
        </>
      )}

      {!lastResult && !mut.isPending && (
        <Card className="p-8 text-center text-muted-foreground">
          اضغط "فحص الآن" لبدء أول فحص.
        </Card>
      )}
    </div>
  );
}
