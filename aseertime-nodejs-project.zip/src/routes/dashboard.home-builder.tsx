import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Layers, Plus, Pencil, Trash2, GripVertical, Eye, EyeOff, Image as ImageIcon, ExternalLink } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { SingleImageUpload } from "@/components/ImageUpload";
import { toast } from "sonner";
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors, type DragEndEvent } from "@dnd-kit/core";
import { arrayMove, SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { SECTION_TYPES, DISPLAY_STYLES, BANNER_POSITIONS, BANNER_LINK_TYPES } from "@/lib/home-builder";

export const Route = createFileRoute("/dashboard/home-builder")({ component: HomeBuilderPage });

type Section = {
  id?: string;
  title_ar: string;
  title_en: string;
  section_type: string;
  display_style: string;
  sort_order: number;
  is_active: boolean;
  category_id: string | null;
  manual_product_ids: string[];
  products_limit: number;
  show_view_all: boolean;
  view_all_url: string | null;
  settings: Record<string, any>;
};

type Banner = {
  id?: string;
  section_id: string | null;
  position: string;
  anchor_section_id: string | null;
  image_mobile: string | null;
  image_tablet: string | null;
  image_desktop: string | null;
  title: string | null;
  subtitle: string | null;
  link_type: string;
  link_value: string | null;
  is_active: boolean;
  sort_order: number;
};

const emptySection: Section = {
  title_ar: "", title_en: "", section_type: "products_grid", display_style: "grid",
  sort_order: 0, is_active: true, category_id: null, manual_product_ids: [],
  products_limit: 6, show_view_all: true, view_all_url: null, settings: {},
};

const emptyBanner: Banner = {
  section_id: null, position: "standalone", anchor_section_id: null,
  image_mobile: null, image_tablet: null, image_desktop: null,
  title: null, subtitle: null, link_type: "none", link_value: null,
  is_active: true, sort_order: 0,
};

function SortableRow({ section, onEdit, onToggle, onDelete, onManageBanners }: {
  section: any;
  onEdit: () => void;
  onToggle: () => void;
  onDelete: () => void;
  onManageBanners: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: section.id });
  const style = { transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1 };
  const typeLabel = SECTION_TYPES.find((t) => t.value === section.section_type)?.label || section.section_type;
  return (
    <div ref={setNodeRef} style={style} className="flex items-center gap-3 bg-card border border-border rounded-xl p-3">
      <button {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing text-muted-foreground touch-none">
        <GripVertical className="w-5 h-5" />
      </button>
      <div className="flex-1 min-w-0">
        <div className="font-bold truncate">{section.title_ar || "(بدون عنوان)"}</div>
        <div className="text-xs text-muted-foreground">{typeLabel}</div>
      </div>
      <Button size="icon" variant="ghost" onClick={onManageBanners} title="بنرات السكشن"><ImageIcon className="w-4 h-4" /></Button>
      <Button size="icon" variant="ghost" onClick={onToggle} title={section.is_active ? "تعطيل" : "تفعيل"}>
        {section.is_active ? <Eye className="w-4 h-4 text-success" /> : <EyeOff className="w-4 h-4 text-muted-foreground" />}
      </Button>
      <Button size="icon" variant="ghost" onClick={onEdit}><Pencil className="w-4 h-4" /></Button>
      <Button size="icon" variant="ghost" onClick={onDelete}><Trash2 className="w-4 h-4 text-destructive" /></Button>
    </div>
  );
}

function HomeBuilderPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Section>(emptySection);
  const [bannersOpen, setBannersOpen] = useState(false);
  const [bannersForSection, setBannersForSection] = useState<string | null>(null);
  const [bannerForm, setBannerForm] = useState<Banner | null>(null);
  const [productSearch, setProductSearch] = useState("");

  const { data: sections = [], isLoading } = useQuery({
    queryKey: ["home-sections-admin"],
    queryFn: async () => {
      const { data, error } = await supabase.from("home_sections").select("*").order("sort_order");
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: cats = [] } = useQuery({
    queryKey: ["home-builder-cats"],
    queryFn: async () => (await supabase.from("product_categories").select("id,name_ar").order("display_order")).data ?? [],
  });

  const { data: products = [] } = useQuery({
    queryKey: ["home-builder-products"],
    queryFn: async () => (await supabase.from("products").select("id,name_ar,image_url,category_id").order("name_ar")).data ?? [],
  });

  const { data: bannersAll = [] } = useQuery({
    queryKey: ["home-banners-admin"],
    queryFn: async () => (await supabase.from("home_section_banners").select("*").order("sort_order")).data ?? [],
  });

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  const onDragEnd = async (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const oldIdx = sections.findIndex((s: any) => s.id === active.id);
    const newIdx = sections.findIndex((s: any) => s.id === over.id);
    const next = arrayMove(sections as any[], oldIdx, newIdx);
    qc.setQueryData(["home-sections-admin"], next);
    // persist new sort_order
    await Promise.all(next.map((s: any, i: number) => supabase.from("home_sections").update({ sort_order: i }).eq("id", s.id)));
    qc.invalidateQueries({ queryKey: ["home-sections-admin"] });
    qc.invalidateQueries({ queryKey: ["storefront-home-builder"] });
  };

  const save = async () => {
    try {
      const payload: any = { ...form };
      if (form.id) {
        const { id, ...upd } = payload;
        const { error } = await supabase.from("home_sections").update(upd).eq("id", id!);
        if (error) throw error;
      } else {
        const maxOrder = Math.max(0, ...sections.map((s: any) => s.sort_order || 0));
        const { id: _i, ...ins } = payload; void _i;
        const { error } = await supabase.from("home_sections").insert({ ...ins, sort_order: maxOrder + 1 });
        if (error) throw error;
      }
      toast.success("تم الحفظ");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["home-sections-admin"] });
      qc.invalidateQueries({ queryKey: ["storefront-home-builder"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل");
    }
  };

  const toggle = async (s: any) => {
    await supabase.from("home_sections").update({ is_active: !s.is_active }).eq("id", s.id);
    qc.invalidateQueries({ queryKey: ["home-sections-admin"] });
    qc.invalidateQueries({ queryKey: ["storefront-home-builder"] });
  };

  const remove = async (s: any) => {
    if (!confirm(`حذف "${s.title_ar}"؟`)) return;
    await supabase.from("home_sections").delete().eq("id", s.id);
    qc.invalidateQueries({ queryKey: ["home-sections-admin"] });
    qc.invalidateQueries({ queryKey: ["storefront-home-builder"] });
  };

  const saveBanner = async () => {
    if (!bannerForm) return;
    try {
      const { id, ...rest } = bannerForm;
      const restAny: any = rest;
      if (id) {
        const { error } = await supabase.from("home_section_banners").update(restAny).eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("home_section_banners").insert(restAny);
        if (error) throw error;
      }
      toast.success("تم الحفظ");
      setBannerForm(null);
      qc.invalidateQueries({ queryKey: ["home-banners-admin"] });
      qc.invalidateQueries({ queryKey: ["storefront-home-builder"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل");
    }
  };

  const removeBanner = async (id: string) => {
    if (!confirm("حذف هذا البنر؟")) return;
    await supabase.from("home_section_banners").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["home-banners-admin"] });
    qc.invalidateQueries({ queryKey: ["storefront-home-builder"] });
  };

  const sectionBanners = bannersAll.filter((b: any) => b.section_id === bannersForSection || (bannersForSection === "__global__" && !b.section_id));

  const filteredProducts = productSearch
    ? products.filter((p: any) => p.name_ar?.toLowerCase().includes(productSearch.toLowerCase()))
    : products;

  return (
    <div>
      <PageHeader
        title="إدارة الصفحة الرئيسية للتطبيق"
        description="ابنِ صفحتك الرئيسية بسحب وإفلات السكشنات وأضف البنرات في أي مكان."
        action={
          <div className="flex gap-2">
            <a href="/" target="_blank" rel="noreferrer">
              <Button variant="outline" className="gap-2"><ExternalLink className="w-4 h-4" />معاينة</Button>
            </a>
            <Button onClick={() => { setBannersForSection("__global__"); setBannersOpen(true); }} variant="outline" className="gap-2">
              <ImageIcon className="w-4 h-4" />بنرات عامة
            </Button>
            <Button onClick={() => { setForm({ ...emptySection, sort_order: sections.length }); setOpen(true); }} className="bg-gradient-primary text-primary-foreground gap-2 shadow-glow">
              <Plus className="w-4 h-4" />إضافة سكشن
            </Button>
          </div>
        }
      />

      {isLoading ? (
        <div className="text-muted-foreground">جارٍ التحميل...</div>
      ) : sections.length === 0 ? (
        <EmptyState icon={Layers} title="لا توجد سكشنات" description="ابدأ بإضافة سكشن جديد للصفحة الرئيسية." actionLabel="إضافة سكشن" onAction={() => { setForm(emptySection); setOpen(true); }} />
      ) : (
        <Card className="p-4">
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
            <SortableContext items={sections.map((s: any) => s.id)} strategy={verticalListSortingStrategy}>
              <div className="space-y-2">
                {sections.map((s: any) => (
                  <SortableRow
                    key={s.id}
                    section={s}
                    onEdit={() => { setForm({ ...emptySection, ...s, manual_product_ids: s.manual_product_ids || [], settings: s.settings || {} }); setOpen(true); }}
                    onToggle={() => toggle(s)}
                    onDelete={() => remove(s)}
                    onManageBanners={() => { setBannersForSection(s.id); setBannersOpen(true); }}
                  />
                ))}
              </div>
            </SortableContext>
          </DndContext>
        </Card>
      )}

      {/* Section editor */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent dir="rtl" className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form.id ? "تعديل سكشن" : "إضافة سكشن"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div><Label>العنوان عربي</Label><Input value={form.title_ar} onChange={(e) => setForm({ ...form, title_ar: e.target.value })} /></div>
            <div><Label>العنوان إنجليزي</Label><Input value={form.title_en} onChange={(e) => setForm({ ...form, title_en: e.target.value })} dir="ltr" /></div>
            <div><Label>نوع السكشن</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.section_type} onChange={(e) => setForm({ ...form, section_type: e.target.value })}>
                {SECTION_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </div>
            {(() => {
              const isBannerOnly = ["hero_carousel", "single_banner", "banner_grid", "categories_section"].includes(form.section_type);
              const needsProducts = !isBannerOnly;
              return (
                <>
                  {needsProducts && (
                    <div><Label>طريقة العرض</Label>
                      <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.display_style} onChange={(e) => setForm({ ...form, display_style: e.target.value })}>
                        {DISPLAY_STYLES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                      </select>
                    </div>
                  )}
                  {needsProducts && (
                    <div><Label>عدد المنتجات</Label>
                      <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.products_limit} onChange={(e) => setForm({ ...form, products_limit: parseInt(e.target.value) })}>
                        {[4, 5, 6, 8, 10, 12, 20, 50].map((n) => <option key={n} value={n}>{n}</option>)}
                      </select>
                    </div>
                  )}
                  {needsProducts && (
                    <div><Label>التصنيف المرتبط</Label>
                      <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.category_id ?? ""} onChange={(e) => setForm({ ...form, category_id: e.target.value || null })}>
                        <option value="">— لا يوجد —</option>
                        {cats.map((c: any) => <option key={c.id} value={c.id}>{c.name_ar}</option>)}
                      </select>
                    </div>
                  )}
                  {needsProducts && (
                    <div className="col-span-2">
                      <Label>منتجات يدوية (اختياري — يتجاوز التصنيف)</Label>
                      <Input placeholder="ابحث عن منتج..." value={productSearch} onChange={(e) => setProductSearch(e.target.value)} className="mb-2" />
                      <div className="max-h-44 overflow-y-auto border border-border rounded-lg p-2 space-y-1">
                        {filteredProducts.slice(0, 50).map((p: any) => {
                          const checked = form.manual_product_ids.includes(p.id);
                          return (
                            <label key={p.id} className="flex items-center gap-2 text-sm cursor-pointer hover:bg-muted/50 p-1 rounded">
                              <input type="checkbox" checked={checked} onChange={(e) => {
                                const next = e.target.checked ? [...form.manual_product_ids, p.id] : form.manual_product_ids.filter((x) => x !== p.id);
                                setForm({ ...form, manual_product_ids: next });
                              }} />
                              {p.image_url && <img src={p.image_url} alt="" className="w-8 h-8 rounded object-cover" />}
                              <span>{p.name_ar}</span>
                            </label>
                          );
                        })}
                      </div>
                      {form.manual_product_ids.length > 0 && <div className="text-xs text-muted-foreground mt-1">مختار: {form.manual_product_ids.length}</div>}
                    </div>
                  )}
                  {form.section_type === "hero_carousel" && (
                    <div className="col-span-2 bg-primary/5 border border-primary/20 rounded-lg p-3 text-sm">
                      سكشن الهيرو يعرض الشرائح من إعدادات <a href="/dashboard/hero" className="text-primary font-bold underline">الهيرو</a> الحالية تلقائيًا — لا حاجة لربط منتجات أو تصنيف.
                    </div>
                  )}
                  {(form.section_type === "single_banner" || form.section_type === "banner_grid") && (
                    <div className="col-span-2 bg-muted/40 border border-border rounded-lg p-3 text-sm">
                      هذا السكشن يعرض البنرات. أضف البنرات من زر <ImageIcon className="inline w-4 h-4" /> بجانب السكشن بعد الحفظ.
                    </div>
                  )}
                  <div className="col-span-2 flex items-center gap-3">
                    <Switch checked={form.show_view_all} onCheckedChange={(v) => setForm({ ...form, show_view_all: v })} />
                    <span className="text-sm">إظهار زر "عرض الكل"</span>
                  </div>
                  {form.show_view_all && (
                    <div className="col-span-2"><Label>رابط زر عرض الكل (اختياري)</Label><Input value={form.view_all_url ?? ""} onChange={(e) => setForm({ ...form, view_all_url: e.target.value || null })} placeholder="/menu/category-id" dir="ltr" /></div>
                  )}
                </>
              );
            })()}
            <div className="col-span-2 flex items-center gap-3">
              <Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
              <span className="text-sm">{form.is_active ? "نشط" : "معطّل"}</span>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Banners manager */}
      <Dialog open={bannersOpen} onOpenChange={setBannersOpen}>
        <DialogContent dir="rtl" className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              بنرات {bannersForSection === "__global__" ? "عامة" : `السكشن: ${(sections.find((s: any) => s.id === bannersForSection) as any)?.title_ar}`}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Button onClick={() => setBannerForm({ ...emptyBanner, section_id: bannersForSection === "__global__" ? null : bannersForSection })} className="gap-2">
              <Plus className="w-4 h-4" />إضافة بنر
            </Button>
            {sectionBanners.length === 0 ? (
              <div className="text-muted-foreground text-sm text-center py-4">لا توجد بنرات</div>
            ) : (
              <div className="space-y-2">
                {sectionBanners.map((b: any) => (
                  <div key={b.id} className="flex items-center gap-3 border border-border rounded-xl p-3">
                    {b.image_mobile && <img src={b.image_mobile} alt="" className="w-16 h-16 rounded object-cover" />}
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{b.title || "(بدون عنوان)"}</div>
                      <div className="text-xs text-muted-foreground">{BANNER_POSITIONS.find((p) => p.value === b.position)?.label} · {b.is_active ? "نشط" : "معطّل"}</div>
                    </div>
                    <Button size="icon" variant="ghost" onClick={() => setBannerForm(b)}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => removeBanner(b.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Banner editor */}
      <Dialog open={!!bannerForm} onOpenChange={(o) => !o && setBannerForm(null)}>
        <DialogContent dir="rtl" className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{bannerForm?.id ? "تعديل بنر" : "إضافة بنر"}</DialogTitle></DialogHeader>
          {bannerForm && (
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2"><Label>صورة الموبايل (مقاس مقترح: 800×600)</Label>
                <SingleImageUpload value={bannerForm.image_mobile || ""} onChange={(url) => setBannerForm({ ...bannerForm, image_mobile: url })} folder="home-banners" />
              </div>
              <div className="col-span-2"><Label>صورة التابلت (مقاس مقترح: 1400×500)</Label>
                <SingleImageUpload value={bannerForm.image_tablet || ""} onChange={(url) => setBannerForm({ ...bannerForm, image_tablet: url })} folder="home-banners" />
              </div>
              <div className="col-span-2"><Label>صورة الديسكتوب (مقاس مقترح: 1800×600)</Label>
                <SingleImageUpload value={bannerForm.image_desktop || ""} onChange={(url) => setBannerForm({ ...bannerForm, image_desktop: url })} folder="home-banners" />
              </div>
              <div className="col-span-2"><Label>العنوان (اختياري)</Label><Input value={bannerForm.title || ""} onChange={(e) => setBannerForm({ ...bannerForm, title: e.target.value })} /></div>
              <div className="col-span-2"><Label>الوصف (اختياري)</Label><Textarea value={bannerForm.subtitle || ""} onChange={(e) => setBannerForm({ ...bannerForm, subtitle: e.target.value })} /></div>
              <div><Label>الموقع</Label>
                <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={bannerForm.position} onChange={(e) => setBannerForm({ ...bannerForm, position: e.target.value })}>
                  {BANNER_POSITIONS.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
                </select>
              </div>
              {(bannerForm.position === "before_section" || bannerForm.position === "after_section") && (
                <div><Label>السكشن المرجعي</Label>
                  <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={bannerForm.anchor_section_id ?? ""} onChange={(e) => setBannerForm({ ...bannerForm, anchor_section_id: e.target.value || null })}>
                    <option value="">— اختر —</option>
                    {sections.map((s: any) => <option key={s.id} value={s.id}>{s.title_ar}</option>)}
                  </select>
                </div>
              )}
              <div><Label>نوع الرابط</Label>
                <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={bannerForm.link_type} onChange={(e) => setBannerForm({ ...bannerForm, link_type: e.target.value })}>
                  {BANNER_LINK_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </div>
              {bannerForm.link_type !== "none" && (
                <div><Label>قيمة الرابط (ID أو URL)</Label><Input value={bannerForm.link_value || ""} onChange={(e) => setBannerForm({ ...bannerForm, link_value: e.target.value })} dir="ltr" /></div>
              )}
              <div><Label>الترتيب</Label><Input type="number" value={bannerForm.sort_order} onChange={(e) => setBannerForm({ ...bannerForm, sort_order: parseInt(e.target.value) || 0 })} /></div>
              <div className="col-span-2 flex items-center gap-3">
                <Switch checked={bannerForm.is_active} onCheckedChange={(v) => setBannerForm({ ...bannerForm, is_active: v })} />
                <span className="text-sm">{bannerForm.is_active ? "نشط" : "معطّل"}</span>
              </div>
            </div>
          )}
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="ghost" onClick={() => setBannerForm(null)}>إلغاء</Button>
            <Button onClick={saveBanner} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
