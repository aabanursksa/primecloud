import { createFileRoute, useParams, useNavigate, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { useCart } from "@/lib/cart";
import { useBranchUnavailableProducts } from "@/lib/branch-availability";
import { Minus, Plus, ShoppingCart, Flame, Clock, Share2, Sparkles, TrendingUp, ChevronLeft, Copy, Check } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/product/$productId")({
  component: ProductPage,
});

const NEW_DAYS = 30;

function ProductPage() {
  const { productId } = useParams({ from: "/product/$productId" });
  const navigate = useNavigate();
  const { addItem, branchId } = useCart();
  const { data: unavailable } = useBranchUnavailableProducts(branchId);
  const isUnavailableInBranch = !!unavailable?.has(productId);

  const { data, isLoading } = useQuery({
    queryKey: ["product", productId],
    queryFn: async () => {
      const [prod, variants, links, category] = await Promise.all([
        supabase.from("products").select("*").eq("id", productId).maybeSingle(),
        supabase.from("product_variants").select("*").eq("product_id", productId).eq("is_available", true).order("display_order"),
        supabase.from("addon_group_links").select("group_id, product_id, category_id").or(`product_id.eq.${productId}`),
        supabase.from("products").select("category_id").eq("id", productId).maybeSingle().then(r => r.data?.category_id),
      ]);
      const p = prod.data;

      // category info
      let categoryRow: any = null;
      if (p?.category_id) {
        const { data: c } = await supabase.from("product_categories").select("id, name_ar").eq("id", p.category_id).maybeSingle();
        categoryRow = c;
      }

      // addon groups
      let catGroupIds: string[] = [];
      if (p?.category_id) {
        const { data: catLinks } = await supabase.from("addon_group_links").select("group_id").eq("category_id", p.category_id);
        catGroupIds = (catLinks ?? []).map((l: any) => l.group_id);
      }
      const prodGroupIds = (links.data ?? []).map((l: any) => l.group_id);
      const allGroupIds = Array.from(new Set([...prodGroupIds, ...catGroupIds]));

      let groups: any[] = [];
      if (allGroupIds.length > 0) {
        const { data: gs } = await supabase
          .from("addon_groups")
          .select("*, product_addons(*)")
          .in("id", allGroupIds)
          .order("display_order");
        groups = (gs ?? []).map((g: any) => ({
          ...g,
          product_addons: (g.product_addons || []).filter((a: any) => a.is_available).sort((a: any, b: any) => a.display_order - b.display_order),
        }));
      }

      // similar products from same category — order by featured + display_order
      let similarProducts: any[] = [];
      if (p?.category_id) {
        const { data: sim } = await supabase
          .from("products")
          .select("*")
          .eq("category_id", p.category_id)
          .eq("show_in_store", true)
          .eq("is_archived", false)
          .neq("id", productId)
          .order("is_featured", { ascending: false })
          .order("display_order")
          .limit(8);
        similarProducts = sim ?? [];
      }

      // bestseller signal — check if this product appears > 0 times in order_items
      let orderCount = 0;
      const { count } = await supabase
        .from("order_items")
        .select("*", { count: "exact", head: true })
        .eq("product_id", productId);
      orderCount = count || 0;

      return { product: p, variants: variants.data ?? [], groups, similarProducts, category: categoryRow, orderCount };
    },
  });

  const [variantId, setVariantId] = useState<string | null>(null);
  const [selectedAddons, setSelectedAddons] = useState<Record<string, Set<string>>>({});
  const [qty, setQty] = useState(1);
  const [notes, setNotes] = useState("");
  const [activeImage, setActiveImage] = useState(0);
  const [shareOpen, setShareOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const variant = data?.variants.find((v) => v.id === variantId) ?? data?.variants[0] ?? null;
  const effectiveVariantId = variant?.id ?? null;

  const unitPrice = variant ? Number(variant.price) : Number(data?.product?.base_price ?? 0);

  const allAddons = useMemo(() => {
    const out: any[] = [];
    (data?.groups ?? []).forEach((g) => {
      const ids = selectedAddons[g.id] ?? new Set<string>();
      g.product_addons.forEach((a: any) => {
        if (ids.has(a.id)) out.push({ addon_id: a.id, addon_name: a.name_ar, price: Number(a.price || 0) });
      });
    });
    return out;
  }, [data, selectedAddons]);

  const totalPrice = (unitPrice + allAddons.reduce((s, a) => s + a.price, 0)) * qty;

  const images = useMemo(() => {
    if (!data?.product) return [] as string[];
    const list: string[] = [];
    if (data.product.image_url) list.push(data.product.image_url);
    (data.product.gallery_urls || []).forEach((u: string) => { if (u && !list.includes(u)) list.push(u); });
    return list;
  }, [data]);

  const isNew = useMemo(() => {
    if (!data?.product?.created_at) return false;
    const ageDays = (Date.now() - new Date(data.product.created_at).getTime()) / (1000 * 60 * 60 * 24);
    return ageDays <= NEW_DAYS;
  }, [data]);

  const isBestseller = (data?.orderCount || 0) >= 10;

  const toggleAddon = (groupId: string, addonId: string, maxSelect: number) => {
    setSelectedAddons((prev) => {
      const set = new Set(prev[groupId] ?? []);
      if (set.has(addonId)) set.delete(addonId);
      else {
        if (maxSelect === 1) set.clear();
        if (set.size >= maxSelect && maxSelect > 0) {
          toast.error(`يمكنك اختيار ${maxSelect} كحد أقصى من هذه المجموعة`);
          return prev;
        }
        set.add(addonId);
      }
      return { ...prev, [groupId]: set };
    });
  };

  const handleAdd = () => {
    if (!data?.product) return;
    if (isUnavailableInBranch) { toast.error("هذا المنتج غير متوفر في الفرع المختار"); return; }
    if (data.variants.length > 0 && !effectiveVariantId) {
      toast.error("اختر الحجم");
      return;
    }
    for (const g of data.groups) {
      if (g.is_required) {
        const count = (selectedAddons[g.id] ?? new Set()).size;
        if (count < (g.min_select || 1)) {
          toast.error(`الرجاء اختيار من: ${g.name_ar}`);
          return;
        }
      }
    }
    addItem({
      product_id: data.product.id,
      product_name: data.product.name_ar,
      product_image: data.product.image_url,
      variant_id: effectiveVariantId,
      variant_name: variant?.name_ar ?? null,
      unit_price: unitPrice,
      quantity: qty,
      addons: allAddons,
      notes: notes || undefined,
    });
    toast.success("تمت الإضافة للسلة");
    navigate({ to: "/cart" });
  };

  const shareUrl = typeof window !== "undefined" ? window.location.href : "";
  const shareTitle = data?.product?.name_ar || "";

  const onShare = async () => {
    if (typeof navigator !== "undefined" && (navigator as any).share) {
      try {
        await (navigator as any).share({ title: shareTitle, url: shareUrl });
        return;
      } catch { /* user cancelled */ }
    }
    setShareOpen(true);
  };

  const copyLink = async () => {
    try { await navigator.clipboard.writeText(shareUrl); setCopied(true); setTimeout(() => setCopied(false), 1500); toast.success("تم نسخ الرابط"); } catch { toast.error("تعذر النسخ"); }
  };

  if (isLoading) return <StoreLayout><div className="container mx-auto px-4 py-20 text-center text-muted-foreground">جارٍ التحميل...</div></StoreLayout>;
  if (!data?.product) return <StoreLayout><div className="container mx-auto px-4 py-20 text-center">المنتج غير موجود</div></StoreLayout>;

  const p = data.product;

  // JSON-LD product schema
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: p.name_ar,
    description: p.description_ar || undefined,
    image: images.length > 0 ? images : undefined,
    sku: p.id,
    category: data.category?.name_ar,
    offers: {
      "@type": "Offer",
      priceCurrency: "SAR",
      price: Number(p.base_price || 0).toFixed(2),
      availability: p.is_available ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
  };

  return (
    <StoreLayout>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div className="container mx-auto px-4 py-6 pb-32">
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-1 text-xs text-muted-foreground mb-4 flex-wrap">
          <Link to="/" className="hover:text-primary">الرئيسية</Link>
          <ChevronLeft className="w-3 h-3" />
          <Link to="/menu" className="hover:text-primary">المنيو</Link>
          {data.category && (
            <>
              <ChevronLeft className="w-3 h-3" />
              <Link to="/menu/$categoryId" params={{ categoryId: data.category.id }} className="hover:text-primary">{data.category.name_ar}</Link>
            </>
          )}
          <ChevronLeft className="w-3 h-3" />
          <span className="text-foreground font-medium truncate">{p.name_ar}</span>
        </nav>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Gallery */}
          <div>
            <div className="relative aspect-square bg-muted rounded-3xl overflow-hidden">
              {images.length > 0 ? (
                <img src={images[activeImage]} alt={p.name_ar} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground">لا توجد صورة</div>
              )}
              {/* Badges */}
              <div className="absolute top-3 right-3 flex flex-col gap-2">
                {isNew && (
                  <span className="bg-emerald-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 shadow">
                    <Sparkles className="w-3 h-3" /> جديد
                  </span>
                )}
                {(p.is_featured || isBestseller) && (
                  <span className="bg-amber-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 shadow">
                    <TrendingUp className="w-3 h-3" /> {isBestseller ? "الأكثر طلباً" : "مميّز"}
                  </span>
                )}
              </div>
              {/* Share button */}
              <button
                onClick={onShare}
                aria-label="مشاركة"
                className="absolute top-3 left-3 w-10 h-10 rounded-full bg-white/90 hover:bg-white shadow flex items-center justify-center text-foreground"
              >
                <Share2 className="w-4 h-4" />
              </button>

              {/* Prev/Next arrows */}
              {images.length > 1 && (
                <>
                  <button
                    onClick={() => setActiveImage((i) => (i - 1 + images.length) % images.length)}
                    aria-label="السابق"
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/80 hover:bg-white shadow flex items-center justify-center"
                  >
                    <ChevronLeft className="w-5 h-5 rotate-180" />
                  </button>
                  <button
                    onClick={() => setActiveImage((i) => (i + 1) % images.length)}
                    aria-label="التالي"
                    className="absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/80 hover:bg-white shadow flex items-center justify-center"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                </>
              )}
            </div>

            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="flex gap-2 mt-3 overflow-x-auto scrollbar-hide">
                {images.map((src, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`shrink-0 w-20 h-20 rounded-xl overflow-hidden border-2 transition ${i === activeImage ? "border-primary" : "border-transparent opacity-70 hover:opacity-100"}`}
                  >
                    <img src={src} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div>
            <h1 className="text-3xl font-bold">{p.name_ar}</h1>
            {p.description_ar && <p className="text-muted-foreground mt-3 leading-relaxed">{p.description_ar}</p>}

            <div className="flex items-center gap-4 mt-4 text-sm text-muted-foreground">
              {p.calories != null && <span className="flex items-center gap-1"><Flame className="w-4 h-4" />{p.calories} سعرة</span>}
              {p.prep_time_minutes != null && <span className="flex items-center gap-1"><Clock className="w-4 h-4" />{p.prep_time_minutes} دقيقة</span>}
            </div>

            <div className="text-3xl font-bold text-primary mt-4">{unitPrice.toFixed(2)} ر.س</div>

            {data.variants.length > 0 && (
              <div className="mt-6">
                <h3 className="font-bold mb-2">الحجم</h3>
                <div className="grid grid-cols-3 gap-2">
                  {data.variants.map((v) => (
                    <button
                      key={v.id}
                      onClick={() => setVariantId(v.id)}
                      className={`p-3 rounded-xl border-2 text-center transition ${effectiveVariantId === v.id ? "border-primary bg-primary/5" : "border-border"}`}
                    >
                      <div className="font-bold">{v.name_ar}</div>
                      <div className="text-xs text-muted-foreground mt-1">{Number(v.price).toFixed(2)} ر.س</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {data.groups.map((g) => (
              <div key={g.id} className="mt-6">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-bold">{g.name_ar}{g.is_required && <span className="text-destructive me-1">*</span>}</h3>
                  <span className="text-xs text-muted-foreground">
                    {g.max_select === 1 ? "اختر واحد" : `حتى ${g.max_select}`}
                  </span>
                </div>
                <div className="space-y-2">
                  {g.product_addons.map((a: any) => {
                    const checked = (selectedAddons[g.id] ?? new Set()).has(a.id);
                    return (
                      <label key={a.id} className={`flex items-center justify-between p-3 rounded-xl border-2 cursor-pointer transition ${checked ? "border-primary bg-primary/5" : "border-border"}`}>
                        <div className="flex items-center gap-3">
                          <input
                            type={g.max_select === 1 ? "radio" : "checkbox"}
                            name={`g-${g.id}`}
                            checked={checked}
                            onChange={() => toggleAddon(g.id, a.id, g.max_select)}
                            className="accent-primary"
                          />
                          <span className="font-medium">{a.name_ar}</span>
                        </div>
                        {Number(a.price) > 0 && <span className="text-sm text-muted-foreground">+ {Number(a.price).toFixed(2)} ر.س</span>}
                      </label>
                    );
                  })}
                </div>
              </div>
            ))}

            <div className="mt-6">
              <h3 className="font-bold mb-2">ملاحظات (اختياري)</h3>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                placeholder="مثلاً: بدون سكر..."
                className="w-full bg-muted rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <div className="mt-6 flex items-center gap-4">
              <div className="flex items-center bg-muted rounded-xl">
                <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="w-10 h-10 flex items-center justify-center"><Minus className="w-4 h-4" /></button>
                <span className="w-10 text-center font-bold">{qty}</span>
                <button onClick={() => setQty((q) => q + 1)} className="w-10 h-10 flex items-center justify-center"><Plus className="w-4 h-4" /></button>
              </div>
              <button
                onClick={handleAdd}
                disabled={!p.is_available || isUnavailableInBranch}
                className="flex-1 bg-primary text-primary-foreground rounded-xl py-3 font-bold flex items-center justify-center gap-2 disabled:opacity-50 hover:bg-primary/90"
              >
                <ShoppingCart className="w-5 h-5" />
                {isUnavailableInBranch ? "غير متوفر في هذا الفرع" : !p.is_available ? "غير متوفر" : `إضافة - ${totalPrice.toFixed(2)} ر.س`}
              </button>
            </div>
          </div>
        </div>

        {/* Similar products */}
        {data.similarProducts.length > 0 && (
          <section className="mt-12">
            <h2 className="text-xl font-bold mb-4">منتجات مشابهة</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {data.similarProducts.map((sp) => (
                <Link key={sp.id} to="/product/$productId" params={{ productId: sp.id }} className="block bg-card border border-border rounded-2xl overflow-hidden hover:shadow-md transition group">
                  <div className="aspect-square bg-muted relative overflow-hidden">
                    {sp.image_url && <img src={sp.image_url} alt={sp.name_ar} className="w-full h-full object-cover group-hover:scale-105 transition" />}
                    {sp.is_featured && (
                      <span className="absolute top-2 right-2 bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">مميّز</span>
                    )}
                  </div>
                  <div className="p-3">
                    <div className="font-bold text-sm line-clamp-1">{sp.name_ar}</div>
                    <div className="text-primary font-bold text-sm mt-1">{Number(sp.base_price).toFixed(2)} ر.س</div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>

      {/* Share modal fallback */}
      {shareOpen && (
        <div className="fixed inset-0 z-[70] bg-black/50 flex items-end md:items-center justify-center p-4" onClick={() => setShareOpen(false)}>
          <div className="bg-card rounded-2xl p-5 w-full max-w-sm" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-bold text-lg mb-3 text-center">مشاركة المنتج</h3>
            <div className="grid grid-cols-4 gap-3 mb-3">
              <a href={`https://wa.me/?text=${encodeURIComponent(`${shareTitle}\n${shareUrl}`)}`} target="_blank" rel="noreferrer" className="flex flex-col items-center gap-1 p-3 rounded-xl hover:bg-muted">
                <div className="w-10 h-10 rounded-full bg-[#25D366] text-white flex items-center justify-center font-bold">W</div>
                <span className="text-xs">واتساب</span>
              </a>
              <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareTitle)}&url=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noreferrer" className="flex flex-col items-center gap-1 p-3 rounded-xl hover:bg-muted">
                <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center font-bold">X</div>
                <span className="text-xs">تويتر</span>
              </a>
              <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noreferrer" className="flex flex-col items-center gap-1 p-3 rounded-xl hover:bg-muted">
                <div className="w-10 h-10 rounded-full bg-[#1877F2] text-white flex items-center justify-center font-bold">f</div>
                <span className="text-xs">فيسبوك</span>
              </a>
              <a href={`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareTitle)}`} target="_blank" rel="noreferrer" className="flex flex-col items-center gap-1 p-3 rounded-xl hover:bg-muted">
                <div className="w-10 h-10 rounded-full bg-[#0088cc] text-white flex items-center justify-center font-bold">T</div>
                <span className="text-xs">تيليجرام</span>
              </a>
            </div>
            <button onClick={copyLink} className="w-full bg-muted hover:bg-muted/70 rounded-xl py-3 font-bold text-sm flex items-center justify-center gap-2">
              {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              {copied ? "تم النسخ" : "نسخ الرابط"}
            </button>
            <button onClick={() => setShareOpen(false)} className="w-full mt-2 text-sm text-muted-foreground py-2">إغلاق</button>
          </div>
        </div>
      )}
    </StoreLayout>
  );
}
