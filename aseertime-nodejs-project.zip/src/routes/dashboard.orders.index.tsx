import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ShoppingBag, Search, Eye } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { ORDER_STATUS_LABEL, ORDER_STATUS_COLOR, ORDER_TYPE_LABEL, PAYMENT_LABEL, StatusBadge } from "@/lib/orders";
import { DateField } from "@/components/DateField";

export const Route = createFileRoute("/dashboard/orders/")({ component: OrdersPage });

const STATS = [
  { key: "all", label: "إجمالي الطلبات" },
  { key: "today", label: "طلبات اليوم" },
  { key: "new", label: "جديدة" },
  { key: "preparing", label: "قيد التحضير" },
  { key: "with_driver", label: "قيد التوصيل" },
  { key: "delivered", label: "تم التسليم" },
  { key: "cancelled", label: "ملغية" },
  { key: "sales", label: "إجمالي المبيعات" },
];

function OrdersPage() {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [branch, setBranch] = useState("");
  const [type, setType] = useState("");
  const [pay, setPay] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const { data: branches = [] } = useQuery({
    queryKey: ["branches-list"],
    queryFn: async () => (await supabase.from("branches").select("id,name").order("display_order")).data ?? [],
  });

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ["orders", { status, branch, type, pay, from, to }],
    queryFn: async () => {
      let q = supabase.from("orders").select("*, customer:customers(name,phone), branch:branches(name), driver:drivers(name)").order("created_at", { ascending: false }).limit(500);
      if (status) q = q.eq("status", status as never);
      if (branch) q = q.eq("branch_id", branch);
      if (type) q = q.eq("order_type", type as never);
      if (pay) q = q.eq("payment_method", pay as never);
      if (from) q = q.gte("created_at", from);
      if (to) q = q.lte("created_at", to);
      const { data, error } = await q;
      if (error) throw error;
      return data ?? [];
    },
  });

  const filtered = orders.filter((o) => {
    if (!search) return true;
    const s = search.toLowerCase();
    const c = (o as { customer?: { name?: string; phone?: string } | null }).customer;
    return o.order_number.toLowerCase().includes(s) || c?.name?.toLowerCase().includes(s) || c?.phone?.includes(s);
  });

  const today = new Date(); today.setHours(0,0,0,0);
  const stats = {
    all: orders.length,
    today: orders.filter((o) => new Date(o.created_at) >= today).length,
    new: orders.filter((o) => o.status === "new").length,
    preparing: orders.filter((o) => o.status === "preparing").length,
    with_driver: orders.filter((o) => o.status === "with_driver").length,
    delivered: orders.filter((o) => o.status === "delivered").length,
    cancelled: orders.filter((o) => o.status === "cancelled").length,
    sales: orders.filter((o) => o.status === "delivered").reduce((s, o) => s + Number(o.total_amount), 0),
  };

  return (
    <div>
      <PageHeader title="الطلبات" description="إدارة ومتابعة طلبات العملاء." />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {STATS.map((s) => (
          <Card key={s.key} className="p-4">
            <div className="text-xs text-muted-foreground">{s.label}</div>
            <div className="text-2xl font-bold mt-1">
              {s.key === "sales" ? `${stats.sales.toFixed(2)} ر.س` : (stats as Record<string, number>)[s.key] ?? 0}
            </div>
          </Card>
        ))}
      </div>

      <Card className="p-4 mb-4">
        <div className="grid md:grid-cols-7 gap-2">
          <div className="md:col-span-2 relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="بحث برقم الطلب أو الجوال أو الاسم" value={search} onChange={(e) => setSearch(e.target.value)} className="pe-9" />
          </div>
          <select className="h-9 rounded-md border border-input bg-background px-2 text-sm" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">كل الحالات</option>
            {Object.entries(ORDER_STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <select className="h-9 rounded-md border border-input bg-background px-2 text-sm" value={branch} onChange={(e) => setBranch(e.target.value)}>
            <option value="">كل الفروع</option>
            {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
          <select className="h-9 rounded-md border border-input bg-background px-2 text-sm" value={type} onChange={(e) => setType(e.target.value)}>
            <option value="">كل الأنواع</option>
            <option value="delivery">توصيل</option>
            <option value="pickup">استلام</option>
          </select>
          <select className="h-9 rounded-md border border-input bg-background px-2 text-sm" value={pay} onChange={(e) => setPay(e.target.value)}>
            <option value="">كل طرق الدفع</option>
            {Object.entries(PAYMENT_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <DateField value={from} onChange={(v) => setFrom(v ?? "")} />
          <DateField value={to} onChange={(v) => setTo(v ?? "")} />
        </div>
      </Card>

      {isLoading ? <div className="text-muted-foreground">جارٍ التحميل...</div> :
       orders.length === 0 ? (
        <EmptyState
          icon={ShoppingBag}
          title="لا توجد طلبات حتى الآن"
          description="ستظهر الطلبات الواردة من التطبيق والمتجر هنا تلقائياً."
          actionLabel="تحديث البيانات"
          onAction={() => window.location.reload()}
        />
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-start p-3">رقم الطلب</th>
                  <th className="text-start p-3">العميل</th>
                  <th className="text-start p-3">الفرع</th>
                  <th className="text-start p-3">النوع</th>
                  <th className="text-start p-3">الحالة</th>
                  <th className="text-start p-3">الدفع</th>
                  <th className="text-start p-3">السائق</th>
                  <th className="text-start p-3">الإجمالي</th>
                  <th className="text-start p-3">الوقت</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((o) => {
                  const c = (o as { customer?: { name?: string; phone?: string } | null }).customer;
                  const b = (o as { branch?: { name?: string } | null }).branch;
                  const d = (o as { driver?: { name?: string } | null }).driver;
                  return (
                    <tr key={o.id} className="border-t hover:bg-muted/30">
                      <td className="p-3 font-mono font-medium">{o.order_number}</td>
                      <td className="p-3">
                        <div>{c?.name ?? "—"}</div>
                        <div className="text-xs text-muted-foreground" dir="ltr">{c?.phone ?? ""}</div>
                      </td>
                      <td className="p-3 text-muted-foreground">{b?.name ?? "—"}</td>
                      <td className="p-3">{ORDER_TYPE_LABEL[o.order_type]}</td>
                      <td className="p-3"><StatusBadge status={o.status} map={ORDER_STATUS_LABEL} color={ORDER_STATUS_COLOR} /></td>
                      <td className="p-3 text-xs">{PAYMENT_LABEL[o.payment_method]}</td>
                      <td className="p-3 text-muted-foreground">{d?.name ?? "—"}</td>
                      <td className="p-3 font-medium">{Number(o.total_amount).toFixed(2)} ر.س</td>
                      <td className="p-3 text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString("en-GB")}</td>
                      <td className="p-3">
                        <Button asChild size="icon" variant="ghost">
                          <Link to="/dashboard/orders/$orderId" params={{ orderId: o.id }}><Eye className="w-4 h-4" /></Link>
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
