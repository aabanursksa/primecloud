import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { Phone, Mail, MapPin, Clock, Send } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: "تواصل معنا — عصير تايم" },
      { name: "description", content: "تواصل مع فريق عصير تايم لأي استفسار أو ملاحظة." },
    ],
  }),
});

function ContactPage() {
  const { data: footer } = useQuery({
    queryKey: ["contact-footer"],
    queryFn: async () => (await supabase.from("footer_settings").select("*").maybeSingle()).data,
  });

  const [form, setForm] = useState({ name: "", phone: "", email: "", message: "" });
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.name.trim().length < 2) return toast.error("الرجاء إدخال الاسم");
    if (form.phone.trim().length < 6) return toast.error("الرجاء إدخال رقم جوال صحيح");
    if (form.message.trim().length < 2) return toast.error("الرجاء كتابة رسالتك");
    setLoading(true);
    const { error } = await supabase.from("contact_messages").insert({
      name: form.name.trim(),
      phone: form.phone.trim(),
      email: form.email.trim() || null,
      message: form.message.trim(),
    });
    setLoading(false);
    if (error) return toast.error("تعذّر إرسال الرسالة، حاول لاحقاً");
    toast.success("تم استلام رسالتك، سنتواصل معك قريباً");
    setForm({ name: "", phone: "", email: "", message: "" });
  };

  return (
    <StoreLayout>
      <div className="container mx-auto px-4 py-10 max-w-5xl">
        <h1 className="text-3xl md:text-4xl font-bold text-center">تواصل معنا</h1>
        <p className="text-center text-muted-foreground mt-2">يسعدنا تواصلك معنا في أي وقت</p>

        <div className="grid md:grid-cols-2 gap-6 mt-8">
          <form onSubmit={submit} className="bg-card border border-border rounded-2xl p-6 space-y-4">
            <div>
              <label className="text-sm font-bold mb-1 block">الاسم *</label>
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full bg-muted rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-bold mb-1 block">الجوال *</label>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} dir="ltr" className="w-full bg-muted rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
              <div>
                <label className="text-sm font-bold mb-1 block">البريد (اختياري)</label>
                <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} dir="ltr" className="w-full bg-muted rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
            </div>
            <div>
              <label className="text-sm font-bold mb-1 block">الرسالة *</label>
              <textarea rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="w-full bg-muted rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
            </div>
            <button disabled={loading} className="w-full bg-primary text-primary-foreground py-3 rounded-xl font-bold flex items-center justify-center gap-2 disabled:opacity-60">
              <Send className="w-4 h-4" />
              {loading ? "جارٍ الإرسال..." : "إرسال الرسالة"}
            </button>
          </form>

          <div className="space-y-3">
            {footer?.phone && (
              <a href={`tel:${footer.phone}`} className="flex items-center gap-3 bg-card border border-border rounded-2xl p-5 hover:shadow-md transition">
                <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center"><Phone className="w-5 h-5" /></div>
                <div><div className="text-xs text-muted-foreground">الجوال</div><div dir="ltr" className="font-bold">{footer.phone}</div></div>
              </a>
            )}
            {footer?.email && (
              <a href={`mailto:${footer.email}`} className="flex items-center gap-3 bg-card border border-border rounded-2xl p-5 hover:shadow-md transition">
                <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center"><Mail className="w-5 h-5" /></div>
                <div><div className="text-xs text-muted-foreground">البريد</div><div dir="ltr" className="font-bold">{footer.email}</div></div>
              </a>
            )}
            {footer?.address && (
              <div className="flex items-center gap-3 bg-card border border-border rounded-2xl p-5">
                <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center"><MapPin className="w-5 h-5" /></div>
                <div><div className="text-xs text-muted-foreground">العنوان</div><div className="font-bold">{footer.address}</div></div>
              </div>
            )}
            {footer?.working_hours && (
              <div className="flex items-center gap-3 bg-card border border-border rounded-2xl p-5">
                <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center"><Clock className="w-5 h-5" /></div>
                <div><div className="text-xs text-muted-foreground">ساعات العمل</div><div className="font-bold">{footer.working_hours}</div></div>
              </div>
            )}
          </div>
        </div>
      </div>
    </StoreLayout>
  );
}
