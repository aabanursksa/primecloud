import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Store, Plus, Pencil, Trash2, Eye } from "lucide-react";
import { DetailDrawer, useDetailDrawer } from "@/components/DetailDrawer";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, PageHeader } from "@/components/EmptyState";
import { toast } from "sonner";
import { logActivity } from "@/lib/activity";

export const Route = createFileRoute("/dashboard/branches")({ component: BranchesPage });

type Branch = {
  id?: string;
  name: string;
  phone: string;
  address: string;
  latitude: number | null;
  longitude: number | null;
  is_active: boolean;
  accepts_orders: boolean;
  delivery_radius_km: number;
  delivery_fee: number;
  min_order_amount: number;
  display_order: number;
};

const empty: Branch = {
  name: "", phone: "", address: "", latitude: null, longitude: null,
  is_active: true, accepts_orders: true,
  delivery_radius_km: 10, delivery_fee: 0, min_order_amount: 0, display_order: 0,
};

function BranchesPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Branch>(empty);
  const detail = useDetailDrawer();

  const { data: branches = [], isLoading } = useQuery({
    queryKey: ["branches"],
    queryFn: async () => {
      const { data, error } = await supabase.from("branches").select("*").order("display_order");
      if (error) throw error;
      return data ?? [];
    },
  });

  const openNew = () => { setForm(empty); setOpen(true); };
  const openEdit = (b: typeof branches[number]) => {
    const norm = Object.fromEntries(Object.entries(b).map(([k, v]) => [k, v ?? (typeof empty[k as keyof Branch] === "string" ? "" : v)])) as unknown as Branch;
    setForm({ ...empty, ...norm }); setOpen(true);
  };

  const save = async () => {
    try {
      if (form.id) {
        const { error } = await supabase.from("branches").update(form).eq("id", form.id);
        if (error) throw error;
        await logActivity("update_branch", "branches", form.id, { name: form.name });
      } else {
        const { id: _ignore, ...payload } = form;
        void _ignore;
        const { data, error } = await supabase.from("branches").insert(payload).select().single();
        if (error) throw error;
        await logActivity("create_branch", "branches", data.id, { name: form.name });
      }
      toast.success("تم الحفظ");
      setOpen(false);
      qc.invalidateQueries({ queryKey: ["branches"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل الحفظ");
    }
  };

  const remove = async (b: typeof branches[number]) => {
    if (!confirm(`حذف فرع "${b.name}"؟`)) return;
    const { error } = await supabase.from("branches").delete().eq("id", b.id);
    if (error) return toast.error(error.message);
    await logActivity("delete_branch", "branches", b.id, { name: b.name });
    toast.success("تم الحذف");
    qc.invalidateQueries({ queryKey: ["branches"] });
  };

  return (
    <div>
      <PageHeader
        title="الفروع"
        description="إدارة فروع المتجر."
        action={<Button onClick={openNew} className="bg-gradient-primary text-primary-foreground shadow-glow gap-2"><Plus className="w-4 h-4" />إضافة فرع</Button>}
      />
      {isLoading ? (
        <div className="text-muted-foreground">جارٍ التحميل...</div>
      ) : branches.length === 0 ? (
        <EmptyState icon={Store} title="لا توجد فروع بعد" description="ابدأ بإضافة أول فرع لمتجرك." actionLabel="أضف أول فرع" onAction={openNew} />
      ) : (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-start p-3 font-medium">الاسم</th>
                <th className="text-start p-3 font-medium">الجوال</th>
                <th className="text-start p-3 font-medium">العنوان</th>
                <th className="text-start p-3 font-medium">الحالة</th>
                <th className="text-start p-3 font-medium">رسوم التوصيل</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {branches.map((b) => (
                <tr key={b.id} className="border-t">
                  <td className="p-3 font-medium">{b.name}</td>
                  <td className="p-3" dir="ltr">{b.phone}</td>
                  <td className="p-3 text-muted-foreground">{b.address}</td>
                  <td className="p-3">
                    {b.is_active ? <span className="text-xs bg-success/10 text-success px-2 py-1 rounded">نشط</span> : <span className="text-xs bg-muted px-2 py-1 rounded">غير نشط</span>}
                  </td>
                  <td className="p-3">{b.delivery_fee} ر.س</td>
                  <td className="p-3 flex gap-1 justify-end">
                    <Button size="icon" variant="ghost" onClick={() => b.id && detail.openDetails("branches", b.id)}><Eye className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => openEdit(b)}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(b)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl" dir="rtl">
          <DialogHeader><DialogTitle>{form.id ? "تعديل فرع" : "إضافة فرع جديد"}</DialogTitle></DialogHeader>
          <div className="grid md:grid-cols-2 gap-4">
            <F label="اسم الفرع"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></F>
            <F label="الجوال"><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} dir="ltr" /></F>
            <F label="العنوان" full><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></F>
            <F label="خط العرض"><Input type="number" step="any" value={form.latitude ?? ""} onChange={(e) => setForm({ ...form, latitude: e.target.value ? parseFloat(e.target.value) : null })} /></F>
            <F label="خط الطول"><Input type="number" step="any" value={form.longitude ?? ""} onChange={(e) => setForm({ ...form, longitude: e.target.value ? parseFloat(e.target.value) : null })} /></F>
            <F label="نطاق التوصيل (كم)"><Input type="number" step="0.5" value={form.delivery_radius_km} onChange={(e) => setForm({ ...form, delivery_radius_km: parseFloat(e.target.value) || 0 })} /></F>
            <F label="رسوم التوصيل"><Input type="number" step="0.01" value={form.delivery_fee} onChange={(e) => setForm({ ...form, delivery_fee: parseFloat(e.target.value) || 0 })} /></F>
            <F label="الحد الأدنى للطلب"><Input type="number" step="0.01" value={form.min_order_amount} onChange={(e) => setForm({ ...form, min_order_amount: parseFloat(e.target.value) || 0 })} /></F>
            <F label="ترتيب الظهور"><Input type="number" value={form.display_order} onChange={(e) => setForm({ ...form, display_order: parseInt(e.target.value) || 0 })} /></F>
            <F label="الحالة"><div className="flex items-center gap-2 h-10"><Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} /><span className="text-sm">{form.is_active ? "نشط" : "غير نشط"}</span></div></F>
            <F label="يقبل الطلبات"><div className="flex items-center gap-2 h-10"><Switch checked={form.accepts_orders} onCheckedChange={(v) => setForm({ ...form, accepts_orders: v })} /><span className="text-sm">{form.accepts_orders ? "نعم" : "لا"}</span></div></F>
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="ghost" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button onClick={save} className="bg-gradient-primary text-primary-foreground">حفظ</Button>
          </div>
        </DialogContent>
      </Dialog>
      <DetailDrawer entity="branches" recordId={detail.id} open={detail.open} onOpenChange={detail.setOpen} />
    </div>
  );
}

function F({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return <div className={full ? "md:col-span-2" : ""}><Label className="mb-1.5 block">{label}</Label>{children}</div>;
}
