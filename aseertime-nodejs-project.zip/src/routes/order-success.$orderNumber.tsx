import { createFileRoute, useParams, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { useCart } from "@/lib/cart";
import { CheckCircle2, MapPin, Truck, Store as StoreIcon, Phone } from "lucide-react";

export const Route = createFileRoute("/order-success/$orderNumber")({ component: SuccessPage });

const STATUS_LABELS: Record<string, string> = {
  new: "تم استلام الطلب", accepted: "مقبول", preparing: "قيد التحضير",
  ready: "جاهز", on_the_way: "مع السائق", delivered: "تم التسليم", cancelled: "ملغي",
};

function SuccessPage() {
  const { orderNumber } = useParams({ from: "/order-success/$orderNumber" });
  const { customerPhone } = useCart();

  const { data: order } = useQuery({
    queryKey: ["order-success", orderNumber, customerPhone],
    queryFn: async () => {
      if (!customerPhone) return null;
      const { data } = await supabase.rpc("track_order", { _order_number: orderNumber, _phone: customerPhone });
      return data as any;
    },
    enabled: !!customerPhone,
  });

  return (
    <StoreLayout>
      <div className="container mx-auto px-4 py-10 max-w-2xl">
        <div className="text-center">
          <CheckCircle2 className="w-20 h-20 mx-auto text-success mb-4" />
          <h1 className="text-3xl font-bold">تم استلام طلبك بنجاح</h1>
          <p className="text-muted-foreground mt-2">رقم الطلب</p>
          <div className="text-2xl font-bold text-primary mt-1">{orderNumber}</div>
        </div>

        {order && (
          <div className="bg-card border border-border rounded-2xl p-5 mt-6 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">الحالة</span>
              <span className="font-bold">{STATUS_LABELS[order.status] || order.status}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                {order.order_type === "pickup" ? <StoreIcon className="w-4 h-4" /> : <Truck className="w-4 h-4" />}
                نوع الطلب
              </span>
              <span className="font-bold">{order.order_type === "pickup" ? "استلام" : "توصيل"}</span>
            </div>
            {order.branch && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground flex items-center gap-1"><MapPin className="w-4 h-4" />الفرع</span>
                <span className="font-bold">{order.branch.name}</span>
              </div>
            )}
            {order.items?.length > 0 && (
              <div className="border-t border-border pt-3 space-y-1.5">
                {order.items.map((it: any, i: number) => (
                  <div key={i} className="flex justify-between text-sm">
                    <span>{it.product_name}{it.variant_name ? ` (${it.variant_name})` : ""} × {it.quantity}</span>
                    <span>{Number(it.total_price).toFixed(2)} ر.س</span>
                  </div>
                ))}
              </div>
            )}
            <div className="flex items-center justify-between border-t border-border pt-3">
              <span className="font-bold">الإجمالي</span>
              <span className="text-primary font-bold text-lg">{Number(order.total_amount).toFixed(2)} ر.س</span>
            </div>
            {order.branch?.phone && (
              <a href={`tel:${order.branch.phone}`} className="flex items-center justify-center gap-2 bg-muted py-2 rounded-xl text-sm">
                <Phone className="w-4 h-4" /> اتصل بالفرع: {order.branch.phone}
              </a>
            )}
          </div>
        )}

        <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
          <Link to="/track-order" className="bg-primary text-primary-foreground px-6 py-3 rounded-xl font-bold text-center">تتبع الطلب</Link>
          <Link to="/my-orders" className="bg-muted px-6 py-3 rounded-xl font-bold text-center">طلباتي</Link>
          <Link to="/menu" className="bg-muted px-6 py-3 rounded-xl font-bold text-center">العودة للمنيو</Link>
        </div>
      </div>
    </StoreLayout>
  );
}
