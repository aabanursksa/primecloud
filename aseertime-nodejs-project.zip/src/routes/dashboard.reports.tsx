import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { PageHeader } from "@/components/EmptyState";
import { ORDER_STATUS_LABEL } from "@/lib/orders";
import { Download } from "lucide-react";
import * as XLSX from "xlsx";
import { DateField } from "@/components/DateField";

export const Route = createFileRoute("/dashboard/reports")({ component: ReportsPage });

function exportXlsx(rows: Record<string, unknown>[], filename: string) {
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Report");
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

function ReportsPage() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [branch, setBranch] = useState("");

  const { data: branches = [] } = useQuery({ queryKey: ["branches-list"], queryFn: async () => (await supabase.from("branches").select("id,name")).data ?? [] });
  const { data: orders = [] } = useQuery({
    queryKey: ["report-orders", { from, to, branch }],
    queryFn: async () => {
      let q = supabase.from("orders").select("*, customer:customers(name,phone), branch:branches(name), driver:drivers(name)").limit(5000);
      if (from) q = q.gte("created_at", from);
      if (to) q = q.lte("created_at", to);
      if (branch) q = q.eq("branch_id", branch);
      return (await q).data ?? [];
    },
  });
  const { data: customers = [] } = useQuery({ queryKey: ["report-customers"], queryFn: async () => (await supabase.from("customers").select("*, orders:orders(id,total_amount,created_at,status)")).data ?? [] });
  const { data: drivers = [] } = useQuery({ queryKey: ["report-drivers"], queryFn: async () => (await supabase.from("drivers").select("*, orders:orders(id,status)")).data ?? [] });
  const { data: coupons = [] } = useQuery({ queryKey: ["report-coupons"], queryFn: async () => (await supabase.from("coupons").select("*, usages:coupon_usages(discount_amount,order_id)")).data ?? [] });

  const completed = orders.filter((o) => o.status === "delivered");
  const cancelled = orders.filter((o) => o.status === "cancelled");
  const sales = completed.reduce((s, o) => s + Number(o.total_amount), 0);
  const avg = completed.length ? sales / completed.length : 0;

  return (
    <div>
      <PageHeader title="التقارير" description="تقارير شاملة عن أداء المتجر." />

      <Card className="p-4 mb-4">
        <div className="grid md:grid-cols-4 gap-2">
          <div><label className="text-xs text-muted-foreground">من</label><DateField value={from} onChange={(v) => setFrom(v ?? "")} /></div>
          <div><label className="text-xs text-muted-foreground">إلى</label><DateField value={to} onChange={(v) => setTo(v ?? "")} /></div>
          <div><label className="text-xs text-muted-foreground">الفرع</label>
            <select className="w-full h-9 rounded-md border border-input bg-background px-2 text-sm" value={branch} onChange={(e) => setBranch(e.target.value)}>
              <option value="">كل الفروع</option>
              {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          </div>
        </div>
      </Card>

      <Tabs defaultValue="orders">
        <TabsList>
          <TabsTrigger value="orders">الطلبات</TabsTrigger>
          <TabsTrigger value="branches">الفروع</TabsTrigger>
          <TabsTrigger value="drivers">السائقون</TabsTrigger>
          <TabsTrigger value="customers">العملاء</TabsTrigger>
          <TabsTrigger value="coupons">الكوبونات</TabsTrigger>
        </TabsList>

        <TabsContent value="orders">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
            <Card className="p-4"><div className="text-xs text-muted-foreground">الطلبات</div><div className="text-2xl font-bold">{orders.length}</div></Card>
            <Card className="p-4"><div className="text-xs text-muted-foreground">المبيعات</div><div className="text-2xl font-bold">{sales.toFixed(0)} ر.س</div></Card>
            <Card className="p-4"><div className="text-xs text-muted-foreground">متوسط الطلب</div><div className="text-2xl font-bold">{avg.toFixed(0)} ر.س</div></Card>
            <Card className="p-4"><div className="text-xs text-muted-foreground">المكتملة</div><div className="text-2xl font-bold">{completed.length}</div></Card>
            <Card className="p-4"><div className="text-xs text-muted-foreground">الملغية</div><div className="text-2xl font-bold">{cancelled.length}</div></Card>
          </div>
          <Card className="p-4">
            <div className="flex justify-between mb-3">
              <h3 className="font-bold">تقرير الطلبات</h3>
              <Button size="sm" variant="outline" className="gap-2" onClick={() => exportXlsx(orders.map((o) => ({ "رقم الطلب": o.order_number, "الحالة": ORDER_STATUS_LABEL[o.status], "الإجمالي": o.total_amount, "التاريخ": o.created_at })), "orders-report")}><Download className="w-4 h-4" />تصدير Excel</Button>
            </div>
            <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
              {Object.entries(ORDER_STATUS_LABEL).map(([k, v]) => (
                <div key={k} className="p-3 bg-muted/40 rounded-lg text-center">
                  <div className="text-xs text-muted-foreground">{v}</div>
                  <div className="text-lg font-bold">{orders.filter((o) => o.status === k).length}</div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="branches">
          <Card className="p-4">
            <div className="flex justify-between mb-3">
              <h3 className="font-bold">أداء الفروع</h3>
              <Button size="sm" variant="outline" className="gap-2" onClick={() => {
                const rows = branches.map((b) => {
                  const bo = orders.filter((o) => o.branch_id === b.id);
                  const bc = bo.filter((o) => o.status !== "cancelled");
                  return {
                    "الفرع": b.name,
                    "الطلبات": bo.length,
                    "المبيعات": bc.reduce((s, o) => s + Number(o.total_amount), 0),
                    "متوسط الطلب": bc.length ? bc.reduce((s, o) => s + Number(o.total_amount), 0) / bc.length : 0,
                    "الملغية": bo.filter((o) => o.status === "cancelled").length,
                  };
                });
                exportXlsx(rows, "branches-report");
              }}><Download className="w-4 h-4" />تصدير Excel</Button>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-muted/50"><tr><th className="text-start p-2">الفرع</th><th className="text-start p-2">الطلبات</th><th className="text-start p-2">المبيعات</th><th className="text-start p-2">متوسط الطلب</th><th className="text-start p-2">الملغية</th></tr></thead>
              <tbody>{branches.map((b) => {
                const bo = orders.filter((o) => o.branch_id === b.id);
                const bc = bo.filter((o) => o.status !== "cancelled");
                const sumv = bc.reduce((s, o) => s + Number(o.total_amount), 0);
                return (<tr key={b.id} className="border-t"><td className="p-2 font-medium">{b.name}</td><td className="p-2">{bo.length}</td><td className="p-2">{sumv.toFixed(2)} ر.س</td><td className="p-2">{bc.length ? (sumv / bc.length).toFixed(2) : 0} ر.س</td><td className="p-2">{bo.filter((o) => o.status === "cancelled").length}</td></tr>);
              })}</tbody>
            </table>
          </Card>
        </TabsContent>

        <TabsContent value="drivers">
          <Card className="p-4">
            <div className="flex justify-between mb-3">
              <h3 className="font-bold">أداء السائقين</h3>
              <Button size="sm" variant="outline" className="gap-2" onClick={() => exportXlsx(drivers.map((d) => {
                const dorders = (d as { orders?: Array<{ status: string }> }).orders ?? [];
                return { "السائق": d.name, "الجوال": d.phone, "المسلمة": dorders.filter((o) => o.status === "delivered").length, "الحالية": dorders.filter((o) => ["with_driver","awaiting_driver"].includes(o.status)).length, "التقييم": d.rating, "الحالة": d.status };
              }), "drivers-report")}><Download className="w-4 h-4" />تصدير Excel</Button>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-muted/50"><tr><th className="text-start p-2">السائق</th><th className="text-start p-2">المسلمة</th><th className="text-start p-2">الحالية</th><th className="text-start p-2">التقييم</th><th className="text-start p-2">الحالة</th></tr></thead>
              <tbody>{drivers.map((d) => {
                const dorders = (d as { orders?: Array<{ status: string }> }).orders ?? [];
                return (<tr key={d.id} className="border-t"><td className="p-2 font-medium">{d.name}</td><td className="p-2">{dorders.filter((o) => o.status === "delivered").length}</td><td className="p-2">{dorders.filter((o) => ["with_driver","awaiting_driver"].includes(o.status)).length}</td><td className="p-2">{Number(d.rating).toFixed(1)}</td><td className="p-2">{d.status}</td></tr>);
              })}</tbody>
            </table>
          </Card>
        </TabsContent>

        <TabsContent value="customers">
          <Card className="p-4">
            <div className="flex justify-between mb-3">
              <h3 className="font-bold">تقرير العملاء</h3>
              <Button size="sm" variant="outline" className="gap-2" onClick={() => exportXlsx(customers.map((c) => {
                const co = (c as { orders?: Array<{ total_amount: number; status: string }> }).orders ?? [];
                const completed = co.filter((o) => o.status !== "cancelled");
                return { "الاسم": c.name, "الجوال": c.phone, "الطلبات": completed.length, "الإنفاق": completed.reduce((s, o) => s + Number(o.total_amount), 0), "التسجيل": c.created_at };
              }), "customers-report")}><Download className="w-4 h-4" />تصدير Excel</Button>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-muted/50"><tr><th className="text-start p-2">العميل</th><th className="text-start p-2">الطلبات</th><th className="text-start p-2">الإنفاق</th><th className="text-start p-2">التسجيل</th></tr></thead>
              <tbody>{customers.slice(0,100).map((c) => {
                const co = (c as { orders?: Array<{ total_amount: number; status: string }> }).orders ?? [];
                const completed = co.filter((o) => o.status !== "cancelled");
                return (<tr key={c.id} className="border-t"><td className="p-2 font-medium">{c.name}</td><td className="p-2">{completed.length}</td><td className="p-2">{completed.reduce((s, o) => s + Number(o.total_amount), 0).toFixed(2)} ر.س</td><td className="p-2 text-xs text-muted-foreground">{new Date(c.created_at).toLocaleDateString("en-GB")}</td></tr>);
              })}</tbody>
            </table>
          </Card>
        </TabsContent>

        <TabsContent value="coupons">
          <Card className="p-4">
            <div className="flex justify-between mb-3">
              <h3 className="font-bold">تقرير الكوبونات</h3>
              <Button size="sm" variant="outline" className="gap-2" onClick={() => exportXlsx(coupons.map((c) => {
                const usages = (c as { usages?: Array<{ discount_amount: number }> }).usages ?? [];
                return { "الكوبون": c.code, "الاسم": c.name, "الاستخدامات": c.used_count, "إجمالي الخصم": usages.reduce((s, u) => s + Number(u.discount_amount), 0), "الحالة": c.status };
              }), "coupons-report")}><Download className="w-4 h-4" />تصدير Excel</Button>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-muted/50"><tr><th className="text-start p-2">الكود</th><th className="text-start p-2">الاسم</th><th className="text-start p-2">الاستخدامات</th><th className="text-start p-2">إجمالي الخصم</th><th className="text-start p-2">الحالة</th></tr></thead>
              <tbody>{coupons.map((c) => {
                const usages = (c as { usages?: Array<{ discount_amount: number }> }).usages ?? [];
                return (<tr key={c.id} className="border-t"><td className="p-2 font-mono" dir="ltr">{c.code}</td><td className="p-2">{c.name}</td><td className="p-2">{c.used_count}</td><td className="p-2">{usages.reduce((s, u) => s + Number(u.discount_amount), 0).toFixed(2)} ر.س</td><td className="p-2">{c.status}</td></tr>);
              })}</tbody>
            </table>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
