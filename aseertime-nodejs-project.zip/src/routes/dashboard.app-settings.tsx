import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Save, Smartphone } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/EmptyState";

export const Route = createFileRoute("/dashboard/app-settings")({ component: AppSettingsPage });

type AppSettings = {
  id?: string; app_name: string | null;
  app_store_url: string | null; google_play_url: string | null;
  current_version: string | null; minimum_version: string | null; force_update: boolean;
  maintenance_mode: boolean; maintenance_message: string | null;
  push_settings: { enabled?: boolean; provider?: string; default_topic?: string };
  home_layout: { show_hero?: boolean; show_categories?: boolean; show_featured?: boolean; show_offers?: boolean };
};

function AppSettingsPage() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["app_settings"],
    queryFn: async () => (await supabase.from("app_settings").select("*").maybeSingle()).data,
  });
  const [form, setForm] = useState<AppSettings | null>(null);
  useEffect(() => {
    if (data) setForm({ ...(data as any), push_settings: (data as any).push_settings ?? {}, home_layout: (data as any).home_layout ?? {} });
    else if (!isLoading) setForm({
      app_name: "", app_store_url: "", google_play_url: "",
      current_version: "1.0.0", minimum_version: "1.0.0", force_update: false,
      maintenance_mode: false, maintenance_message: "",
      push_settings: { enabled: true, provider: "fcm", default_topic: "all" },
      home_layout: { show_hero: true, show_categories: true, show_featured: true, show_offers: true },
    });
  }, [data, isLoading]);

  const save = async () => {
    if (!form) return;
    const res = form.id
      ? await supabase.from("app_settings").update(form).eq("id", form.id)
      : await supabase.from("app_settings").insert(form);
    if (res.error) return toast.error(res.error.message);
    toast.success("تم حفظ إعدادات التطبيق");
    qc.invalidateQueries({ queryKey: ["app_settings"] });
  };

  if (isLoading || !form) return <Skeleton className="h-96" />;

  return (
    <>
      <PageHeader title="إعدادات التطبيق" description="إدارة تطبيق الموبايل" action={
        <Button onClick={save} className="bg-gradient-primary text-primary-foreground gap-2"><Save className="w-4 h-4" /> حفظ</Button>
      } />

      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="p-6 space-y-4">
          <h3 className="font-bold flex items-center gap-2"><Smartphone className="w-4 h-4" /> معلومات التطبيق</h3>
          <div><Label>اسم التطبيق</Label><Input value={form.app_name ?? ""} onChange={(e) => setForm({ ...form, app_name: e.target.value })} /></div>
          <div><Label>رابط App Store</Label><Input value={form.app_store_url ?? ""} onChange={(e) => setForm({ ...form, app_store_url: e.target.value })} /></div>
          <div><Label>رابط Google Play</Label><Input value={form.google_play_url ?? ""} onChange={(e) => setForm({ ...form, google_play_url: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>الإصدار الحالي</Label><Input value={form.current_version ?? ""} onChange={(e) => setForm({ ...form, current_version: e.target.value })} /></div>
            <div><Label>الإصدار الأدنى</Label><Input value={form.minimum_version ?? ""} onChange={(e) => setForm({ ...form, minimum_version: e.target.value })} /></div>
          </div>
          <div className="flex items-center justify-between"><Label>إجبار التحديث</Label>
            <Switch checked={form.force_update} onCheckedChange={(v) => setForm({ ...form, force_update: v })} />
          </div>
        </Card>

        <Card className="p-6 space-y-4">
          <h3 className="font-bold">وضع الصيانة</h3>
          <div className="flex items-center justify-between"><Label>تفعيل الصيانة</Label>
            <Switch checked={form.maintenance_mode} onCheckedChange={(v) => setForm({ ...form, maintenance_mode: v })} />
          </div>
          <div><Label>رسالة الصيانة</Label>
            <Textarea rows={3} value={form.maintenance_message ?? ""} onChange={(e) => setForm({ ...form, maintenance_message: e.target.value })} placeholder="نعتذر، التطبيق تحت الصيانة..." />
          </div>
        </Card>

        <Card className="p-6 space-y-4">
          <h3 className="font-bold">الإشعارات</h3>
          <div className="flex items-center justify-between"><Label>تفعيل Push</Label>
            <Switch checked={!!form.push_settings.enabled} onCheckedChange={(v) => setForm({ ...form, push_settings: { ...form.push_settings, enabled: v } })} />
          </div>
          <div><Label>الموضوع الافتراضي</Label>
            <Input value={form.push_settings.default_topic ?? ""} onChange={(e) => setForm({ ...form, push_settings: { ...form.push_settings, default_topic: e.target.value } })} />
          </div>
        </Card>

        <Card className="p-6 space-y-4">
          <h3 className="font-bold">تخطيط الصفحة الرئيسية</h3>
          {([
            ["show_hero", "إظهار الهيرو"],
            ["show_categories", "إظهار الأقسام"],
            ["show_featured", "إظهار المميز"],
            ["show_offers", "إظهار العروض"],
          ] as const).map(([k, label]) => (
            <div key={k} className="flex items-center justify-between"><Label>{label}</Label>
              <Switch checked={!!form.home_layout[k]} onCheckedChange={(v) => setForm({ ...form, home_layout: { ...form.home_layout, [k]: v } })} />
            </div>
          ))}
        </Card>
      </div>
    </>
  );
}
