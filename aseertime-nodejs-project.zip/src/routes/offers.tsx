import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { StoreLayout } from "@/components/store/StoreLayout";
import { Tag, Copy } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/offers")({
  component: OffersPage,
});

function OffersPage() {
  const { data, isLoading } = useQuery({
    queryKey: ["public-offers"],
    queryFn: async () => {
      const now = new Date().toISOString();
      const { data } = await supabase.from("coupons").select("*").eq("status", "active");
      return (data ?? []).filter((c) => (!c.start_date || c.start_date <= now) && (!c.end_date || c.end_date >= now));
    },
  });

  const copy = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success("تم نسخ الكود");
  };

  return (
    <StoreLayout>
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">العروض</h1>
        {isLoading ? (
          <div className="text-center text-muted-foreground py-20">جارٍ التحميل...</div>
        ) : !data || data.length === 0 ? (
          <div className="text-center py-20">
            <Tag className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <h3 className="font-bold">لا توجد عروض حالياً</h3>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.map((c) => (
              <div key={c.id} className="border-2 border-dashed border-primary/40 rounded-2xl p-5 bg-primary/5">
                <div className="flex items-center gap-2 text-primary font-bold"><Tag className="w-4 h-4" />{c.name}</div>
                <div className="mt-3 flex items-center justify-between bg-card rounded-xl p-3">
                  <span className="font-mono font-bold text-lg">{c.code}</span>
                  <button onClick={() => copy(c.code)} className="text-primary"><Copy className="w-4 h-4" /></button>
                </div>
                <div className="mt-3 text-sm text-muted-foreground">
                  خصم {c.discount_type === "percent" ? `${c.discount_value}%` : c.discount_type === "free_delivery" ? "توصيل مجاني" : `${c.discount_value} ر.س`}
                </div>
                {Number(c.minimum_order) > 0 && (
                  <div className="text-xs text-muted-foreground mt-1">حد أدنى للطلب: {Number(c.minimum_order).toFixed(2)} ر.س</div>
                )}
                {c.end_date && (
                  <div className="text-xs text-muted-foreground mt-1">ينتهي: {new Date(c.end_date).toLocaleDateString("en-GB")}</div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </StoreLayout>
  );
}
