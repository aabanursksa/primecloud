import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from "react";

export type CartAddon = { addon_id: string; addon_name: string; price: number };
export type CartItem = {
  id: string;
  product_id: string;
  product_name: string;
  product_image?: string | null;
  variant_id?: string | null;
  variant_name?: string | null;
  unit_price: number;
  quantity: number;
  addons: CartAddon[];
  notes?: string;
};

type CartContextType = {
  items: CartItem[];
  branchId: string | null;
  customerPhone: string | null;
  setCustomerPhone: (p: string | null) => void;
  setBranchId: (id: string | null) => void;
  addItem: (item: Omit<CartItem, "id">) => void;
  updateQty: (id: string, qty: number) => void;
  updateItem: (id: string, patch: Partial<Omit<CartItem, "id">>) => void;
  removeItem: (id: string) => void;
  clear: () => void;
  itemCount: number;
  subtotal: number;
};

const CartContext = createContext<CartContextType | null>(null);
const KEY = "jt_cart_v1";
const BRANCH_KEY = "jt_branch_v1";
const PHONE_KEY = "jt_phone_v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [branchId, setBranchIdState] = useState<string | null>(null);
  const [customerPhone, setCustomerPhoneState] = useState<string | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setItems(JSON.parse(raw));
      const b = localStorage.getItem(BRANCH_KEY);
      if (b) setBranchIdState(b);
      const p = localStorage.getItem(PHONE_KEY);
      if (p) setCustomerPhoneState(p);
    } catch {}
  }, []);

  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(items)); } catch {}
  }, [items]);

  const setBranchId = useCallback((id: string | null) => {
    setBranchIdState(id);
    try {
      if (id) localStorage.setItem(BRANCH_KEY, id);
      else localStorage.removeItem(BRANCH_KEY);
    } catch {}
  }, []);

  const setCustomerPhone = useCallback((p: string | null) => {
    setCustomerPhoneState(p);
    try {
      if (p) localStorage.setItem(PHONE_KEY, p);
      else localStorage.removeItem(PHONE_KEY);
    } catch {}
  }, []);

  const addItem: CartContextType["addItem"] = (item) => {
    const id = `${item.product_id}-${item.variant_id ?? ""}-${item.addons.map(a => a.addon_id).sort().join(",")}-${Date.now()}`;
    setItems((prev) => [...prev, { ...item, id }]);
  };
  const updateQty = (id: string, qty: number) =>
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, quantity: Math.max(1, qty) } : i)));
  const updateItem = (id: string, patch: Partial<Omit<CartItem, "id">>) =>
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
  const removeItem = (id: string) => setItems((prev) => prev.filter((i) => i.id !== id));
  const clear = () => setItems([]);

  const itemCount = items.reduce((s, i) => s + i.quantity, 0);
  const subtotal = items.reduce((s, i) => {
    const addonsTotal = i.addons.reduce((a, x) => a + Number(x.price || 0), 0);
    return s + (Number(i.unit_price) + addonsTotal) * i.quantity;
  }, 0);

  return (
    <CartContext.Provider value={{ items, branchId, setBranchId, customerPhone, setCustomerPhone, addItem, updateQty, updateItem, removeItem, clear, itemCount, subtotal }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
