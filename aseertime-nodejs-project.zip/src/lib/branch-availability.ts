import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Returns a Set of product IDs that are explicitly UNAVAILABLE at the given branch.
 * If product_branches has no row for a (product, branch), it's considered available by default.
 * Only rows where is_available=false are treated as unavailable.
 */
export function useBranchUnavailableProducts(branchId: string | null) {
  return useQuery({
    queryKey: ["branch-unavailable", branchId],
    queryFn: async () => {
      if (!branchId) return new Set<string>();
      const { data } = await supabase
        .from("product_branches")
        .select("product_id, is_available")
        .eq("branch_id", branchId)
        .eq("is_available", false);
      return new Set<string>((data ?? []).map((r: any) => r.product_id));
    },
  });
}
