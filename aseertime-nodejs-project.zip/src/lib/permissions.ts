import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export function usePermissions() {
  const { user, role, loading } = useAuth();
  const isAdmin = role === "admin";
  // Wait for the role to actually load before evaluating permissions.
  const roleReady = !loading && role !== null;
  const q = useQuery({
    queryKey: ["my-permissions", role],
    enabled: !!user && roleReady && !isAdmin,
    staleTime: 5 * 60_000,
    gcTime: 10 * 60_000,
    queryFn: async () => {
      if (!role) return new Set<string>();
      const { data: roles } = await supabase
        .from("roles")
        .select("id")
        .eq("key", role);
      const ids = (roles ?? []).map((r: any) => r.id);
      if (ids.length === 0) return new Set<string>();
      const { data: rp } = await supabase
        .from("role_permissions")
        .select("permission_key")
        .in("role_id", ids);
      return new Set<string>((rp ?? []).map((x: any) => x.permission_key));
    },
  });
  const set = q.data ?? new Set<string>();
  const has = (key: string) => isAdmin || set.has(key);
  const hasAny = (keys: string[]) => isAdmin || keys.some((k) => set.has(k));
  // Treat as loading until role is known and (for non-admins) permissions fetched.
  const isLoading = loading || !roleReady || (!isAdmin && q.isLoading);
  return { isAdmin, isLoading, has, hasAny, all: set };
}
