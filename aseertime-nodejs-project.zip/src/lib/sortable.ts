import { supabase } from "@/integrations/supabase/client";

export async function moveSort<T extends { id: string; sort_order: number }>(
  table: string,
  rows: T[],
  id: string,
  dir: -1 | 1,
) {
  const sorted = [...rows].sort((a, b) => a.sort_order - b.sort_order);
  const idx = sorted.findIndex((r) => r.id === id);
  const swap = idx + dir;
  if (idx < 0 || swap < 0 || swap >= sorted.length) return;
  const a = sorted[idx];
  const b = sorted[swap];
  await supabase.from(table as any).update({ sort_order: b.sort_order }).eq("id", a.id);
  await supabase.from(table as any).update({ sort_order: a.sort_order }).eq("id", b.id);
}
