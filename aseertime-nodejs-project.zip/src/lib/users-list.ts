import { supabase } from "@/integrations/supabase/client";

export type UserRow = {
  id: string;
  full_name: string | null;
  phone: string | null;
  avatar_url: string | null;
  created_at: string;
  status: "active" | "inactive" | "suspended";
  last_login_at: string | null;
  roles: string[];
  branch_ids: string[];
};

export async function fetchUsersList(): Promise<UserRow[]> {
  const [profilesRes, rolesRes, branchesRes] = await Promise.all([
    supabase.from("profiles").select("id, full_name, phone, avatar_url, created_at, status, last_login_at"),
    supabase.from("user_roles").select("user_id, role"),
    supabase.from("user_branches").select("user_id, branch_id"),
  ]);
  if (profilesRes.error) throw new Error(profilesRes.error.message);
  if (rolesRes.error) throw new Error(rolesRes.error.message);
  if (branchesRes.error) throw new Error(branchesRes.error.message);

  const roleMap = new Map<string, string[]>();
  (rolesRes.data ?? []).forEach((r) => {
    const arr = roleMap.get(r.user_id) ?? [];
    arr.push(r.role as string);
    roleMap.set(r.user_id, arr);
  });
  const branchMap = new Map<string, string[]>();
  (branchesRes.data ?? []).forEach((b) => {
    const arr = branchMap.get(b.user_id) ?? [];
    arr.push(b.branch_id as string);
    branchMap.set(b.user_id, arr);
  });

  return (profilesRes.data ?? []).map((p) => ({
    id: p.id,
    full_name: p.full_name,
    phone: p.phone,
    avatar_url: p.avatar_url,
    created_at: p.created_at,
    status: (p.status ?? "active") as UserRow["status"],
    last_login_at: p.last_login_at ?? null,
    roles: roleMap.get(p.id) ?? [],
    branch_ids: branchMap.get(p.id) ?? [],
  }));
}
