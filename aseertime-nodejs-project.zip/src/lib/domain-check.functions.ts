import { createServerFn } from "@tanstack/react-start";

type CheckResult = {
  url: string;
  ok: boolean;
  status: number | null;
  finalUrl: string | null;
  redirected: boolean;
  redirectChain: string[];
  server: string | null;
  contentType: string | null;
  responseTimeMs: number | null;
  error: string | null;
};

async function checkOne(url: string): Promise<CheckResult> {
  const start = Date.now();
  const chain: string[] = [];
  try {
    // Manual redirect tracking
    let current = url;
    let res: Response | null = null;
    for (let i = 0; i < 5; i++) {
      const r = await fetch(current, {
        method: "GET",
        redirect: "manual",
        headers: { "user-agent": "Lovable-DomainChecker/1.0" },
        signal: AbortSignal.timeout(8000),
      });
      if (r.status >= 300 && r.status < 400 && r.headers.get("location")) {
        chain.push(`${r.status} → ${r.headers.get("location")}`);
        current = new URL(r.headers.get("location")!, current).toString();
        continue;
      }
      res = r;
      break;
    }
    const elapsed = Date.now() - start;
    if (!res) {
      return {
        url, ok: false, status: null, finalUrl: current, redirected: chain.length > 0,
        redirectChain: chain, server: null, contentType: null,
        responseTimeMs: elapsed, error: "Too many redirects",
      };
    }
    return {
      url,
      ok: res.ok,
      status: res.status,
      finalUrl: current,
      redirected: chain.length > 0,
      redirectChain: chain,
      server: res.headers.get("server"),
      contentType: res.headers.get("content-type"),
      responseTimeMs: elapsed,
      error: null,
    };
  } catch (e: any) {
    return {
      url, ok: false, status: null, finalUrl: null, redirected: false,
      redirectChain: chain, server: null, contentType: null,
      responseTimeMs: Date.now() - start,
      error: e?.message || "Network error",
    };
  }
}

export const checkDomainHealth = createServerFn({ method: "POST" })
  .inputValidator((d: { domain: string }) => {
    const clean = d.domain.trim().replace(/^https?:\/\//, "").replace(/\/$/, "");
    if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(clean)) throw new Error("نطاق غير صالح");
    return { domain: clean };
  })
  .handler(async ({ data }) => {
    const targets = [
      `https://${data.domain}`,
      `https://www.${data.domain}`,
      `http://${data.domain}`,
    ];
    const results = await Promise.all(targets.map(checkOne));
    return {
      checkedAt: new Date().toISOString(),
      domain: data.domain,
      results,
    };
  });
