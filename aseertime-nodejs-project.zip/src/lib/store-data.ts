import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Shared cached query for store_settings. All consumers share the same
 * react-query cache entry, eliminating duplicate network calls per page load.
 */
export function useStoreSettings() {
  return useQuery({
    queryKey: ["store_settings"],
    queryFn: async () => {
      const { data } = await supabase.from("store_settings").select("*").limit(1).maybeSingle();
      return data;
    },
    staleTime: 5 * 60_000,
    gcTime: 10 * 60_000,
  });
}

export function useFooterSettings() {
  return useQuery({
    queryKey: ["footer_settings"],
    queryFn: async () => {
      const { data } = await supabase.from("footer_settings").select("*").limit(1).maybeSingle();
      return data;
    },
    staleTime: 5 * 60_000,
    gcTime: 10 * 60_000,
  });
}
