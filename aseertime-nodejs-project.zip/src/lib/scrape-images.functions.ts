import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { z } from "zod";

async function ensureManager(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId);
  if (error) throw new Error(error.message);
  const roles = (data ?? []).map((r: any) => r.role);
  if (!roles.some((r: string) => r === "admin" || r === "manager")) {
    throw new Error("صلاحية المسؤول مطلوبة");
  }
}

type ScrapedItem = { name: string; image: string; description?: string; price?: string };

function parseHungerstationMarkdown(md: string): ScrapedItem[] {
  const items: ScrapedItem[] = [];
  // Pattern: ![name](image_url)\n\n### name\n\n[description]\n\n[price]
  const regex = /!\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)\s*\n+###\s+([^\n]+)\n+([^\n]*)?/g;
  let m: RegExpExecArray | null;
  const seen = new Set<string>();
  while ((m = regex.exec(md)) !== null) {
    const image = m[2];
    const name = (m[3] || m[1]).replace(/\\/g, "").trim();
    if (!image.includes("deliveryhero.io") && !image.includes("hungerstation.com/_next/image?url=%2Fimage")) continue;
    if (seen.has(name)) continue;
    seen.add(name);
    items.push({
      name,
      image,
      description: (m[4] || "").trim() || undefined,
    });
  }
  return items;
}

export const scrapeMenuImages = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { url: string }) => z.object({ url: z.string().url() }).parse(data))
  .handler(async ({ data, context }) => {
    await ensureManager(context.supabase, context.userId);
    const apiKey = process.env.FIRECRAWL_API_KEY;
    if (!apiKey) throw new Error("FIRECRAWL_API_KEY غير مهيّأ");

    const res = await fetch("https://api.firecrawl.dev/v2/scrape", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ url: data.url, formats: ["markdown"], onlyMainContent: true, waitFor: 3000 }),
    });
    const json: any = await res.json();
    if (!res.ok || !json?.success) {
      throw new Error(`فشل جلب الصفحة: ${json?.error || res.status}`);
    }
    const md: string = json?.data?.markdown || "";
    const scraped = parseHungerstationMarkdown(md);

    // Load products missing image
    const { data: products, error } = await supabaseAdmin
      .from("products")
      .select("id, name_ar, image_url")
      .order("name_ar");
    if (error) throw new Error(error.message);

    // Naive matching by name normalization
    const norm = (s: string) =>
      s.replace(/[\s\-–—_.,()]+/g, "").replace(/[\u064B-\u065F\u0670]/g, "").toLowerCase();
    const scrapedMap = new Map<string, ScrapedItem>();
    for (const it of scraped) scrapedMap.set(norm(it.name), it);

    const matches = (products ?? []).map((p) => {
      const key = norm(p.name_ar || "");
      let match = scrapedMap.get(key);
      if (!match) {
        // partial: includes
        for (const [k, v] of scrapedMap) {
          if (k && (k.includes(key) || key.includes(k))) {
            match = v;
            break;
          }
        }
      }
      return {
        product_id: p.id,
        product_name: p.name_ar,
        current_image: p.image_url,
        scraped_name: match?.name || null,
        scraped_image: match?.image || null,
      };
    });

    return { scraped_count: scraped.length, products_count: products?.length ?? 0, matches };
  });

export const applyProductImages = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { updates: { product_id: string; image_url: string }[] }) =>
    z
      .object({
        updates: z.array(z.object({ product_id: z.string().uuid(), image_url: z.string().url() })).min(1),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    await ensureManager(context.supabase, context.userId);
    let updated = 0;
    for (const u of data.updates) {
      const { error } = await supabaseAdmin
        .from("products")
        .update({ image_url: u.image_url })
        .eq("id", u.product_id);
      if (!error) updated++;
    }
    return { updated };
  });
