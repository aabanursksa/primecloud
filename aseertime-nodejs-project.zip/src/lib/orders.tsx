export const ORDER_STATUS_LABEL: Record<string, string> = {
  new: "جديد",
  accepted: "مقبول",
  preparing: "قيد التحضير",
  ready: "جاهز للاستلام",
  awaiting_driver: "بانتظار السائق",
  with_driver: "مع السائق",
  delivered: "تم التسليم",
  cancelled: "ملغي",
  refunded: "مسترجع",
};

export const ORDER_STATUS_COLOR: Record<string, string> = {
  new: "bg-info/10 text-info",
  accepted: "bg-info/10 text-info",
  preparing: "bg-warning/10 text-warning",
  ready: "bg-warning/10 text-warning",
  awaiting_driver: "bg-warning/10 text-warning",
  with_driver: "bg-primary/10 text-primary",
  delivered: "bg-success/10 text-success",
  cancelled: "bg-destructive/10 text-destructive",
  refunded: "bg-muted text-muted-foreground",
};

export const ORDER_TYPE_LABEL: Record<string, string> = { delivery: "توصيل", pickup: "استلام" };

export const PAYMENT_LABEL: Record<string, string> = {
  cash: "نقدي", card: "بطاقة", online: "أونلاين", wallet: "محفظة",
};

export const PAYMENT_STATUS_LABEL: Record<string, string> = {
  pending: "معلق", paid: "مدفوع", failed: "فشل", refunded: "مسترجع",
};

export const DRIVER_STATUS_LABEL: Record<string, string> = {
  available: "متاح", busy: "مشغول", offline: "غير متصل", suspended: "موقوف",
};

export const DRIVER_STATUS_COLOR: Record<string, string> = {
  available: "bg-success/10 text-success",
  busy: "bg-warning/10 text-warning",
  offline: "bg-muted text-muted-foreground",
  suspended: "bg-destructive/10 text-destructive",
};

export const CUSTOMER_STATUS_LABEL: Record<string, string> = {
  active: "نشط", inactive: "غير نشط", banned: "محظور",
};

export const CUSTOMER_STATUS_COLOR: Record<string, string> = {
  active: "bg-success/10 text-success",
  inactive: "bg-muted text-muted-foreground",
  banned: "bg-destructive/10 text-destructive",
};

export const COUPON_TYPE_LABEL: Record<string, string> = {
  fixed: "مبلغ ثابت", percent: "نسبة مئوية", free_delivery: "توصيل مجاني",
};

export function StatusBadge({ status, map, color }: { status: string; map: Record<string,string>; color: Record<string,string> }) {
  const label = map[status] ?? status;
  const cls = color[status] ?? "bg-muted text-muted-foreground";
  return <span className={`text-xs px-2 py-1 rounded font-medium ${cls}`}>{label}</span>;
}
