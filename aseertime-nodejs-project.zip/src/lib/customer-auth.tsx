import { createContext, useContext, useEffect, useState, ReactNode, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

type CustomerSession = { phone: string; name: string | null; loginAt: number };

type PhoneCheck = { exists: boolean; name?: string | null; banned?: boolean };

type Ctx = {
  customer: CustomerSession | null;
  isLoggedIn: boolean;
  // OTP flow
  checkPhone: (phone: string) => Promise<PhoneCheck>;
  requestOtp: (phone: string) => Promise<{ devCode: string }>;
  verifyOtp: (phone: string, code: string, name?: string) => Promise<void>;
  logout: () => void;
  refresh: () => Promise<void>;
};

const CustomerCtx = createContext<Ctx | null>(null);
const KEY = "jt_customer_v1";
const OTP_KEY = "jt_otp_v1"; // { phone, code, expiresAt }

function normalizePhone(p: string) {
  return p.trim().replace(/\s+/g, "");
}

export function CustomerAuthProvider({ children }: { children: ReactNode }) {
  const [customer, setCustomer] = useState<CustomerSession | null>(null);
  const otpRef = useRef<{ phone: string; code: string; expiresAt: number } | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setCustomer(JSON.parse(raw));
      const otpRaw = sessionStorage.getItem(OTP_KEY);
      if (otpRaw) otpRef.current = JSON.parse(otpRaw);
    } catch {}
  }, []);

  const persist = (c: CustomerSession | null) => {
    setCustomer(c);
    try {
      if (c) localStorage.setItem(KEY, JSON.stringify(c));
      else localStorage.removeItem(KEY);
    } catch {}
  };

  const checkPhone = useCallback(async (phone: string): Promise<PhoneCheck> => {
    const ph = normalizePhone(phone);
    if (ph.length < 6) return { exists: false };
    const { data } = await supabase.rpc("customer_phone_exists", { _phone: ph });
    const d = (data as any) || {};
    return { exists: !!d.exists, name: d.name ?? null, banned: !!d.banned };
  }, []);

  const requestOtp = useCallback(async (phone: string) => {
    const ph = normalizePhone(phone);
    if (ph.length < 6) throw new Error("رقم الجوال غير صحيح");
    // Check banned
    const check = await checkPhone(ph);
    if (check.banned) throw new Error("هذا الحساب موقوف");
    // Generate dummy 4-digit code
    const code = String(Math.floor(1000 + Math.random() * 9000));
    const expiresAt = Date.now() + 5 * 60_000; // 5 min
    otpRef.current = { phone: ph, code, expiresAt };
    try { sessionStorage.setItem(OTP_KEY, JSON.stringify(otpRef.current)); } catch {}
    // TODO: replace with real SMS gateway call
    return { devCode: code };
  }, [checkPhone]);

  const verifyOtp = useCallback(async (phone: string, code: string, name?: string) => {
    const ph = normalizePhone(phone);
    const otp = otpRef.current;
    if (!otp || otp.phone !== ph) throw new Error("اطلب كود جديد");
    if (Date.now() > otp.expiresAt) throw new Error("انتهت صلاحية الكود");
    if (otp.code !== code.trim()) throw new Error("الكود غير صحيح");

    // Determine if customer exists
    const check = await checkPhone(ph);
    let displayName: string | null = check.name ?? null;

    if (!check.exists) {
      const trimmed = name?.trim() || "";
      if (trimmed.length < 2) throw new Error("الاسم مطلوب لإنشاء حساب جديد");
      await supabase.rpc("update_customer_profile", { _phone: ph, _name: trimmed, _email: "" });
      displayName = trimmed;
    }
    await supabase.rpc("customer_touch_login", { _phone: ph });

    otpRef.current = null;
    try { sessionStorage.removeItem(OTP_KEY); } catch {}
    persist({ phone: ph, name: displayName, loginAt: Date.now() });
  }, [checkPhone]);

  const logout = useCallback(() => persist(null), []);

  const refresh = useCallback(async () => {
    if (!customer) return;
  }, [customer]);

  return (
    <CustomerCtx.Provider value={{ customer, isLoggedIn: !!customer, checkPhone, requestOtp, verifyOtp, logout, refresh }}>
      {children}
    </CustomerCtx.Provider>
  );
}

export function useCustomerAuth() {
  const ctx = useContext(CustomerCtx);
  if (!ctx) throw new Error("useCustomerAuth must be used within CustomerAuthProvider");
  return ctx;
}
