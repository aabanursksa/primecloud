import { supabase } from "@/integrations/supabase/client";
import type { HomeSection, HomeBanner } from "@/components/store/home-sections/SectionRenderer";

export const SECTION_TYPES = [
  { value: "hero_carousel", label: "Hero Banner Carousel" },
  { value: "single_banner", label: "بنر مفرد" },
  { value: "banner_grid", label: "شبكة بنرات" },
  { value: "products_carousel", label: "Products Carousel" },
  { value: "products_grid", label: "Products Grid" },
  { value: "featured_products", label: "منتجات مميزة" },
  { value: "category_products", label: "منتجات تصنيف" },
  { value: "most_ordered", label: "الأكثر طلبًا" },
  { value: "new_products", label: "جديدنا" },
  { value: "offers_products", label: "عروض اليوم" },
  { value: "categories_section", label: "قسم التصنيفات" },
  { value: "combo_section", label: "كومبو / بوكسات" },
  { value: "banner_with_products", label: "بنر + منتجات" },
] as const;

export const DISPLAY_STYLES = [
  { value: "carousel", label: "Carousel أفقي" },
  { value: "grid", label: "Grid" },
  { value: "vertical_list", label: "قائمة عمودية" },
  { value: "featured_large", label: "كبيرة Featured" },
  { value: "compact", label: "صغيرة Compact" },
] as const;

export const BANNER_POSITIONS = [
  { value: "standalone", label: "بنر مستقل" },
  { value: "top_of_page", label: "أعلى الصفحة" },
  { value: "after_categories", label: "بعد التصنيفات" },
  { value: "before_section", label: "قبل سكشن" },
  { value: "after_section", label: "بعد سكشن" },
  { value: "inside_section", label: "داخل سكشن" },
] as const;

export const BANNER_LINK_TYPES = [
  { value: "none", label: "بدون" },
  { value: "product", label: "منتج" },
  { value: "category", label: "تصنيف" },
  { value: "offer", label: "عرض" },
  { value: "page", label: "صفحة" },
  { value: "external", label: "رابط خارجي" },
] as const;

// Fetch all products needed for sections
export async function fetchSectionsData(sections: HomeSection[]) {
  const productsPerSection: Record<string, any[]> = {};

  for (const s of sections) {
    let products: any[] = [];
    const limit = s.products_limit || 6;

    try {
      if (s.section_type === "category_products" || s.section_type === "products_carousel" || s.section_type === "products_grid" || s.section_type === "banner_with_products" || s.section_type === "combo_section") {
        if (s.manual_product_ids && s.manual_product_ids.length > 0) {
          const { data } = await supabase.from("products").select("*").in("id", s.manual_product_ids).eq("show_in_store", true).eq("is_archived", false);
          products = (data || []).slice(0, limit);
        } else if (s.category_id) {
          const { data } = await supabase.from("products").select("*").eq("category_id", s.category_id).eq("show_in_store", true).eq("is_archived", false).order("display_order").limit(limit);
          products = data || [];
        }
      } else if (s.section_type === "featured_products") {
        const { data } = await supabase.from("products").select("*").eq("is_featured", true).eq("show_in_store", true).eq("is_archived", false).order("display_order").limit(limit);
        products = data || [];
      } else if (s.section_type === "new_products") {
        const { data } = await supabase.from("products").select("*").eq("show_in_store", true).eq("is_archived", false).order("created_at", { ascending: false }).limit(limit);
        products = data || [];
      } else if (s.section_type === "offers_products") {
        const { data } = await supabase.from("products").select("*").not("discount_price", "is", null).eq("show_in_store", true).eq("is_archived", false).limit(limit);
        products = data || [];
      } else if (s.section_type === "most_ordered") {
        const { data: items } = await supabase.from("order_items").select("product_id");
        const counts = new Map<string, number>();
        (items || []).forEach((i: any) => { if (i.product_id) counts.set(i.product_id, (counts.get(i.product_id) || 0) + 1); });
        const topIds = Array.from(counts.entries()).sort((a, b) => b[1] - a[1]).slice(0, limit).map(([id]) => id);
        if (topIds.length > 0) {
          const { data } = await supabase.from("products").select("*").in("id", topIds).eq("show_in_store", true).eq("is_archived", false);
          // Preserve order
          const map = new Map((data || []).map((p: any) => [p.id, p]));
          products = topIds.map((id) => map.get(id)).filter(Boolean) as any[];
        }
      }
    } catch {
      // ignore
    }
    productsPerSection[s.id] = products;
  }

  return productsPerSection;
}

export function arrangeSectionsWithBanners(
  sections: HomeSection[],
  banners: HomeBanner[]
): Array<{ kind: "section"; data: HomeSection } | { kind: "banner"; data: HomeBanner }> {
  const out: Array<{ kind: "section"; data: HomeSection } | { kind: "banner"; data: HomeBanner }> = [];

  // top_of_page banners first
  banners.filter((b) => b.position === "top_of_page" && !b.section_id).forEach((b) => out.push({ kind: "banner", data: b }));

  for (const s of sections) {
    // before_section banners
    banners.filter((b) => b.position === "before_section" && b.anchor_section_id === s.id).forEach((b) => out.push({ kind: "banner", data: b }));

    out.push({ kind: "section", data: s });

    // after_categories banners
    if (s.section_type === "categories_section") {
      banners.filter((b) => b.position === "after_categories" && !b.section_id).forEach((b) => out.push({ kind: "banner", data: b }));
    }

    // after_section banners
    banners.filter((b) => b.position === "after_section" && b.anchor_section_id === s.id).forEach((b) => out.push({ kind: "banner", data: b }));
  }

  // standalone banners at end
  banners.filter((b) => b.position === "standalone" && !b.section_id && !b.anchor_section_id).forEach((b) => out.push({ kind: "banner", data: b }));

  return out;
}
