export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      activity_logs: {
        Row: {
          action: string
          created_at: string
          description: string | null
          entity: string | null
          entity_id: string | null
          id: string
          ip_address: string | null
          module: string | null
          new_values: Json | null
          old_values: Json | null
          payload: Json | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          description?: string | null
          entity?: string | null
          entity_id?: string | null
          id?: string
          ip_address?: string | null
          module?: string | null
          new_values?: Json | null
          old_values?: Json | null
          payload?: Json | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          description?: string | null
          entity?: string | null
          entity_id?: string | null
          id?: string
          ip_address?: string | null
          module?: string | null
          new_values?: Json | null
          old_values?: Json | null
          payload?: Json | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      addon_group_links: {
        Row: {
          category_id: string | null
          group_id: string
          id: string
          product_id: string | null
        }
        Insert: {
          category_id?: string | null
          group_id: string
          id?: string
          product_id?: string | null
        }
        Update: {
          category_id?: string | null
          group_id?: string
          id?: string
          product_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "addon_group_links_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "product_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "addon_group_links_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "addon_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "addon_group_links_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      addon_groups: {
        Row: {
          created_at: string
          display_order: number
          id: string
          is_required: boolean
          max_select: number
          min_select: number
          name_ar: string
          name_en: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          id?: string
          is_required?: boolean
          max_select?: number
          min_select?: number
          name_ar: string
          name_en?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          id?: string
          is_required?: boolean
          max_select?: number
          min_select?: number
          name_ar?: string
          name_en?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          app_name: string | null
          app_store_url: string | null
          current_version: string | null
          force_update: boolean
          google_play_url: string | null
          home_layout: Json
          id: string
          maintenance_message: string | null
          maintenance_mode: boolean
          minimum_version: string | null
          push_settings: Json
          updated_at: string
        }
        Insert: {
          app_name?: string | null
          app_store_url?: string | null
          current_version?: string | null
          force_update?: boolean
          google_play_url?: string | null
          home_layout?: Json
          id?: string
          maintenance_message?: string | null
          maintenance_mode?: boolean
          minimum_version?: string | null
          push_settings?: Json
          updated_at?: string
        }
        Update: {
          app_name?: string | null
          app_store_url?: string | null
          current_version?: string | null
          force_update?: boolean
          google_play_url?: string | null
          home_layout?: Json
          id?: string
          maintenance_message?: string | null
          maintenance_mode?: boolean
          minimum_version?: string | null
          push_settings?: Json
          updated_at?: string
        }
        Relationships: []
      }
      banners: {
        Row: {
          created_at: string
          cta_text: string | null
          cta_url: string | null
          end_date: string | null
          id: string
          image_only: boolean
          image_url: string | null
          link_type: Database["public"]["Enums"]["banner_link_type"]
          link_value: string | null
          placement: Database["public"]["Enums"]["banner_placement"]
          platform: Database["public"]["Enums"]["platform_target"]
          sort_order: number
          start_date: string | null
          status: Database["public"]["Enums"]["banner_status"]
          subtitle: string | null
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          cta_text?: string | null
          cta_url?: string | null
          end_date?: string | null
          id?: string
          image_only?: boolean
          image_url?: string | null
          link_type?: Database["public"]["Enums"]["banner_link_type"]
          link_value?: string | null
          placement?: Database["public"]["Enums"]["banner_placement"]
          platform?: Database["public"]["Enums"]["platform_target"]
          sort_order?: number
          start_date?: string | null
          status?: Database["public"]["Enums"]["banner_status"]
          subtitle?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          cta_text?: string | null
          cta_url?: string | null
          end_date?: string | null
          id?: string
          image_only?: boolean
          image_url?: string | null
          link_type?: Database["public"]["Enums"]["banner_link_type"]
          link_value?: string | null
          placement?: Database["public"]["Enums"]["banner_placement"]
          platform?: Database["public"]["Enums"]["platform_target"]
          sort_order?: number
          start_date?: string | null
          status?: Database["public"]["Enums"]["banner_status"]
          subtitle?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      branches: {
        Row: {
          accepts_orders: boolean
          address: string | null
          business_hours: Json | null
          created_at: string
          delivery_fee: number | null
          delivery_radius_km: number | null
          display_order: number
          id: string
          is_active: boolean
          latitude: number | null
          longitude: number | null
          min_order_amount: number | null
          name: string
          phone: string | null
          updated_at: string
        }
        Insert: {
          accepts_orders?: boolean
          address?: string | null
          business_hours?: Json | null
          created_at?: string
          delivery_fee?: number | null
          delivery_radius_km?: number | null
          display_order?: number
          id?: string
          is_active?: boolean
          latitude?: number | null
          longitude?: number | null
          min_order_amount?: number | null
          name: string
          phone?: string | null
          updated_at?: string
        }
        Update: {
          accepts_orders?: boolean
          address?: string | null
          business_hours?: Json | null
          created_at?: string
          delivery_fee?: number | null
          delivery_radius_km?: number | null
          display_order?: number
          id?: string
          is_active?: boolean
          latitude?: number | null
          longitude?: number | null
          min_order_amount?: number | null
          name?: string
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      contact_messages: {
        Row: {
          created_at: string
          email: string | null
          id: string
          is_read: boolean
          message: string
          name: string
          phone: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          is_read?: boolean
          message: string
          name: string
          phone: string
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          is_read?: boolean
          message?: string
          name?: string
          phone?: string
        }
        Relationships: []
      }
      coupon_usages: {
        Row: {
          coupon_id: string
          created_at: string
          customer_id: string | null
          discount_amount: number
          id: string
          order_id: string | null
        }
        Insert: {
          coupon_id: string
          created_at?: string
          customer_id?: string | null
          discount_amount?: number
          id?: string
          order_id?: string | null
        }
        Update: {
          coupon_id?: string
          created_at?: string
          customer_id?: string | null
          discount_amount?: number
          id?: string
          order_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "coupon_usages_coupon_id_fkey"
            columns: ["coupon_id"]
            isOneToOne: false
            referencedRelation: "coupons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "coupon_usages_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      coupons: {
        Row: {
          branch_id: string | null
          category_ids: string[]
          code: string
          created_at: string
          discount_type: Database["public"]["Enums"]["coupon_discount_type"]
          discount_value: number
          end_date: string | null
          id: string
          maximum_discount: number | null
          minimum_order: number
          name: string
          product_ids: string[]
          start_date: string | null
          status: Database["public"]["Enums"]["coupon_status"]
          updated_at: string
          usage_limit: number | null
          usage_per_customer: number | null
          used_count: number
        }
        Insert: {
          branch_id?: string | null
          category_ids?: string[]
          code: string
          created_at?: string
          discount_type: Database["public"]["Enums"]["coupon_discount_type"]
          discount_value?: number
          end_date?: string | null
          id?: string
          maximum_discount?: number | null
          minimum_order?: number
          name: string
          product_ids?: string[]
          start_date?: string | null
          status?: Database["public"]["Enums"]["coupon_status"]
          updated_at?: string
          usage_limit?: number | null
          usage_per_customer?: number | null
          used_count?: number
        }
        Update: {
          branch_id?: string | null
          category_ids?: string[]
          code?: string
          created_at?: string
          discount_type?: Database["public"]["Enums"]["coupon_discount_type"]
          discount_value?: number
          end_date?: string | null
          id?: string
          maximum_discount?: number | null
          minimum_order?: number
          name?: string
          product_ids?: string[]
          start_date?: string | null
          status?: Database["public"]["Enums"]["coupon_status"]
          updated_at?: string
          usage_limit?: number | null
          usage_per_customer?: number | null
          used_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "coupons_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_addresses: {
        Row: {
          apartment: string | null
          building: string | null
          city: string | null
          created_at: string
          customer_id: string
          district: string | null
          driver_notes: string | null
          floor: string | null
          id: string
          is_default: boolean
          landmark: string | null
          latitude: number | null
          longitude: number | null
          street: string | null
          title: string | null
        }
        Insert: {
          apartment?: string | null
          building?: string | null
          city?: string | null
          created_at?: string
          customer_id: string
          district?: string | null
          driver_notes?: string | null
          floor?: string | null
          id?: string
          is_default?: boolean
          landmark?: string | null
          latitude?: number | null
          longitude?: number | null
          street?: string | null
          title?: string | null
        }
        Update: {
          apartment?: string | null
          building?: string | null
          city?: string | null
          created_at?: string
          customer_id?: string
          district?: string | null
          driver_notes?: string | null
          floor?: string | null
          id?: string
          is_default?: boolean
          landmark?: string | null
          latitude?: number | null
          longitude?: number | null
          street?: string | null
          title?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "customer_addresses_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      customers: {
        Row: {
          created_at: string
          email: string | null
          id: string
          last_login_at: string | null
          name: string
          notes: string | null
          phone: string
          status: Database["public"]["Enums"]["customer_status"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          last_login_at?: string | null
          name: string
          notes?: string | null
          phone: string
          status?: Database["public"]["Enums"]["customer_status"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          last_login_at?: string | null
          name?: string
          notes?: string | null
          phone?: string
          status?: Database["public"]["Enums"]["customer_status"]
          updated_at?: string
        }
        Relationships: []
      }
      delivery_zones: {
        Row: {
          branch_id: string | null
          created_at: string
          delivery_fee: number
          estimated_time_minutes: number | null
          id: string
          minimum_order: number
          name: string
          notes: string | null
          sort_order: number
          status: Database["public"]["Enums"]["zone_status"]
          updated_at: string
        }
        Insert: {
          branch_id?: string | null
          created_at?: string
          delivery_fee?: number
          estimated_time_minutes?: number | null
          id?: string
          minimum_order?: number
          name: string
          notes?: string | null
          sort_order?: number
          status?: Database["public"]["Enums"]["zone_status"]
          updated_at?: string
        }
        Update: {
          branch_id?: string | null
          created_at?: string
          delivery_fee?: number
          estimated_time_minutes?: number | null
          id?: string
          minimum_order?: number
          name?: string
          notes?: string | null
          sort_order?: number
          status?: Database["public"]["Enums"]["zone_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "delivery_zones_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      drivers: {
        Row: {
          avatar_url: string | null
          branch_id: string | null
          created_at: string
          email: string | null
          id: string
          is_active: boolean
          last_active_at: string | null
          name: string
          national_id: string | null
          notes: string | null
          phone: string
          plate_number: string | null
          rating: number
          status: Database["public"]["Enums"]["driver_status"]
          updated_at: string
          vehicle_type: string | null
        }
        Insert: {
          avatar_url?: string | null
          branch_id?: string | null
          created_at?: string
          email?: string | null
          id?: string
          is_active?: boolean
          last_active_at?: string | null
          name: string
          national_id?: string | null
          notes?: string | null
          phone: string
          plate_number?: string | null
          rating?: number
          status?: Database["public"]["Enums"]["driver_status"]
          updated_at?: string
          vehicle_type?: string | null
        }
        Update: {
          avatar_url?: string | null
          branch_id?: string | null
          created_at?: string
          email?: string | null
          id?: string
          is_active?: boolean
          last_active_at?: string | null
          name?: string
          national_id?: string | null
          notes?: string | null
          phone?: string
          plate_number?: string | null
          rating?: number
          status?: Database["public"]["Enums"]["driver_status"]
          updated_at?: string
          vehicle_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "drivers_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      faqs: {
        Row: {
          answer: string
          category: string | null
          created_at: string
          id: string
          question: string
          show_in_faq: boolean
          show_in_product: boolean
          sort_order: number
          status: Database["public"]["Enums"]["publish_status"]
          updated_at: string
        }
        Insert: {
          answer: string
          category?: string | null
          created_at?: string
          id?: string
          question: string
          show_in_faq?: boolean
          show_in_product?: boolean
          sort_order?: number
          status?: Database["public"]["Enums"]["publish_status"]
          updated_at?: string
        }
        Update: {
          answer?: string
          category?: string | null
          created_at?: string
          id?: string
          question?: string
          show_in_faq?: boolean
          show_in_product?: boolean
          sort_order?: number
          status?: Database["public"]["Enums"]["publish_status"]
          updated_at?: string
        }
        Relationships: []
      }
      footer_settings: {
        Row: {
          about_text: string | null
          address: string | null
          app_store_url: string | null
          copyright_text: string | null
          email: string | null
          google_play_url: string | null
          id: string
          logo_url: string | null
          phone: string | null
          social_links: Json
          updated_at: string
          visible_sections: Json
          working_hours: string | null
        }
        Insert: {
          about_text?: string | null
          address?: string | null
          app_store_url?: string | null
          copyright_text?: string | null
          email?: string | null
          google_play_url?: string | null
          id?: string
          logo_url?: string | null
          phone?: string | null
          social_links?: Json
          updated_at?: string
          visible_sections?: Json
          working_hours?: string | null
        }
        Update: {
          about_text?: string | null
          address?: string | null
          app_store_url?: string | null
          copyright_text?: string | null
          email?: string | null
          google_play_url?: string | null
          id?: string
          logo_url?: string | null
          phone?: string | null
          social_links?: Json
          updated_at?: string
          visible_sections?: Json
          working_hours?: string | null
        }
        Relationships: []
      }
      header_settings: {
        Row: {
          app_overrides: Json
          contact_phone: string | null
          cta_text: string | null
          cta_url: string | null
          id: string
          logo_url: string | null
          show_branch_selector: boolean
          show_cart: boolean
          show_cta: boolean
          show_login: boolean
          show_logo: boolean
          show_search: boolean
          updated_at: string
        }
        Insert: {
          app_overrides?: Json
          contact_phone?: string | null
          cta_text?: string | null
          cta_url?: string | null
          id?: string
          logo_url?: string | null
          show_branch_selector?: boolean
          show_cart?: boolean
          show_cta?: boolean
          show_login?: boolean
          show_logo?: boolean
          show_search?: boolean
          updated_at?: string
        }
        Update: {
          app_overrides?: Json
          contact_phone?: string | null
          cta_text?: string | null
          cta_url?: string | null
          id?: string
          logo_url?: string | null
          show_branch_selector?: boolean
          show_cart?: boolean
          show_cta?: boolean
          show_login?: boolean
          show_logo?: boolean
          show_search?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      hero_slides: {
        Row: {
          created_at: string
          cta_text: string | null
          cta_url: string | null
          end_date: string | null
          id: string
          image_only: boolean
          image_url: string | null
          platform: Database["public"]["Enums"]["platform_target"]
          sort_order: number
          start_date: string | null
          status: Database["public"]["Enums"]["banner_status"]
          subtitle: string | null
          text_alignment: Database["public"]["Enums"]["text_alignment"]
          text_color: string | null
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          cta_text?: string | null
          cta_url?: string | null
          end_date?: string | null
          id?: string
          image_only?: boolean
          image_url?: string | null
          platform?: Database["public"]["Enums"]["platform_target"]
          sort_order?: number
          start_date?: string | null
          status?: Database["public"]["Enums"]["banner_status"]
          subtitle?: string | null
          text_alignment?: Database["public"]["Enums"]["text_alignment"]
          text_color?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          cta_text?: string | null
          cta_url?: string | null
          end_date?: string | null
          id?: string
          image_only?: boolean
          image_url?: string | null
          platform?: Database["public"]["Enums"]["platform_target"]
          sort_order?: number
          start_date?: string | null
          status?: Database["public"]["Enums"]["banner_status"]
          subtitle?: string | null
          text_alignment?: Database["public"]["Enums"]["text_alignment"]
          text_color?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      home_section_banners: {
        Row: {
          anchor_section_id: string | null
          created_at: string
          end_date: string | null
          id: string
          image_desktop: string | null
          image_mobile: string | null
          image_tablet: string | null
          is_active: boolean
          link_type: Database["public"]["Enums"]["home_banner_link_type"]
          link_value: string | null
          position: Database["public"]["Enums"]["home_banner_position"]
          section_id: string | null
          sort_order: number
          start_date: string | null
          subtitle: string | null
          title: string | null
          updated_at: string
        }
        Insert: {
          anchor_section_id?: string | null
          created_at?: string
          end_date?: string | null
          id?: string
          image_desktop?: string | null
          image_mobile?: string | null
          image_tablet?: string | null
          is_active?: boolean
          link_type?: Database["public"]["Enums"]["home_banner_link_type"]
          link_value?: string | null
          position?: Database["public"]["Enums"]["home_banner_position"]
          section_id?: string | null
          sort_order?: number
          start_date?: string | null
          subtitle?: string | null
          title?: string | null
          updated_at?: string
        }
        Update: {
          anchor_section_id?: string | null
          created_at?: string
          end_date?: string | null
          id?: string
          image_desktop?: string | null
          image_mobile?: string | null
          image_tablet?: string | null
          is_active?: boolean
          link_type?: Database["public"]["Enums"]["home_banner_link_type"]
          link_value?: string | null
          position?: Database["public"]["Enums"]["home_banner_position"]
          section_id?: string | null
          sort_order?: number
          start_date?: string | null
          subtitle?: string | null
          title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "home_section_banners_anchor_section_id_fkey"
            columns: ["anchor_section_id"]
            isOneToOne: false
            referencedRelation: "home_sections"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "home_section_banners_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "home_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      home_sections: {
        Row: {
          category_id: string | null
          created_at: string
          display_style: Database["public"]["Enums"]["home_display_style"]
          id: string
          is_active: boolean
          manual_product_ids: string[]
          products_limit: number
          section_type: Database["public"]["Enums"]["home_section_type"]
          settings: Json
          show_view_all: boolean
          sort_order: number
          title_ar: string
          title_en: string | null
          updated_at: string
          view_all_url: string | null
        }
        Insert: {
          category_id?: string | null
          created_at?: string
          display_style?: Database["public"]["Enums"]["home_display_style"]
          id?: string
          is_active?: boolean
          manual_product_ids?: string[]
          products_limit?: number
          section_type: Database["public"]["Enums"]["home_section_type"]
          settings?: Json
          show_view_all?: boolean
          sort_order?: number
          title_ar?: string
          title_en?: string | null
          updated_at?: string
          view_all_url?: string | null
        }
        Update: {
          category_id?: string | null
          created_at?: string
          display_style?: Database["public"]["Enums"]["home_display_style"]
          id?: string
          is_active?: boolean
          manual_product_ids?: string[]
          products_limit?: number
          section_type?: Database["public"]["Enums"]["home_section_type"]
          settings?: Json
          show_view_all?: boolean
          sort_order?: number
          title_ar?: string
          title_en?: string | null
          updated_at?: string
          view_all_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "home_sections_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "product_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      import_logs: {
        Row: {
          created_at: string
          errors: Json | null
          filename: string | null
          id: string
          summary: Json | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          errors?: Json | null
          filename?: string | null
          id?: string
          summary?: Json | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          errors?: Json | null
          filename?: string | null
          id?: string
          summary?: Json | null
          user_id?: string | null
        }
        Relationships: []
      }
      integrations: {
        Row: {
          config: Json
          created_at: string
          id: string
          last_test_message: string | null
          last_test_status: Database["public"]["Enums"]["integration_test_status"]
          last_tested_at: string | null
          name: string
          provider: string
          status: Database["public"]["Enums"]["publish_status"]
          updated_at: string
        }
        Insert: {
          config?: Json
          created_at?: string
          id?: string
          last_test_message?: string | null
          last_test_status?: Database["public"]["Enums"]["integration_test_status"]
          last_tested_at?: string | null
          name: string
          provider: string
          status?: Database["public"]["Enums"]["publish_status"]
          updated_at?: string
        }
        Update: {
          config?: Json
          created_at?: string
          id?: string
          last_test_message?: string | null
          last_test_status?: Database["public"]["Enums"]["integration_test_status"]
          last_tested_at?: string | null
          name?: string
          provider?: string
          status?: Database["public"]["Enums"]["publish_status"]
          updated_at?: string
        }
        Relationships: []
      }
      navigation_menu_items: {
        Row: {
          created_at: string
          id: string
          link_type: Database["public"]["Enums"]["banner_link_type"]
          link_value: string | null
          menu_id: string
          open_in_new_tab: boolean
          parent_id: string | null
          sort_order: number
          status: Database["public"]["Enums"]["publish_status"]
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          link_type?: Database["public"]["Enums"]["banner_link_type"]
          link_value?: string | null
          menu_id: string
          open_in_new_tab?: boolean
          parent_id?: string | null
          sort_order?: number
          status?: Database["public"]["Enums"]["publish_status"]
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          link_type?: Database["public"]["Enums"]["banner_link_type"]
          link_value?: string | null
          menu_id?: string
          open_in_new_tab?: boolean
          parent_id?: string | null
          sort_order?: number
          status?: Database["public"]["Enums"]["publish_status"]
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "navigation_menu_items_menu_id_fkey"
            columns: ["menu_id"]
            isOneToOne: false
            referencedRelation: "navigation_menus"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "navigation_menu_items_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "navigation_menu_items"
            referencedColumns: ["id"]
          },
        ]
      }
      navigation_menus: {
        Row: {
          created_at: string
          id: string
          location: Database["public"]["Enums"]["menu_location"]
          name: string
          status: Database["public"]["Enums"]["publish_status"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          location: Database["public"]["Enums"]["menu_location"]
          name: string
          status?: Database["public"]["Enums"]["publish_status"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          location?: Database["public"]["Enums"]["menu_location"]
          name?: string
          status?: Database["public"]["Enums"]["publish_status"]
          updated_at?: string
        }
        Relationships: []
      }
      notification_settings: {
        Row: {
          created_at: string
          drivers_enabled: boolean
          email_enabled: boolean
          id: string
          integrations_enabled: boolean
          inventory_enabled: boolean
          orders_enabled: boolean
          push_enabled: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          drivers_enabled?: boolean
          email_enabled?: boolean
          id?: string
          integrations_enabled?: boolean
          inventory_enabled?: boolean
          orders_enabled?: boolean
          push_enabled?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          drivers_enabled?: boolean
          email_enabled?: boolean
          id?: string
          integrations_enabled?: boolean
          inventory_enabled?: boolean
          orders_enabled?: boolean
          push_enabled?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          action_url: string | null
          created_at: string
          id: string
          is_read: boolean
          message: string | null
          title: string
          type: string
          user_id: string | null
        }
        Insert: {
          action_url?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string | null
          title: string
          type?: string
          user_id?: string | null
        }
        Update: {
          action_url?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string | null
          title?: string
          type?: string
          user_id?: string | null
        }
        Relationships: []
      }
      order_item_addons: {
        Row: {
          addon_id: string | null
          addon_name: string
          id: string
          order_item_id: string
          price: number
        }
        Insert: {
          addon_id?: string | null
          addon_name: string
          id?: string
          order_item_id: string
          price?: number
        }
        Update: {
          addon_id?: string | null
          addon_name?: string
          id?: string
          order_item_id?: string
          price?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_item_addons_addon_id_fkey"
            columns: ["addon_id"]
            isOneToOne: false
            referencedRelation: "product_addons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_item_addons_order_item_id_fkey"
            columns: ["order_item_id"]
            isOneToOne: false
            referencedRelation: "order_items"
            referencedColumns: ["id"]
          },
        ]
      }
      order_items: {
        Row: {
          id: string
          notes: string | null
          order_id: string
          product_id: string | null
          product_image: string | null
          product_name: string
          quantity: number
          total_price: number
          unit_price: number
          variant_id: string | null
          variant_name: string | null
        }
        Insert: {
          id?: string
          notes?: string | null
          order_id: string
          product_id?: string | null
          product_image?: string | null
          product_name: string
          quantity?: number
          total_price?: number
          unit_price?: number
          variant_id?: string | null
          variant_name?: string | null
        }
        Update: {
          id?: string
          notes?: string | null
          order_id?: string
          product_id?: string | null
          product_image?: string | null
          product_name?: string
          quantity?: number
          total_price?: number
          unit_price?: number
          variant_id?: string | null
          variant_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_variant_id_fkey"
            columns: ["variant_id"]
            isOneToOne: false
            referencedRelation: "product_variants"
            referencedColumns: ["id"]
          },
        ]
      }
      order_status_logs: {
        Row: {
          changed_by: string | null
          created_at: string
          id: string
          new_status: Database["public"]["Enums"]["order_status"]
          note: string | null
          old_status: Database["public"]["Enums"]["order_status"] | null
          order_id: string
        }
        Insert: {
          changed_by?: string | null
          created_at?: string
          id?: string
          new_status: Database["public"]["Enums"]["order_status"]
          note?: string | null
          old_status?: Database["public"]["Enums"]["order_status"] | null
          order_id: string
        }
        Update: {
          changed_by?: string | null
          created_at?: string
          id?: string
          new_status?: Database["public"]["Enums"]["order_status"]
          note?: string | null
          old_status?: Database["public"]["Enums"]["order_status"] | null
          order_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_status_logs_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          admin_notes: string | null
          branch_id: string | null
          branch_name: string | null
          coupon_code: string | null
          coupon_id: string | null
          created_at: string
          customer_email: string | null
          customer_id: string | null
          customer_name: string | null
          customer_notes: string | null
          customer_phone: string | null
          delivery_address_id: string | null
          delivery_address_snapshot: Json | null
          delivery_fee: number
          discount_amount: number
          driver_id: string | null
          estimated_delivery_time: number | null
          estimated_preparation_time: number | null
          id: string
          order_number: string
          order_type: Database["public"]["Enums"]["order_type"]
          payment_method: Database["public"]["Enums"]["payment_method"]
          payment_status: Database["public"]["Enums"]["payment_status"]
          status: Database["public"]["Enums"]["order_status"]
          subtotal: number
          total_amount: number
          updated_at: string
          vat_amount: number
        }
        Insert: {
          admin_notes?: string | null
          branch_id?: string | null
          branch_name?: string | null
          coupon_code?: string | null
          coupon_id?: string | null
          created_at?: string
          customer_email?: string | null
          customer_id?: string | null
          customer_name?: string | null
          customer_notes?: string | null
          customer_phone?: string | null
          delivery_address_id?: string | null
          delivery_address_snapshot?: Json | null
          delivery_fee?: number
          discount_amount?: number
          driver_id?: string | null
          estimated_delivery_time?: number | null
          estimated_preparation_time?: number | null
          id?: string
          order_number?: string
          order_type?: Database["public"]["Enums"]["order_type"]
          payment_method?: Database["public"]["Enums"]["payment_method"]
          payment_status?: Database["public"]["Enums"]["payment_status"]
          status?: Database["public"]["Enums"]["order_status"]
          subtotal?: number
          total_amount?: number
          updated_at?: string
          vat_amount?: number
        }
        Update: {
          admin_notes?: string | null
          branch_id?: string | null
          branch_name?: string | null
          coupon_code?: string | null
          coupon_id?: string | null
          created_at?: string
          customer_email?: string | null
          customer_id?: string | null
          customer_name?: string | null
          customer_notes?: string | null
          customer_phone?: string | null
          delivery_address_id?: string | null
          delivery_address_snapshot?: Json | null
          delivery_fee?: number
          discount_amount?: number
          driver_id?: string | null
          estimated_delivery_time?: number | null
          estimated_preparation_time?: number | null
          id?: string
          order_number?: string
          order_type?: Database["public"]["Enums"]["order_type"]
          payment_method?: Database["public"]["Enums"]["payment_method"]
          payment_status?: Database["public"]["Enums"]["payment_status"]
          status?: Database["public"]["Enums"]["order_status"]
          subtotal?: number
          total_amount?: number
          updated_at?: string
          vat_amount?: number
        }
        Relationships: [
          {
            foreignKeyName: "orders_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_coupon_id_fkey"
            columns: ["coupon_id"]
            isOneToOne: false
            referencedRelation: "coupons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_delivery_address_id_fkey"
            columns: ["delivery_address_id"]
            isOneToOne: false
            referencedRelation: "customer_addresses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "drivers"
            referencedColumns: ["id"]
          },
        ]
      }
      page_blocks: {
        Row: {
          block_type: string
          created_at: string
          id: string
          is_active: boolean
          location: string | null
          page_id: string | null
          settings: Json
          sort_order: number
          updated_at: string
        }
        Insert: {
          block_type: string
          created_at?: string
          id?: string
          is_active?: boolean
          location?: string | null
          page_id?: string | null
          settings?: Json
          sort_order?: number
          updated_at?: string
        }
        Update: {
          block_type?: string
          created_at?: string
          id?: string
          is_active?: boolean
          location?: string | null
          page_id?: string | null
          settings?: Json
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "page_blocks_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "pages"
            referencedColumns: ["id"]
          },
        ]
      }
      pages: {
        Row: {
          content: string | null
          created_at: string
          featured_image: string | null
          id: string
          show_in_footer: boolean
          show_in_header: boolean
          slug: string
          sort_order: number
          status: Database["public"]["Enums"]["publish_status"]
          title: string
          updated_at: string
        }
        Insert: {
          content?: string | null
          created_at?: string
          featured_image?: string | null
          id?: string
          show_in_footer?: boolean
          show_in_header?: boolean
          slug: string
          sort_order?: number
          status?: Database["public"]["Enums"]["publish_status"]
          title: string
          updated_at?: string
        }
        Update: {
          content?: string | null
          created_at?: string
          featured_image?: string | null
          id?: string
          show_in_footer?: boolean
          show_in_header?: boolean
          slug?: string
          sort_order?: number
          status?: Database["public"]["Enums"]["publish_status"]
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      permissions: {
        Row: {
          description: string | null
          id: string
          key: string
          module: string
          name: string
        }
        Insert: {
          description?: string | null
          id?: string
          key: string
          module: string
          name: string
        }
        Update: {
          description?: string | null
          id?: string
          key?: string
          module?: string
          name?: string
        }
        Relationships: []
      }
      product_addons: {
        Row: {
          created_at: string
          display_order: number
          group_id: string
          id: string
          is_available: boolean
          name_ar: string
          name_en: string | null
          price: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          group_id: string
          id?: string
          is_available?: boolean
          name_ar: string
          name_en?: string | null
          price?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          group_id?: string
          id?: string
          is_available?: boolean
          name_ar?: string
          name_en?: string | null
          price?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_addons_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "addon_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      product_branches: {
        Row: {
          branch_id: string
          is_available: boolean
          product_id: string
        }
        Insert: {
          branch_id: string
          is_available?: boolean
          product_id: string
        }
        Update: {
          branch_id?: string
          is_available?: boolean
          product_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_branches_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_branches_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      product_categories: {
        Row: {
          created_at: string
          display_order: number
          home_product_limit: number
          icon: string | null
          id: string
          image_url: string | null
          is_active: boolean
          is_featured: boolean
          name_ar: string
          name_en: string | null
          parent_id: string | null
          show_in_app: boolean
          show_in_store: boolean
          show_on_home: boolean
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          home_product_limit?: number
          icon?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          is_featured?: boolean
          name_ar: string
          name_en?: string | null
          parent_id?: string | null
          show_in_app?: boolean
          show_in_store?: boolean
          show_on_home?: boolean
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          home_product_limit?: number
          icon?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          is_featured?: boolean
          name_ar?: string
          name_en?: string | null
          parent_id?: string | null
          show_in_app?: boolean
          show_in_store?: boolean
          show_on_home?: boolean
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_categories_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "product_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      product_variants: {
        Row: {
          calories: number | null
          created_at: string
          display_order: number
          id: string
          is_available: boolean
          name_ar: string
          name_en: string | null
          price: number
          product_id: string
          sku: string | null
          updated_at: string
        }
        Insert: {
          calories?: number | null
          created_at?: string
          display_order?: number
          id?: string
          is_available?: boolean
          name_ar: string
          name_en?: string | null
          price?: number
          product_id: string
          sku?: string | null
          updated_at?: string
        }
        Update: {
          calories?: number | null
          created_at?: string
          display_order?: number
          id?: string
          is_available?: boolean
          name_ar?: string
          name_en?: string | null
          price?: number
          product_id?: string
          sku?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_variants_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          base_price: number
          calories: number | null
          category_id: string | null
          created_at: string
          description_ar: string | null
          description_en: string | null
          discount_price: number | null
          display_order: number
          gallery_urls: string[]
          id: string
          image_url: string | null
          is_archived: boolean
          is_available: boolean
          is_featured: boolean
          name_ar: string
          name_en: string | null
          prep_time_minutes: number | null
          show_in_app: boolean
          show_in_store: boolean
          updated_at: string
        }
        Insert: {
          base_price?: number
          calories?: number | null
          category_id?: string | null
          created_at?: string
          description_ar?: string | null
          description_en?: string | null
          discount_price?: number | null
          display_order?: number
          gallery_urls?: string[]
          id?: string
          image_url?: string | null
          is_archived?: boolean
          is_available?: boolean
          is_featured?: boolean
          name_ar: string
          name_en?: string | null
          prep_time_minutes?: number | null
          show_in_app?: boolean
          show_in_store?: boolean
          updated_at?: string
        }
        Update: {
          base_price?: number
          calories?: number | null
          category_id?: string | null
          created_at?: string
          description_ar?: string | null
          description_en?: string | null
          discount_price?: number | null
          display_order?: number
          gallery_urls?: string[]
          id?: string
          image_url?: string | null
          is_archived?: boolean
          is_available?: boolean
          is_featured?: boolean
          name_ar?: string
          name_en?: string | null
          prep_time_minutes?: number | null
          show_in_app?: boolean
          show_in_store?: boolean
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "products_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "product_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          last_login_at: string | null
          phone: string | null
          status: Database["public"]["Enums"]["user_status"]
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          last_login_at?: string | null
          phone?: string | null
          status?: Database["public"]["Enums"]["user_status"]
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          last_login_at?: string | null
          phone?: string | null
          status?: Database["public"]["Enums"]["user_status"]
          updated_at?: string
        }
        Relationships: []
      }
      role_permissions: {
        Row: {
          id: string
          permission_key: string
          role_id: string
        }
        Insert: {
          id?: string
          permission_key: string
          role_id: string
        }
        Update: {
          id?: string
          permission_key?: string
          role_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "role_permissions_permission_key_fkey"
            columns: ["permission_key"]
            isOneToOne: false
            referencedRelation: "permissions"
            referencedColumns: ["key"]
          },
          {
            foreignKeyName: "role_permissions_role_id_fkey"
            columns: ["role_id"]
            isOneToOne: false
            referencedRelation: "roles"
            referencedColumns: ["id"]
          },
        ]
      }
      roles: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_system: boolean
          key: string
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_system?: boolean
          key: string
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_system?: boolean
          key?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      security_sessions: {
        Row: {
          browser: string | null
          created_at: string
          device: string | null
          id: string
          ip_address: string | null
          last_activity_at: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          browser?: string | null
          created_at?: string
          device?: string | null
          id?: string
          ip_address?: string | null
          last_activity_at?: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          browser?: string | null
          created_at?: string
          device?: string | null
          id?: string
          ip_address?: string | null
          last_activity_at?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      seo_settings: {
        Row: {
          canonical_url: string | null
          created_at: string
          default_og_image: string | null
          default_twitter_image: string | null
          entity_id: string | null
          entity_type: Database["public"]["Enums"]["seo_entity_type"]
          google_verification: string | null
          id: string
          meta_description: string | null
          meta_keywords: string | null
          meta_title: string | null
          og_description: string | null
          og_image: string | null
          og_title: string | null
          robots_follow: boolean
          robots_index: boolean
          sitemap_enabled: boolean
          slug: string | null
          twitter_description: string | null
          twitter_image: string | null
          twitter_title: string | null
          updated_at: string
        }
        Insert: {
          canonical_url?: string | null
          created_at?: string
          default_og_image?: string | null
          default_twitter_image?: string | null
          entity_id?: string | null
          entity_type: Database["public"]["Enums"]["seo_entity_type"]
          google_verification?: string | null
          id?: string
          meta_description?: string | null
          meta_keywords?: string | null
          meta_title?: string | null
          og_description?: string | null
          og_image?: string | null
          og_title?: string | null
          robots_follow?: boolean
          robots_index?: boolean
          sitemap_enabled?: boolean
          slug?: string | null
          twitter_description?: string | null
          twitter_image?: string | null
          twitter_title?: string | null
          updated_at?: string
        }
        Update: {
          canonical_url?: string | null
          created_at?: string
          default_og_image?: string | null
          default_twitter_image?: string | null
          entity_id?: string | null
          entity_type?: Database["public"]["Enums"]["seo_entity_type"]
          google_verification?: string | null
          id?: string
          meta_description?: string | null
          meta_keywords?: string | null
          meta_title?: string | null
          og_description?: string | null
          og_image?: string | null
          og_title?: string | null
          robots_follow?: boolean
          robots_index?: boolean
          sitemap_enabled?: boolean
          slug?: string | null
          twitter_description?: string | null
          twitter_image?: string | null
          twitter_title?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      store_settings: {
        Row: {
          accepting_orders: boolean
          address: string | null
          business_hours: Json | null
          created_at: string
          currency: string
          delivery_fee: number
          email: string | null
          id: string
          logo_url: string | null
          min_order_amount: number
          name: string | null
          phone: string | null
          primary_color: string | null
          secondary_color: string | null
          updated_at: string
          vat_percent: number
        }
        Insert: {
          accepting_orders?: boolean
          address?: string | null
          business_hours?: Json | null
          created_at?: string
          currency?: string
          delivery_fee?: number
          email?: string | null
          id?: string
          logo_url?: string | null
          min_order_amount?: number
          name?: string | null
          phone?: string | null
          primary_color?: string | null
          secondary_color?: string | null
          updated_at?: string
          vat_percent?: number
        }
        Update: {
          accepting_orders?: boolean
          address?: string | null
          business_hours?: Json | null
          created_at?: string
          currency?: string
          delivery_fee?: number
          email?: string | null
          id?: string
          logo_url?: string | null
          min_order_amount?: number
          name?: string | null
          phone?: string | null
          primary_color?: string | null
          secondary_color?: string | null
          updated_at?: string
          vat_percent?: number
        }
        Relationships: []
      }
      user_branches: {
        Row: {
          branch_id: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          branch_id: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          branch_id?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_branches_branch_id_fkey"
            columns: ["branch_id"]
            isOneToOne: false
            referencedRelation: "branches"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      webhook_logs: {
        Row: {
          attempt_count: number
          created_at: string
          event: string
          id: string
          payload: Json | null
          response_body: string | null
          response_status: number | null
          webhook_id: string
        }
        Insert: {
          attempt_count?: number
          created_at?: string
          event: string
          id?: string
          payload?: Json | null
          response_body?: string | null
          response_status?: number | null
          webhook_id: string
        }
        Update: {
          attempt_count?: number
          created_at?: string
          event?: string
          id?: string
          payload?: Json | null
          response_body?: string | null
          response_status?: number | null
          webhook_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "webhook_logs_webhook_id_fkey"
            columns: ["webhook_id"]
            isOneToOne: false
            referencedRelation: "webhooks"
            referencedColumns: ["id"]
          },
        ]
      }
      webhooks: {
        Row: {
          created_at: string
          events: string[]
          id: string
          name: string
          secret: string | null
          status: Database["public"]["Enums"]["webhook_status"]
          updated_at: string
          url: string
        }
        Insert: {
          created_at?: string
          events?: string[]
          id?: string
          name: string
          secret?: string | null
          status?: Database["public"]["Enums"]["webhook_status"]
          updated_at?: string
          url: string
        }
        Update: {
          created_at?: string
          events?: string[]
          id?: string
          name?: string
          secret?: string | null
          status?: Database["public"]["Enums"]["webhook_status"]
          updated_at?: string
          url?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      customer_phone_exists: { Args: { _phone: string }; Returns: Json }
      customer_touch_login: { Args: { _phone: string }; Returns: undefined }
      delete_customer_address: {
        Args: { _address_id: string; _phone: string }
        Returns: undefined
      }
      get_customer_addresses: { Args: { _phone: string }; Returns: Json }
      get_customer_order: {
        Args: { _order_number: string; _phone: string }
        Returns: Json
      }
      get_customer_orders: { Args: { _phone: string }; Returns: Json }
      has_permission: {
        Args: { _perm_key: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_customer_banned: { Args: { _phone: string }; Returns: boolean }
      is_manager: { Args: { _user_id: string }; Returns: boolean }
      place_storefront_order: { Args: { payload: Json }; Returns: Json }
      touch_last_login: { Args: never; Returns: undefined }
      track_order: {
        Args: { _order_number: string; _phone: string }
        Returns: Json
      }
      update_customer_profile: {
        Args: { _email: string; _name: string; _phone: string }
        Returns: Json
      }
      upsert_customer_address: {
        Args: { _address: Json; _phone: string }
        Returns: Json
      }
    }
    Enums: {
      app_role: "admin" | "manager" | "staff"
      banner_link_type: "page" | "category" | "product" | "external" | "none"
      banner_placement: "home" | "categories" | "product" | "offers" | "all"
      banner_status: "active" | "inactive" | "scheduled" | "expired"
      coupon_discount_type: "fixed" | "percent" | "free_delivery"
      coupon_status: "active" | "inactive"
      customer_status: "active" | "inactive" | "banned"
      driver_status: "available" | "busy" | "offline" | "suspended"
      home_banner_link_type:
        | "none"
        | "product"
        | "category"
        | "offer"
        | "page"
        | "external"
      home_banner_position:
        | "top_of_page"
        | "after_categories"
        | "before_section"
        | "after_section"
        | "inside_section"
        | "standalone"
      home_display_style:
        | "carousel"
        | "grid"
        | "vertical_list"
        | "featured_large"
        | "compact"
      home_section_type:
        | "hero_carousel"
        | "single_banner"
        | "banner_grid"
        | "products_carousel"
        | "products_grid"
        | "featured_products"
        | "category_products"
        | "most_ordered"
        | "new_products"
        | "offers_products"
        | "categories_section"
        | "combo_section"
        | "banner_with_products"
      integration_test_status: "success" | "failed" | "untested"
      menu_location: "header" | "footer" | "app"
      order_status:
        | "new"
        | "accepted"
        | "preparing"
        | "ready"
        | "awaiting_driver"
        | "with_driver"
        | "delivered"
        | "cancelled"
        | "refunded"
      order_type: "delivery" | "pickup"
      payment_method: "cash" | "card" | "online" | "wallet"
      payment_status: "pending" | "paid" | "failed" | "refunded"
      platform_target: "store" | "app" | "both"
      publish_status: "published" | "draft" | "inactive"
      seo_entity_type: "site" | "page" | "product" | "category"
      text_alignment: "start" | "center" | "end"
      user_status: "active" | "inactive" | "suspended"
      webhook_status: "active" | "inactive"
      zone_status: "active" | "inactive"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "manager", "staff"],
      banner_link_type: ["page", "category", "product", "external", "none"],
      banner_placement: ["home", "categories", "product", "offers", "all"],
      banner_status: ["active", "inactive", "scheduled", "expired"],
      coupon_discount_type: ["fixed", "percent", "free_delivery"],
      coupon_status: ["active", "inactive"],
      customer_status: ["active", "inactive", "banned"],
      driver_status: ["available", "busy", "offline", "suspended"],
      home_banner_link_type: [
        "none",
        "product",
        "category",
        "offer",
        "page",
        "external",
      ],
      home_banner_position: [
        "top_of_page",
        "after_categories",
        "before_section",
        "after_section",
        "inside_section",
        "standalone",
      ],
      home_display_style: [
        "carousel",
        "grid",
        "vertical_list",
        "featured_large",
        "compact",
      ],
      home_section_type: [
        "hero_carousel",
        "single_banner",
        "banner_grid",
        "products_carousel",
        "products_grid",
        "featured_products",
        "category_products",
        "most_ordered",
        "new_products",
        "offers_products",
        "categories_section",
        "combo_section",
        "banner_with_products",
      ],
      integration_test_status: ["success", "failed", "untested"],
      menu_location: ["header", "footer", "app"],
      order_status: [
        "new",
        "accepted",
        "preparing",
        "ready",
        "awaiting_driver",
        "with_driver",
        "delivered",
        "cancelled",
        "refunded",
      ],
      order_type: ["delivery", "pickup"],
      payment_method: ["cash", "card", "online", "wallet"],
      payment_status: ["pending", "paid", "failed", "refunded"],
      platform_target: ["store", "app", "both"],
      publish_status: ["published", "draft", "inactive"],
      seo_entity_type: ["site", "page", "product", "category"],
      text_alignment: ["start", "center", "end"],
      user_status: ["active", "inactive", "suspended"],
      webhook_status: ["active", "inactive"],
      zone_status: ["active", "inactive"],
    },
  },
} as const
