import { ReactNode } from "react";
import { Navigate } from "@tanstack/react-router";
import { usePermissions } from "@/lib/permissions";

export function PermissionGuard({ permission, children }: { permission: string; children: ReactNode }) {
  const { has, isLoading } = usePermissions();
  if (isLoading) return <div className="text-muted-foreground p-6">جارٍ التحقق من الصلاحيات...</div>;
  if (!has(permission)) return <Navigate to="/dashboard/forbidden" />;
  return <>{children}</>;
}
