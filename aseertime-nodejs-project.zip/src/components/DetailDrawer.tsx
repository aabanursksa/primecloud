import { useEffect, useState } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Link } from "@tanstack/react-router";
import { ExternalLink, AlertCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export type DetailEntity = "orders" | "customers" | "products" | "branches";

const ENTITY_CONFIG: Record<DetailEntity, {
  title: string;
  select: string;
  fullPagePath?: (id: string) => string;
  primary: (row: any) => string;
  subtitle?: (row: any) => string;
}> = {
  orders: {
    title: "تفاصيل الطلب",
    select: "*, order_items(*), customers(name, phone, email), branches(name)",
    fullPagePath: (id) => `/dashboard/orders/${id}`,
    primary: (r) => r.order_number ?? r.id,
    subtitle: (r) => r.customer_name ?? r.customers?.name ?? "",
  },
  customers: {
    title: "تفاصيل العميل",
    select: "*, customer_addresses(*)",
    fullPagePath: (id) => `/dashboard/customers/${id}`,
    primary: (r) => r.name,
    subtitle: (r) => r.phone,
  },
  products: {
    title: "تفاصيل المنتج",
    select: "*, product_variants(*), product_categories(name_ar)",
    primary: (r) => r.name_ar,
    subtitle: (r) => r.product_categories?.name_ar ?? "",
  },
  branches: {
    title: "تفاصيل الفرع",
    select: "*",
    primary: (r) => r.name,
    subtitle: (r) => r.address ?? r.phone ?? "",
  },
};

const HIDDEN_KEYS = new Set(["id", "created_at", "updated_at"]);

interface Props {
  entity: DetailEntity | null;
  recordId: string | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

function formatValue(v: any): string {
  if (v === null || v === undefined || v === "") return "—";
  if (typeof v === "boolean") return v ? "نعم" : "لا";
  if (typeof v === "number") return String(v);
  if (typeof v === "string") {
    if (/^\d{4}-\d{2}-\d{2}T/.test(v)) {
      try { return new Date(v).toLocaleString("ar-SA"); } catch { return v; }
    }
    return v;
  }
  return JSON.stringify(v);
}

function labelKey(k: string): string {
  const map: Record<string, string> = {
    name: "الاسم", name_ar: "الاسم", name_en: "الاسم (EN)",
    phone: "الجوال", email: "البريد", status: "الحالة",
    notes: "ملاحظات", address: "العنوان", total_amount: "الإجمالي",
    subtotal: "المجموع الجزئي", vat_amount: "الضريبة", delivery_fee: "التوصيل",
    discount_amount: "الخصم", payment_method: "طريقة الدفع",
    payment_status: "حالة الدفع", order_type: "نوع الطلب",
    order_number: "رقم الطلب", customer_name: "اسم العميل",
    customer_phone: "جوال العميل", branch_name: "الفرع",
    base_price: "السعر", description_ar: "الوصف", image_url: "الصورة",
    is_active: "مفعل", is_available: "متاح", is_featured: "مميز",
    last_login_at: "آخر دخول", latitude: "خط العرض", longitude: "خط الطول",
  };
  return map[k] ?? k;
}

export function DetailDrawer({ entity, recordId, open, onOpenChange }: Props) {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const config = entity ? ENTITY_CONFIG[entity] : null;

  useEffect(() => {
    if (!open || !entity || !recordId || !config) {
      setData(null); setError(null); return;
    }
    let cancelled = false;
    setLoading(true); setError(null);
    (async () => {
      const { data: row, error: err } = await supabase
        .from(entity as any)
        .select(config.select)
        .eq("id", recordId)
        .maybeSingle();
      if (cancelled) return;
      setLoading(false);
      if (err) {
        setError(err.message);
        toast.error("تعذّر تحميل البيانات: " + err.message);
      } else if (!row) {
        setError("not_found");
      } else {
        setData(row);
      }
    })();
    return () => { cancelled = true; };
  }, [open, entity, recordId, config]);

  const fields = data
    ? Object.entries(data).filter(([k, v]) =>
        !HIDDEN_KEYS.has(k) && typeof v !== "object")
    : [];
  const relations = data
    ? Object.entries(data).filter(([_, v]) => Array.isArray(v) && v.length > 0)
    : [];

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="left" className="w-full sm:max-w-xl overflow-hidden flex flex-col" dir="rtl">
        <SheetHeader>
          <SheetTitle>{config?.title ?? "التفاصيل"}</SheetTitle>
          {data && config && (
            <SheetDescription className="flex items-center justify-between gap-2">
              <span>
                <span className="font-medium text-foreground">{config.primary(data)}</span>
                {config.subtitle?.(data) && <span className="block text-xs">{config.subtitle(data)}</span>}
              </span>
              {config.fullPagePath && recordId && (
                <Button asChild size="sm" variant="outline">
                  <Link to={config.fullPagePath(recordId)} onClick={() => onOpenChange(false)}>
                    <ExternalLink className="h-4 w-4 ml-1" />
                    فتح الصفحة الكاملة
                  </Link>
                </Button>
              )}
            </SheetDescription>
          )}
        </SheetHeader>

        <ScrollArea className="flex-1 mt-4 -mx-6 px-6">
          {loading && (
            <div className="space-y-3">
              {[...Array(8)].map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
            </div>
          )}
          {!loading && error === "not_found" && (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <AlertCircle className="h-10 w-10 mb-2" />
              <p>السجل غير موجود</p>
            </div>
          )}
          {!loading && error && error !== "not_found" && (
            <div className="flex flex-col items-center justify-center py-12 text-destructive">
              <AlertCircle className="h-10 w-10 mb-2" />
              <p>{error}</p>
            </div>
          )}
          {!loading && data && (
            <div className="space-y-4">
              <dl className="grid grid-cols-1 gap-2">
                {fields.map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-3 py-2 border-b border-border last:border-0">
                    <dt className="text-sm text-muted-foreground shrink-0">{labelKey(k)}</dt>
                    <dd className="text-sm font-medium text-end break-all">
                      {k === "status" ? <Badge variant="secondary">{formatValue(v)}</Badge> : formatValue(v)}
                    </dd>
                  </div>
                ))}
              </dl>

              {relations.map(([k, arr]) => (
                <div key={k}>
                  <Separator className="my-2" />
                  <h4 className="text-sm font-semibold mb-2">{labelKey(k)} ({(arr as any[]).length})</h4>
                  <div className="space-y-2">
                    {(arr as any[]).map((item, i) => (
                      <div key={i} className="text-xs bg-muted/50 rounded p-2 space-y-1">
                        {Object.entries(item)
                          .filter(([ik, iv]) => !HIDDEN_KEYS.has(ik) && typeof iv !== "object" && iv !== null && iv !== "")
                          .slice(0, 6)
                          .map(([ik, iv]) => (
                            <div key={ik} className="flex justify-between gap-2">
                              <span className="text-muted-foreground">{labelKey(ik)}</span>
                              <span className="font-medium text-end break-all">{formatValue(iv)}</span>
                            </div>
                          ))}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}

// Hook helper for easy usage
export function useDetailDrawer() {
  const [state, setState] = useState<{ entity: DetailEntity | null; id: string | null; open: boolean }>({
    entity: null, id: null, open: false,
  });
  const openDetails = (entity: DetailEntity, id: string) =>
    setState({ entity, id, open: true });
  const close = () => setState((s) => ({ ...s, open: false }));
  return { ...state, openDetails, close, setOpen: (v: boolean) => setState((s) => ({ ...s, open: v })) };
}
