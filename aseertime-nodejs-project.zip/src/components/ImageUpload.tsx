import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Upload, X, Loader2, ImagePlus } from "lucide-react";
import { toast } from "sonner";

const BUCKET = "store-assets";

async function uploadFile(file: File, folder: string): Promise<string> {
  const ext = file.name.split(".").pop() ?? "jpg";
  const path = `${folder}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
    cacheControl: "3600",
    upsert: false,
    contentType: file.type,
  });
  if (error) throw error;
  return supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl;
}

export function SingleImageUpload({
  value,
  onChange,
  folder,
  label = "الصورة",
}: {
  value: string;
  onChange: (url: string) => void;
  folder: string;
  label?: string;
}) {
  const [busy, setBusy] = useState(false);

  const handle = async (file: File | null) => {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) return toast.error("الحد الأقصى 5MB");
    setBusy(true);
    try {
      const url = await uploadFile(file, folder);
      onChange(url);
      toast.success("تم رفع الصورة");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل الرفع");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex items-center gap-3">
      {value ? (
        <div className="relative group">
          <img src={value} alt={label} className="w-20 h-20 rounded-lg object-cover border border-border" />
          <button
            type="button"
            onClick={() => onChange("")}
            className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      ) : (
        <div className="w-20 h-20 rounded-lg border-2 border-dashed border-border flex items-center justify-center bg-muted/30 text-muted-foreground">
          <ImagePlus className="w-6 h-6" />
        </div>
      )}
      <label className="cursor-pointer">
        <input
          type="file"
          accept="image/*"
          className="hidden"
          disabled={busy}
          onChange={(e) => handle(e.target.files?.[0] ?? null)}
        />
        <Button type="button" variant="outline" size="sm" asChild>
          <span className="gap-2">
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            {value ? "تغيير" : "رفع صورة"}
          </span>
        </Button>
      </label>
    </div>
  );
}

export function MultiImageUpload({
  values,
  onChange,
  folder,
  max = 6,
}: {
  values: string[];
  onChange: (urls: string[]) => void;
  folder: string;
  max?: number;
}) {
  const [busy, setBusy] = useState(false);

  const handle = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const remaining = max - values.length;
    const list = Array.from(files).slice(0, remaining);
    setBusy(true);
    try {
      const urls: string[] = [];
      for (const f of list) {
        if (f.size > 5 * 1024 * 1024) {
          toast.error(`${f.name}: تجاوز 5MB`);
          continue;
        }
        urls.push(await uploadFile(f, folder));
      }
      onChange([...values, ...urls]);
      if (urls.length) toast.success(`تم رفع ${urls.length} صورة`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل الرفع");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-3">
        {values.map((url, i) => (
          <div key={url + i} className="relative group">
            <img src={url} alt="" className="w-20 h-20 rounded-lg object-cover border border-border" />
            <button
              type="button"
              onClick={() => onChange(values.filter((_, idx) => idx !== i))}
              className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
        {values.length < max && (
          <label className="w-20 h-20 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center bg-muted/30 text-muted-foreground cursor-pointer hover:bg-muted/60 transition">
            <input
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              disabled={busy}
              onChange={(e) => handle(e.target.files)}
            />
            {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : <ImagePlus className="w-5 h-5" />}
            <span className="text-[10px] mt-1">إضافة</span>
          </label>
        )}
      </div>
      <p className="text-xs text-muted-foreground">حتى {max} صور — كل صورة بحد أقصى 5MB</p>
    </div>
  );
}
