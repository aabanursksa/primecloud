import logoUrl from "@/assets/aseertime_logo_loader.svg";

export function LogoLoader({ label = "جارٍ التحميل..." }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-5 py-16">
      <div className="relative w-24 h-24">
        {/* Soft pulsing halo */}
        <span className="absolute inset-0 rounded-full bg-primary/20 animate-ping" />
        <span className="absolute inset-2 rounded-full bg-primary/10 animate-pulse" />
        {/* Logo with bouncing + subtle rotation */}
        <img
          src={logoUrl}
          alt="عسير تايم"
          className="relative w-full h-full drop-shadow-md animate-[loader-bounce_1.4s_ease-in-out_infinite]"
        />
      </div>

      {/* Animated dots */}
      <div className="flex items-center gap-1.5">
        <span className="w-2 h-2 rounded-full bg-primary animate-[loader-dot_1s_ease-in-out_infinite]" />
        <span className="w-2 h-2 rounded-full bg-primary animate-[loader-dot_1s_ease-in-out_infinite] [animation-delay:0.15s]" />
        <span className="w-2 h-2 rounded-full bg-primary animate-[loader-dot_1s_ease-in-out_infinite] [animation-delay:0.3s]" />
      </div>

      {label && <p className="text-sm text-muted-foreground animate-pulse">{label}</p>}

      <style>{`
        @keyframes loader-bounce {
          0%, 100% { transform: translateY(0) scale(1) rotate(0deg); }
          50% { transform: translateY(-10px) scale(1.05) rotate(-6deg); }
        }
        @keyframes loader-dot {
          0%, 100% { transform: translateY(0); opacity: 0.4; }
          50% { transform: translateY(-6px); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
