import { Link, useLocation } from "@tanstack/react-router";
import { Home, UtensilsCrossed, ShoppingCart, MapPin, User } from "lucide-react";
import { useCart } from "@/lib/cart";
import { useCartUI } from "./CartDrawer";

export function MobileBottomNav() {
  const loc = useLocation();
  const { itemCount } = useCart();
  const { openCart } = useCartUI();
  const path = loc.pathname;
  const Item = ({ to, icon: Icon, label, onClick, active, badge }: any) => {
    const cls = `flex flex-col items-center justify-center gap-0.5 flex-1 py-2 ${active ? "text-primary" : "text-muted-foreground"}`;
    const content = (
      <>
        <div className="relative">
          <Icon className="w-5 h-5" />
          {badge ? <span className="absolute -top-1 -right-2 bg-primary text-primary-foreground text-[9px] rounded-full min-w-[16px] h-4 px-1 flex items-center justify-center font-bold">{badge}</span> : null}
        </div>
        <span className="text-[10px] font-medium">{label}</span>
      </>
    );
    if (onClick) return <button onClick={onClick} className={cls}>{content}</button>;
    return <Link to={to} className={cls}>{content}</Link>;
  };
  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-card/95 backdrop-blur border-t border-border" dir="rtl">
      <div className="flex items-stretch">
        <Item to="/" icon={Home} label="الرئيسية" active={path === "/"} />
        <Item to="/menu" icon={UtensilsCrossed} label="المنيو" active={path.startsWith("/menu")} />
        <Item onClick={openCart} icon={ShoppingCart} label="السلة" active={false} badge={itemCount || undefined} />
        <Item to="/track-order" icon={MapPin} label="تتبع" active={path.startsWith("/track-order")} />
        <Item to="/account" icon={User} label="حسابي" active={path.startsWith("/account") || path.startsWith("/auth")} />
      </div>
    </nav>
  );
}
