import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { MessageCircle, ArrowUp } from "lucide-react";
import { useEffect, useState } from "react";

export function FloatingActions() {
  const { data: footer } = useQuery({
    queryKey: ["footer_settings"],
    queryFn: async () => (await supabase.from("footer_settings").select("*").maybeSingle()).data,
    staleTime: 5 * 60_000,
    gcTime: 10 * 60_000,
  });
  const { data: store } = useQuery({
    queryKey: ["store_settings"],
    queryFn: async () => (await supabase.from("store_settings").select("*").limit(1).maybeSingle()).data,
    staleTime: 5 * 60_000,
    gcTime: 10 * 60_000,
  });
  const social = (footer?.social_links as any) || {};
  const waRaw = social.whatsapp || footer?.phone || (store as any)?.phone || null;
  const data = waRaw ? { wa: String(waRaw).replace(/\D/g, "") || null } : null;

  const [showTop, setShowTop] = useState(false);
  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="fixed bottom-24 md:bottom-6 left-4 z-30 flex flex-col gap-2">
      {showTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label="للأعلى"
          className="w-11 h-11 rounded-full bg-card border border-border shadow-lg flex items-center justify-center hover:bg-muted"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}
      {data?.wa && (
        <a
          href={`https://wa.me/${data.wa}`}
          target="_blank"
          rel="noreferrer"
          aria-label="واتساب"
          className="w-12 h-12 rounded-full bg-[#25D366] text-white shadow-lg flex items-center justify-center hover:scale-110 transition"
        >
          <MessageCircle className="w-6 h-6" />
        </a>
      )}
    </div>
  );
}
