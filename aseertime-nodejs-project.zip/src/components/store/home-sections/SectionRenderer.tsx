import { Link } from "@tanstack/react-router";
import { ProductCard } from "@/components/store/ProductCard";
import { CategoryPill } from "@/components/store/CategoryPill";
import { ChevronLeft } from "lucide-react";

export type HomeSection = {
  id: string;
  title_ar: string;
  title_en?: string | null;
  section_type: string;
  display_style: string;
  category_id: string | null;
  manual_product_ids: string[];
  products_limit: number;
  show_view_all: boolean;
  view_all_url: string | null;
  settings: Record<string, any>;
};

export type HomeBanner = {
  id: string;
  section_id: string | null;
  position: string;
  anchor_section_id: string | null;
  image_mobile: string | null;
  image_tablet: string | null;
  image_desktop: string | null;
  title: string | null;
  subtitle: string | null;
  link_type: string;
  link_value: string | null;
  is_active: boolean;
};

function SectionHeader({ s }: { s: HomeSection }) {
  if (!s.title_ar && !s.show_view_all) return null;
  return (
    <div className="flex items-center justify-between mb-4">
      <h2 className="text-xl font-bold">{s.title_ar}</h2>
      {s.show_view_all && (
        <a href={s.view_all_url || (s.category_id ? `/menu/${s.category_id}` : "/menu")} className="text-sm text-primary flex items-center gap-1">
          عرض الكل <ChevronLeft className="w-4 h-4" />
        </a>
      )}
    </div>
  );
}

export function ResponsiveBanner({ b }: { b: HomeBanner }) {
  const desktop = b.image_desktop || b.image_tablet || b.image_mobile;
  const tablet = b.image_tablet || b.image_desktop || b.image_mobile;
  const mobile = b.image_mobile || b.image_tablet || b.image_desktop;
  if (!mobile && !desktop && !tablet) return null;

  const link = (() => {
    if (!b.link_value || b.link_type === "none") return null;
    if (b.link_type === "external") return b.link_value;
    if (b.link_type === "product") return `/product/${b.link_value}`;
    if (b.link_type === "category") return `/menu/${b.link_value}`;
    if (b.link_type === "page") return `/pages/${b.link_value}`;
    if (b.link_type === "offer") return `/offers`;
    return null;
  })();

  const inner = (
    <div className="relative overflow-hidden rounded-2xl bg-muted aspect-[3/1]">
      <picture>
        {desktop && <source media="(min-width: 1024px)" srcSet={desktop} />}
        {tablet && <source media="(min-width: 640px)" srcSet={tablet} />}
        <img src={mobile || desktop || ""} alt={b.title || ""} className="absolute inset-0 w-full h-full object-cover" />
      </picture>
      {(b.title || b.subtitle) && (
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-5 text-white">
          {b.title && <div className="font-bold text-lg">{b.title}</div>}
          {b.subtitle && <div className="text-sm opacity-90">{b.subtitle}</div>}
        </div>
      )}
    </div>
  );
  return link ? <a href={link} className="block">{inner}</a> : inner;
}

function ProductsCarousel({ products }: { products: any[] }) {
  return (
    <div className="flex gap-4 overflow-x-auto pb-3 scrollbar-hide snap-x snap-mandatory -mx-4 px-4">
      {products.map((p) => (
        <div key={p.id} className="snap-start shrink-0 w-44 sm:w-52">
          <ProductCard product={p} />
        </div>
      ))}
    </div>
  );
}

function ProductsGrid({ products, cols = 4 }: { products: any[]; cols?: number }) {
  const gridCols = cols === 5 ? "grid-cols-2 md:grid-cols-3 lg:grid-cols-5" : "grid-cols-2 md:grid-cols-3 lg:grid-cols-4";
  return (
    <div className={`grid ${gridCols} gap-4`}>
      {products.map((p) => <ProductCard key={p.id} product={p} />)}
    </div>
  );
}

function ProductsVerticalList({ products }: { products: any[] }) {
  return (
    <div className="flex flex-col gap-3">
      {products.map((p) => (
        <Link key={p.id} to="/product/$productId" params={{ productId: p.id }} className="flex items-center gap-3 bg-card border border-border rounded-2xl p-3 hover:shadow-md transition">
          {p.image_url && <img src={p.image_url} alt={p.name_ar} className="w-20 h-20 rounded-xl object-cover" />}
          <div className="flex-1 min-w-0">
            <div className="font-bold line-clamp-1">{p.name_ar}</div>
            {p.description_ar && <div className="text-xs text-muted-foreground line-clamp-2 mt-1">{p.description_ar}</div>}
            <div className="font-bold text-primary mt-1">{Number(p.base_price).toFixed(2)} ر.س</div>
          </div>
        </Link>
      ))}
    </div>
  );
}

function FeaturedLarge({ products }: { products: any[] }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {products.map((p) => (
        <Link key={p.id} to="/product/$productId" params={{ productId: p.id }} className="relative aspect-[16/9] rounded-2xl overflow-hidden group bg-muted">
          {p.image_url && <img src={p.image_url} alt={p.name_ar} className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition" />}
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-5 text-white">
            <div className="text-xl font-bold">{p.name_ar}</div>
            <div className="font-bold mt-1">{Number(p.base_price).toFixed(2)} ر.س</div>
          </div>
        </Link>
      ))}
    </div>
  );
}

function CategoriesGrid({ categories }: { categories: any[] }) {
  return (
    <div className="flex gap-4 overflow-x-auto pb-3 scrollbar-hide snap-x snap-mandatory -mx-4 px-4">
      {categories.map((c) => <CategoryPill key={c.id} category={c} />)}
    </div>
  );
}

export function SectionRenderer({
  section,
  products,
  banners,
  categories,
}: {
  section: HomeSection;
  products: any[];
  banners: HomeBanner[];
  categories: any[];
}) {
  const { section_type, display_style } = section;

  // Categories section
  if (section_type === "categories_section") {
    return (
      <section className="container mx-auto px-4">
        <SectionHeader s={section} />
        <CategoriesGrid categories={categories} />
      </section>
    );
  }

  // Banner sections
  if (section_type === "single_banner" || section_type === "hero_carousel" || section_type === "banner_grid") {
    const sectionBanners = banners.filter((b) => b.section_id === section.id);
    if (sectionBanners.length === 0) return null;
    if (section_type === "hero_carousel" || (section_type === "single_banner" && sectionBanners.length === 1)) {
      return (
        <section className="container mx-auto px-4">
          {section.title_ar && <SectionHeader s={section} />}
          <div className="grid grid-cols-1 gap-4">
            {sectionBanners.slice(0, section_type === "single_banner" ? 1 : 99).map((b) => <ResponsiveBanner key={b.id} b={b} />)}
          </div>
        </section>
      );
    }
    return (
      <section className="container mx-auto px-4">
        {section.title_ar && <SectionHeader s={section} />}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {sectionBanners.map((b) => <ResponsiveBanner key={b.id} b={b} />)}
        </div>
      </section>
    );
  }

  // Banner + products combo
  if (section_type === "banner_with_products") {
    const sectionBanners = banners.filter((b) => b.section_id === section.id);
    return (
      <section className="container mx-auto px-4">
        <SectionHeader s={section} />
        {sectionBanners[0] && <div className="mb-4"><ResponsiveBanner b={sectionBanners[0]} /></div>}
        {display_style === "carousel" ? <ProductsCarousel products={products} /> : <ProductsGrid products={products} />}
      </section>
    );
  }

  // Products sections
  if (products.length === 0) return null;
  return (
    <section className="container mx-auto px-4">
      <SectionHeader s={section} />
      {display_style === "carousel" && <ProductsCarousel products={products} />}
      {display_style === "vertical_list" && <ProductsVerticalList products={products} />}
      {display_style === "featured_large" && <FeaturedLarge products={products} />}
      {(display_style === "grid" || display_style === "compact") && (
        <ProductsGrid products={products} cols={products.length === 5 ? 5 : 4} />
      )}
    </section>
  );
}
