import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface Props {
  title?: string;
  description?: string;
  image?: string;
  canonical?: string;
}

/**
 * Injects SEO meta tags + active integration scripts (GA, Meta Pixel, TikTok, Snap, GTM)
 * into <head>. Reads from seo_settings (entity_type='site') and integrations table.
 */
export function StoreHead({ title, description, image, canonical }: Props) {
  const { data } = useQuery({
    queryKey: ["store-head"],
    queryFn: async () => {
      const [seo, integ, store] = await Promise.all([
        supabase.from("seo_settings").select("*").eq("entity_type", "site").maybeSingle(),
        supabase.from("integrations").select("*").eq("status", "published"),
        supabase.from("store_settings").select("name,logo_url").limit(1).maybeSingle(),
      ]);
      return { seo: seo.data, integrations: integ.data ?? [], store: store.data };
    },
    staleTime: 5 * 60_000,
  });

  useEffect(() => {
    if (!data) return;
    const seo = data.seo as any;
    const storeName = data.store?.name || "عصير تايم";

    const finalTitle = title || seo?.meta_title || storeName;
    const finalDesc = description || seo?.meta_description || "";
    const finalImage = image || seo?.og_image || seo?.default_og_image || data.store?.logo_url || "";
    const finalCanonical = canonical || seo?.canonical_url || (typeof window !== "undefined" ? window.location.href : "");

    document.title = finalTitle;

    const setMeta = (selector: string, attrs: Record<string, string>) => {
      let el = document.head.querySelector(selector) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement("meta");
        Object.entries(attrs).forEach(([k, v]) => el!.setAttribute(k, v));
        document.head.appendChild(el);
      } else {
        Object.entries(attrs).forEach(([k, v]) => el!.setAttribute(k, v));
      }
    };

    if (finalDesc) setMeta('meta[name="description"]', { name: "description", content: finalDesc });
    if (seo?.meta_keywords) setMeta('meta[name="keywords"]', { name: "keywords", content: seo.meta_keywords });

    const robots = `${seo?.robots_index === false ? "noindex" : "index"},${seo?.robots_follow === false ? "nofollow" : "follow"}`;
    setMeta('meta[name="robots"]', { name: "robots", content: robots });

    setMeta('meta[property="og:title"]', { property: "og:title", content: seo?.og_title || finalTitle });
    setMeta('meta[property="og:description"]', { property: "og:description", content: seo?.og_description || finalDesc });
    if (finalImage) setMeta('meta[property="og:image"]', { property: "og:image", content: finalImage });
    setMeta('meta[property="og:type"]', { property: "og:type", content: "website" });

    setMeta('meta[name="twitter:card"]', { name: "twitter:card", content: "summary_large_image" });
    setMeta('meta[name="twitter:title"]', { name: "twitter:title", content: seo?.twitter_title || finalTitle });
    setMeta('meta[name="twitter:description"]', { name: "twitter:description", content: seo?.twitter_description || finalDesc });
    if (seo?.twitter_image || finalImage) {
      setMeta('meta[name="twitter:image"]', { name: "twitter:image", content: seo?.twitter_image || seo?.default_twitter_image || finalImage });
    }

    if (seo?.google_verification) {
      setMeta('meta[name="google-site-verification"]', { name: "google-site-verification", content: seo.google_verification });
    }

    if (finalCanonical) {
      let link = document.head.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement("link");
        link.rel = "canonical";
        document.head.appendChild(link);
      }
      link.href = finalCanonical;
    }

    // Integrations (tracking pixels)
    const injected: HTMLElement[] = [];
    const inject = (id: string, src?: string, inline?: string) => {
      if (document.getElementById(id)) return;
      const s = document.createElement("script");
      s.id = id;
      s.async = true;
      if (src) s.src = src;
      if (inline) s.innerHTML = inline;
      document.head.appendChild(s);
      injected.push(s);
    };

    for (const it of data.integrations) {
      const cfg = (it.config ?? {}) as any;
      switch (it.provider) {
        case "google_analytics": {
          const id = cfg.measurement_id || cfg.tracking_id;
          if (id) {
            inject(`ga-src-${id}`, `https://www.googletagmanager.com/gtag/js?id=${id}`);
            inject(`ga-init-${id}`, undefined, `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${id}');`);
          }
          break;
        }
        case "google_tag_manager": {
          const id = cfg.container_id || cfg.gtm_id;
          if (id) inject(`gtm-${id}`, undefined, `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','${id}');`);
          break;
        }
        case "meta_pixel":
        case "facebook_pixel": {
          const id = cfg.pixel_id;
          if (id) inject(`fbq-${id}`, undefined, `!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','${id}');fbq('track','PageView');`);
          break;
        }
        case "tiktok_pixel": {
          const id = cfg.pixel_id;
          if (id) inject(`ttq-${id}`, undefined, `!function (w, d, t) {w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=document.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};ttq.load('${id}');ttq.page();}(window, document, 'ttq');`);
          break;
        }
        case "snap_pixel": {
          const id = cfg.pixel_id;
          if (id) inject(`snap-${id}`, undefined, `(function(e,t,n){if(e.snaptr)return;var a=e.snaptr=function(){a.handleRequest?a.handleRequest.apply(a,arguments):a.queue.push(arguments)};a.queue=[];var s='script';r=t.createElement(s);r.async=!0;r.src=n;var u=t.getElementsByTagName(s)[0];u.parentNode.insertBefore(r,u);})(window,document,'https://sc-static.net/scevent.min.js');snaptr('init','${id}');snaptr('track','PAGE_VIEW');`);
          break;
        }
      }
    }

    return () => {
      injected.forEach((el) => el.parentNode?.removeChild(el));
    };
  }, [data, title, description, image, canonical]);

  return null;
}
