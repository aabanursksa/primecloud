import { useState, useEffect, useRef } from "react";
import { useNavigate, Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Search, X } from "lucide-react";

export function LiveSearch({ inline = false }: { inline?: boolean }) {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [results, setResults] = useState<{ products: any[]; categories: any[]; pages: any[] }>({ products: [], categories: [], pages: [] });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (q.trim().length < 2) { setResults({ products: [], categories: [], pages: [] }); return; }
    setLoading(true);
    const t = setTimeout(async () => {
      const term = `%${q.trim()}%`;
      const [p, c, pg] = await Promise.all([
        supabase.from("products").select("id, name_ar, base_price, image_url, category_id").or(`name_ar.ilike.${term},name_en.ilike.${term},description_ar.ilike.${term}`).eq("show_in_store", true).eq("is_archived", false).limit(6),
        supabase.from("product_categories").select("id, name_ar, image_url").or(`name_ar.ilike.${term},name_en.ilike.${term}`).eq("is_active", true).eq("show_in_store", true).limit(4),
        supabase.from("pages").select("slug, title").ilike("title", term).eq("status", "published").limit(3),
      ]);
      setResults({ products: p.data || [], categories: c.data || [], pages: pg.data || [] });
      setLoading(false);
    }, 250);
    return () => clearTimeout(t);
  }, [q]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (q.trim()) { navigate({ to: "/menu", search: { q: q.trim() } as any }); setOpen(false); }
  };

  const empty = !loading && q.trim().length >= 2 && !results.products.length && !results.categories.length && !results.pages.length;

  return (
    <div ref={containerRef} className={`relative ${inline ? "w-full" : "flex-1 max-w-md"}`}>
      <form onSubmit={submit} className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          value={q}
          onChange={(e) => { setQ(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          placeholder="ابحث عن منتج..."
          className="w-full bg-muted rounded-xl pe-10 ps-9 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
        {q && <button type="button" onClick={() => { setQ(""); setResults({ products: [], categories: [], pages: [] }); }} className="absolute left-2 top-1/2 -translate-y-1/2 p-1"><X className="w-4 h-4" /></button>}
      </form>
      {open && q.trim().length >= 2 && (
        <div className="absolute top-full mt-2 inset-x-0 bg-card border border-border rounded-xl shadow-lg max-h-[70vh] overflow-y-auto z-50">
          {loading && <div className="p-4 text-sm text-center text-muted-foreground">جارٍ البحث...</div>}
          {empty && <div className="p-6 text-center text-sm text-muted-foreground">لا توجد نتائج مطابقة</div>}
          {results.categories.length > 0 && (
            <div className="p-2">
              <div className="text-[10px] font-bold text-muted-foreground px-2 mb-1">الأقسام</div>
              {results.categories.map((c) => (
                <Link key={c.id} to="/menu/$categoryId" params={{ categoryId: c.id }} onClick={() => setOpen(false)} className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted text-sm">
                  {c.image_url && <img src={c.image_url} alt="" className="w-8 h-8 rounded object-cover" />}
                  <span>{c.name_ar}</span>
                </Link>
              ))}
            </div>
          )}
          {results.products.length > 0 && (
            <div className="p-2 border-t border-border">
              <div className="text-[10px] font-bold text-muted-foreground px-2 mb-1">المنتجات</div>
              {results.products.map((p) => (
                <Link key={p.id} to="/product/$productId" params={{ productId: p.id }} onClick={() => setOpen(false)} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted">
                  {p.image_url ? <img src={p.image_url} alt="" className="w-10 h-10 rounded object-cover" /> : <div className="w-10 h-10 bg-muted rounded" />}
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{p.name_ar}</div>
                    <div className="text-xs text-primary">{Number(p.base_price).toFixed(2)} ر.س</div>
                  </div>
                </Link>
              ))}
            </div>
          )}
          {results.pages.length > 0 && (
            <div className="p-2 border-t border-border">
              <div className="text-[10px] font-bold text-muted-foreground px-2 mb-1">الصفحات</div>
              {results.pages.map((pg) => (
                <Link key={pg.slug} to="/pages/$slug" params={{ slug: pg.slug }} onClick={() => setOpen(false)} className="block p-2 rounded-lg hover:bg-muted text-sm">{pg.title}</Link>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
