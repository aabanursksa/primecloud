import { ReactNode, useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCart } from "@/lib/cart";
import { ShoppingCart, Search, Menu as MenuIcon, X, Phone, MapPin, Mail, Clock, ChevronDown, Home, UtensilsCrossed, User, Instagram, Facebook, Youtube, Linkedin, Send } from "lucide-react";

const TwitterX = (p: any) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
);
const TikTok = (p: any) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43V8.2a8.16 8.16 0 0 0 4.77 1.52V6.27a4.85 4.85 0 0 1-1.84-.42z"/></svg>
);
const Snapchat = (p: any) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M12.166.001c.84.029 4.345.213 6.001 4.001.605 1.397.453 3.776.331 5.687-.014.246-.029.484-.04.703l-.005.077c-.022.43-.046.873.011.998.117.014.345-.013.526-.078.337-.119.776-.273 1.225-.025.28.155.456.408.481.694a.93.93 0 0 1-.486.943c-.262.139-.526.23-.74.302-.121.041-.293.099-.354.139l-.006.005c-.029.034-.041.117.012.275.054.158.213.4.518.625.43.317 1.085.498 1.812.498.078 0 .145-.005.211-.011.067-.005.135-.012.207-.012.314 0 .486.155.486.402 0 .256-.213.428-.626.572-.317.111-.766.262-1.243.319-.117.013-.246.013-.402.013-.279 0-.527-.04-.74-.078-.082-.014-.156-.027-.225-.027-.275 0-.355.077-.486.213-.139.139-.295.301-.609.508-.578.376-1.402.582-2.31.582-.486 0-.973-.058-1.466-.174-.225-.054-.45-.116-.675-.179-.225-.063-.45-.124-.675-.179-.493-.116-.98-.174-1.466-.174-.908 0-1.733.206-2.31.582-.314.207-.47.369-.609.508-.131.136-.211.213-.486.213-.069 0-.143.013-.225.027-.213.038-.461.078-.74.078-.156 0-.285 0-.402-.013-.477-.057-.926-.208-1.243-.319-.413-.144-.626-.316-.626-.572 0-.247.172-.402.486-.402.072 0 .14.007.207.012.066.006.133.011.211.011.727 0 1.382-.181 1.812-.498.305-.225.464-.467.518-.625.053-.158.041-.241.012-.275l-.006-.005c-.061-.04-.233-.098-.354-.139-.214-.072-.478-.163-.74-.302a.93.93 0 0 1-.486-.943c.025-.286.201-.539.481-.694.449-.248.888-.094 1.225.025.181.065.409.092.526.078.057-.125.033-.568.011-.998l-.005-.077a44 44 0 0 1-.04-.703c-.122-1.911-.274-4.29.331-5.687C7.821.213 11.327.029 12.166.001z"/></svg>
);
const WhatsApp = (p: any) => (
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M.057 24l1.687-6.163a11.87 11.87 0 0 1-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.82 11.82 0 0 1 8.413 3.488 11.82 11.82 0 0 1 3.48 8.414c-.003 6.557-5.338 11.892-11.893 11.892a11.9 11.9 0 0 1-5.688-1.448zM6.597 20.13c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884a9.9 9.9 0 0 0 1.516 5.26l-.999 3.648zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.71.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
);
const SOCIAL_ICONS: Record<string, { Icon: any; label: string; color: string }> = {
  instagram: { Icon: Instagram, label: "Instagram", color: "hover:bg-[#E4405F] hover:text-white" },
  facebook: { Icon: Facebook, label: "Facebook", color: "hover:bg-[#1877F2] hover:text-white" },
  twitter: { Icon: TwitterX, label: "X", color: "hover:bg-black hover:text-white" },
  x: { Icon: TwitterX, label: "X", color: "hover:bg-black hover:text-white" },
  youtube: { Icon: Youtube, label: "YouTube", color: "hover:bg-[#FF0000] hover:text-white" },
  linkedin: { Icon: Linkedin, label: "LinkedIn", color: "hover:bg-[#0A66C2] hover:text-white" },
  tiktok: { Icon: TikTok, label: "TikTok", color: "hover:bg-black hover:text-white" },
  snapchat: { Icon: Snapchat, label: "Snapchat", color: "hover:bg-[#FFFC00] hover:text-black" },
  whatsapp: { Icon: WhatsApp, label: "WhatsApp", color: "hover:bg-[#25D366] hover:text-white" },
  telegram: { Icon: Send, label: "Telegram", color: "hover:bg-[#26A5E4] hover:text-white" },
};
import logo from "@/assets/aseertime_logo.svg";
import { StoreHead } from "./StoreHead";
import { BranchSelector } from "./BranchSelector";
import { MobileBottomNav } from "./MobileBottomNav";
import { LiveSearch } from "./LiveSearch";
import { useCartUI } from "./CartDrawer";
import { FloatingActions } from "./FloatingActions";

export function StoreLayout({ children }: { children: ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [branchOpen, setBranchOpen] = useState(false);
  const { itemCount, branchId } = useCart();
  const navigate = useNavigate();
  const [searchQ, setSearchQ] = useState("");

  const { data: store } = useQuery({
    queryKey: ["store_settings"],
    queryFn: async () => (await supabase.from("store_settings").select("*").limit(1).maybeSingle()).data,
    staleTime: 5 * 60_000,
    gcTime: 10 * 60_000,
  });
  const { data: footerData } = useQuery({
    queryKey: ["footer_settings"],
    queryFn: async () => (await supabase.from("footer_settings").select("*").maybeSingle()).data,
    staleTime: 5 * 60_000,
    gcTime: 10 * 60_000,
  });
  const { data: header } = useQuery({
    queryKey: ["store-header-v2"],
    queryFn: async () => {
      const [hdr, headerMenu, footerMenu, branches] = await Promise.all([
        supabase.from("header_settings").select("*").limit(1).maybeSingle(),
        supabase.from("navigation_menus").select("id, location, navigation_menu_items(id, title, link_value, link_type, sort_order, parent_id, status)").eq("location", "header").eq("status", "published").maybeSingle(),
        supabase.from("navigation_menus").select("id, navigation_menu_items(id, title, link_value, link_type, sort_order, parent_id, status)").eq("location", "footer").eq("status", "published").maybeSingle(),
        supabase.from("branches").select("id, name").eq("is_active", true).eq("accepts_orders", true),
      ]);
      const items = ((headerMenu.data as any)?.navigation_menu_items ?? [])
        .filter((i: any) => i.status === "published" && !i.parent_id)
        .sort((a: any, b: any) => a.sort_order - b.sort_order);
      const footerItems = ((footerMenu.data as any)?.navigation_menu_items ?? [])
        .filter((i: any) => i.status === "published" && !i.parent_id)
        .sort((a: any, b: any) => a.sort_order - b.sort_order);
      return {
        header: hdr.data,
        items,
        footerItems,
        branches: branches.data ?? [],
      };
    },
    staleTime: 5 * 60_000,
  });
  const merged = header ? { ...header, store, footer: footerData } : null;

  const selectedBranch = (merged?.branches ?? []).find((b: any) => b.id === branchId);

  useEffect(() => { setMobileOpen(false); }, []);

  const onSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQ.trim()) navigate({ to: "/menu", search: { q: searchQ.trim() } as any });
  };

  const linkHref = (item: any): string => {
    if (item.link_type === "url") return item.link_value || "#";
    if (item.link_type === "page") return `/pages/${item.link_value}`;
    if (item.link_type === "category") return `/menu/${item.link_value}`;
    if (item.link_type === "product") return `/product/${item.link_value}`;
    return "#";
  };

  return (
    <div className="min-h-screen flex flex-col bg-background" dir="rtl">
      <StoreHead />
      {/* Top bar */}
      <header className="sticky top-0 z-40 bg-card/95 backdrop-blur border-b border-border">
        <div className="container mx-auto px-3 sm:px-4 h-14 sm:h-16 flex items-center gap-2 sm:gap-4">
          <button onClick={() => setMobileOpen(true)} aria-label="القائمة" className="md:hidden p-2.5 -mr-2 rounded-lg hover:bg-muted">
            <MenuIcon className="w-6 h-6" />
          </button>

          <Link to="/" className="flex items-center gap-2 shrink-0">
            <img src={merged?.header?.logo_url || merged?.store?.logo_url || logo} alt="" className="w-9 h-9" />
            <span className="font-bold text-lg hidden sm:block">{merged?.store?.name || "عصير تايم"}</span>
          </Link>

          <nav className="hidden md:flex items-center gap-1 mr-4">
            <Link to="/menu" className="px-3 py-2 rounded-lg text-sm font-medium hover:bg-muted">المنيو</Link>
            <Link to="/branches" className="px-3 py-2 rounded-lg text-sm font-medium hover:bg-muted">الفروع</Link>
            <Link to="/offers" className="px-3 py-2 rounded-lg text-sm font-medium hover:bg-muted">العروض</Link>
            <Link to="/track-order" className="px-3 py-2 rounded-lg text-sm font-medium hover:bg-muted">تتبع طلبك</Link>
            <Link to="/contact" className="px-3 py-2 rounded-lg text-sm font-medium hover:bg-muted">تواصل معنا</Link>
            {merged?.items?.map((it: any) => (
              <a key={it.id} href={linkHref(it)} className="px-3 py-2 rounded-lg text-sm font-medium hover:bg-muted">
                {it.title}
              </a>
            ))}
          </nav>

          {merged?.header?.show_search !== false && (
            <div className="hidden lg:block flex-1 max-w-md">
              <LiveSearch />
            </div>
          )}

          <div className="flex items-center gap-1 sm:gap-2 ms-auto">
            {(merged?.header?.show_branch_selector !== false) && (merged?.branches?.length ?? 0) > 0 && (
              <button
                onClick={() => setBranchOpen(true)}
                className="flex items-center gap-1.5 bg-muted hover:bg-muted/70 px-2.5 sm:px-3 py-2 rounded-lg text-xs sm:text-sm font-medium max-w-[140px] sm:max-w-[180px] min-h-[40px]"
                title="اختر الفرع"
              >
                <MapPin className="w-4 h-4 text-primary shrink-0" />
                <span className="truncate">{selectedBranch?.name || "اختر الفرع"}</span>
                <ChevronDown className="w-3 h-3 opacity-60" />
              </button>
            )}
            {merged?.header?.contact_phone && (
              <a href={`tel:${merged!.header!.contact_phone}`} className="hidden md:flex items-center gap-1 text-sm text-muted-foreground hover:text-primary">
                <Phone className="w-4 h-4" />
                {merged!.header!.contact_phone}
              </a>
            )}
            {merged?.header?.show_cta && merged?.header?.cta_text && merged?.header?.cta_url && (
              <a href={merged!.header!.cta_url} className="hidden md:inline-flex bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-bold hover:bg-primary/90">
                {merged!.header!.cta_text}
              </a>
            )}
            <Link to="/account" aria-label="حسابي" className="hidden md:inline-flex p-2.5 rounded-lg hover:bg-muted" title="حسابي">
              <User className="w-5 h-5" />
            </Link>
            {merged?.header?.show_cart !== false && (
              <Link to="/cart" aria-label="السلة" className="relative p-2.5 rounded-lg hover:bg-muted">
                <ShoppingCart className="w-5 h-5 sm:w-5 sm:h-5" />
                {itemCount > 0 && (
                  <span className="absolute -top-0.5 -left-0.5 bg-primary text-primary-foreground text-[10px] rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1 font-bold">
                    {itemCount}
                  </span>
                )}
              </Link>
            )}
          </div>
        </div>
      </header>

      <BranchSelector open={branchOpen} onClose={() => setBranchOpen(false)} />

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobileOpen(false)} />
          <aside className="absolute right-0 top-0 bottom-0 w-72 bg-card p-4 overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <span className="font-bold">القائمة</span>
              <button onClick={() => setMobileOpen(false)}><X className="w-5 h-5" /></button>
            </div>
            <div className="mb-4"><LiveSearch inline /></div>
            <nav className="space-y-1">
              <Link to="/menu" onClick={() => setMobileOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-muted text-base font-medium">المنيو</Link>
              <Link to="/branches" onClick={() => setMobileOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-muted text-base font-medium">الفروع</Link>
              <Link to="/offers" onClick={() => setMobileOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-muted text-base font-medium">العروض</Link>
              <Link to="/track-order" onClick={() => setMobileOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-muted text-base font-medium">تتبع طلبك</Link>
              <Link to="/account" onClick={() => setMobileOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-muted text-base font-medium">حسابي</Link>
              <Link to="/contact" onClick={() => setMobileOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-muted text-base font-medium">تواصل معنا</Link>
              {merged?.items?.map((it: any) => (
                <a key={it.id} href={linkHref(it)} onClick={() => setMobileOpen(false)} className="block px-4 py-3 rounded-lg hover:bg-muted text-base font-medium">
                  {it.title}
                </a>
              ))}
            </nav>
          </aside>
        </div>
      )}

      <main className="flex-1 pb-20 md:pb-0">{children}</main>

      <FloatingActions />

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav />

      {/* Footer */}
      {merged?.footer && (
        <footer className="bg-card border-t border-border mt-12">
          <div className="container mx-auto px-4 py-10 grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              {(merged!.footer.logo_url || merged!.store?.logo_url) && (
                <img src={(merged!.footer.logo_url || merged!.store?.logo_url) ?? undefined} alt="" className="w-12 h-12 mb-3" />
              )}
              {merged!.footer.about_text && (
                <p className="text-sm text-muted-foreground">{merged!.footer.about_text}</p>
              )}
            </div>
            {merged!.footerItems.length > 0 && (
              <div>
                <h4 className="font-bold mb-3">روابط</h4>
                <ul className="space-y-2 text-sm">
                  {merged!.footerItems.map((it: any) => (
                    <li key={it.id}><a href={linkHref(it)} className="text-muted-foreground hover:text-primary">{it.title}</a></li>
                  ))}
                </ul>
              </div>
            )}
            <div>
              <h4 className="font-bold mb-3">تواصل</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                {merged!.footer.phone && <li className="flex items-center gap-2"><Phone className="w-4 h-4" />{merged!.footer.phone}</li>}
                {merged!.footer.email && <li className="flex items-center gap-2"><Mail className="w-4 h-4" />{merged!.footer.email}</li>}
                {merged!.footer.address && <li className="flex items-center gap-2"><MapPin className="w-4 h-4" />{merged!.footer.address}</li>}
                {merged!.footer.working_hours && <li className="flex items-center gap-2"><Clock className="w-4 h-4" />{merged!.footer.working_hours}</li>}
              </ul>
            </div>
            {(merged!.footer.social_links && Object.keys(merged!.footer.social_links).length > 0) && (
              <div>
                <h4 className="font-bold mb-3">تابعونا</h4>
                <div className="flex gap-2 flex-wrap">
                  {Object.entries(merged!.footer.social_links as Record<string, string>).filter(([, v]) => !!v).map(([k, v]) => {
                    const meta = SOCIAL_ICONS[k.toLowerCase()];
                    const Icon = meta?.Icon;
                    const colorCls = meta?.color || "hover:bg-primary hover:text-primary-foreground";
                    const label = meta?.label || k;
                    return (
                      <a
                        key={k}
                        href={v}
                        target="_blank"
                        rel="noreferrer"
                        aria-label={label}
                        title={label}
                        className={`w-10 h-10 flex items-center justify-center bg-muted rounded-full text-foreground transition ${colorCls}`}
                      >
                        {Icon ? <Icon className="w-5 h-5" /> : <span className="text-xs">{k.slice(0,2)}</span>}
                      </a>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
          {merged!.footer.copyright_text && (
            <div className="border-t border-border py-4 text-center text-xs text-muted-foreground">
              {merged!.footer.copyright_text}
            </div>
          )}
        </footer>
      )}
    </div>
  );
}
