import { ReactNode } from "react";
import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { StoreLayout } from "@/components/store/StoreLayout";
import { useCustomerAuth } from "@/lib/customer-auth";
import { User, MapPin, Package, Search, LogOut } from "lucide-react";
import { toast } from "sonner";
import { useEffect, useState } from "react";

const TABS = [
  { to: "/account", label: "نظرة عامة", icon: User, exact: true },
  { to: "/account/orders", label: "طلباتي", icon: Package },
  { to: "/account/addresses", label: "عناويني", icon: MapPin },
  { to: "/account/profile", label: "بياناتي", icon: User },
  { to: "/track-order", label: "تتبع طلب", icon: Search },
];

export function AccountLayout({ children }: { children: ReactNode }) {
  const { customer, isLoggedIn, logout, checkPhone, requestOtp, verifyOtp } = useCustomerAuth();
  const loc = useLocation();
  const navigate = useNavigate();
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [needsName, setNeedsName] = useState(false);
  const [existingName, setExistingName] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [resendIn, setResendIn] = useState(0);

  // Resend countdown
  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setInterval(() => setResendIn((v) => Math.max(0, v - 1)), 1000);
    return () => clearInterval(t);
  }, [resendIn]);

  const handleSendOtp = async () => {
    setBusy(true);
    try {
      const ph = phone.trim();
      if (ph.length < 9) throw new Error("أدخل رقم جوال صحيح");
      const check = await checkPhone(ph);
      if (check.banned) throw new Error("هذا الحساب موقوف");
      setNeedsName(!check.exists);
      setExistingName(check.name ?? null);
      const { devCode } = await requestOtp(ph);
      toast.success(`تم إرسال الكود — (تجريبي: ${devCode})`, { duration: 8000 });
      setStep("otp");
      setResendIn(30);
    } catch (err: any) {
      toast.error(err?.message || "خطأ");
    } finally { setBusy(false); }
  };

  const handleVerify = async () => {
    setBusy(true);
    try {
      await verifyOtp(phone.trim(), code.trim(), needsName ? name : undefined);
      toast.success("تم الدخول");
      navigate({ to: "/account" });
    } catch (err: any) {
      toast.error(err?.message || "خطأ");
    } finally { setBusy(false); }
  };

  if (!isLoggedIn || !customer) {
    return (
      <StoreLayout>
        <div className="container mx-auto px-4 py-10 max-w-md">
          <div className="bg-card border border-border rounded-2xl p-6">
            <h1 className="text-2xl font-bold mb-2">{step === "phone" ? "تسجيل الدخول" : "تأكيد رقم الجوال"}</h1>
            <p className="text-sm text-muted-foreground mb-6">
              {step === "phone"
                ? "أدخل رقم جوالك وسنرسل لك كود التحقق برسالة نصية."
                : `أدخل الكود المرسل إلى ${phone}`}
            </p>

            {step === "phone" ? (
              <form onSubmit={(e) => { e.preventDefault(); handleSendOtp(); }} className="space-y-3">
                <input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/[^\d+]/g, ""))}
                  placeholder="رقم الجوال *"
                  required
                  dir="ltr"
                  inputMode="tel"
                  autoComplete="tel"
                  className="w-full bg-muted rounded-xl px-4 py-3.5 text-base focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <button disabled={busy} className="w-full bg-primary text-primary-foreground py-3.5 rounded-xl font-bold text-base disabled:opacity-50 min-h-[48px]">
                  {busy ? "..." : "إرسال الكود"}
                </button>
              </form>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); handleVerify(); }} className="space-y-3">
                <input
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 4))}
                  placeholder="كود التحقق (4 أرقام)"
                  required
                  dir="ltr"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  className="w-full bg-muted rounded-xl px-4 py-3.5 text-base text-center tracking-[0.4em] focus:outline-none focus:ring-2 focus:ring-primary"
                />
                {needsName && (
                  <div>
                    <input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="الاسم *"
                      required
                      autoComplete="name"
                      className="w-full bg-muted rounded-xl px-4 py-3.5 text-base focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <p className="text-xs text-muted-foreground mt-1">ليس لديك حساب — سننشئ لك حساباً جديداً.</p>
                  </div>
                )}
                {!needsName && existingName && (
                  <p className="text-xs text-muted-foreground">مرحباً بعودتك، {existingName} 👋</p>
                )}
                <button disabled={busy || code.length < 4 || (needsName && name.trim().length < 2)} className="w-full bg-primary text-primary-foreground py-3.5 rounded-xl font-bold text-base disabled:opacity-50 min-h-[48px]">
                  {busy ? "..." : "تأكيد ودخول"}
                </button>
                <div className="flex items-center justify-between text-xs">
                  <button type="button" onClick={() => { setStep("phone"); setCode(""); }} className="text-muted-foreground hover:text-foreground">
                    تغيير الرقم
                  </button>
                  <button
                    type="button"
                    disabled={resendIn > 0 || busy}
                    onClick={handleSendOtp}
                    className="text-primary disabled:text-muted-foreground"
                  >
                    {resendIn > 0 ? `إعادة الإرسال خلال ${resendIn}ث` : "إعادة إرسال الكود"}
                  </button>
                </div>
              </form>
            )}

            <div className="text-center mt-4 text-xs text-muted-foreground">
              يمكنك أيضاً <Link to="/menu" className="text-primary">الطلب كزائر</Link>
            </div>
          </div>
        </div>
      </StoreLayout>
    );
  }

  return (
    <StoreLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="bg-gradient-to-l from-primary to-primary/70 text-primary-foreground rounded-2xl p-5 mb-4 flex items-center justify-between flex-wrap gap-3">
          <div>
            <div className="text-xs opacity-80">مرحباً</div>
            <div className="text-xl font-bold">{customer.name || customer.phone}</div>
            <div className="text-xs opacity-80 mt-0.5" dir="ltr">{customer.phone}</div>
          </div>
          <button onClick={() => { logout(); toast.success("تم تسجيل الخروج"); navigate({ to: "/" }); }}
            className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-1">
            <LogOut className="w-4 h-4" />خروج
          </button>
        </div>

        <div className="grid lg:grid-cols-[220px_1fr] gap-4">
          <nav className="lg:sticky lg:top-20 self-start bg-card border border-border rounded-2xl p-2 flex lg:flex-col overflow-x-auto gap-1 -mx-1 px-1 lg:mx-0 lg:px-2">
            {TABS.map((t) => {
              const active = t.exact ? loc.pathname === t.to : loc.pathname.startsWith(t.to);
              return (
                <Link key={t.to} to={t.to as any}
                  className={`flex items-center gap-2 px-3 py-3 rounded-lg text-sm whitespace-nowrap min-h-[44px] ${active ? "bg-primary/10 text-primary font-bold" : "hover:bg-muted"}`}>
                  <t.icon className="w-4 h-4" />{t.label}
                </Link>
              );
            })}
          </nav>
          <div>{children}</div>
        </div>
      </div>
    </StoreLayout>
  );
}
