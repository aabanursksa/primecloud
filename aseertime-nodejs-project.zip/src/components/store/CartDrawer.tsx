import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { useCart } from "@/lib/cart";
import { Link } from "@tanstack/react-router";
import { X, Plus, Minus, Trash2, ShoppingCart } from "lucide-react";

type CartUIContextType = {
  openCart: () => void;
  closeCart: () => void;
  isOpen: boolean;
};

const CartUIContext = createContext<CartUIContextType | null>(null);

export function CartUIProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const { items, subtotal, updateQty, removeItem, itemCount } = useCart();

  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);

  return (
    <CartUIContext.Provider value={{ openCart: () => setIsOpen(true), closeCart: () => setIsOpen(false), isOpen }}>
      {children}
      {isOpen && (
        <div className="fixed inset-0 z-[60]" dir="rtl">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-full sm:w-[420px] bg-card flex flex-col shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h2 className="font-bold text-lg flex items-center gap-2"><ShoppingCart className="w-5 h-5 text-primary" />السلة ({itemCount})</h2>
              <button onClick={() => setIsOpen(false)} aria-label="إغلاق" className="p-2 rounded-lg hover:bg-muted"><X className="w-5 h-5" /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {items.length === 0 ? (
                <div className="text-center py-16 text-muted-foreground">
                  <ShoppingCart className="w-16 h-16 mx-auto opacity-30 mb-3" />
                  <p>سلتك فارغة</p>
                </div>
              ) : items.map((it) => (
                <div key={it.id} className="flex gap-3 bg-muted/50 rounded-xl p-3">
                  {it.product_image && <img src={it.product_image} alt="" className="w-16 h-16 rounded-lg object-cover" />}
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-sm truncate">{it.product_name}</div>
                    {it.variant_name && <div className="text-xs text-muted-foreground">{it.variant_name}</div>}
                    {it.addons.length > 0 && <div className="text-[11px] text-muted-foreground truncate">+ {it.addons.map(a => a.addon_name).join("، ")}</div>}
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-1 bg-card border border-border rounded-lg">
                        <button onClick={() => it.quantity > 1 ? updateQty(it.id, it.quantity - 1) : removeItem(it.id)} className="p-1.5"><Minus className="w-3 h-3" /></button>
                        <span className="px-2 text-sm font-bold">{it.quantity}</span>
                        <button onClick={() => updateQty(it.id, it.quantity + 1)} className="p-1.5"><Plus className="w-3 h-3" /></button>
                      </div>
                      <div className="font-bold text-primary text-sm">{((Number(it.unit_price) + it.addons.reduce((a, x) => a + Number(x.price || 0), 0)) * it.quantity).toFixed(2)} ر.س</div>
                    </div>
                  </div>
                  <button onClick={() => removeItem(it.id)} aria-label="حذف" className="text-destructive p-1 self-start"><Trash2 className="w-4 h-4" /></button>
                </div>
              ))}
            </div>
            {items.length > 0 && (
              <div className="p-4 border-t border-border space-y-2">
                <div className="flex justify-between font-bold">
                  <span>الإجمالي</span>
                  <span className="text-primary">{subtotal.toFixed(2)} ر.س</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Link to="/cart" onClick={() => setIsOpen(false)} className="text-center bg-muted py-3 rounded-xl font-bold text-sm">عرض السلة</Link>
                  <Link to="/checkout" onClick={() => setIsOpen(false)} className="text-center bg-primary text-primary-foreground py-3 rounded-xl font-bold text-sm">إتمام الطلب</Link>
                </div>
              </div>
            )}
          </aside>
        </div>
      )}
    </CartUIContext.Provider>
  );
}

export function useCartUI() {
  const ctx = useContext(CartUIContext);
  if (!ctx) throw new Error("useCartUI must be used within CartUIProvider");
  return ctx;
}
