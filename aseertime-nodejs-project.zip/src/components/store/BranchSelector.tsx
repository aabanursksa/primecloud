import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCart } from "@/lib/cart";
import { MapPin, Phone, Clock, X, Check } from "lucide-react";

type Props = {
  open: boolean;
  onClose: () => void;
  onSelected?: (branchId: string) => void;
  required?: boolean;
};

export function BranchSelector({ open, onClose, onSelected, required }: Props) {
  const { branchId, setBranchId } = useCart();

  const { data: branches, isLoading } = useQuery({
    queryKey: ["active-branches"],
    queryFn: async () => {
      const { data } = await supabase
        .from("branches")
        .select("*")
        .eq("is_active", true)
        .eq("accepts_orders", true)
        .order("display_order");
      return data ?? [];
    },
    enabled: open,
  });

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape" && !required) onClose(); };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose, required]);

  if (!open) return null;

  const select = (id: string) => {
    setBranchId(id);
    onSelected?.(id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center" dir="rtl">
      <div className="absolute inset-0 bg-black/60" onClick={() => !required && onClose()} />
      <div className="relative bg-card w-full sm:max-w-lg sm:rounded-2xl rounded-t-3xl max-h-[85vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-card border-b border-border p-4 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-lg">اختر الفرع</h3>
            {required && <p className="text-xs text-muted-foreground mt-0.5">يجب اختيار فرع لإكمال طلبك</p>}
          </div>
          {!required && (
            <button onClick={onClose} className="p-2 hover:bg-muted rounded-lg">
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="p-4 space-y-3">
          {isLoading ? (
            <div className="text-center text-muted-foreground py-8">جارٍ التحميل...</div>
          ) : (branches ?? []).length === 0 ? (
            <div className="text-center py-10">
              <MapPin className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="font-bold">لا توجد فروع تستقبل الطلبات حالياً</p>
              <p className="text-sm text-muted-foreground mt-1">يرجى المحاولة لاحقاً</p>
            </div>
          ) : (
            (branches ?? []).map((b: any) => {
              const selected = branchId === b.id;
              return (
                <button
                  key={b.id}
                  onClick={() => select(b.id)}
                  className={`w-full text-right p-4 rounded-2xl border-2 transition ${selected ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${selected ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary"}`}>
                      {selected ? <Check className="w-5 h-5" /> : <MapPin className="w-5 h-5" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold">{b.name}</div>
                      {b.address && <div className="text-xs text-muted-foreground mt-1 flex items-start gap-1"><MapPin className="w-3 h-3 mt-0.5 shrink-0" />{b.address}</div>}
                      {b.phone && <div className="text-xs text-muted-foreground mt-1 flex items-center gap-1"><Phone className="w-3 h-3" />{b.phone}</div>}
                      <div className="flex flex-wrap gap-2 mt-2">
                        <span className="text-[10px] bg-success/10 text-success px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Clock className="w-3 h-3" /> يستقبل الطلبات
                        </span>
                        {b.delivery_fee != null && Number(b.delivery_fee) > 0 && (
                          <span className="text-[10px] bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
                            توصيل: {Number(b.delivery_fee).toFixed(2)} ر.س
                          </span>
                        )}
                        {b.min_order_amount != null && Number(b.min_order_amount) > 0 && (
                          <span className="text-[10px] bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
                            حد أدنى: {Number(b.min_order_amount).toFixed(2)} ر.س
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
