import { Link } from "@tanstack/react-router";

export function CategoryPill({ category }: { category: any }) {
  return (
    <Link
      to="/menu/$categoryId"
      params={{ categoryId: category.id }}
      className="shrink-0 snap-start flex flex-col items-center gap-2 group"
    >
      <div className="w-28 h-28 sm:w-32 sm:h-32 md:w-40 md:h-40 lg:w-48 lg:h-48 rounded-3xl bg-card border border-border overflow-hidden group-hover:border-primary group-hover:shadow-lg transition flex items-center justify-center">
        {category.image_url ? (
          <img src={category.image_url} alt={category.name_ar} className="w-full h-full object-cover" />
        ) : (
          <span className="text-4xl">{category.icon || "🥤"}</span>
        )}
      </div>
      <span className="text-sm md:text-base font-medium max-w-[120px] md:max-w-[160px] text-center line-clamp-1">{category.name_ar}</span>
    </Link>
  );
}
