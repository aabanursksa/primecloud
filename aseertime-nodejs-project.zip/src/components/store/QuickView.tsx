import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCart } from "@/lib/cart";
import { useCartUI } from "./CartDrawer";
import { X, Plus, Minus } from "lucide-react";
import { toast } from "sonner";
import { Link } from "@tanstack/react-router";

type QuickViewContextType = { open: (productId: string) => void };
const Ctx = createContext<QuickViewContextType | null>(null);

export function QuickViewProvider({ children }: { children: ReactNode }) {
  const [productId, setProductId] = useState<string | null>(null);
  return (
    <Ctx.Provider value={{ open: setProductId }}>
      {children}
      {productId && <QuickViewSheet productId={productId} onClose={() => setProductId(null)} />}
    </Ctx.Provider>
  );
}

export function useQuickView() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useQuickView outside provider");
  return c;
}

function QuickViewSheet({ productId, onClose }: { productId: string; onClose: () => void }) {
  const { addItem } = useCart();
  const { openCart } = useCartUI();
  const [variantId, setVariantId] = useState<string | null>(null);
  const [selectedAddons, setSelectedAddons] = useState<Record<string, boolean>>({});
  const [qty, setQty] = useState(1);
  const [notes, setNotes] = useState("");

  useEffect(() => { document.body.style.overflow = "hidden"; return () => { document.body.style.overflow = ""; }; }, []);

  const { data, isLoading } = useQuery({
    queryKey: ["qv-product", productId],
    queryFn: async () => {
      const [p, v, gl] = await Promise.all([
        supabase.from("products").select("*").eq("id", productId).maybeSingle(),
        supabase.from("product_variants").select("*").eq("product_id", productId).eq("is_available", true).order("display_order"),
        supabase.from("addon_group_links").select("group_id").eq("product_id", productId),
      ]);
      const groupIds = (gl.data || []).map((x: any) => x.group_id);
      let groups: any[] = [], addons: any[] = [];
      if (groupIds.length) {
        const [g, a] = await Promise.all([
          supabase.from("addon_groups").select("*").in("id", groupIds).order("display_order"),
          supabase.from("product_addons").select("*").in("group_id", groupIds).eq("is_available", true).order("display_order"),
        ]);
        groups = g.data || []; addons = a.data || [];
      }
      return { product: p.data, variants: v.data || [], groups, addons };
    },
  });

  useEffect(() => {
    if (data?.variants?.length && !variantId) setVariantId(data.variants[0].id);
  }, [data, variantId]);

  if (isLoading || !data?.product) {
    return (
      <div className="fixed inset-0 z-[70] bg-black/50 flex items-end sm:items-center justify-center" onClick={onClose}>
        <div className="bg-card rounded-t-3xl sm:rounded-3xl p-8 w-full sm:w-[500px]">جارٍ التحميل...</div>
      </div>
    );
  }

  const p = data.product;
  const selectedVariant = data.variants.find((v: any) => v.id === variantId);
  const unitPrice = selectedVariant?.price ?? p.base_price;
  const chosenAddons = data.addons.filter((a: any) => selectedAddons[a.id]);
  const addonsTotal = chosenAddons.reduce((s: number, a: any) => s + Number(a.price || 0), 0);
  const totalPrice = (Number(unitPrice) + addonsTotal) * qty;

  const validate = (): string | null => {
    for (const g of data.groups) {
      const sel = data.addons.filter((a: any) => a.group_id === g.id && selectedAddons[a.id]);
      if (g.is_required && sel.length < (g.min_select || 1)) return `اختر ${g.min_select || 1} على الأقل من «${g.name_ar}»`;
      if (g.max_select && sel.length > g.max_select) return `الحد الأقصى ${g.max_select} من «${g.name_ar}»`;
    }
    return null;
  };

  const onAdd = () => {
    const err = validate();
    if (err) { toast.error(err); return; }
    if (!p.is_available) { toast.error("المنتج غير متوفر"); return; }
    addItem({
      product_id: p.id,
      product_name: p.name_ar,
      product_image: p.image_url,
      variant_id: selectedVariant?.id ?? null,
      variant_name: selectedVariant?.name_ar ?? null,
      unit_price: Number(unitPrice),
      quantity: qty,
      addons: chosenAddons.map((a: any) => ({ addon_id: a.id, addon_name: a.name_ar, price: Number(a.price) })),
      notes: notes || undefined,
    });
    toast.success("أُضيف إلى السلة");
    onClose();
    openCart();
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center" dir="rtl">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative bg-card w-full sm:max-w-2xl max-h-[92vh] rounded-t-3xl sm:rounded-3xl overflow-hidden flex flex-col">
        <button onClick={onClose} className="absolute top-3 left-3 z-10 bg-card/90 backdrop-blur p-2 rounded-full shadow"><X className="w-5 h-5" /></button>
        <div className="overflow-y-auto">
          {p.image_url && <img src={p.image_url} alt={p.name_ar} className="w-full aspect-[4/3] sm:aspect-[16/9] object-cover" />}
          <div className="p-5 space-y-4">
            <div>
              <h2 className="text-xl font-bold">{p.name_ar}</h2>
              {p.description_ar && <p className="text-sm text-muted-foreground mt-1">{p.description_ar}</p>}
            </div>
            <div className="flex items-center gap-3 text-sm">
              <span className="text-primary font-bold text-lg">{Number(unitPrice).toFixed(2)} ر.س</span>
              {p.calories != null && <span className="text-muted-foreground">• {p.calories} سعرة</span>}
              {p.prep_time_minutes && <span className="text-muted-foreground">• {p.prep_time_minutes} دقيقة</span>}
            </div>

            {data.variants.length > 0 && (
              <div>
                <div className="font-bold text-sm mb-2">الحجم</div>
                <div className="flex flex-wrap gap-2">
                  {data.variants.map((v: any) => (
                    <button key={v.id} onClick={() => setVariantId(v.id)} className={`px-4 py-2 rounded-xl text-sm border ${variantId === v.id ? "bg-primary text-primary-foreground border-primary" : "bg-muted border-border"}`}>
                      {v.name_ar} <span className="opacity-70">({Number(v.price).toFixed(0)} ر.س)</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {data.groups.map((g: any) => {
              const groupAddons = data.addons.filter((a: any) => a.group_id === g.id);
              if (!groupAddons.length) return null;
              const single = (g.max_select || 0) === 1;
              return (
                <div key={g.id}>
                  <div className="font-bold text-sm mb-2 flex items-center gap-2">
                    {g.name_ar}
                    {g.is_required && <span className="text-xs text-destructive">*</span>}
                  </div>
                  <div className="space-y-1.5">
                    {groupAddons.map((a: any) => (
                      <label key={a.id} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted cursor-pointer">
                        <input
                          type={single ? "radio" : "checkbox"}
                          name={`g-${g.id}`}
                          checked={!!selectedAddons[a.id]}
                          onChange={(e) => {
                            setSelectedAddons((prev) => {
                              const next = { ...prev };
                              if (single) groupAddons.forEach((x: any) => delete next[x.id]);
                              if (e.target.checked) next[a.id] = true; else delete next[a.id];
                              return next;
                            });
                          }}
                        />
                        <span className="flex-1 text-sm">{a.name_ar}</span>
                        {Number(a.price) > 0 && <span className="text-sm text-muted-foreground">+{Number(a.price).toFixed(2)} ر.س</span>}
                      </label>
                    ))}
                  </div>
                </div>
              );
            })}

            <div>
              <div className="font-bold text-sm mb-2">ملاحظات</div>
              <textarea value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={300} className="w-full bg-muted rounded-lg px-3 py-2 text-sm" placeholder="أي طلب خاص؟" />
            </div>
          </div>
        </div>

        <div className="border-t border-border p-4 bg-card flex items-center gap-3">
          <div className="flex items-center gap-1 bg-muted rounded-xl">
            <button onClick={() => setQty(Math.max(1, qty - 1))} className="p-2"><Minus className="w-4 h-4" /></button>
            <span className="px-3 font-bold">{qty}</span>
            <button onClick={() => setQty(qty + 1)} className="p-2"><Plus className="w-4 h-4" /></button>
          </div>
          <button onClick={onAdd} disabled={!p.is_available} className="flex-1 bg-primary text-primary-foreground font-bold py-3 rounded-xl disabled:opacity-50">
            {p.is_available ? `إضافة • ${totalPrice.toFixed(2)} ر.س` : "غير متوفر"}
          </button>
          <Link to="/product/$productId" params={{ productId: p.id }} onClick={onClose} className="text-sm text-primary underline whitespace-nowrap">التفاصيل</Link>
        </div>
      </div>
    </div>
  );
}
