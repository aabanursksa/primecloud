import { Link } from "@tanstack/react-router";
import { Plus, Flame, ImageOff, Sparkles } from "lucide-react";
import { useQuickView } from "./QuickView";

type Props = {
  product: any;
  unavailableInBranch?: boolean;
  /** Minimum price across product variants — when present, shown as "يبدأ من" */
  minVariantPrice?: number | null;
  /** Number of variants — when > 1, price is rendered as "starts from" */
  variantCount?: number;
};

export function ProductCard({ product, unavailableInBranch, minVariantPrice, variantCount = 0 }: Props) {
  const isUnavailable = unavailableInBranch || !product.is_available;
  const { open } = useQuickView();

  const basePrice = Number(product.base_price ?? 0);
  const discountPrice = product.discount_price != null ? Number(product.discount_price) : null;
  const hasDiscount = discountPrice != null && discountPrice > 0 && discountPrice < basePrice;

  // Determine display price
  const startsFrom = variantCount > 1 && minVariantPrice != null;
  const shownPrice = startsFrom ? Number(minVariantPrice) : (hasDiscount ? discountPrice! : basePrice);

  // "New" if created within last 14 days
  const isNew = (() => {
    if (!product.created_at) return false;
    const days = (Date.now() - new Date(product.created_at).getTime()) / 86400000;
    return days <= 14;
  })();

  return (
    <div className="group bg-card border border-border rounded-2xl overflow-hidden hover:shadow-lg hover:border-primary/30 transition flex flex-col relative h-full">
      <Link to="/product/$productId" params={{ productId: product.id }} className="block">
        <div className="aspect-square bg-muted relative overflow-hidden">
          {product.image_url ? (
            <img
              src={product.image_url}
              alt={product.name_ar}
              loading="lazy"
              className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 ${isUnavailable ? "grayscale opacity-60" : ""}`}
              onError={(e) => {
                const t = e.currentTarget;
                t.style.display = "none";
                const ph = t.parentElement?.querySelector("[data-img-fallback]") as HTMLElement | null;
                if (ph) ph.style.display = "flex";
              }}
            />
          ) : null}
          <div
            data-img-fallback
            style={{ display: product.image_url ? "none" : "flex" }}
            className="absolute inset-0 flex-col items-center justify-center gap-2 bg-gradient-to-br from-muted via-muted/60 to-muted text-muted-foreground"
          >
            <ImageOff className="w-8 h-8 opacity-50" />
            <span className="text-[11px] font-medium">لا توجد صورة</span>
          </div>

          {/* Badges */}
          <div className="absolute top-2 right-2 flex flex-col gap-1 items-end">
            {unavailableInBranch ? (
              <span className="bg-destructive text-destructive-foreground text-[10px] px-2 py-1 rounded-full font-medium shadow">غير متوفر في هذا الفرع</span>
            ) : !product.is_available ? (
              <span className="bg-destructive text-destructive-foreground text-[10px] px-2 py-1 rounded-full font-medium shadow">غير متوفر</span>
            ) : (
              <>
                {hasDiscount && (
                  <span className="bg-destructive text-destructive-foreground text-[10px] px-2 py-1 rounded-full font-bold shadow">
                    -{Math.round(((basePrice - discountPrice!) / basePrice) * 100)}%
                  </span>
                )}
                {product.is_featured && (
                  <span className="bg-primary text-primary-foreground text-[10px] px-2 py-1 rounded-full flex items-center gap-1 font-medium shadow">
                    <Flame className="w-3 h-3" /> مميز
                  </span>
                )}
                {isNew && !product.is_featured && (
                  <span className="bg-success text-success-foreground text-[10px] px-2 py-1 rounded-full flex items-center gap-1 font-medium shadow">
                    <Sparkles className="w-3 h-3" /> جديد
                  </span>
                )}
              </>
            )}
          </div>
        </div>
      </Link>

      <div className="p-3 sm:p-3.5 flex-1 flex flex-col">
        <Link to="/product/$productId" params={{ productId: product.id }} className="font-bold text-sm sm:text-[15px] leading-snug line-clamp-2 hover:text-primary min-h-[2.6em]">
          {product.name_ar}
        </Link>
        {product.description_ar && (
          <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{product.description_ar}</p>
        )}
        {product.calories != null && (
          <div className="text-[10px] text-muted-foreground mt-1">{product.calories} سعرة</div>
        )}

        <div className="flex items-end justify-between mt-auto pt-2.5 gap-2">
          <div className="flex flex-col min-w-0">
            {startsFrom && <span className="text-[9px] text-muted-foreground leading-none">يبدأ من</span>}
            <div className="flex items-baseline gap-1.5">
              <span className="font-bold text-primary text-base sm:text-[15px]">{shownPrice.toFixed(2)}</span>
              <span className="text-[10px] text-muted-foreground">ر.س</span>
            </div>
            {hasDiscount && !startsFrom && (
              <span className="text-[10px] text-muted-foreground line-through">{basePrice.toFixed(2)} ر.س</span>
            )}
          </div>
          <button
            onClick={(e) => { e.preventDefault(); if (!isUnavailable) open(product.id); }}
            disabled={isUnavailable}
            aria-label={isUnavailable ? "غير متوفر" : "إضافة سريعة"}
            className="shrink-0 w-10 h-10 rounded-full bg-gradient-primary text-primary-foreground flex items-center justify-center hover:scale-110 active:scale-95 transition-transform shadow-md disabled:opacity-40 disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
