import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ProductCard } from "@/components/store/ProductCard";
import { ChevronDown, MapPin, Phone, Clock, Tag, Copy, Check, Sparkles, Star } from "lucide-react";
import { toast } from "sonner";

type Block = {
  id: string;
  block_type: string;
  is_active: boolean;
  sort_order: number;
  settings: any;
};

export function BlocksRenderer({ blocks }: { blocks: Block[] }) {
  const list = (blocks || []).filter((b) => b.is_active).sort((a, b) => a.sort_order - b.sort_order);
  return (
    <>
      {list.map((b) => (
        <BlockSwitch key={b.id} block={b} />
      ))}
    </>
  );
}

function BlockSwitch({ block }: { block: Block }) {
  const s = block.settings || {};
  switch (block.block_type) {
    case "hero": return <HeroBlock s={s} />;
    case "text": return <TextBlock s={s} />;
    case "image_text": return <ImageTextBlock s={s} />;
    case "cards": return <CardsBlock s={s} />;
    case "vision_mission": return <VisionMissionBlock s={s} />;
    case "why_us": return <WhyUsBlock s={s} />;
    case "stats": return <StatsBlock s={s} />;
    case "features": return <CardsBlock s={{ ...s, _variant: "features" }} />;
    case "services": return <CardsBlock s={{ ...s, _variant: "services" }} />;
    case "faq": return <FAQBlock s={s} />;
    case "gallery": return <GalleryBlock s={s} />;
    case "testimonials": return <TestimonialsBlock s={s} />;
    case "cta": return <CTABlock s={s} />;
    case "branches": return <BranchesBlock s={s} />;
    case "products": return <ProductsBlock s={s} />;
    case "offers": return <OffersBlock s={s} />;
    case "contact": return <ContactBlock s={s} />;
    case "map": return <MapBlock s={s} />;
    case "video": return <VideoBlock s={s} />;
    case "divider": return <div style={{ height: s.height || 40 }} aria-hidden />;
    case "spacer": return <div style={{ height: s.height || 40 }} aria-hidden />;
    default: return null;
  }
}

function Section({ children, bg, py = 12 }: any) {
  return (
    <section style={{ background: bg }} className="w-full">
      <div className="container mx-auto px-4" style={{ paddingTop: py * 4, paddingBottom: py * 4 }}>
        {children}
      </div>
    </section>
  );
}

function SectionHeader({ title, subtitle, align = "center", color }: any) {
  if (!title && !subtitle) return null;
  return (
    <div className="mb-8" style={{ textAlign: align, color }}>
      {title && <h2 className="text-2xl md:text-4xl font-extrabold">{title}</h2>}
      {subtitle && <p className="mt-2 text-base md:text-lg opacity-80">{subtitle}</p>}
    </div>
  );
}

/* -------------------- BLOCKS -------------------- */

function HeroBlock({ s }: any) {
  if (!s.title && !s.image_url) return null;
  return (
    <section className="relative">
      <div className="container mx-auto px-4 pt-4">
        <div className="relative overflow-hidden rounded-2xl md:rounded-3xl bg-gradient-primary text-primary-foreground aspect-[16/9] sm:aspect-[21/9] md:aspect-auto md:min-h-[360px]">
          {s.image_url && (
            <img src={s.image_url} alt={s.title || ""} className="absolute inset-0 w-full h-full object-contain md:object-cover" />
          )}
          <div className="hidden md:block absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-black/10" />
          <div className="hidden md:flex relative z-10 h-full w-full p-6 md:p-12 items-center">
            <div className="max-w-xl">
              {s.title && <h1 className="text-3xl md:text-5xl font-bold drop-shadow" style={{ color: s.text_color || "#fff" }}>{s.title}</h1>}
              {s.subtitle && <p className="mt-3 md:mt-4 text-base md:text-lg opacity-95" style={{ color: s.text_color || "#fff" }}>{s.subtitle}</p>}
              {s.cta_text && s.cta_url && (
                <a href={s.cta_url} className="inline-flex mt-5 bg-white text-primary font-bold px-6 py-3 rounded-xl">{s.cta_text}</a>
              )}
            </div>
          </div>
        </div>
        {(s.title || s.subtitle) && (
          <div className="md:hidden mt-3 text-center">
            {s.title && <h1 className="text-xl font-bold">{s.title}</h1>}
            {s.subtitle && <p className="text-sm text-muted-foreground mt-1">{s.subtitle}</p>}
            {s.cta_text && s.cta_url && (
              <a href={s.cta_url} className="inline-flex mt-3 bg-primary text-primary-foreground font-bold px-5 py-2.5 rounded-xl text-sm">{s.cta_text}</a>
            )}
          </div>
        )}
      </div>
    </section>
  );
}

function TextBlock({ s }: any) {
  if (!s.content && !s.title) return null;
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title} subtitle={s.subtitle} align={s.align} color={s.text_color} />
      {s.content && (
        <div className="max-w-3xl mx-auto leading-relaxed text-base md:text-lg whitespace-pre-wrap" style={{ textAlign: s.align || "right", color: s.text_color }}>
          {s.content}
        </div>
      )}
    </Section>
  );
}

function ImageTextBlock({ s }: any) {
  if (!s.title && !s.content && !s.image_url) return null;
  const reverse = s.image_position === "left";
  return (
    <Section bg={s.bg}>
      <div className={`grid md:grid-cols-2 gap-6 md:gap-12 items-center ${reverse ? "md:[direction:ltr]" : ""}`}>
        {s.image_url && (
          <img src={s.image_url} alt={s.title || ""} className="w-full rounded-2xl shadow-md" loading="lazy" />
        )}
        <div style={{ color: s.text_color }}>
          {s.title && <h2 className="text-2xl md:text-3xl font-bold mb-3">{s.title}</h2>}
          {s.content && <p className="text-base md:text-lg leading-relaxed whitespace-pre-wrap opacity-90">{s.content}</p>}
          {s.cta_text && s.cta_url && (
            <a href={s.cta_url} className="inline-flex mt-4 bg-primary text-primary-foreground font-bold px-5 py-2.5 rounded-xl">{s.cta_text}</a>
          )}
        </div>
      </div>
    </Section>
  );
}

function CardsBlock({ s }: any) {
  const items = (s.items || []).filter((i: any) => i?.title || i?.icon || i?.image_url);
  if (!items.length) return null;
  const cols = s.columns || 3;
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title} subtitle={s.subtitle} align={s.align} color={s.text_color} />
      <div className={`grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6`} style={{ ['--cols' as any]: cols }}>
        <style>{`@media (min-width:1024px){.cards-grid-${block_id_safe(s)}{grid-template-columns:repeat(${cols},minmax(0,1fr))}}`}</style>
        <div className={`contents lg:hidden`} />
      </div>
      <div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-${Math.min(cols,4)} gap-4 md:gap-6 mt-2`}>
        {items.map((it: any, i: number) => (
          <div key={i} className="bg-card border border-border rounded-2xl p-5 hover:shadow-md transition group" style={{ background: s.card_bg }}>
            {it.image_url ? (
              <img src={it.image_url} alt={it.title || ""} className="w-14 h-14 mb-3 rounded-xl object-cover" loading="lazy" />
            ) : it.icon ? (
              <div className="w-12 h-12 mb-3 rounded-xl bg-primary/10 text-primary flex items-center justify-center text-2xl">{it.icon}</div>
            ) : null}
            {it.title && <h3 className="font-bold text-lg mb-1" style={{ color: s.text_color }}>{it.title}</h3>}
            {it.description && <p className="text-sm text-muted-foreground leading-relaxed">{it.description}</p>}
            {it.cta_text && it.cta_url && (
              <a href={it.cta_url} className="inline-flex mt-3 text-sm font-bold text-primary">{it.cta_text} ←</a>
            )}
          </div>
        ))}
      </div>
    </Section>
  );
}

function block_id_safe(s: any) { return (s?._key || "x").toString().replace(/[^a-z0-9]/gi, ""); }

function VisionMissionBlock({ s }: any) {
  const items = (s.items || []).filter((i: any) => i?.title || i?.description);
  if (!items.length) return null;
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title} subtitle={s.subtitle} align="center" color={s.text_color} />
      <div className={`grid grid-cols-1 ${items.length >= 3 ? "md:grid-cols-3" : "md:grid-cols-2"} gap-6`}>
        {items.map((it: any, i: number) => (
          <div key={i} className="text-center bg-card border border-border rounded-2xl p-6 md:p-8 hover:shadow-lg transition">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-primary text-primary-foreground flex items-center justify-center text-3xl">
              {it.icon || "✨"}
            </div>
            <h3 className="font-bold text-xl mb-2">{it.title}</h3>
            <p className="text-muted-foreground leading-relaxed">{it.description}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}

function WhyUsBlock({ s }: any) {
  const items = (s.items || []).filter((i: any) => i?.title);
  if (!items.length) return null;
  return (
    <Section bg={s.bg || "linear-gradient(135deg, hsl(var(--muted)) 0%, transparent 100%)"}>
      <SectionHeader title={s.title || "لماذا نحن؟"} subtitle={s.subtitle} />
      <div className={`grid grid-cols-1 sm:grid-cols-2 ${items.length >= 3 ? "lg:grid-cols-3" : ""} gap-6`}>
        {items.map((it: any, i: number) => (
          <div key={i} className="flex gap-4 items-start bg-card rounded-2xl p-5 border border-border">
            <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center text-2xl shrink-0">{it.icon || "✓"}</div>
            <div>
              <h3 className="font-bold text-lg mb-1">{it.title}</h3>
              {it.description && <p className="text-sm text-muted-foreground">{it.description}</p>}
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}

function StatsBlock({ s }: any) {
  const items = (s.items || []).filter((i: any) => i?.label);
  const { data: dyn } = useQuery({
    queryKey: ["stats-dyn", items.map((i: any) => i.source).join(",")],
    queryFn: async () => {
      const res: Record<string, number> = {};
      const sources: string[] = Array.from(new Set(items.map((i: any) => i.source as string).filter(Boolean)));
      for (const src of sources) {
        let table = "", filter: any = null;
        if (src === "products") table = "products";
        else if (src === "branches") { table = "branches"; filter = { is_active: true }; }
        else if (src === "orders") table = "orders";
        else if (src === "customers") table = "customers";
        else if (src === "drivers") table = "drivers";
        else if (src === "coupons") { table = "coupons"; filter = { status: "active" }; }
        if (!table) continue;
        let q = supabase.from(table as any).select("*", { count: "exact", head: true });
        if (filter) for (const k of Object.keys(filter)) q = q.eq(k, filter[k]);
        const { count } = await q;
        res[src] = count || 0;
      }
      return res;
    },
    enabled: items.some((i: any) => i?.source),
  });
  if (!items.length) return null;
  return (
    <Section bg={s.bg || "var(--gradient-primary, hsl(var(--primary)))"}>
      <SectionHeader title={s.title} subtitle={s.subtitle} color={s.text_color || "#fff"} />
      <div className={`grid grid-cols-2 md:grid-cols-${Math.min(items.length, 4)} gap-4 md:gap-8 text-center`}>
        {items.map((it: any, i: number) => {
          const value = it.source ? (dyn?.[it.source] ?? 0) : Number(it.value ?? 0);
          return (
            <div key={i} className="p-4 md:p-6 rounded-2xl bg-white/10 backdrop-blur" style={{ color: s.text_color || "#fff" }}>
              {it.icon && <div className="text-3xl mb-2">{it.icon}</div>}
              <CountUp to={value} className="text-3xl md:text-5xl font-extrabold" suffix={it.suffix} />
              <div className="text-sm md:text-base opacity-90 mt-1">{it.label}</div>
            </div>
          );
        })}
      </div>
    </Section>
  );
}

function CountUp({ to, suffix, className }: { to: number; suffix?: string; className?: string }) {
  const [v, setV] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    let started = false;
    const obs = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !started) {
        started = true;
        const start = Date.now();
        const dur = 1200;
        const step = () => {
          const p = Math.min(1, (Date.now() - start) / dur);
          setV(Math.round(to * (1 - Math.pow(1 - p, 3))));
          if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      }
    });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [to]);
  return <span ref={ref} className={className}>{v.toLocaleString("ar-EG")}{suffix || ""}</span>;
}

function FAQBlock({ s }: any) {
  const { data: dbFaqs } = useQuery({
    queryKey: ["faqs", s.from_db],
    queryFn: async () => {
      const { data } = await supabase.from("faqs").select("*").eq("status", "published").eq("show_in_faq", true).order("sort_order");
      return data || [];
    },
    enabled: !!s.from_db,
  });
  const items = s.from_db ? (dbFaqs || []).map((f: any) => ({ q: f.question, a: f.answer })) : (s.items || []);
  const list = items.filter((i: any) => i?.q && i?.a);
  if (!list.length) return null;
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title || "الأسئلة الشائعة"} subtitle={s.subtitle} />
      <div className="max-w-3xl mx-auto space-y-3">
        {list.map((it: any, i: number) => (
          <details key={i} className="group bg-card border border-border rounded-xl">
            <summary className="cursor-pointer list-none flex items-center justify-between p-4 font-bold">
              <span>{it.q}</span>
              <ChevronDown className="w-4 h-4 transition group-open:rotate-180" />
            </summary>
            <div className="px-4 pb-4 text-muted-foreground leading-relaxed whitespace-pre-wrap">{it.a}</div>
          </details>
        ))}
      </div>
    </Section>
  );
}

function GalleryBlock({ s }: any) {
  const images = (s.images || []).filter((i: any) => i?.url);
  const [lb, setLb] = useState<string | null>(null);
  if (!images.length) return null;
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title} subtitle={s.subtitle} />
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
        {images.map((img: any, i: number) => (
          <button key={i} onClick={() => setLb(img.url)} className="relative aspect-square overflow-hidden rounded-xl group">
            <img src={img.url} alt={img.alt || ""} loading="lazy" className="w-full h-full object-cover transition group-hover:scale-105" />
            {img.caption && <div className="absolute bottom-0 inset-x-0 bg-black/60 text-white text-xs p-2 text-center">{img.caption}</div>}
          </button>
        ))}
      </div>
      {lb && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4" onClick={() => setLb(null)}>
          <img src={lb} alt="" className="max-w-full max-h-full rounded-lg" />
        </div>
      )}
    </Section>
  );
}

function TestimonialsBlock({ s }: any) {
  const items = (s.items || []).filter((i: any) => i?.text);
  if (!items.length) return null;
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title || "آراء عملائنا"} subtitle={s.subtitle} />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {items.map((it: any, i: number) => (
          <div key={i} className="bg-card border border-border rounded-2xl p-5">
            <div className="flex items-center gap-1 mb-3 text-amber-500">
              {Array.from({ length: it.rating || 5 }).map((_, n) => <Star key={n} className="w-4 h-4 fill-current" />)}
            </div>
            <p className="text-muted-foreground leading-relaxed mb-4">"{it.text}"</p>
            <div className="flex items-center gap-3">
              {it.avatar && <img src={it.avatar} alt="" className="w-10 h-10 rounded-full object-cover" />}
              <div>
                <div className="font-bold">{it.name}</div>
                {it.role && <div className="text-xs text-muted-foreground">{it.role}</div>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}

function CTABlock({ s }: any) {
  if (!s.title && !s.cta_text) return null;
  return (
    <Section bg={s.bg || "var(--gradient-primary)"} py={16}>
      <div className="text-center max-w-2xl mx-auto" style={{ color: s.text_color || "#fff" }}>
        {s.title && <h2 className="text-3xl md:text-5xl font-extrabold mb-3">{s.title}</h2>}
        {s.subtitle && <p className="text-lg opacity-95 mb-6">{s.subtitle}</p>}
        {s.cta_text && s.cta_url && (
          <a href={s.cta_url} target={s.cta_url.startsWith("http") ? "_blank" : undefined} className="inline-flex bg-white text-primary font-bold px-8 py-3.5 rounded-xl text-lg hover:scale-105 transition">{s.cta_text}</a>
        )}
      </div>
    </Section>
  );
}

function BranchesBlock({ s }: any) {
  const { data } = useQuery({
    queryKey: ["block-branches"],
    queryFn: async () => (await supabase.from("branches").select("*").eq("is_active", true).order("display_order")).data || [],
  });
  if (!data?.length) return null;
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title || "فروعنا"} subtitle={s.subtitle} />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {data.map((b: any) => (
          <div key={b.id} className="bg-card border border-border rounded-2xl p-5 hover:shadow-md transition">
            <h3 className="font-bold text-lg mb-2 flex items-center gap-2"><MapPin className="w-4 h-4 text-primary" />{b.name}</h3>
            {b.address && <p className="text-sm text-muted-foreground mb-2">{b.address}</p>}
            <div className="space-y-1 text-sm">
              {b.phone && <a href={`tel:${b.phone}`} className="flex items-center gap-2 hover:text-primary"><Phone className="w-3.5 h-3.5" />{b.phone}</a>}
              {b.delivery_fee != null && <div className="text-muted-foreground">رسوم التوصيل: {b.delivery_fee} ر.س</div>}
              <div className={`inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full ${b.accepts_orders ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                {b.accepts_orders ? "يستقبل الطلبات" : "متوقف مؤقتاً"}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}

function ProductsBlock({ s }: any) {
  const { data } = useQuery({
    queryKey: ["block-products", s.source, s.category_id, s.product_ids?.join(","), s.limit],
    queryFn: async () => {
      let q = supabase.from("products").select("*").eq("show_in_store", true).eq("is_archived", false).eq("is_available", true);
      if (s.source === "category" && s.category_id) q = q.eq("category_id", s.category_id);
      else if (s.source === "featured") q = q.eq("is_featured", true);
      else if (s.source === "manual" && s.product_ids?.length) q = q.in("id", s.product_ids);
      q = q.order(s.source === "latest" ? "created_at" : "display_order", { ascending: s.source !== "latest" }).limit(s.limit || 8);
      return (await q).data || [];
    },
  });
  if (!data?.length) return null;
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title || "منتجات مختارة"} subtitle={s.subtitle} />
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">
        {data.map((p: any) => <ProductCard key={p.id} product={p} />)}
      </div>
    </Section>
  );
}

function OffersBlock({ s }: any) {
  const { data } = useQuery({
    queryKey: ["block-offers"],
    queryFn: async () => {
      const { data } = await supabase.from("coupons").select("id, code, name, discount_type, discount_value, end_date, minimum_order").eq("status", "active");
      return (data || []).filter((c: any) => !c.end_date || new Date(c.end_date) > new Date());
    },
  });
  const [copied, setCopied] = useState<string | null>(null);
  if (!data?.length) return null;
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title || "العروض الحالية"} subtitle={s.subtitle} />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {data.map((c: any) => (
          <div key={c.id} className="relative bg-gradient-primary text-primary-foreground rounded-2xl p-5 overflow-hidden">
            <Tag className="absolute top-3 left-3 opacity-20 w-16 h-16" />
            <div className="font-bold text-lg mb-1">{c.name}</div>
            <div className="text-sm opacity-90 mb-3">
              {c.discount_type === "percent" ? `خصم ${c.discount_value}%` : c.discount_type === "fixed" ? `خصم ${c.discount_value} ر.س` : "توصيل مجاني"}
              {c.minimum_order > 0 && ` — الحد الأدنى ${c.minimum_order} ر.س`}
            </div>
            <button
              onClick={() => { navigator.clipboard.writeText(c.code); setCopied(c.id); toast.success("تم نسخ الكود"); setTimeout(() => setCopied(null), 2000); }}
              className="bg-white text-primary font-bold px-4 py-2 rounded-lg flex items-center gap-2 text-sm"
            >
              {copied === c.id ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />} {c.code}
            </button>
            {c.end_date && <div className="text-xs mt-2 opacity-80">ينتهي: {new Date(c.end_date).toLocaleDateString("ar")}</div>}
          </div>
        ))}
      </div>
    </Section>
  );
}

function ContactBlock({ s }: any) {
  const { data: settings } = useQuery({
    queryKey: ["store_settings"],
    queryFn: async () => (await supabase.from("store_settings").select("*").limit(1).maybeSingle()).data,
    staleTime: 5 * 60_000,
    gcTime: 10 * 60_000,
  });
  const [form, setForm] = useState({ name: "", phone: "", email: "", message: "" });
  const [loading, setLoading] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.name.length < 2 || form.phone.length < 6 || form.message.length < 2) { toast.error("املأ البيانات المطلوبة"); return; }
    setLoading(true);
    const { error } = await supabase.from("contact_messages").insert(form);
    setLoading(false);
    if (error) { toast.error("تعذر الإرسال، حاول لاحقاً"); return; }
    toast.success("تم استلام رسالتك، سنعاود التواصل قريباً");
    setForm({ name: "", phone: "", email: "", message: "" });
  };
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title || "تواصل معنا"} subtitle={s.subtitle} />
      <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        <div className="space-y-3">
          {settings?.phone && <a href={`tel:${settings.phone}`} className="flex items-center gap-3 p-4 bg-card border border-border rounded-xl"><Phone className="w-5 h-5 text-primary" />{settings.phone}</a>}
          {settings?.email && <a href={`mailto:${settings.email}`} className="flex items-center gap-3 p-4 bg-card border border-border rounded-xl"><span>📧</span>{settings.email}</a>}
          {settings?.address && <div className="flex items-center gap-3 p-4 bg-card border border-border rounded-xl"><MapPin className="w-5 h-5 text-primary" />{settings.address}</div>}
          {s.whatsapp && <a href={`https://wa.me/${s.whatsapp}`} target="_blank" rel="noreferrer" className="flex items-center gap-3 p-4 bg-green-500 text-white rounded-xl">💬 WhatsApp</a>}
        </div>
        <form onSubmit={submit} className="bg-card border border-border rounded-2xl p-5 space-y-3">
          <input className="w-full bg-muted rounded-lg px-4 py-2.5" placeholder="الاسم *" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} maxLength={100} required />
          <input className="w-full bg-muted rounded-lg px-4 py-2.5" placeholder="الجوال *" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} maxLength={20} required />
          <input className="w-full bg-muted rounded-lg px-4 py-2.5" type="email" placeholder="البريد (اختياري)" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} maxLength={255} />
          <textarea className="w-full bg-muted rounded-lg px-4 py-2.5 min-h-[120px]" placeholder="رسالتك *" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} maxLength={2000} required />
          <button disabled={loading} className="w-full bg-primary text-primary-foreground font-bold py-3 rounded-xl disabled:opacity-50">{loading ? "جارٍ الإرسال..." : "إرسال"}</button>
        </form>
      </div>
    </Section>
  );
}

function MapBlock({ s }: any) {
  if (!s.embed_url && !s.lat) return null;
  const src = s.embed_url || `https://www.google.com/maps?q=${s.lat},${s.lng}&z=15&output=embed`;
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title} subtitle={s.subtitle} />
      <div className="rounded-2xl overflow-hidden border border-border" style={{ height: s.height || 420 }}>
        <iframe src={src} className="w-full h-full" loading="lazy" />
      </div>
    </Section>
  );
}

function VideoBlock({ s }: any) {
  if (!s.url) return null;
  const ytId = (s.url.match(/(?:youtu\.be\/|v=)([\w-]+)/) || [])[1];
  return (
    <Section bg={s.bg}>
      <SectionHeader title={s.title} subtitle={s.subtitle} />
      <div className="aspect-video max-w-4xl mx-auto rounded-2xl overflow-hidden bg-black">
        {ytId ? (
          <iframe src={`https://www.youtube.com/embed/${ytId}`} className="w-full h-full" allowFullScreen />
        ) : (
          <video src={s.url} controls className="w-full h-full" />
        )}
      </div>
    </Section>
  );
}
