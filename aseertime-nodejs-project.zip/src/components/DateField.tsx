import * as React from "react";
import { format, parse, isValid } from "date-fns";
import { enGB } from "date-fns/locale";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

interface DateFieldProps {
  value?: string | null; // ISO yyyy-MM-dd
  onChange: (v: string | null) => void;
  placeholder?: string;
  className?: string;
}

export function DateField({ value, onChange, placeholder = "DD/MM/YYYY", className }: DateFieldProps) {
  const date = React.useMemo(() => {
    if (!value) return undefined;
    const d = parse(value, "yyyy-MM-dd", new Date());
    return isValid(d) ? d : undefined;
  }, [value]);

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          dir="ltr"
          className={cn(
            "w-full justify-between font-normal h-9",
            !date && "text-muted-foreground",
            className,
          )}
        >
          <span>{date ? format(date, "dd/MM/yyyy", { locale: enGB }) : placeholder}</span>
          <CalendarIcon className="h-4 w-4 opacity-60" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start" dir="ltr">
        <Calendar
          mode="single"
          selected={date}
          onSelect={(d) => onChange(d ? format(d, "yyyy-MM-dd") : null)}
          locale={enGB}
          initialFocus
          className={cn("p-3 pointer-events-auto")}
        />
      </PopoverContent>
    </Popover>
  );
}
