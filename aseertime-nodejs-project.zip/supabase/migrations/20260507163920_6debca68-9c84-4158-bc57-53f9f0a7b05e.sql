-- 1) extra address fields
ALTER TABLE public.customer_addresses
  ADD COLUMN IF NOT EXISTS floor text,
  ADD COLUMN IF NOT EXISTS apartment text,
  ADD COLUMN IF NOT EXISTS driver_notes text;

-- 2) updated trigger function: include customer name in new-order notification
CREATE OR REPLACE FUNCTION public.log_order_status_change()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_cname text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    SELECT name INTO v_cname FROM public.customers WHERE id = NEW.customer_id;
    INSERT INTO public.order_status_logs (order_id, old_status, new_status, changed_by)
    VALUES (NEW.id, NULL, NEW.status, auth.uid());
    INSERT INTO public.notifications (title, message, type, action_url)
    VALUES (
      'طلب جديد',
      'طلب رقم ' || NEW.order_number || COALESCE(' من ' || v_cname, ''),
      'order_new',
      '/dashboard/orders/' || NEW.id
    );
  ELSIF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.order_status_logs (order_id, old_status, new_status, changed_by)
    VALUES (NEW.id, OLD.status, NEW.status, auth.uid());
    IF NEW.status = 'cancelled' THEN
      INSERT INTO public.notifications (title, message, type, action_url)
      VALUES ('طلب ملغي', 'تم إلغاء الطلب ' || NEW.order_number, 'order_cancelled', '/dashboard/orders/' || NEW.id);
    END IF;
  END IF;
  RETURN NEW;
END $function$;

-- ensure trigger exists (idempotent)
DROP TRIGGER IF EXISTS trg_orders_status_change ON public.orders;
CREATE TRIGGER trg_orders_status_change
  AFTER INSERT OR UPDATE OF status ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.log_order_status_change();

-- 3) public RPC to check if a phone belongs to a banned customer (so storefront can early-block)
CREATE OR REPLACE FUNCTION public.is_customer_banned(_phone text)
 RETURNS boolean
 LANGUAGE sql
 STABLE
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT COALESCE((SELECT status = 'banned' FROM public.customers WHERE phone = _phone LIMIT 1), false);
$function$;