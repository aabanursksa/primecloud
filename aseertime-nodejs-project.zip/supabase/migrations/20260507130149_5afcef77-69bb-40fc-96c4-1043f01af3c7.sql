ALTER TABLE public.products ADD COLUMN IF NOT EXISTS gallery_urls text[] NOT NULL DEFAULT '{}';

-- Public read on store-assets bucket + manager write
DO $$ BEGIN
  CREATE POLICY "public read store-assets" ON storage.objects FOR SELECT USING (bucket_id = 'store-assets');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE POLICY "managers upload store-assets" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'store-assets' AND public.is_manager(auth.uid()));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE POLICY "managers update store-assets" ON storage.objects FOR UPDATE USING (bucket_id = 'store-assets' AND public.is_manager(auth.uid()));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE POLICY "managers delete store-assets" ON storage.objects FOR DELETE USING (bucket_id = 'store-assets' AND public.is_manager(auth.uid()));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;