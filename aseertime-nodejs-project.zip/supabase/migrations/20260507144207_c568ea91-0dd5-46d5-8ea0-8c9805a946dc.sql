
-- Public read access for storefront tables
CREATE POLICY "public read store products" ON public.products FOR SELECT USING (show_in_store = true AND is_archived = false);
CREATE POLICY "public read store categories" ON public.product_categories FOR SELECT USING (show_in_store = true AND is_active = true);
CREATE POLICY "public read variants" ON public.product_variants FOR SELECT USING (true);
CREATE POLICY "public read addon_groups" ON public.addon_groups FOR SELECT USING (true);
CREATE POLICY "public read product_addons" ON public.product_addons FOR SELECT USING (is_available = true);
CREATE POLICY "public read addon_group_links" ON public.addon_group_links FOR SELECT USING (true);
CREATE POLICY "public read product_branches" ON public.product_branches FOR SELECT USING (true);
CREATE POLICY "public read active branches" ON public.branches FOR SELECT USING (is_active = true);
CREATE POLICY "public read delivery_zones" ON public.delivery_zones FOR SELECT USING (status = 'active');
CREATE POLICY "public read active coupons" ON public.coupons FOR SELECT USING (status = 'active');
CREATE POLICY "public read store_settings" ON public.store_settings FOR SELECT USING (true);

-- RPC to place a public order (storefront, no auth)
CREATE OR REPLACE FUNCTION public.place_storefront_order(payload jsonb)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_customer_id uuid;
  v_order_id uuid;
  v_order_number text;
  v_address_id uuid := NULL;
  v_item jsonb;
  v_oi_id uuid;
  v_addon jsonb;
  v_coupon_id uuid := NULL;
  v_phone text := payload->'customer'->>'phone';
  v_name text := payload->'customer'->>'name';
  v_email text := payload->'customer'->>'email';
BEGIN
  IF v_phone IS NULL OR length(v_phone) < 6 THEN
    RAISE EXCEPTION 'phone_required';
  END IF;
  IF v_name IS NULL OR length(v_name) < 2 THEN
    RAISE EXCEPTION 'name_required';
  END IF;

  -- find or create customer
  SELECT id INTO v_customer_id FROM public.customers WHERE phone = v_phone LIMIT 1;
  IF v_customer_id IS NULL THEN
    INSERT INTO public.customers (name, phone, email)
    VALUES (v_name, v_phone, v_email)
    RETURNING id INTO v_customer_id;
  END IF;

  -- address (optional)
  IF (payload->'address') IS NOT NULL AND payload->>'order_type' = 'delivery' THEN
    INSERT INTO public.customer_addresses (customer_id, title, city, district, street, building, landmark, latitude, longitude)
    VALUES (
      v_customer_id,
      COALESCE(payload->'address'->>'title','عنوان التوصيل'),
      payload->'address'->>'city',
      payload->'address'->>'district',
      payload->'address'->>'street',
      payload->'address'->>'building',
      payload->'address'->>'landmark',
      NULLIF(payload->'address'->>'latitude','')::numeric,
      NULLIF(payload->'address'->>'longitude','')::numeric
    )
    RETURNING id INTO v_address_id;
  END IF;

  -- coupon
  IF (payload->>'coupon_code') IS NOT NULL AND length(payload->>'coupon_code') > 0 THEN
    SELECT id INTO v_coupon_id FROM public.coupons WHERE code = payload->>'coupon_code' AND status = 'active' LIMIT 1;
  END IF;

  INSERT INTO public.orders (
    customer_id, branch_id, order_type, payment_method, status,
    subtotal, vat_amount, delivery_fee, discount_amount, total_amount,
    customer_notes, delivery_address_id, coupon_id
  )
  VALUES (
    v_customer_id,
    NULLIF(payload->>'branch_id','')::uuid,
    COALESCE((payload->>'order_type')::order_type, 'delivery'),
    COALESCE((payload->>'payment_method')::payment_method, 'cash'),
    'new',
    COALESCE((payload->>'subtotal')::numeric, 0),
    COALESCE((payload->>'vat_amount')::numeric, 0),
    COALESCE((payload->>'delivery_fee')::numeric, 0),
    COALESCE((payload->>'discount_amount')::numeric, 0),
    COALESCE((payload->>'total_amount')::numeric, 0),
    payload->>'customer_notes',
    v_address_id,
    v_coupon_id
  )
  RETURNING id, order_number INTO v_order_id, v_order_number;

  -- items
  FOR v_item IN SELECT * FROM jsonb_array_elements(payload->'items') LOOP
    INSERT INTO public.order_items (order_id, product_id, variant_id, product_name, variant_name, quantity, unit_price, total_price, notes)
    VALUES (
      v_order_id,
      NULLIF(v_item->>'product_id','')::uuid,
      NULLIF(v_item->>'variant_id','')::uuid,
      v_item->>'product_name',
      v_item->>'variant_name',
      COALESCE((v_item->>'quantity')::int, 1),
      COALESCE((v_item->>'unit_price')::numeric, 0),
      COALESCE((v_item->>'total_price')::numeric, 0),
      v_item->>'notes'
    )
    RETURNING id INTO v_oi_id;

    IF (v_item->'addons') IS NOT NULL THEN
      FOR v_addon IN SELECT * FROM jsonb_array_elements(v_item->'addons') LOOP
        INSERT INTO public.order_item_addons (order_item_id, addon_id, addon_name, price)
        VALUES (
          v_oi_id,
          NULLIF(v_addon->>'addon_id','')::uuid,
          v_addon->>'addon_name',
          COALESCE((v_addon->>'price')::numeric, 0)
        );
      END LOOP;
    END IF;
  END LOOP;

  -- coupon usage
  IF v_coupon_id IS NOT NULL THEN
    INSERT INTO public.coupon_usages (coupon_id, customer_id, order_id, discount_amount)
    VALUES (v_coupon_id, v_customer_id, v_order_id, COALESCE((payload->>'discount_amount')::numeric, 0));
    UPDATE public.coupons SET used_count = used_count + 1 WHERE id = v_coupon_id;
  END IF;

  RETURN jsonb_build_object('order_id', v_order_id, 'order_number', v_order_number);
END;
$$;

GRANT EXECUTE ON FUNCTION public.place_storefront_order(jsonb) TO anon, authenticated;

-- RPC for tracking order publicly by order_number + phone
CREATE OR REPLACE FUNCTION public.track_order(_order_number text, _phone text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_order RECORD;
  v_items jsonb;
  v_logs jsonb;
  v_branch jsonb;
BEGIN
  SELECT o.* INTO v_order
  FROM public.orders o
  JOIN public.customers c ON c.id = o.customer_id
  WHERE o.order_number = _order_number AND c.phone = _phone
  LIMIT 1;

  IF v_order IS NULL THEN RETURN NULL; END IF;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'product_name', oi.product_name,
    'variant_name', oi.variant_name,
    'quantity', oi.quantity,
    'total_price', oi.total_price
  )), '[]'::jsonb) INTO v_items FROM public.order_items oi WHERE oi.order_id = v_order.id;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'old_status', osl.old_status,
    'new_status', osl.new_status,
    'created_at', osl.created_at
  ) ORDER BY osl.created_at), '[]'::jsonb) INTO v_logs FROM public.order_status_logs osl WHERE osl.order_id = v_order.id;

  SELECT to_jsonb(b) INTO v_branch FROM public.branches b WHERE b.id = v_order.branch_id;

  RETURN jsonb_build_object(
    'order_number', v_order.order_number,
    'status', v_order.status,
    'order_type', v_order.order_type,
    'total_amount', v_order.total_amount,
    'created_at', v_order.created_at,
    'items', v_items,
    'logs', v_logs,
    'branch', v_branch
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.track_order(text, text) TO anon, authenticated;
