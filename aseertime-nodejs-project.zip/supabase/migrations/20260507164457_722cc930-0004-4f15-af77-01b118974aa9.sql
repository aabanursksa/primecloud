
-- Add snapshot columns to orders
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS customer_name text,
  ADD COLUMN IF NOT EXISTS customer_phone text,
  ADD COLUMN IF NOT EXISTS customer_email text,
  ADD COLUMN IF NOT EXISTS branch_name text,
  ADD COLUMN IF NOT EXISTS coupon_code text,
  ADD COLUMN IF NOT EXISTS delivery_address_snapshot jsonb,
  ADD COLUMN IF NOT EXISTS estimated_preparation_time integer,
  ADD COLUMN IF NOT EXISTS estimated_delivery_time integer;

ALTER TABLE public.order_items
  ADD COLUMN IF NOT EXISTS product_image text;

-- Hardened place_storefront_order: recompute prices from DB, validate availability
CREATE OR REPLACE FUNCTION public.place_storefront_order(payload jsonb)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_customer_id uuid;
  v_customer_status customer_status;
  v_order_id uuid;
  v_order_number text;
  v_address_id uuid := NULL;
  v_item jsonb;
  v_oi_id uuid;
  v_addon jsonb;
  v_coupon RECORD;
  v_phone text := payload->'customer'->>'phone';
  v_name  text := payload->'customer'->>'name';
  v_email text := NULLIF(payload->'customer'->>'email','');
  v_branch RECORD;
  v_zone RECORD;
  v_settings RECORD;
  v_product RECORD;
  v_variant RECORD;
  v_addon_row RECORD;
  v_qty int;
  v_unit_price numeric;
  v_addons_total numeric;
  v_line_total numeric;
  v_subtotal numeric := 0;
  v_vat numeric := 0;
  v_delivery_fee numeric := 0;
  v_discount numeric := 0;
  v_total numeric := 0;
  v_taxable numeric := 0;
  v_vat_percent numeric := 15;
  v_min_order numeric := 0;
  v_pb_available boolean;
  v_used_count int;
  v_addr jsonb;
BEGIN
  -- Customer validation
  IF v_phone IS NULL OR length(v_phone) < 6 THEN RAISE EXCEPTION 'phone_required'; END IF;
  IF v_name IS NULL OR length(v_name) < 2 THEN RAISE EXCEPTION 'name_required'; END IF;

  SELECT id, status INTO v_customer_id, v_customer_status FROM public.customers WHERE phone = v_phone LIMIT 1;
  IF v_customer_id IS NULL THEN
    INSERT INTO public.customers (name, phone, email) VALUES (v_name, v_phone, v_email)
    RETURNING id INTO v_customer_id;
  ELSE
    IF v_customer_status = 'banned' THEN RAISE EXCEPTION 'customer_banned'; END IF;
    UPDATE public.customers SET name = v_name, email = COALESCE(v_email, email), updated_at = now() WHERE id = v_customer_id;
  END IF;

  -- Branch validation
  SELECT * INTO v_branch FROM public.branches WHERE id = NULLIF(payload->>'branch_id','')::uuid LIMIT 1;
  IF v_branch IS NULL THEN RAISE EXCEPTION 'branch_required'; END IF;
  IF NOT v_branch.is_active OR NOT v_branch.accepts_orders THEN RAISE EXCEPTION 'branch_not_accepting'; END IF;

  -- Settings (vat)
  SELECT * INTO v_settings FROM public.store_settings LIMIT 1;
  v_vat_percent := COALESCE(v_settings.vat_percent, 15);

  -- Items: items array required
  IF (payload->'items') IS NULL OR jsonb_array_length(payload->'items') = 0 THEN
    RAISE EXCEPTION 'cart_empty';
  END IF;

  -- Compute subtotal from DB-truth prices
  FOR v_item IN SELECT * FROM jsonb_array_elements(payload->'items') LOOP
    v_qty := GREATEST(1, COALESCE((v_item->>'quantity')::int, 1));

    SELECT * INTO v_product FROM public.products WHERE id = NULLIF(v_item->>'product_id','')::uuid;
    IF v_product IS NULL THEN RAISE EXCEPTION 'product_missing:%', v_item->>'product_name'; END IF;
    IF NOT v_product.is_available OR v_product.is_archived OR NOT v_product.show_in_store THEN
      RAISE EXCEPTION 'product_unavailable:%', v_product.name_ar;
    END IF;

    -- Branch availability if explicit row exists
    SELECT is_available INTO v_pb_available FROM public.product_branches
      WHERE product_id = v_product.id AND branch_id = v_branch.id LIMIT 1;
    IF v_pb_available IS NOT NULL AND v_pb_available = false THEN
      RAISE EXCEPTION 'product_unavailable_at_branch:%', v_product.name_ar;
    END IF;

    -- Variant resolution
    IF NULLIF(v_item->>'variant_id','') IS NOT NULL THEN
      SELECT * INTO v_variant FROM public.product_variants
        WHERE id = (v_item->>'variant_id')::uuid AND product_id = v_product.id LIMIT 1;
      IF v_variant IS NULL OR NOT v_variant.is_available THEN
        RAISE EXCEPTION 'variant_unavailable:%', v_product.name_ar;
      END IF;
      v_unit_price := v_variant.price;
    ELSE
      v_variant := NULL;
      v_unit_price := v_product.base_price;
    END IF;

    -- Addons
    v_addons_total := 0;
    IF (v_item->'addons') IS NOT NULL THEN
      FOR v_addon IN SELECT * FROM jsonb_array_elements(v_item->'addons') LOOP
        SELECT * INTO v_addon_row FROM public.product_addons
          WHERE id = NULLIF(v_addon->>'addon_id','')::uuid LIMIT 1;
        IF v_addon_row IS NULL OR NOT v_addon_row.is_available THEN
          RAISE EXCEPTION 'addon_unavailable:%', v_addon->>'addon_name';
        END IF;
        v_addons_total := v_addons_total + COALESCE(v_addon_row.price, 0);
      END LOOP;
    END IF;

    v_line_total := (v_unit_price + v_addons_total) * v_qty;
    v_subtotal := v_subtotal + v_line_total;
  END LOOP;

  -- Delivery fee
  IF (payload->>'order_type') = 'delivery' THEN
    IF NULLIF(payload->>'zone_id','') IS NOT NULL THEN
      SELECT * INTO v_zone FROM public.delivery_zones
        WHERE id = (payload->>'zone_id')::uuid AND status = 'active' LIMIT 1;
      IF v_zone IS NULL THEN RAISE EXCEPTION 'zone_invalid'; END IF;
      IF v_zone.branch_id IS NOT NULL AND v_zone.branch_id <> v_branch.id THEN
        RAISE EXCEPTION 'zone_branch_mismatch';
      END IF;
      v_delivery_fee := v_zone.delivery_fee;
      v_min_order := v_zone.minimum_order;
    ELSE
      v_delivery_fee := COALESCE(v_branch.delivery_fee, v_settings.delivery_fee, 0);
      v_min_order := COALESCE(v_branch.min_order_amount, v_settings.min_order_amount, 0);
    END IF;
    IF v_min_order > 0 AND v_subtotal < v_min_order THEN
      RAISE EXCEPTION 'below_min_order:%', v_min_order;
    END IF;
  END IF;

  -- Coupon
  IF NULLIF(payload->>'coupon_code','') IS NOT NULL THEN
    SELECT * INTO v_coupon FROM public.coupons WHERE code = payload->>'coupon_code' AND status = 'active' LIMIT 1;
    IF v_coupon IS NULL THEN RAISE EXCEPTION 'coupon_invalid'; END IF;
    IF v_coupon.start_date IS NOT NULL AND v_coupon.start_date > now() THEN RAISE EXCEPTION 'coupon_not_started'; END IF;
    IF v_coupon.end_date   IS NOT NULL AND v_coupon.end_date   < now() THEN RAISE EXCEPTION 'coupon_expired'; END IF;
    IF v_coupon.usage_limit IS NOT NULL AND v_coupon.used_count >= v_coupon.usage_limit THEN RAISE EXCEPTION 'coupon_used_up'; END IF;
    IF v_coupon.branch_id IS NOT NULL AND v_coupon.branch_id <> v_branch.id THEN RAISE EXCEPTION 'coupon_branch_mismatch'; END IF;
    IF v_coupon.minimum_order > 0 AND v_subtotal < v_coupon.minimum_order THEN RAISE EXCEPTION 'coupon_below_min'; END IF;
    IF v_coupon.usage_per_customer IS NOT NULL THEN
      SELECT COUNT(*) INTO v_used_count FROM public.coupon_usages WHERE coupon_id = v_coupon.id AND customer_id = v_customer_id;
      IF v_used_count >= v_coupon.usage_per_customer THEN RAISE EXCEPTION 'coupon_per_customer_exceeded'; END IF;
    END IF;

    IF v_coupon.discount_type = 'percent' THEN
      v_discount := v_subtotal * (v_coupon.discount_value / 100);
      IF v_coupon.maximum_discount IS NOT NULL THEN
        v_discount := LEAST(v_discount, v_coupon.maximum_discount);
      END IF;
    ELSIF v_coupon.discount_type = 'fixed' THEN
      v_discount := LEAST(v_coupon.discount_value, v_subtotal);
    ELSIF v_coupon.discount_type = 'free_delivery' THEN
      v_delivery_fee := 0;
      v_discount := 0;
    END IF;
  END IF;

  v_taxable := GREATEST(0, v_subtotal - v_discount);
  v_vat := round((v_taxable * (v_vat_percent / 100))::numeric, 2);
  v_total := round((v_taxable + v_vat + v_delivery_fee)::numeric, 2);

  -- Address
  IF (payload->'address') IS NOT NULL AND payload->>'order_type' = 'delivery' THEN
    INSERT INTO public.customer_addresses (
      customer_id, title, city, district, street, building, floor, apartment, landmark, driver_notes, latitude, longitude
    ) VALUES (
      v_customer_id,
      COALESCE(payload->'address'->>'title','عنوان التوصيل'),
      payload->'address'->>'city',
      payload->'address'->>'district',
      payload->'address'->>'street',
      payload->'address'->>'building',
      payload->'address'->>'floor',
      payload->'address'->>'apartment',
      payload->'address'->>'landmark',
      payload->'address'->>'driver_notes',
      NULLIF(payload->'address'->>'latitude','')::numeric,
      NULLIF(payload->'address'->>'longitude','')::numeric
    ) RETURNING id INTO v_address_id;
    SELECT to_jsonb(a) INTO v_addr FROM public.customer_addresses a WHERE a.id = v_address_id;
  END IF;

  -- Insert order with snapshots & DB-trusted totals
  INSERT INTO public.orders (
    customer_id, branch_id, order_type, payment_method, status,
    subtotal, vat_amount, delivery_fee, discount_amount, total_amount,
    customer_notes, delivery_address_id, coupon_id,
    customer_name, customer_phone, customer_email, branch_name, coupon_code, delivery_address_snapshot
  ) VALUES (
    v_customer_id, v_branch.id,
    COALESCE((payload->>'order_type')::order_type, 'delivery'),
    COALESCE((payload->>'payment_method')::payment_method, 'cash'),
    'new',
    v_subtotal, v_vat, v_delivery_fee, v_discount, v_total,
    NULLIF(payload->>'customer_notes',''), v_address_id, v_coupon.id,
    v_name, v_phone, v_email, v_branch.name, v_coupon.code, v_addr
  ) RETURNING id, order_number INTO v_order_id, v_order_number;

  -- Insert items + addons with DB-trusted prices
  FOR v_item IN SELECT * FROM jsonb_array_elements(payload->'items') LOOP
    v_qty := GREATEST(1, COALESCE((v_item->>'quantity')::int, 1));
    SELECT * INTO v_product FROM public.products WHERE id = (v_item->>'product_id')::uuid;

    IF NULLIF(v_item->>'variant_id','') IS NOT NULL THEN
      SELECT * INTO v_variant FROM public.product_variants WHERE id = (v_item->>'variant_id')::uuid;
      v_unit_price := v_variant.price;
    ELSE
      v_variant := NULL;
      v_unit_price := v_product.base_price;
    END IF;

    v_addons_total := 0;
    IF (v_item->'addons') IS NOT NULL THEN
      FOR v_addon IN SELECT * FROM jsonb_array_elements(v_item->'addons') LOOP
        SELECT * INTO v_addon_row FROM public.product_addons WHERE id = (v_addon->>'addon_id')::uuid;
        v_addons_total := v_addons_total + COALESCE(v_addon_row.price, 0);
      END LOOP;
    END IF;

    v_line_total := (v_unit_price + v_addons_total) * v_qty;

    INSERT INTO public.order_items (
      order_id, product_id, variant_id, product_name, variant_name, product_image,
      quantity, unit_price, total_price, notes
    ) VALUES (
      v_order_id, v_product.id,
      CASE WHEN v_variant IS NULL THEN NULL ELSE v_variant.id END,
      v_product.name_ar,
      CASE WHEN v_variant IS NULL THEN NULL ELSE v_variant.name_ar END,
      v_product.image_url,
      v_qty, v_unit_price, v_line_total, NULLIF(v_item->>'notes','')
    ) RETURNING id INTO v_oi_id;

    IF (v_item->'addons') IS NOT NULL THEN
      FOR v_addon IN SELECT * FROM jsonb_array_elements(v_item->'addons') LOOP
        SELECT * INTO v_addon_row FROM public.product_addons WHERE id = (v_addon->>'addon_id')::uuid;
        INSERT INTO public.order_item_addons (order_item_id, addon_id, addon_name, price)
        VALUES (v_oi_id, v_addon_row.id, v_addon_row.name_ar, v_addon_row.price);
      END LOOP;
    END IF;
  END LOOP;

  IF v_coupon.id IS NOT NULL THEN
    INSERT INTO public.coupon_usages (coupon_id, customer_id, order_id, discount_amount)
    VALUES (v_coupon.id, v_customer_id, v_order_id, v_discount);
    UPDATE public.coupons SET used_count = used_count + 1 WHERE id = v_coupon.id;
  END IF;

  RETURN jsonb_build_object('order_id', v_order_id, 'order_number', v_order_number, 'total_amount', v_total);
END;
$$;
