
-- 1) profiles: status + last_login_at
DO $$ BEGIN
  CREATE TYPE public.user_status AS ENUM ('active','inactive','suspended');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS status public.user_status NOT NULL DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS last_login_at timestamptz;

-- 2) Roles table (custom + system)
CREATE TABLE IF NOT EXISTS public.roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  is_system boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth read roles" ON public.roles;
CREATE POLICY "auth read roles" ON public.roles FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "admins write roles" ON public.roles;
CREATE POLICY "admins write roles" ON public.roles FOR ALL
  USING (has_role(auth.uid(),'admin'::app_role))
  WITH CHECK (has_role(auth.uid(),'admin'::app_role));

-- 3) Permissions catalog
CREATE TABLE IF NOT EXISTS public.permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  module text NOT NULL,
  name text NOT NULL,
  description text
);
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth read permissions" ON public.permissions;
CREATE POLICY "auth read permissions" ON public.permissions FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "admins write permissions" ON public.permissions;
CREATE POLICY "admins write permissions" ON public.permissions FOR ALL
  USING (has_role(auth.uid(),'admin'::app_role))
  WITH CHECK (has_role(auth.uid(),'admin'::app_role));

-- 4) Role <-> Permission link
CREATE TABLE IF NOT EXISTS public.role_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id uuid NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
  permission_key text NOT NULL REFERENCES public.permissions(key) ON DELETE CASCADE,
  UNIQUE(role_id, permission_key)
);
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "auth read role_permissions" ON public.role_permissions;
CREATE POLICY "auth read role_permissions" ON public.role_permissions FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "admins write role_permissions" ON public.role_permissions;
CREATE POLICY "admins write role_permissions" ON public.role_permissions FOR ALL
  USING (has_role(auth.uid(),'admin'::app_role))
  WITH CHECK (has_role(auth.uid(),'admin'::app_role));

-- 5) User branches
CREATE TABLE IF NOT EXISTS public.user_branches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  branch_id uuid NOT NULL REFERENCES public.branches(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, branch_id)
);
ALTER TABLE public.user_branches ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "managers read user_branches" ON public.user_branches;
CREATE POLICY "managers read user_branches" ON public.user_branches FOR SELECT
  USING (is_manager(auth.uid()) OR auth.uid() = user_id);
DROP POLICY IF EXISTS "admins write user_branches" ON public.user_branches;
CREATE POLICY "admins write user_branches" ON public.user_branches FOR ALL
  USING (has_role(auth.uid(),'admin'::app_role))
  WITH CHECK (has_role(auth.uid(),'admin'::app_role));

-- 6) Notification settings (per user)
CREATE TABLE IF NOT EXISTS public.notification_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  orders_enabled boolean NOT NULL DEFAULT true,
  drivers_enabled boolean NOT NULL DEFAULT true,
  inventory_enabled boolean NOT NULL DEFAULT true,
  integrations_enabled boolean NOT NULL DEFAULT true,
  email_enabled boolean NOT NULL DEFAULT false,
  push_enabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.notification_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "users own notif settings" ON public.notification_settings;
CREATE POLICY "users own notif settings" ON public.notification_settings FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 7) Security sessions
CREATE TABLE IF NOT EXISTS public.security_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  device text,
  browser text,
  ip_address text,
  user_agent text,
  last_activity_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.security_sessions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "users own sessions" ON public.security_sessions;
CREATE POLICY "users own sessions" ON public.security_sessions FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 8) notifications: add user_id (nullable = broadcast)
ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS user_id uuid;

-- 9) activity_logs: extras
ALTER TABLE public.activity_logs
  ADD COLUMN IF NOT EXISTS module text,
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS old_values jsonb,
  ADD COLUMN IF NOT EXISTS new_values jsonb,
  ADD COLUMN IF NOT EXISTS ip_address text,
  ADD COLUMN IF NOT EXISTS user_agent text;

-- 10) Permission check function
CREATE OR REPLACE FUNCTION public.has_permission(_user_id uuid, _perm_key text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles ur
    JOIN public.roles r ON r.key = ur.role::text
    JOIN public.role_permissions rp ON rp.role_id = r.id
    WHERE ur.user_id = _user_id AND rp.permission_key = _perm_key
  ) OR public.has_role(_user_id, 'admin'::app_role);
$$;

-- 11) Update last_login helper (called by client after sign-in)
CREATE OR REPLACE FUNCTION public.touch_last_login()
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  UPDATE public.profiles SET last_login_at = now() WHERE id = auth.uid();
$$;

-- 12) Seed system roles
INSERT INTO public.roles (key, name, description, is_system) VALUES
  ('admin','مسؤول','صلاحيات كاملة على النظام', true),
  ('manager','مدير','إدارة المتجر والعمليات', true),
  ('staff','موظف','صلاحيات تشغيلية محدودة', true)
ON CONFLICT (key) DO NOTHING;

-- 13) Seed permissions catalog
INSERT INTO public.permissions (key, module, name, description) VALUES
  -- Dashboard
  ('dashboard.view','dashboard','عرض الصفحة الرئيسية',NULL),
  -- Orders
  ('orders.view','orders','عرض الطلبات',NULL),
  ('orders.detail','orders','عرض تفاصيل الطلب',NULL),
  ('orders.status','orders','تعديل حالة الطلب',NULL),
  ('orders.cancel','orders','إلغاء الطلب',NULL),
  ('orders.assign_driver','orders','تعيين سائق',NULL),
  ('orders.print','orders','طباعة الفاتورة',NULL),
  -- Products
  ('products.view','products','عرض المنتجات',NULL),
  ('products.create','products','إضافة منتج',NULL),
  ('products.edit','products','تعديل منتج',NULL),
  ('products.delete','products','حذف منتج',NULL),
  ('products.toggle','products','تفعيل/تعطيل منتج',NULL),
  ('products.import','products','استيراد Excel',NULL),
  -- Categories
  ('categories.view','categories','عرض الأقسام',NULL),
  ('categories.create','categories','إضافة قسم',NULL),
  ('categories.edit','categories','تعديل قسم',NULL),
  ('categories.delete','categories','حذف قسم',NULL),
  -- Add-ons
  ('addons.view','addons','عرض الإضافات',NULL),
  ('addons.create','addons','إضافة إضافة',NULL),
  ('addons.edit','addons','تعديل إضافة',NULL),
  ('addons.delete','addons','حذف إضافة',NULL),
  -- Branches
  ('branches.view','branches','عرض الفروع',NULL),
  ('branches.create','branches','إضافة فرع',NULL),
  ('branches.edit','branches','تعديل فرع',NULL),
  ('branches.toggle','branches','تعطيل فرع',NULL),
  -- Drivers
  ('drivers.view','drivers','عرض السائقين',NULL),
  ('drivers.create','drivers','إضافة سائق',NULL),
  ('drivers.edit','drivers','تعديل سائق',NULL),
  ('drivers.toggle','drivers','تعطيل سائق',NULL),
  -- Customers
  ('customers.view','customers','عرض العملاء',NULL),
  ('customers.edit','customers','تعديل العميل',NULL),
  ('customers.block','customers','حظر العميل',NULL),
  -- Coupons
  ('coupons.view','coupons','عرض الكوبونات',NULL),
  ('coupons.create','coupons','إضافة كوبون',NULL),
  ('coupons.edit','coupons','تعديل كوبون',NULL),
  ('coupons.toggle','coupons','تعطيل كوبون',NULL),
  -- Banners & Hero
  ('banners.view','banners','عرض البنرات',NULL),
  ('banners.manage','banners','إدارة البنرات والهيرو',NULL),
  -- Content
  ('content.pages','content','إدارة الصفحات',NULL),
  ('content.header','content','إدارة الهيدر',NULL),
  ('content.footer','content','إدارة الفوتر',NULL),
  ('content.menus','content','إدارة المنيو',NULL),
  ('content.faq','content','إدارة FAQ',NULL),
  -- SEO
  ('seo.view','seo','عرض SEO',NULL),
  ('seo.edit','seo','تعديل SEO',NULL),
  -- Integrations
  ('integrations.view','integrations','عرض التكاملات',NULL),
  ('integrations.edit','integrations','تعديل مفاتيح التكامل',NULL),
  ('integrations.test','integrations','اختبار الاتصال',NULL),
  -- Reports
  ('reports.view','reports','عرض التقارير',NULL),
  ('reports.export_excel','reports','تصدير Excel',NULL),
  ('reports.export_pdf','reports','تصدير PDF',NULL),
  -- Settings
  ('settings.view','settings','عرض إعدادات المتجر',NULL),
  ('settings.edit','settings','تعديل إعدادات المتجر',NULL),
  ('settings.app','settings','إعدادات التطبيق',NULL),
  -- Users & Roles
  ('users.view','users','عرض المستخدمين',NULL),
  ('users.create','users','إضافة مستخدم',NULL),
  ('users.edit','users','تعديل مستخدم',NULL),
  ('users.permissions','users','إدارة الصلاحيات',NULL),
  -- Activity
  ('activity.view','activity','عرض سجل النشاط',NULL)
ON CONFLICT (key) DO NOTHING;

-- 14) Seed default role-permission assignments
-- Admin: everything
INSERT INTO public.role_permissions (role_id, permission_key)
SELECT r.id, p.key FROM public.roles r CROSS JOIN public.permissions p
WHERE r.key = 'admin'
ON CONFLICT DO NOTHING;

-- Manager: everything except users.permissions and integrations.edit/test
INSERT INTO public.role_permissions (role_id, permission_key)
SELECT r.id, p.key FROM public.roles r CROSS JOIN public.permissions p
WHERE r.key = 'manager'
  AND p.key NOT IN ('users.permissions','integrations.edit','integrations.test','users.create')
ON CONFLICT DO NOTHING;

-- Staff: read-only essentials + order ops
INSERT INTO public.role_permissions (role_id, permission_key)
SELECT r.id, p.key FROM public.roles r CROSS JOIN public.permissions p
WHERE r.key = 'staff'
  AND p.key IN (
    'dashboard.view','orders.view','orders.detail','orders.status','orders.assign_driver','orders.print',
    'products.view','categories.view','addons.view','branches.view','drivers.view','customers.view',
    'coupons.view','banners.view','reports.view','activity.view'
  )
ON CONFLICT DO NOTHING;
