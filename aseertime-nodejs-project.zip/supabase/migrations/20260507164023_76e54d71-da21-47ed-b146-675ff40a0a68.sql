CREATE OR REPLACE FUNCTION public.upsert_customer_address(_phone text, _address jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_cid uuid; v_aid uuid; v_status customer_status; v_is_default boolean;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RAISE EXCEPTION 'phone_required'; END IF;
  SELECT id, status INTO v_cid, v_status FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_cid IS NULL THEN RAISE EXCEPTION 'customer_not_found'; END IF;
  IF v_status = 'banned' THEN RAISE EXCEPTION 'customer_banned'; END IF;

  v_is_default := COALESCE((_address->>'is_default')::boolean, false);
  v_aid := NULLIF(_address->>'id','')::uuid;

  IF v_aid IS NOT NULL THEN
    UPDATE public.customer_addresses SET
      title = _address->>'title', city = _address->>'city', district = _address->>'district',
      street = _address->>'street', building = _address->>'building',
      floor = _address->>'floor', apartment = _address->>'apartment',
      landmark = _address->>'landmark', driver_notes = _address->>'driver_notes',
      latitude = NULLIF(_address->>'latitude','')::numeric, longitude = NULLIF(_address->>'longitude','')::numeric,
      is_default = v_is_default
    WHERE id = v_aid AND customer_id = v_cid;
  ELSE
    INSERT INTO public.customer_addresses (customer_id, title, city, district, street, building, floor, apartment, landmark, driver_notes, latitude, longitude, is_default)
    VALUES (v_cid, _address->>'title', _address->>'city', _address->>'district',
      _address->>'street', _address->>'building', _address->>'floor', _address->>'apartment',
      _address->>'landmark', _address->>'driver_notes',
      NULLIF(_address->>'latitude','')::numeric, NULLIF(_address->>'longitude','')::numeric, v_is_default)
    RETURNING id INTO v_aid;
  END IF;

  IF v_is_default THEN
    UPDATE public.customer_addresses SET is_default = false WHERE customer_id = v_cid AND id <> v_aid;
  END IF;

  RETURN jsonb_build_object('id', v_aid);
END;
$function$;