CREATE OR REPLACE FUNCTION public.customer_phone_exists(_phone text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_id uuid; v_name text; v_status customer_status;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN
    RETURN jsonb_build_object('exists', false);
  END IF;
  SELECT id, name, status INTO v_id, v_name, v_status
  FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_id IS NULL THEN
    RETURN jsonb_build_object('exists', false);
  END IF;
  RETURN jsonb_build_object(
    'exists', true,
    'name', v_name,
    'banned', v_status = 'banned'
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.customer_phone_exists(text) TO anon, authenticated;