-- Enums
DO $$ BEGIN CREATE TYPE public.order_status AS ENUM ('new','accepted','preparing','ready','awaiting_driver','with_driver','delivered','cancelled','refunded'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.order_type AS ENUM ('delivery','pickup'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.payment_method AS ENUM ('cash','card','online','wallet'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.payment_status AS ENUM ('pending','paid','failed','refunded'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.customer_status AS ENUM ('active','inactive','banned'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.driver_status AS ENUM ('available','busy','offline','suspended'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.coupon_discount_type AS ENUM ('fixed','percent','free_delivery'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.coupon_status AS ENUM ('active','inactive'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.zone_status AS ENUM ('active','inactive'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Customers
CREATE TABLE IF NOT EXISTS public.customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text NOT NULL UNIQUE,
  email text,
  status public.customer_status NOT NULL DEFAULT 'active',
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers read customers" ON public.customers FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers write customers" ON public.customers FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));
CREATE TRIGGER customers_updated_at BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.customer_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  title text,
  city text, district text, street text, building text, landmark text,
  latitude numeric, longitude numeric,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.customer_addresses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers read addresses" ON public.customer_addresses FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers write addresses" ON public.customer_addresses FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

-- Drivers
CREATE TABLE IF NOT EXISTS public.drivers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text NOT NULL,
  email text,
  avatar_url text,
  branch_id uuid REFERENCES public.branches(id) ON DELETE SET NULL,
  national_id text,
  vehicle_type text,
  plate_number text,
  status public.driver_status NOT NULL DEFAULT 'offline',
  rating numeric NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  notes text,
  last_active_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.drivers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers read drivers" ON public.drivers FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers write drivers" ON public.drivers FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));
CREATE TRIGGER drivers_updated_at BEFORE UPDATE ON public.drivers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Delivery zones
CREATE TABLE IF NOT EXISTS public.delivery_zones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  branch_id uuid REFERENCES public.branches(id) ON DELETE CASCADE,
  name text NOT NULL,
  delivery_fee numeric NOT NULL DEFAULT 0,
  minimum_order numeric NOT NULL DEFAULT 0,
  estimated_time_minutes integer DEFAULT 30,
  status public.zone_status NOT NULL DEFAULT 'active',
  sort_order integer NOT NULL DEFAULT 0,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.delivery_zones ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers read zones" ON public.delivery_zones FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers write zones" ON public.delivery_zones FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));
CREATE TRIGGER zones_updated_at BEFORE UPDATE ON public.delivery_zones FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Coupons
CREATE TABLE IF NOT EXISTS public.coupons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  discount_type public.coupon_discount_type NOT NULL,
  discount_value numeric NOT NULL DEFAULT 0,
  minimum_order numeric NOT NULL DEFAULT 0,
  maximum_discount numeric,
  start_date timestamptz,
  end_date timestamptz,
  usage_limit integer,
  usage_per_customer integer DEFAULT 1,
  status public.coupon_status NOT NULL DEFAULT 'active',
  branch_id uuid REFERENCES public.branches(id) ON DELETE SET NULL,
  product_ids uuid[] NOT NULL DEFAULT '{}',
  category_ids uuid[] NOT NULL DEFAULT '{}',
  used_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers read coupons" ON public.coupons FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers write coupons" ON public.coupons FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));
CREATE TRIGGER coupons_updated_at BEFORE UPDATE ON public.coupons FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.coupon_usages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  coupon_id uuid NOT NULL REFERENCES public.coupons(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES public.customers(id) ON DELETE SET NULL,
  order_id uuid,
  discount_amount numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.coupon_usages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers read coupon usages" ON public.coupon_usages FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers insert coupon usages" ON public.coupon_usages FOR INSERT WITH CHECK (public.is_manager(auth.uid()));

-- Orders
CREATE SEQUENCE IF NOT EXISTS public.orders_number_seq START 10001;

CREATE TABLE IF NOT EXISTS public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text NOT NULL UNIQUE DEFAULT ('ORD-' || nextval('public.orders_number_seq')),
  customer_id uuid REFERENCES public.customers(id) ON DELETE SET NULL,
  branch_id uuid REFERENCES public.branches(id) ON DELETE SET NULL,
  driver_id uuid REFERENCES public.drivers(id) ON DELETE SET NULL,
  order_type public.order_type NOT NULL DEFAULT 'delivery',
  status public.order_status NOT NULL DEFAULT 'new',
  payment_method public.payment_method NOT NULL DEFAULT 'cash',
  payment_status public.payment_status NOT NULL DEFAULT 'pending',
  subtotal numeric NOT NULL DEFAULT 0,
  vat_amount numeric NOT NULL DEFAULT 0,
  delivery_fee numeric NOT NULL DEFAULT 0,
  discount_amount numeric NOT NULL DEFAULT 0,
  total_amount numeric NOT NULL DEFAULT 0,
  customer_notes text,
  admin_notes text,
  delivery_address_id uuid REFERENCES public.customer_addresses(id) ON DELETE SET NULL,
  coupon_id uuid REFERENCES public.coupons(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers read orders" ON public.orders FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers write orders" ON public.orders FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));
CREATE TRIGGER orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX IF NOT EXISTS orders_status_idx ON public.orders(status);
CREATE INDEX IF NOT EXISTS orders_branch_idx ON public.orders(branch_id);
CREATE INDEX IF NOT EXISTS orders_customer_idx ON public.orders(customer_id);
CREATE INDEX IF NOT EXISTS orders_created_idx ON public.orders(created_at DESC);

CREATE TABLE IF NOT EXISTS public.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES public.products(id) ON DELETE SET NULL,
  variant_id uuid REFERENCES public.product_variants(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  variant_name text,
  quantity integer NOT NULL DEFAULT 1,
  unit_price numeric NOT NULL DEFAULT 0,
  total_price numeric NOT NULL DEFAULT 0,
  notes text
);
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers read order_items" ON public.order_items FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers write order_items" ON public.order_items FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

CREATE TABLE IF NOT EXISTS public.order_item_addons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_item_id uuid NOT NULL REFERENCES public.order_items(id) ON DELETE CASCADE,
  addon_id uuid REFERENCES public.product_addons(id) ON DELETE SET NULL,
  addon_name text NOT NULL,
  price numeric NOT NULL DEFAULT 0
);
ALTER TABLE public.order_item_addons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers read order_item_addons" ON public.order_item_addons FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers write order_item_addons" ON public.order_item_addons FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

CREATE TABLE IF NOT EXISTS public.order_status_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  old_status public.order_status,
  new_status public.order_status NOT NULL,
  changed_by uuid,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.order_status_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers read order_status_logs" ON public.order_status_logs FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers write order_status_logs" ON public.order_status_logs FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

-- Notifications
CREATE TABLE IF NOT EXISTS public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  message text,
  type text NOT NULL DEFAULT 'info',
  is_read boolean NOT NULL DEFAULT false,
  action_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers read notifications" ON public.notifications FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers write notifications" ON public.notifications FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

-- Auto log status changes & notifications on new orders
CREATE OR REPLACE FUNCTION public.log_order_status_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.order_status_logs (order_id, old_status, new_status, changed_by) VALUES (NEW.id, NULL, NEW.status, auth.uid());
    INSERT INTO public.notifications (title, message, type, action_url) VALUES ('طلب جديد', 'تم استلام طلب رقم ' || NEW.order_number, 'order_new', '/dashboard/orders/' || NEW.id);
  ELSIF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.order_status_logs (order_id, old_status, new_status, changed_by) VALUES (NEW.id, OLD.status, NEW.status, auth.uid());
    IF NEW.status = 'cancelled' THEN
      INSERT INTO public.notifications (title, message, type, action_url) VALUES ('طلب ملغي', 'تم إلغاء الطلب ' || NEW.order_number, 'order_cancelled', '/dashboard/orders/' || NEW.id);
    END IF;
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS orders_status_trigger ON public.orders;
CREATE TRIGGER orders_status_trigger AFTER INSERT OR UPDATE OF status ON public.orders FOR EACH ROW EXECUTE FUNCTION public.log_order_status_change();