
-- Page Builder blocks table (used by both pages and home)
CREATE TABLE IF NOT EXISTS public.page_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_id uuid NULL REFERENCES public.pages(id) ON DELETE CASCADE,
  location text NULL, -- 'home' when not bound to a page
  block_type text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_page_blocks_page ON public.page_blocks(page_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_page_blocks_location ON public.page_blocks(location, sort_order) WHERE location IS NOT NULL;

ALTER TABLE public.page_blocks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public read active page_blocks" ON public.page_blocks;
CREATE POLICY "public read active page_blocks" ON public.page_blocks
  FOR SELECT USING (is_active = true);

DROP POLICY IF EXISTS "managers write page_blocks" ON public.page_blocks;
CREATE POLICY "managers write page_blocks" ON public.page_blocks
  FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

DROP TRIGGER IF EXISTS trg_page_blocks_updated ON public.page_blocks;
CREATE TRIGGER trg_page_blocks_updated BEFORE UPDATE ON public.page_blocks
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Contact messages from storefront contact form
CREATE TABLE IF NOT EXISTS public.contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text NOT NULL,
  email text NULL,
  message text NOT NULL,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anyone insert contact" ON public.contact_messages;
CREATE POLICY "anyone insert contact" ON public.contact_messages
  FOR INSERT WITH CHECK (
    char_length(name) BETWEEN 2 AND 100
    AND char_length(phone) BETWEEN 6 AND 20
    AND char_length(message) BETWEEN 2 AND 2000
  );

DROP POLICY IF EXISTS "managers read contact" ON public.contact_messages;
CREATE POLICY "managers read contact" ON public.contact_messages
  FOR SELECT USING (is_manager(auth.uid()));

DROP POLICY IF EXISTS "managers update contact" ON public.contact_messages;
CREATE POLICY "managers update contact" ON public.contact_messages
  FOR UPDATE USING (is_manager(auth.uid()));
