ALTER TABLE public.hero_slides ADD COLUMN IF NOT EXISTS image_only boolean NOT NULL DEFAULT false;
ALTER TABLE public.banners ADD COLUMN IF NOT EXISTS image_only boolean NOT NULL DEFAULT false;