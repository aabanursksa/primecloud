
-- ENUMS
CREATE TYPE public.banner_status AS ENUM ('active','inactive','scheduled','expired');
CREATE TYPE public.banner_link_type AS ENUM ('page','category','product','external','none');
CREATE TYPE public.banner_placement AS ENUM ('home','categories','product','offers','all');
CREATE TYPE public.platform_target AS ENUM ('store','app','both');
CREATE TYPE public.text_alignment AS ENUM ('start','center','end');
CREATE TYPE public.publish_status AS ENUM ('published','draft','inactive');
CREATE TYPE public.menu_location AS ENUM ('header','footer','app');
CREATE TYPE public.seo_entity_type AS ENUM ('site','page','product','category');
CREATE TYPE public.integration_test_status AS ENUM ('success','failed','untested');
CREATE TYPE public.webhook_status AS ENUM ('active','inactive');

-- BANNERS
CREATE TABLE public.banners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  subtitle text,
  image_url text,
  cta_text text,
  cta_url text,
  link_type public.banner_link_type NOT NULL DEFAULT 'none',
  link_value text,
  placement public.banner_placement NOT NULL DEFAULT 'home',
  platform public.platform_target NOT NULL DEFAULT 'both',
  status public.banner_status NOT NULL DEFAULT 'active',
  start_date timestamptz,
  end_date timestamptz,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- HERO SLIDES
CREATE TABLE public.hero_slides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  subtitle text,
  image_url text,
  cta_text text,
  cta_url text,
  platform public.platform_target NOT NULL DEFAULT 'both',
  text_color text DEFAULT '#ffffff',
  text_alignment public.text_alignment NOT NULL DEFAULT 'start',
  status public.banner_status NOT NULL DEFAULT 'active',
  start_date timestamptz,
  end_date timestamptz,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- NAVIGATION MENUS
CREATE TABLE public.navigation_menus (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  location public.menu_location NOT NULL,
  status public.publish_status NOT NULL DEFAULT 'published',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.navigation_menu_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  menu_id uuid NOT NULL REFERENCES public.navigation_menus(id) ON DELETE CASCADE,
  title text NOT NULL,
  link_type public.banner_link_type NOT NULL DEFAULT 'page',
  link_value text,
  parent_id uuid REFERENCES public.navigation_menu_items(id) ON DELETE CASCADE,
  sort_order integer NOT NULL DEFAULT 0,
  status public.publish_status NOT NULL DEFAULT 'published',
  open_in_new_tab boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- HEADER SETTINGS (singleton)
CREATE TABLE public.header_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  logo_url text,
  show_logo boolean NOT NULL DEFAULT true,
  cta_text text,
  cta_url text,
  contact_phone text,
  show_search boolean NOT NULL DEFAULT true,
  show_cart boolean NOT NULL DEFAULT true,
  show_login boolean NOT NULL DEFAULT true,
  show_branch_selector boolean NOT NULL DEFAULT true,
  show_cta boolean NOT NULL DEFAULT true,
  app_overrides jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- FOOTER SETTINGS (singleton)
CREATE TABLE public.footer_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  logo_url text,
  about_text text,
  phone text,
  email text,
  address text,
  working_hours text,
  copyright_text text,
  app_store_url text,
  google_play_url text,
  social_links jsonb NOT NULL DEFAULT '{}'::jsonb,
  visible_sections jsonb NOT NULL DEFAULT '{"about":true,"links":true,"contact":true,"social":true,"apps":true}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- PAGES
CREATE TABLE public.pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text NOT NULL UNIQUE,
  content text,
  featured_image text,
  status public.publish_status NOT NULL DEFAULT 'draft',
  show_in_header boolean NOT NULL DEFAULT false,
  show_in_footer boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- FAQS
CREATE TABLE public.faqs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  answer text NOT NULL,
  category text,
  status public.publish_status NOT NULL DEFAULT 'published',
  show_in_faq boolean NOT NULL DEFAULT true,
  show_in_product boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- SEO SETTINGS
CREATE TABLE public.seo_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type public.seo_entity_type NOT NULL,
  entity_id uuid,
  meta_title text,
  meta_description text,
  meta_keywords text,
  slug text,
  canonical_url text,
  og_title text,
  og_description text,
  og_image text,
  twitter_title text,
  twitter_description text,
  twitter_image text,
  robots_index boolean NOT NULL DEFAULT true,
  robots_follow boolean NOT NULL DEFAULT true,
  default_og_image text,
  default_twitter_image text,
  google_verification text,
  sitemap_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (entity_type, entity_id)
);

-- INTEGRATIONS
CREATE TABLE public.integrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL UNIQUE,
  name text NOT NULL,
  status public.publish_status NOT NULL DEFAULT 'inactive',
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  last_tested_at timestamptz,
  last_test_status public.integration_test_status NOT NULL DEFAULT 'untested',
  last_test_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- WEBHOOKS
CREATE TABLE public.webhooks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  url text NOT NULL,
  secret text,
  events text[] NOT NULL DEFAULT '{}',
  status public.webhook_status NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.webhook_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  webhook_id uuid NOT NULL REFERENCES public.webhooks(id) ON DELETE CASCADE,
  event text NOT NULL,
  payload jsonb,
  response_status integer,
  response_body text,
  attempt_count integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- APP SETTINGS (singleton)
CREATE TABLE public.app_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  app_name text,
  app_store_url text,
  google_play_url text,
  current_version text,
  minimum_version text,
  force_update boolean NOT NULL DEFAULT false,
  maintenance_mode boolean NOT NULL DEFAULT false,
  maintenance_message text,
  push_settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  home_layout jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Add menu visibility flags & per-platform limits to product_categories
ALTER TABLE public.product_categories
  ADD COLUMN IF NOT EXISTS show_on_home boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS show_in_app boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS show_in_store boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS is_featured boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS home_product_limit integer NOT NULL DEFAULT 8;

-- updated_at triggers
CREATE TRIGGER trg_banners_updated BEFORE UPDATE ON public.banners FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_hero_updated BEFORE UPDATE ON public.hero_slides FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_navmenus_updated BEFORE UPDATE ON public.navigation_menus FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_navitems_updated BEFORE UPDATE ON public.navigation_menu_items FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_header_updated BEFORE UPDATE ON public.header_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_footer_updated BEFORE UPDATE ON public.footer_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_pages_updated BEFORE UPDATE ON public.pages FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_faqs_updated BEFORE UPDATE ON public.faqs FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_seo_updated BEFORE UPDATE ON public.seo_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_integrations_updated BEFORE UPDATE ON public.integrations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_webhooks_updated BEFORE UPDATE ON public.webhooks FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_appsettings_updated BEFORE UPDATE ON public.app_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ENABLE RLS
ALTER TABLE public.banners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hero_slides ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.navigation_menus ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.navigation_menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.header_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.footer_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.faqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seo_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.integrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.webhooks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.webhook_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

-- POLICIES
-- Public read for storefront/app on public-content tables (active rows)
CREATE POLICY "public read active banners" ON public.banners FOR SELECT USING (status = 'active');
CREATE POLICY "managers write banners" ON public.banners FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

CREATE POLICY "public read active hero" ON public.hero_slides FOR SELECT USING (status = 'active');
CREATE POLICY "managers write hero" ON public.hero_slides FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

CREATE POLICY "public read menus" ON public.navigation_menus FOR SELECT USING (status = 'published');
CREATE POLICY "managers write menus" ON public.navigation_menus FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

CREATE POLICY "public read menu items" ON public.navigation_menu_items FOR SELECT USING (status = 'published');
CREATE POLICY "managers write menu items" ON public.navigation_menu_items FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

CREATE POLICY "public read header" ON public.header_settings FOR SELECT USING (true);
CREATE POLICY "managers write header" ON public.header_settings FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

CREATE POLICY "public read footer" ON public.footer_settings FOR SELECT USING (true);
CREATE POLICY "managers write footer" ON public.footer_settings FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

CREATE POLICY "public read published pages" ON public.pages FOR SELECT USING (status = 'published');
CREATE POLICY "managers write pages" ON public.pages FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

CREATE POLICY "public read published faqs" ON public.faqs FOR SELECT USING (status = 'published');
CREATE POLICY "managers write faqs" ON public.faqs FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

CREATE POLICY "public read seo" ON public.seo_settings FOR SELECT USING (true);
CREATE POLICY "managers write seo" ON public.seo_settings FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

-- Integrations & webhooks: managers only (contain secrets)
CREATE POLICY "managers read integrations" ON public.integrations FOR SELECT USING (is_manager(auth.uid()));
CREATE POLICY "managers write integrations" ON public.integrations FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

CREATE POLICY "managers read webhooks" ON public.webhooks FOR SELECT USING (is_manager(auth.uid()));
CREATE POLICY "managers write webhooks" ON public.webhooks FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

CREATE POLICY "managers read webhook logs" ON public.webhook_logs FOR SELECT USING (is_manager(auth.uid()));
CREATE POLICY "managers write webhook logs" ON public.webhook_logs FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

CREATE POLICY "public read app settings" ON public.app_settings FOR SELECT USING (true);
CREATE POLICY "managers write app settings" ON public.app_settings FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));
