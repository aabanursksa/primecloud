
-- Enums
DO $$ BEGIN
  CREATE TYPE public.home_section_type AS ENUM (
    'hero_carousel','single_banner','banner_grid','products_carousel','products_grid',
    'featured_products','category_products','most_ordered','new_products','offers_products',
    'categories_section','combo_section','banner_with_products'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.home_display_style AS ENUM ('carousel','grid','vertical_list','featured_large','compact');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.home_banner_position AS ENUM (
    'top_of_page','after_categories','before_section','after_section','inside_section','standalone'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.home_banner_link_type AS ENUM ('none','product','category','offer','page','external');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- home_sections table
CREATE TABLE IF NOT EXISTS public.home_sections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title_ar text NOT NULL DEFAULT '',
  title_en text DEFAULT '',
  section_type public.home_section_type NOT NULL,
  display_style public.home_display_style NOT NULL DEFAULT 'grid',
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  category_id uuid REFERENCES public.product_categories(id) ON DELETE SET NULL,
  manual_product_ids uuid[] NOT NULL DEFAULT '{}',
  products_limit integer NOT NULL DEFAULT 6,
  show_view_all boolean NOT NULL DEFAULT true,
  view_all_url text,
  settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_home_sections_active_order ON public.home_sections (is_active, sort_order);

ALTER TABLE public.home_sections ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public read active home_sections" ON public.home_sections;
CREATE POLICY "public read active home_sections" ON public.home_sections
  FOR SELECT USING (is_active = true);

DROP POLICY IF EXISTS "managers write home_sections" ON public.home_sections;
CREATE POLICY "managers write home_sections" ON public.home_sections
  FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

DROP TRIGGER IF EXISTS trg_home_sections_updated ON public.home_sections;
CREATE TRIGGER trg_home_sections_updated BEFORE UPDATE ON public.home_sections
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- home_section_banners table
CREATE TABLE IF NOT EXISTS public.home_section_banners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  section_id uuid REFERENCES public.home_sections(id) ON DELETE CASCADE,
  position public.home_banner_position NOT NULL DEFAULT 'standalone',
  anchor_section_id uuid REFERENCES public.home_sections(id) ON DELETE SET NULL,
  image_mobile text,
  image_tablet text,
  image_desktop text,
  title text,
  subtitle text,
  link_type public.home_banner_link_type NOT NULL DEFAULT 'none',
  link_value text,
  start_date timestamptz,
  end_date timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_home_banners_active_order ON public.home_section_banners (is_active, sort_order);
CREATE INDEX IF NOT EXISTS idx_home_banners_anchor ON public.home_section_banners (anchor_section_id);

ALTER TABLE public.home_section_banners ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public read active home_banners" ON public.home_section_banners;
CREATE POLICY "public read active home_banners" ON public.home_section_banners
  FOR SELECT USING (is_active = true);

DROP POLICY IF EXISTS "managers write home_banners" ON public.home_section_banners;
CREATE POLICY "managers write home_banners" ON public.home_section_banners
  FOR ALL USING (is_manager(auth.uid())) WITH CHECK (is_manager(auth.uid()));

DROP TRIGGER IF EXISTS trg_home_banners_updated ON public.home_section_banners;
CREATE TRIGGER trg_home_banners_updated BEFORE UPDATE ON public.home_section_banners
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Add discount_price column to products if not exists (for offers section)
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS discount_price numeric;
