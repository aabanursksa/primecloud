
-- Add last_login_at column
ALTER TABLE public.customers ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMPTZ;

-- Block banned customers in place_storefront_order
CREATE OR REPLACE FUNCTION public.place_storefront_order(payload jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_customer_id uuid;
  v_customer_status customer_status;
  v_order_id uuid;
  v_order_number text;
  v_address_id uuid := NULL;
  v_item jsonb;
  v_oi_id uuid;
  v_addon jsonb;
  v_coupon_id uuid := NULL;
  v_phone text := payload->'customer'->>'phone';
  v_name text := payload->'customer'->>'name';
  v_email text := payload->'customer'->>'email';
BEGIN
  IF v_phone IS NULL OR length(v_phone) < 6 THEN
    RAISE EXCEPTION 'phone_required';
  END IF;
  IF v_name IS NULL OR length(v_name) < 2 THEN
    RAISE EXCEPTION 'name_required';
  END IF;

  SELECT id, status INTO v_customer_id, v_customer_status FROM public.customers WHERE phone = v_phone LIMIT 1;
  IF v_customer_id IS NULL THEN
    INSERT INTO public.customers (name, phone, email)
    VALUES (v_name, v_phone, v_email)
    RETURNING id INTO v_customer_id;
  ELSE
    IF v_customer_status = 'banned' THEN
      RAISE EXCEPTION 'customer_banned';
    END IF;
  END IF;

  IF (payload->'address') IS NOT NULL AND payload->>'order_type' = 'delivery' THEN
    INSERT INTO public.customer_addresses (customer_id, title, city, district, street, building, landmark, latitude, longitude)
    VALUES (
      v_customer_id,
      COALESCE(payload->'address'->>'title','عنوان التوصيل'),
      payload->'address'->>'city',
      payload->'address'->>'district',
      payload->'address'->>'street',
      payload->'address'->>'building',
      payload->'address'->>'landmark',
      NULLIF(payload->'address'->>'latitude','')::numeric,
      NULLIF(payload->'address'->>'longitude','')::numeric
    )
    RETURNING id INTO v_address_id;
  END IF;

  IF (payload->>'coupon_code') IS NOT NULL AND length(payload->>'coupon_code') > 0 THEN
    SELECT id INTO v_coupon_id FROM public.coupons WHERE code = payload->>'coupon_code' AND status = 'active' LIMIT 1;
  END IF;

  INSERT INTO public.orders (
    customer_id, branch_id, order_type, payment_method, status,
    subtotal, vat_amount, delivery_fee, discount_amount, total_amount,
    customer_notes, delivery_address_id, coupon_id
  )
  VALUES (
    v_customer_id,
    NULLIF(payload->>'branch_id','')::uuid,
    COALESCE((payload->>'order_type')::order_type, 'delivery'),
    COALESCE((payload->>'payment_method')::payment_method, 'cash'),
    'new',
    COALESCE((payload->>'subtotal')::numeric, 0),
    COALESCE((payload->>'vat_amount')::numeric, 0),
    COALESCE((payload->>'delivery_fee')::numeric, 0),
    COALESCE((payload->>'discount_amount')::numeric, 0),
    COALESCE((payload->>'total_amount')::numeric, 0),
    payload->>'customer_notes',
    v_address_id,
    v_coupon_id
  )
  RETURNING id, order_number INTO v_order_id, v_order_number;

  FOR v_item IN SELECT * FROM jsonb_array_elements(payload->'items') LOOP
    INSERT INTO public.order_items (order_id, product_id, variant_id, product_name, variant_name, quantity, unit_price, total_price, notes)
    VALUES (
      v_order_id,
      NULLIF(v_item->>'product_id','')::uuid,
      NULLIF(v_item->>'variant_id','')::uuid,
      v_item->>'product_name',
      v_item->>'variant_name',
      COALESCE((v_item->>'quantity')::int, 1),
      COALESCE((v_item->>'unit_price')::numeric, 0),
      COALESCE((v_item->>'total_price')::numeric, 0),
      v_item->>'notes'
    )
    RETURNING id INTO v_oi_id;

    IF (v_item->'addons') IS NOT NULL THEN
      FOR v_addon IN SELECT * FROM jsonb_array_elements(v_item->'addons') LOOP
        INSERT INTO public.order_item_addons (order_item_id, addon_id, addon_name, price)
        VALUES (
          v_oi_id,
          NULLIF(v_addon->>'addon_id','')::uuid,
          v_addon->>'addon_name',
          COALESCE((v_addon->>'price')::numeric, 0)
        );
      END LOOP;
    END IF;
  END LOOP;

  IF v_coupon_id IS NOT NULL THEN
    INSERT INTO public.coupon_usages (coupon_id, customer_id, order_id, discount_amount)
    VALUES (v_coupon_id, v_customer_id, v_order_id, COALESCE((payload->>'discount_amount')::numeric, 0));
    UPDATE public.coupons SET used_count = used_count + 1 WHERE id = v_coupon_id;
  END IF;

  RETURN jsonb_build_object('order_id', v_order_id, 'order_number', v_order_number);
END;
$function$;

-- Update customer profile (name/email) by phone
CREATE OR REPLACE FUNCTION public.update_customer_profile(_phone text, _name text, _email text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_id uuid; v_status customer_status;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RAISE EXCEPTION 'phone_required'; END IF;
  IF _name IS NULL OR length(_name) < 2 THEN RAISE EXCEPTION 'name_required'; END IF;
  SELECT id, status INTO v_id, v_status FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_id IS NULL THEN
    INSERT INTO public.customers (name, phone, email) VALUES (_name, _phone, NULLIF(_email,''))
    RETURNING id INTO v_id;
  ELSE
    IF v_status = 'banned' THEN RAISE EXCEPTION 'customer_banned'; END IF;
    UPDATE public.customers SET name = _name, email = NULLIF(_email,''), updated_at = now() WHERE id = v_id;
  END IF;
  RETURN jsonb_build_object('id', v_id);
END;
$function$;

-- Touch last login by phone
CREATE OR REPLACE FUNCTION public.customer_touch_login(_phone text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RETURN; END IF;
  UPDATE public.customers SET last_login_at = now() WHERE phone = _phone;
END;
$function$;

-- Upsert customer address by phone
CREATE OR REPLACE FUNCTION public.upsert_customer_address(_phone text, _address jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_cid uuid; v_aid uuid; v_status customer_status; v_is_default boolean;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RAISE EXCEPTION 'phone_required'; END IF;
  SELECT id, status INTO v_cid, v_status FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_cid IS NULL THEN RAISE EXCEPTION 'customer_not_found'; END IF;
  IF v_status = 'banned' THEN RAISE EXCEPTION 'customer_banned'; END IF;

  v_is_default := COALESCE((_address->>'is_default')::boolean, false);
  v_aid := NULLIF(_address->>'id','')::uuid;

  IF v_aid IS NOT NULL THEN
    UPDATE public.customer_addresses SET
      title = _address->>'title', city = _address->>'city', district = _address->>'district',
      street = _address->>'street', building = _address->>'building', landmark = _address->>'landmark',
      latitude = NULLIF(_address->>'latitude','')::numeric, longitude = NULLIF(_address->>'longitude','')::numeric,
      is_default = v_is_default
    WHERE id = v_aid AND customer_id = v_cid;
  ELSE
    INSERT INTO public.customer_addresses (customer_id, title, city, district, street, building, landmark, latitude, longitude, is_default)
    VALUES (v_cid, _address->>'title', _address->>'city', _address->>'district',
      _address->>'street', _address->>'building', _address->>'landmark',
      NULLIF(_address->>'latitude','')::numeric, NULLIF(_address->>'longitude','')::numeric, v_is_default)
    RETURNING id INTO v_aid;
  END IF;

  IF v_is_default THEN
    UPDATE public.customer_addresses SET is_default = false WHERE customer_id = v_cid AND id <> v_aid;
  END IF;

  RETURN jsonb_build_object('id', v_aid);
END;
$function$;

-- Delete customer address by phone
CREATE OR REPLACE FUNCTION public.delete_customer_address(_phone text, _address_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_cid uuid;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RAISE EXCEPTION 'phone_required'; END IF;
  SELECT id INTO v_cid FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_cid IS NULL THEN RETURN; END IF;
  DELETE FROM public.customer_addresses WHERE id = _address_id AND customer_id = v_cid;
END;
$function$;

-- Get single customer order (verifies phone)
CREATE OR REPLACE FUNCTION public.get_customer_order(_order_number text, _phone text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_order RECORD; v_items jsonb; v_logs jsonb; v_branch jsonb; v_addr jsonb;
BEGIN
  SELECT o.* INTO v_order FROM public.orders o
  JOIN public.customers c ON c.id = o.customer_id
  WHERE o.order_number = _order_number AND c.phone = _phone LIMIT 1;
  IF v_order IS NULL THEN RETURN NULL; END IF;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'product_id', oi.product_id, 'variant_id', oi.variant_id,
    'product_name', oi.product_name, 'variant_name', oi.variant_name,
    'quantity', oi.quantity, 'unit_price', oi.unit_price, 'total_price', oi.total_price, 'notes', oi.notes,
    'addons', (SELECT COALESCE(jsonb_agg(jsonb_build_object('addon_name', a.addon_name, 'price', a.price)), '[]'::jsonb) FROM public.order_item_addons a WHERE a.order_item_id = oi.id)
  )), '[]'::jsonb) INTO v_items FROM public.order_items oi WHERE oi.order_id = v_order.id;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'old_status', osl.old_status, 'new_status', osl.new_status, 'created_at', osl.created_at
  ) ORDER BY osl.created_at), '[]'::jsonb) INTO v_logs FROM public.order_status_logs osl WHERE osl.order_id = v_order.id;

  SELECT to_jsonb(b) INTO v_branch FROM public.branches b WHERE b.id = v_order.branch_id;
  SELECT to_jsonb(a) INTO v_addr FROM public.customer_addresses a WHERE a.id = v_order.delivery_address_id;

  RETURN jsonb_build_object(
    'id', v_order.id, 'order_number', v_order.order_number, 'status', v_order.status,
    'order_type', v_order.order_type, 'payment_method', v_order.payment_method, 'payment_status', v_order.payment_status,
    'subtotal', v_order.subtotal, 'vat_amount', v_order.vat_amount, 'delivery_fee', v_order.delivery_fee,
    'discount_amount', v_order.discount_amount, 'total_amount', v_order.total_amount,
    'customer_notes', v_order.customer_notes, 'created_at', v_order.created_at,
    'branch_id', v_order.branch_id, 'items', v_items, 'logs', v_logs, 'branch', v_branch, 'address', v_addr
  );
END;
$function$;

-- Allow public to call these RPCs via PostgREST
GRANT EXECUTE ON FUNCTION public.update_customer_profile(text, text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.customer_touch_login(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.upsert_customer_address(text, jsonb) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.delete_customer_address(text, uuid) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_customer_order(text, text) TO anon, authenticated;
