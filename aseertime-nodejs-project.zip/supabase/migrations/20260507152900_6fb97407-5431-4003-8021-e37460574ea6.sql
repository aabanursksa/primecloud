-- Public storefront RPCs: customer orders + addresses by phone

CREATE OR REPLACE FUNCTION public.get_customer_orders(_phone text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_customer_id uuid;
  v_orders jsonb;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RETURN '[]'::jsonb; END IF;
  SELECT id INTO v_customer_id FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_customer_id IS NULL THEN RETURN '[]'::jsonb; END IF;

  SELECT COALESCE(jsonb_agg(o ORDER BY created_at DESC), '[]'::jsonb) INTO v_orders
  FROM (
    SELECT
      o.id, o.order_number, o.status, o.order_type, o.payment_method, o.payment_status,
      o.subtotal, o.vat_amount, o.delivery_fee, o.discount_amount, o.total_amount,
      o.created_at, o.branch_id,
      (SELECT to_jsonb(b) FROM public.branches b WHERE b.id = o.branch_id) AS branch,
      (SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'product_id', oi.product_id,
        'variant_id', oi.variant_id,
        'product_name', oi.product_name,
        'variant_name', oi.variant_name,
        'quantity', oi.quantity,
        'unit_price', oi.unit_price,
        'total_price', oi.total_price,
        'notes', oi.notes,
        'addons', (SELECT COALESCE(jsonb_agg(jsonb_build_object('addon_id', a.addon_id, 'addon_name', a.addon_name, 'price', a.price)), '[]'::jsonb) FROM public.order_item_addons a WHERE a.order_item_id = oi.id)
      )), '[]'::jsonb) FROM public.order_items oi WHERE oi.order_id = o.id) AS items
    FROM public.orders o
    WHERE o.customer_id = v_customer_id
    ORDER BY o.created_at DESC
    LIMIT 50
  ) o;

  RETURN v_orders;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_customer_addresses(_phone text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_customer_id uuid;
  v_rows jsonb;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RETURN '[]'::jsonb; END IF;
  SELECT id INTO v_customer_id FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_customer_id IS NULL THEN RETURN '[]'::jsonb; END IF;
  SELECT COALESCE(jsonb_agg(to_jsonb(a) ORDER BY a.created_at DESC), '[]'::jsonb) INTO v_rows
  FROM public.customer_addresses a WHERE a.customer_id = v_customer_id;
  RETURN v_rows;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_customer_orders(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_customer_addresses(text) TO anon, authenticated;