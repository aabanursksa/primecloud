
-- Fix search_path on trigger function
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- Revoke broad execute on SECURITY DEFINER functions; allow only authenticated
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.is_manager(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_manager(uuid) TO authenticated;

-- Tighten storage read: only allow reading objects, no listing of bucket via prefix-less queries.
-- Replace the broad SELECT policy with one that only matches when a specific name is provided.
DROP POLICY IF EXISTS "public read store-assets" ON storage.objects;
CREATE POLICY "public read store-assets files" ON storage.objects FOR SELECT
  USING (bucket_id = 'store-assets' AND name IS NOT NULL);
