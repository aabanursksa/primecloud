
-- ============ ENUMS ============
CREATE TYPE public.app_role AS ENUM ('admin', 'manager', 'staff');

-- ============ HELPERS ============
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- ============ PROFILES ============
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  phone TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============ USER ROLES ============
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE OR REPLACE FUNCTION public.is_manager(_user_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('admin','manager'));
$$;

-- Auto profile + first user becomes admin
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE user_count INT;
BEGIN
  INSERT INTO public.profiles (id, full_name, phone)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'phone');
  SELECT COUNT(*) INTO user_count FROM auth.users;
  IF user_count = 1 THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  ELSE
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'staff');
  END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============ STORE SETTINGS (singleton) ============
CREATE TABLE public.store_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT,
  logo_url TEXT,
  primary_color TEXT DEFAULT '#ED1C24',
  secondary_color TEXT DEFAULT '#F97316',
  phone TEXT,
  email TEXT,
  address TEXT,
  currency TEXT NOT NULL DEFAULT 'SAR',
  vat_percent NUMERIC(5,2) NOT NULL DEFAULT 15,
  delivery_fee NUMERIC(10,2) NOT NULL DEFAULT 0,
  min_order_amount NUMERIC(10,2) NOT NULL DEFAULT 0,
  business_hours JSONB DEFAULT '{}'::jsonb,
  accepting_orders BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_store_settings_updated BEFORE UPDATE ON public.store_settings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============ BRANCHES ============
CREATE TABLE public.branches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  latitude NUMERIC(10,6),
  longitude NUMERIC(10,6),
  business_hours JSONB DEFAULT '{}'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT true,
  accepts_orders BOOLEAN NOT NULL DEFAULT true,
  delivery_radius_km NUMERIC(6,2) DEFAULT 10,
  delivery_fee NUMERIC(10,2) DEFAULT 0,
  min_order_amount NUMERIC(10,2) DEFAULT 0,
  display_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.branches ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_branches_updated BEFORE UPDATE ON public.branches
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============ CATEGORIES ============
CREATE TABLE public.product_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_ar TEXT NOT NULL,
  name_en TEXT,
  image_url TEXT,
  icon TEXT,
  parent_id UUID REFERENCES public.product_categories(id) ON DELETE SET NULL,
  display_order INT NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.product_categories ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_categories_updated BEFORE UPDATE ON public.product_categories
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE UNIQUE INDEX product_categories_name_ar_unique ON public.product_categories (LOWER(name_ar));

-- ============ PRODUCTS ============
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_ar TEXT NOT NULL,
  name_en TEXT,
  description_ar TEXT,
  description_en TEXT,
  image_url TEXT,
  category_id UUID REFERENCES public.product_categories(id) ON DELETE SET NULL,
  base_price NUMERIC(10,2) NOT NULL DEFAULT 0,
  calories INT,
  prep_time_minutes INT,
  is_available BOOLEAN NOT NULL DEFAULT true,
  display_order INT NOT NULL DEFAULT 0,
  show_in_app BOOLEAN NOT NULL DEFAULT true,
  show_in_store BOOLEAN NOT NULL DEFAULT true,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  is_archived BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_products_updated BEFORE UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX products_category_idx ON public.products(category_id);
CREATE UNIQUE INDEX products_name_ar_category_unique ON public.products (LOWER(name_ar), category_id);

-- ============ VARIANTS ============
CREATE TABLE public.product_variants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  name_ar TEXT NOT NULL,
  name_en TEXT,
  price NUMERIC(10,2) NOT NULL DEFAULT 0,
  calories INT,
  sku TEXT,
  is_available BOOLEAN NOT NULL DEFAULT true,
  display_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.product_variants ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_variants_updated BEFORE UPDATE ON public.product_variants
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============ PRODUCT <-> BRANCH ============
CREATE TABLE public.product_branches (
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  branch_id UUID NOT NULL REFERENCES public.branches(id) ON DELETE CASCADE,
  is_available BOOLEAN NOT NULL DEFAULT true,
  PRIMARY KEY (product_id, branch_id)
);
ALTER TABLE public.product_branches ENABLE ROW LEVEL SECURITY;

-- ============ ADDON GROUPS ============
CREATE TABLE public.addon_groups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_ar TEXT NOT NULL,
  name_en TEXT,
  is_required BOOLEAN NOT NULL DEFAULT false,
  min_select INT NOT NULL DEFAULT 0,
  max_select INT NOT NULL DEFAULT 1,
  display_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.addon_groups ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_addon_groups_updated BEFORE UPDATE ON public.addon_groups
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.product_addons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id UUID NOT NULL REFERENCES public.addon_groups(id) ON DELETE CASCADE,
  name_ar TEXT NOT NULL,
  name_en TEXT,
  price NUMERIC(10,2) NOT NULL DEFAULT 0,
  is_available BOOLEAN NOT NULL DEFAULT true,
  display_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.product_addons ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_product_addons_updated BEFORE UPDATE ON public.product_addons
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.addon_group_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id UUID NOT NULL REFERENCES public.addon_groups(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
  category_id UUID REFERENCES public.product_categories(id) ON DELETE CASCADE,
  CHECK (product_id IS NOT NULL OR category_id IS NOT NULL)
);
ALTER TABLE public.addon_group_links ENABLE ROW LEVEL SECURITY;

-- ============ IMPORT LOGS ============
CREATE TABLE public.import_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  filename TEXT,
  summary JSONB DEFAULT '{}'::jsonb,
  errors JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.import_logs ENABLE ROW LEVEL SECURITY;

-- ============ ACTIVITY LOGS ============
CREATE TABLE public.activity_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity TEXT,
  entity_id UUID,
  payload JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;
CREATE INDEX activity_logs_created_idx ON public.activity_logs(created_at DESC);

-- ============ POLICIES ============
-- profiles
CREATE POLICY "users read own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "managers read all profiles" ON public.profiles FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "users update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- user_roles
CREATE POLICY "users read own roles" ON public.user_roles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "admins read all roles" ON public.user_roles FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admins manage roles" ON public.user_roles FOR ALL USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- store_settings
CREATE POLICY "auth read settings" ON public.store_settings FOR SELECT TO authenticated USING (true);
CREATE POLICY "managers write settings" ON public.store_settings FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

-- branches
CREATE POLICY "auth read branches" ON public.branches FOR SELECT TO authenticated USING (true);
CREATE POLICY "managers write branches" ON public.branches FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

-- categories
CREATE POLICY "auth read categories" ON public.product_categories FOR SELECT TO authenticated USING (true);
CREATE POLICY "managers write categories" ON public.product_categories FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

-- products
CREATE POLICY "auth read products" ON public.products FOR SELECT TO authenticated USING (true);
CREATE POLICY "managers write products" ON public.products FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

-- variants
CREATE POLICY "auth read variants" ON public.product_variants FOR SELECT TO authenticated USING (true);
CREATE POLICY "managers write variants" ON public.product_variants FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

-- product_branches
CREATE POLICY "auth read product_branches" ON public.product_branches FOR SELECT TO authenticated USING (true);
CREATE POLICY "managers write product_branches" ON public.product_branches FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

-- addon groups + addons + links
CREATE POLICY "auth read addon_groups" ON public.addon_groups FOR SELECT TO authenticated USING (true);
CREATE POLICY "managers write addon_groups" ON public.addon_groups FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));
CREATE POLICY "auth read product_addons" ON public.product_addons FOR SELECT TO authenticated USING (true);
CREATE POLICY "managers write product_addons" ON public.product_addons FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));
CREATE POLICY "auth read addon_group_links" ON public.addon_group_links FOR SELECT TO authenticated USING (true);
CREATE POLICY "managers write addon_group_links" ON public.addon_group_links FOR ALL USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));

-- import_logs (managers only)
CREATE POLICY "managers read import_logs" ON public.import_logs FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "managers insert import_logs" ON public.import_logs FOR INSERT WITH CHECK (public.is_manager(auth.uid()));

-- activity_logs (managers read; any authenticated insert through trigger/server)
CREATE POLICY "managers read activity_logs" ON public.activity_logs FOR SELECT USING (public.is_manager(auth.uid()));
CREATE POLICY "auth insert activity_logs" ON public.activity_logs FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- ============ STORAGE ============
INSERT INTO storage.buckets (id, name, public) VALUES ('store-assets', 'store-assets', true)
  ON CONFLICT (id) DO NOTHING;

CREATE POLICY "public read store-assets" ON storage.objects FOR SELECT USING (bucket_id = 'store-assets');
CREATE POLICY "managers upload store-assets" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'store-assets' AND public.is_manager(auth.uid()));
CREATE POLICY "managers update store-assets" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'store-assets' AND public.is_manager(auth.uid()));
CREATE POLICY "managers delete store-assets" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'store-assets' AND public.is_manager(auth.uid()));
