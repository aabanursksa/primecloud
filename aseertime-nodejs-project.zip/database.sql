--
-- PostgreSQL database dump
--

\restrict ih74VFQMwuPKGqbW9EXPsXpaVFtLqVKc9uLW16bk9jHcabGQUluaWAehRqOvz4Q

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'admin',
    'manager',
    'staff'
);


--
-- Name: banner_link_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.banner_link_type AS ENUM (
    'page',
    'category',
    'product',
    'external',
    'none'
);


--
-- Name: banner_placement; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.banner_placement AS ENUM (
    'home',
    'categories',
    'product',
    'offers',
    'all'
);


--
-- Name: banner_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.banner_status AS ENUM (
    'active',
    'inactive',
    'scheduled',
    'expired'
);


--
-- Name: coupon_discount_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.coupon_discount_type AS ENUM (
    'fixed',
    'percent',
    'free_delivery'
);


--
-- Name: coupon_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.coupon_status AS ENUM (
    'active',
    'inactive'
);


--
-- Name: customer_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.customer_status AS ENUM (
    'active',
    'inactive',
    'banned'
);


--
-- Name: driver_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.driver_status AS ENUM (
    'available',
    'busy',
    'offline',
    'suspended'
);


--
-- Name: home_banner_link_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.home_banner_link_type AS ENUM (
    'none',
    'product',
    'category',
    'offer',
    'page',
    'external'
);


--
-- Name: home_banner_position; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.home_banner_position AS ENUM (
    'top_of_page',
    'after_categories',
    'before_section',
    'after_section',
    'inside_section',
    'standalone'
);


--
-- Name: home_display_style; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.home_display_style AS ENUM (
    'carousel',
    'grid',
    'vertical_list',
    'featured_large',
    'compact'
);


--
-- Name: home_section_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.home_section_type AS ENUM (
    'hero_carousel',
    'single_banner',
    'banner_grid',
    'products_carousel',
    'products_grid',
    'featured_products',
    'category_products',
    'most_ordered',
    'new_products',
    'offers_products',
    'categories_section',
    'combo_section',
    'banner_with_products'
);


--
-- Name: integration_test_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.integration_test_status AS ENUM (
    'success',
    'failed',
    'untested'
);


--
-- Name: menu_location; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.menu_location AS ENUM (
    'header',
    'footer',
    'app'
);


--
-- Name: order_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.order_status AS ENUM (
    'new',
    'accepted',
    'preparing',
    'ready',
    'awaiting_driver',
    'with_driver',
    'delivered',
    'cancelled',
    'refunded'
);


--
-- Name: order_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.order_type AS ENUM (
    'delivery',
    'pickup'
);


--
-- Name: payment_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_method AS ENUM (
    'cash',
    'card',
    'online',
    'wallet'
);


--
-- Name: payment_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_status AS ENUM (
    'pending',
    'paid',
    'failed',
    'refunded'
);


--
-- Name: platform_target; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.platform_target AS ENUM (
    'store',
    'app',
    'both'
);


--
-- Name: publish_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.publish_status AS ENUM (
    'published',
    'draft',
    'inactive'
);


--
-- Name: seo_entity_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.seo_entity_type AS ENUM (
    'site',
    'page',
    'product',
    'category'
);


--
-- Name: text_alignment; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.text_alignment AS ENUM (
    'start',
    'center',
    'end'
);


--
-- Name: user_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_status AS ENUM (
    'active',
    'inactive',
    'suspended'
);


--
-- Name: webhook_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.webhook_status AS ENUM (
    'active',
    'inactive'
);


--
-- Name: zone_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.zone_status AS ENUM (
    'active',
    'inactive'
);


--
-- Name: customer_phone_exists(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.customer_phone_exists(_phone text) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE v_id uuid; v_name text; v_status customer_status;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN
    RETURN jsonb_build_object('exists', false);
  END IF;
  SELECT id, name, status INTO v_id, v_name, v_status
  FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_id IS NULL THEN
    RETURN jsonb_build_object('exists', false);
  END IF;
  RETURN jsonb_build_object(
    'exists', true,
    'name', v_name,
    'banned', v_status = 'banned'
  );
END;
$$;


--
-- Name: customer_touch_login(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.customer_touch_login(_phone text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RETURN; END IF;
  UPDATE public.customers SET last_login_at = now() WHERE phone = _phone;
END;
$$;


--
-- Name: delete_customer_address(text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.delete_customer_address(_phone text, _address_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE v_cid uuid;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RAISE EXCEPTION 'phone_required'; END IF;
  SELECT id INTO v_cid FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_cid IS NULL THEN RETURN; END IF;
  DELETE FROM public.customer_addresses WHERE id = _address_id AND customer_id = v_cid;
END;
$$;


--
-- Name: get_customer_addresses(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_customer_addresses(_phone text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  v_customer_id uuid;
  v_rows jsonb;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RETURN '[]'::jsonb; END IF;
  SELECT id INTO v_customer_id FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_customer_id IS NULL THEN RETURN '[]'::jsonb; END IF;
  SELECT COALESCE(jsonb_agg(to_jsonb(a) ORDER BY a.created_at DESC), '[]'::jsonb) INTO v_rows
  FROM public.customer_addresses a WHERE a.customer_id = v_customer_id;
  RETURN v_rows;
END;
$$;


--
-- Name: get_customer_order(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_customer_order(_order_number text, _phone text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE v_order RECORD; v_items jsonb; v_logs jsonb; v_branch jsonb; v_addr jsonb;
BEGIN
  SELECT o.* INTO v_order FROM public.orders o
  JOIN public.customers c ON c.id = o.customer_id
  WHERE o.order_number = _order_number AND c.phone = _phone LIMIT 1;
  IF v_order IS NULL THEN RETURN NULL; END IF;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'product_id', oi.product_id, 'variant_id', oi.variant_id,
    'product_name', oi.product_name, 'variant_name', oi.variant_name,
    'quantity', oi.quantity, 'unit_price', oi.unit_price, 'total_price', oi.total_price, 'notes', oi.notes,
    'addons', (SELECT COALESCE(jsonb_agg(jsonb_build_object('addon_name', a.addon_name, 'price', a.price)), '[]'::jsonb) FROM public.order_item_addons a WHERE a.order_item_id = oi.id)
  )), '[]'::jsonb) INTO v_items FROM public.order_items oi WHERE oi.order_id = v_order.id;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'old_status', osl.old_status, 'new_status', osl.new_status, 'created_at', osl.created_at
  ) ORDER BY osl.created_at), '[]'::jsonb) INTO v_logs FROM public.order_status_logs osl WHERE osl.order_id = v_order.id;

  SELECT to_jsonb(b) INTO v_branch FROM public.branches b WHERE b.id = v_order.branch_id;
  SELECT to_jsonb(a) INTO v_addr FROM public.customer_addresses a WHERE a.id = v_order.delivery_address_id;

  RETURN jsonb_build_object(
    'id', v_order.id, 'order_number', v_order.order_number, 'status', v_order.status,
    'order_type', v_order.order_type, 'payment_method', v_order.payment_method, 'payment_status', v_order.payment_status,
    'subtotal', v_order.subtotal, 'vat_amount', v_order.vat_amount, 'delivery_fee', v_order.delivery_fee,
    'discount_amount', v_order.discount_amount, 'total_amount', v_order.total_amount,
    'customer_notes', v_order.customer_notes, 'created_at', v_order.created_at,
    'branch_id', v_order.branch_id, 'items', v_items, 'logs', v_logs, 'branch', v_branch, 'address', v_addr
  );
END;
$$;


--
-- Name: get_customer_orders(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_customer_orders(_phone text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  v_customer_id uuid;
  v_orders jsonb;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RETURN '[]'::jsonb; END IF;
  SELECT id INTO v_customer_id FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_customer_id IS NULL THEN RETURN '[]'::jsonb; END IF;

  SELECT COALESCE(jsonb_agg(o ORDER BY created_at DESC), '[]'::jsonb) INTO v_orders
  FROM (
    SELECT
      o.id, o.order_number, o.status, o.order_type, o.payment_method, o.payment_status,
      o.subtotal, o.vat_amount, o.delivery_fee, o.discount_amount, o.total_amount,
      o.created_at, o.branch_id, o.coupon_id,
      (SELECT to_jsonb(b) FROM public.branches b WHERE b.id = o.branch_id) AS branch,
      (SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'product_id', oi.product_id,
        'variant_id', oi.variant_id,
        'product_name', oi.product_name,
        'variant_name', oi.variant_name,
        'quantity', oi.quantity,
        'unit_price', oi.unit_price,
        'total_price', oi.total_price,
        'notes', oi.notes,
        'addons', (SELECT COALESCE(jsonb_agg(jsonb_build_object('addon_id', a.addon_id, 'addon_name', a.addon_name, 'price', a.price)), '[]'::jsonb) FROM public.order_item_addons a WHERE a.order_item_id = oi.id)
      )), '[]'::jsonb) FROM public.order_items oi WHERE oi.order_id = o.id) AS items
    FROM public.orders o
    WHERE o.customer_id = v_customer_id
    ORDER BY o.created_at DESC
    LIMIT 50
  ) o;

  RETURN v_orders;
END;
$$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE user_count INT;
BEGIN
  INSERT INTO public.profiles (id, full_name, phone)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'phone');
  SELECT COUNT(*) INTO user_count FROM auth.users;
  IF user_count = 1 THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  ELSE
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'staff');
  END IF;
  RETURN NEW;
END; $$;


--
-- Name: has_permission(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_permission(_user_id uuid, _perm_key text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles ur
    JOIN public.roles r ON r.key = ur.role::text
    JOIN public.role_permissions rp ON rp.role_id = r.id
    WHERE ur.user_id = _user_id AND rp.permission_key = _perm_key
  ) OR public.has_role(_user_id, 'admin'::app_role);
$$;


--
-- Name: has_role(uuid, public.app_role); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_role(_user_id uuid, _role public.app_role) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;


--
-- Name: is_customer_banned(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_customer_banned(_phone text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT COALESCE((SELECT status = 'banned' FROM public.customers WHERE phone = _phone LIMIT 1), false);
$$;


--
-- Name: is_manager(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_manager(_user_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('admin','manager'));
$$;


--
-- Name: log_order_status_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_order_status_change() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE v_cname text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    SELECT name INTO v_cname FROM public.customers WHERE id = NEW.customer_id;
    INSERT INTO public.order_status_logs (order_id, old_status, new_status, changed_by)
    VALUES (NEW.id, NULL, NEW.status, auth.uid());
    INSERT INTO public.notifications (title, message, type, action_url)
    VALUES (
      'طلب جديد',
      'طلب رقم ' || NEW.order_number || COALESCE(' من ' || v_cname, ''),
      'order_new',
      '/dashboard/orders/' || NEW.id
    );
  ELSIF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.order_status_logs (order_id, old_status, new_status, changed_by)
    VALUES (NEW.id, OLD.status, NEW.status, auth.uid());
    IF NEW.status = 'cancelled' THEN
      INSERT INTO public.notifications (title, message, type, action_url)
      VALUES ('طلب ملغي', 'تم إلغاء الطلب ' || NEW.order_number, 'order_cancelled', '/dashboard/orders/' || NEW.id);
    END IF;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: place_storefront_order(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.place_storefront_order(payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  v_customer_id uuid;
  v_customer_status customer_status;
  v_order_id uuid;
  v_order_number text;
  v_address_id uuid := NULL;
  v_item jsonb;
  v_oi_id uuid;
  v_addon jsonb;
  v_coupon RECORD;
  v_phone text := payload->'customer'->>'phone';
  v_name  text := payload->'customer'->>'name';
  v_email text := NULLIF(payload->'customer'->>'email','');
  v_branch RECORD;
  v_zone RECORD;
  v_settings RECORD;
  v_product RECORD;
  v_variant RECORD;
  v_addon_row RECORD;
  v_qty int;
  v_unit_price numeric;
  v_addons_total numeric;
  v_line_total numeric;
  v_subtotal numeric := 0;
  v_vat numeric := 0;
  v_delivery_fee numeric := 0;
  v_discount numeric := 0;
  v_total numeric := 0;
  v_taxable numeric := 0;
  v_vat_percent numeric := 15;
  v_min_order numeric := 0;
  v_pb_available boolean;
  v_used_count int;
  v_addr jsonb;
BEGIN
  -- Customer validation
  IF v_phone IS NULL OR length(v_phone) < 6 THEN RAISE EXCEPTION 'phone_required'; END IF;
  IF v_name IS NULL OR length(v_name) < 2 THEN RAISE EXCEPTION 'name_required'; END IF;

  SELECT id, status INTO v_customer_id, v_customer_status FROM public.customers WHERE phone = v_phone LIMIT 1;
  IF v_customer_id IS NULL THEN
    INSERT INTO public.customers (name, phone, email) VALUES (v_name, v_phone, v_email)
    RETURNING id INTO v_customer_id;
  ELSE
    IF v_customer_status = 'banned' THEN RAISE EXCEPTION 'customer_banned'; END IF;
    UPDATE public.customers SET name = v_name, email = COALESCE(v_email, email), updated_at = now() WHERE id = v_customer_id;
  END IF;

  -- Branch validation
  SELECT * INTO v_branch FROM public.branches WHERE id = NULLIF(payload->>'branch_id','')::uuid LIMIT 1;
  IF v_branch IS NULL THEN RAISE EXCEPTION 'branch_required'; END IF;
  IF NOT v_branch.is_active OR NOT v_branch.accepts_orders THEN RAISE EXCEPTION 'branch_not_accepting'; END IF;

  -- Settings (vat)
  SELECT * INTO v_settings FROM public.store_settings LIMIT 1;
  v_vat_percent := COALESCE(v_settings.vat_percent, 15);

  -- Items: items array required
  IF (payload->'items') IS NULL OR jsonb_array_length(payload->'items') = 0 THEN
    RAISE EXCEPTION 'cart_empty';
  END IF;

  -- Compute subtotal from DB-truth prices
  FOR v_item IN SELECT * FROM jsonb_array_elements(payload->'items') LOOP
    v_qty := GREATEST(1, COALESCE((v_item->>'quantity')::int, 1));

    SELECT * INTO v_product FROM public.products WHERE id = NULLIF(v_item->>'product_id','')::uuid;
    IF v_product IS NULL THEN RAISE EXCEPTION 'product_missing:%', v_item->>'product_name'; END IF;
    IF NOT v_product.is_available OR v_product.is_archived OR NOT v_product.show_in_store THEN
      RAISE EXCEPTION 'product_unavailable:%', v_product.name_ar;
    END IF;

    -- Branch availability if explicit row exists
    SELECT is_available INTO v_pb_available FROM public.product_branches
      WHERE product_id = v_product.id AND branch_id = v_branch.id LIMIT 1;
    IF v_pb_available IS NOT NULL AND v_pb_available = false THEN
      RAISE EXCEPTION 'product_unavailable_at_branch:%', v_product.name_ar;
    END IF;

    -- Variant resolution
    IF NULLIF(v_item->>'variant_id','') IS NOT NULL THEN
      SELECT * INTO v_variant FROM public.product_variants
        WHERE id = (v_item->>'variant_id')::uuid AND product_id = v_product.id LIMIT 1;
      IF v_variant IS NULL OR NOT v_variant.is_available THEN
        RAISE EXCEPTION 'variant_unavailable:%', v_product.name_ar;
      END IF;
      v_unit_price := v_variant.price;
    ELSE
      v_variant := NULL;
      v_unit_price := v_product.base_price;
    END IF;

    -- Addons
    v_addons_total := 0;
    IF (v_item->'addons') IS NOT NULL THEN
      FOR v_addon IN SELECT * FROM jsonb_array_elements(v_item->'addons') LOOP
        SELECT * INTO v_addon_row FROM public.product_addons
          WHERE id = NULLIF(v_addon->>'addon_id','')::uuid LIMIT 1;
        IF v_addon_row IS NULL OR NOT v_addon_row.is_available THEN
          RAISE EXCEPTION 'addon_unavailable:%', v_addon->>'addon_name';
        END IF;
        v_addons_total := v_addons_total + COALESCE(v_addon_row.price, 0);
      END LOOP;
    END IF;

    v_line_total := (v_unit_price + v_addons_total) * v_qty;
    v_subtotal := v_subtotal + v_line_total;
  END LOOP;

  -- Delivery fee
  IF (payload->>'order_type') = 'delivery' THEN
    IF NULLIF(payload->>'zone_id','') IS NOT NULL THEN
      SELECT * INTO v_zone FROM public.delivery_zones
        WHERE id = (payload->>'zone_id')::uuid AND status = 'active' LIMIT 1;
      IF v_zone IS NULL THEN RAISE EXCEPTION 'zone_invalid'; END IF;
      IF v_zone.branch_id IS NOT NULL AND v_zone.branch_id <> v_branch.id THEN
        RAISE EXCEPTION 'zone_branch_mismatch';
      END IF;
      v_delivery_fee := v_zone.delivery_fee;
      v_min_order := v_zone.minimum_order;
    ELSE
      v_delivery_fee := COALESCE(v_branch.delivery_fee, v_settings.delivery_fee, 0);
      v_min_order := COALESCE(v_branch.min_order_amount, v_settings.min_order_amount, 0);
    END IF;
    IF v_min_order > 0 AND v_subtotal < v_min_order THEN
      RAISE EXCEPTION 'below_min_order:%', v_min_order;
    END IF;
  END IF;

  -- Coupon
  IF NULLIF(payload->>'coupon_code','') IS NOT NULL THEN
    SELECT * INTO v_coupon FROM public.coupons WHERE code = payload->>'coupon_code' AND status = 'active' LIMIT 1;
    IF v_coupon IS NULL THEN RAISE EXCEPTION 'coupon_invalid'; END IF;
    IF v_coupon.start_date IS NOT NULL AND v_coupon.start_date > now() THEN RAISE EXCEPTION 'coupon_not_started'; END IF;
    IF v_coupon.end_date   IS NOT NULL AND v_coupon.end_date   < now() THEN RAISE EXCEPTION 'coupon_expired'; END IF;
    IF v_coupon.usage_limit IS NOT NULL AND v_coupon.used_count >= v_coupon.usage_limit THEN RAISE EXCEPTION 'coupon_used_up'; END IF;
    IF v_coupon.branch_id IS NOT NULL AND v_coupon.branch_id <> v_branch.id THEN RAISE EXCEPTION 'coupon_branch_mismatch'; END IF;
    IF v_coupon.minimum_order > 0 AND v_subtotal < v_coupon.minimum_order THEN RAISE EXCEPTION 'coupon_below_min'; END IF;
    IF v_coupon.usage_per_customer IS NOT NULL THEN
      SELECT COUNT(*) INTO v_used_count FROM public.coupon_usages WHERE coupon_id = v_coupon.id AND customer_id = v_customer_id;
      IF v_used_count >= v_coupon.usage_per_customer THEN RAISE EXCEPTION 'coupon_per_customer_exceeded'; END IF;
    END IF;

    IF v_coupon.discount_type = 'percent' THEN
      v_discount := v_subtotal * (v_coupon.discount_value / 100);
      IF v_coupon.maximum_discount IS NOT NULL THEN
        v_discount := LEAST(v_discount, v_coupon.maximum_discount);
      END IF;
    ELSIF v_coupon.discount_type = 'fixed' THEN
      v_discount := LEAST(v_coupon.discount_value, v_subtotal);
    ELSIF v_coupon.discount_type = 'free_delivery' THEN
      v_delivery_fee := 0;
      v_discount := 0;
    END IF;
  END IF;

  v_taxable := GREATEST(0, v_subtotal - v_discount);
  v_vat := round((v_taxable * (v_vat_percent / 100))::numeric, 2);
  v_total := round((v_taxable + v_vat + v_delivery_fee)::numeric, 2);

  -- Address
  IF (payload->'address') IS NOT NULL AND payload->>'order_type' = 'delivery' THEN
    INSERT INTO public.customer_addresses (
      customer_id, title, city, district, street, building, floor, apartment, landmark, driver_notes, latitude, longitude
    ) VALUES (
      v_customer_id,
      COALESCE(payload->'address'->>'title','عنوان التوصيل'),
      payload->'address'->>'city',
      payload->'address'->>'district',
      payload->'address'->>'street',
      payload->'address'->>'building',
      payload->'address'->>'floor',
      payload->'address'->>'apartment',
      payload->'address'->>'landmark',
      payload->'address'->>'driver_notes',
      NULLIF(payload->'address'->>'latitude','')::numeric,
      NULLIF(payload->'address'->>'longitude','')::numeric
    ) RETURNING id INTO v_address_id;
    SELECT to_jsonb(a) INTO v_addr FROM public.customer_addresses a WHERE a.id = v_address_id;
  END IF;

  -- Insert order with snapshots & DB-trusted totals
  INSERT INTO public.orders (
    customer_id, branch_id, order_type, payment_method, status,
    subtotal, vat_amount, delivery_fee, discount_amount, total_amount,
    customer_notes, delivery_address_id, coupon_id,
    customer_name, customer_phone, customer_email, branch_name, coupon_code, delivery_address_snapshot
  ) VALUES (
    v_customer_id, v_branch.id,
    COALESCE((payload->>'order_type')::order_type, 'delivery'),
    COALESCE((payload->>'payment_method')::payment_method, 'cash'),
    'new',
    v_subtotal, v_vat, v_delivery_fee, v_discount, v_total,
    NULLIF(payload->>'customer_notes',''), v_address_id, v_coupon.id,
    v_name, v_phone, v_email, v_branch.name, v_coupon.code, v_addr
  ) RETURNING id, order_number INTO v_order_id, v_order_number;

  -- Insert items + addons with DB-trusted prices
  FOR v_item IN SELECT * FROM jsonb_array_elements(payload->'items') LOOP
    v_qty := GREATEST(1, COALESCE((v_item->>'quantity')::int, 1));
    SELECT * INTO v_product FROM public.products WHERE id = (v_item->>'product_id')::uuid;

    IF NULLIF(v_item->>'variant_id','') IS NOT NULL THEN
      SELECT * INTO v_variant FROM public.product_variants WHERE id = (v_item->>'variant_id')::uuid;
      v_unit_price := v_variant.price;
    ELSE
      v_variant := NULL;
      v_unit_price := v_product.base_price;
    END IF;

    v_addons_total := 0;
    IF (v_item->'addons') IS NOT NULL THEN
      FOR v_addon IN SELECT * FROM jsonb_array_elements(v_item->'addons') LOOP
        SELECT * INTO v_addon_row FROM public.product_addons WHERE id = (v_addon->>'addon_id')::uuid;
        v_addons_total := v_addons_total + COALESCE(v_addon_row.price, 0);
      END LOOP;
    END IF;

    v_line_total := (v_unit_price + v_addons_total) * v_qty;

    INSERT INTO public.order_items (
      order_id, product_id, variant_id, product_name, variant_name, product_image,
      quantity, unit_price, total_price, notes
    ) VALUES (
      v_order_id, v_product.id,
      CASE WHEN v_variant IS NULL THEN NULL ELSE v_variant.id END,
      v_product.name_ar,
      CASE WHEN v_variant IS NULL THEN NULL ELSE v_variant.name_ar END,
      v_product.image_url,
      v_qty, v_unit_price, v_line_total, NULLIF(v_item->>'notes','')
    ) RETURNING id INTO v_oi_id;

    IF (v_item->'addons') IS NOT NULL THEN
      FOR v_addon IN SELECT * FROM jsonb_array_elements(v_item->'addons') LOOP
        SELECT * INTO v_addon_row FROM public.product_addons WHERE id = (v_addon->>'addon_id')::uuid;
        INSERT INTO public.order_item_addons (order_item_id, addon_id, addon_name, price)
        VALUES (v_oi_id, v_addon_row.id, v_addon_row.name_ar, v_addon_row.price);
      END LOOP;
    END IF;
  END LOOP;

  IF v_coupon.id IS NOT NULL THEN
    INSERT INTO public.coupon_usages (coupon_id, customer_id, order_id, discount_amount)
    VALUES (v_coupon.id, v_customer_id, v_order_id, v_discount);
    UPDATE public.coupons SET used_count = used_count + 1 WHERE id = v_coupon.id;
  END IF;

  RETURN jsonb_build_object('order_id', v_order_id, 'order_number', v_order_number, 'total_amount', v_total);
END;
$$;


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;


--
-- Name: touch_last_login(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.touch_last_login() RETURNS void
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  UPDATE public.profiles SET last_login_at = now() WHERE id = auth.uid();
$$;


--
-- Name: track_order(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.track_order(_order_number text, _phone text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  v_order RECORD;
  v_items jsonb;
  v_logs jsonb;
  v_branch jsonb;
BEGIN
  SELECT o.* INTO v_order
  FROM public.orders o
  JOIN public.customers c ON c.id = o.customer_id
  WHERE o.order_number = _order_number AND c.phone = _phone
  LIMIT 1;

  IF v_order IS NULL THEN RETURN NULL; END IF;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'product_name', oi.product_name,
    'variant_name', oi.variant_name,
    'quantity', oi.quantity,
    'total_price', oi.total_price
  )), '[]'::jsonb) INTO v_items FROM public.order_items oi WHERE oi.order_id = v_order.id;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'old_status', osl.old_status,
    'new_status', osl.new_status,
    'created_at', osl.created_at
  ) ORDER BY osl.created_at), '[]'::jsonb) INTO v_logs FROM public.order_status_logs osl WHERE osl.order_id = v_order.id;

  SELECT to_jsonb(b) INTO v_branch FROM public.branches b WHERE b.id = v_order.branch_id;

  RETURN jsonb_build_object(
    'order_number', v_order.order_number,
    'status', v_order.status,
    'order_type', v_order.order_type,
    'total_amount', v_order.total_amount,
    'created_at', v_order.created_at,
    'items', v_items,
    'logs', v_logs,
    'branch', v_branch
  );
END;
$$;


--
-- Name: update_customer_profile(text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_customer_profile(_phone text, _name text, _email text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE v_id uuid; v_status customer_status;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RAISE EXCEPTION 'phone_required'; END IF;
  IF _name IS NULL OR length(_name) < 2 THEN RAISE EXCEPTION 'name_required'; END IF;
  SELECT id, status INTO v_id, v_status FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_id IS NULL THEN
    INSERT INTO public.customers (name, phone, email) VALUES (_name, _phone, NULLIF(_email,''))
    RETURNING id INTO v_id;
  ELSE
    IF v_status = 'banned' THEN RAISE EXCEPTION 'customer_banned'; END IF;
    UPDATE public.customers SET name = _name, email = NULLIF(_email,''), updated_at = now() WHERE id = v_id;
  END IF;
  RETURN jsonb_build_object('id', v_id);
END;
$$;


--
-- Name: upsert_customer_address(text, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.upsert_customer_address(_phone text, _address jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE v_cid uuid; v_aid uuid; v_status customer_status; v_is_default boolean;
BEGIN
  IF _phone IS NULL OR length(_phone) < 6 THEN RAISE EXCEPTION 'phone_required'; END IF;
  SELECT id, status INTO v_cid, v_status FROM public.customers WHERE phone = _phone LIMIT 1;
  IF v_cid IS NULL THEN RAISE EXCEPTION 'customer_not_found'; END IF;
  IF v_status = 'banned' THEN RAISE EXCEPTION 'customer_banned'; END IF;

  v_is_default := COALESCE((_address->>'is_default')::boolean, false);
  v_aid := NULLIF(_address->>'id','')::uuid;

  IF v_aid IS NOT NULL THEN
    UPDATE public.customer_addresses SET
      title = _address->>'title', city = _address->>'city', district = _address->>'district',
      street = _address->>'street', building = _address->>'building',
      floor = _address->>'floor', apartment = _address->>'apartment',
      landmark = _address->>'landmark', driver_notes = _address->>'driver_notes',
      latitude = NULLIF(_address->>'latitude','')::numeric, longitude = NULLIF(_address->>'longitude','')::numeric,
      is_default = v_is_default
    WHERE id = v_aid AND customer_id = v_cid;
  ELSE
    INSERT INTO public.customer_addresses (customer_id, title, city, district, street, building, floor, apartment, landmark, driver_notes, latitude, longitude, is_default)
    VALUES (v_cid, _address->>'title', _address->>'city', _address->>'district',
      _address->>'street', _address->>'building', _address->>'floor', _address->>'apartment',
      _address->>'landmark', _address->>'driver_notes',
      NULLIF(_address->>'latitude','')::numeric, NULLIF(_address->>'longitude','')::numeric, v_is_default)
    RETURNING id INTO v_aid;
  END IF;

  IF v_is_default THEN
    UPDATE public.customer_addresses SET is_default = false WHERE customer_id = v_cid AND id <> v_aid;
  END IF;

  RETURN jsonb_build_object('id', v_aid);
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    action text NOT NULL,
    entity text,
    entity_id uuid,
    payload jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    module text,
    description text,
    old_values jsonb,
    new_values jsonb,
    ip_address text,
    user_agent text
);


--
-- Name: addon_group_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.addon_group_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    group_id uuid NOT NULL,
    product_id uuid,
    category_id uuid,
    CONSTRAINT addon_group_links_check CHECK (((product_id IS NOT NULL) OR (category_id IS NOT NULL)))
);


--
-- Name: addon_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.addon_groups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name_ar text NOT NULL,
    name_en text,
    is_required boolean DEFAULT false NOT NULL,
    min_select integer DEFAULT 0 NOT NULL,
    max_select integer DEFAULT 1 NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    app_name text,
    app_store_url text,
    google_play_url text,
    current_version text,
    minimum_version text,
    force_update boolean DEFAULT false NOT NULL,
    maintenance_mode boolean DEFAULT false NOT NULL,
    maintenance_message text,
    push_settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    home_layout jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: banners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.banners (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    subtitle text,
    image_url text,
    cta_text text,
    cta_url text,
    link_type public.banner_link_type DEFAULT 'none'::public.banner_link_type NOT NULL,
    link_value text,
    placement public.banner_placement DEFAULT 'home'::public.banner_placement NOT NULL,
    platform public.platform_target DEFAULT 'both'::public.platform_target NOT NULL,
    status public.banner_status DEFAULT 'active'::public.banner_status NOT NULL,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    image_only boolean DEFAULT false NOT NULL
);


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    phone text,
    address text,
    latitude numeric(10,6),
    longitude numeric(10,6),
    business_hours jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true NOT NULL,
    accepts_orders boolean DEFAULT true NOT NULL,
    delivery_radius_km numeric(6,2) DEFAULT 10,
    delivery_fee numeric(10,2) DEFAULT 0,
    min_order_amount numeric(10,2) DEFAULT 0,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text,
    message text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: coupon_usages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coupon_usages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    coupon_id uuid NOT NULL,
    customer_id uuid,
    order_id uuid,
    discount_amount numeric DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: coupons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coupons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    discount_type public.coupon_discount_type NOT NULL,
    discount_value numeric DEFAULT 0 NOT NULL,
    minimum_order numeric DEFAULT 0 NOT NULL,
    maximum_discount numeric,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    usage_limit integer,
    usage_per_customer integer DEFAULT 1,
    status public.coupon_status DEFAULT 'active'::public.coupon_status NOT NULL,
    branch_id uuid,
    product_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    category_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    used_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_addresses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    customer_id uuid NOT NULL,
    title text,
    city text,
    district text,
    street text,
    building text,
    landmark text,
    latitude numeric,
    longitude numeric,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    floor text,
    apartment text,
    driver_notes text
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text,
    status public.customer_status DEFAULT 'active'::public.customer_status NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login_at timestamp with time zone
);


--
-- Name: delivery_zones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_zones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    branch_id uuid,
    name text NOT NULL,
    delivery_fee numeric DEFAULT 0 NOT NULL,
    minimum_order numeric DEFAULT 0 NOT NULL,
    estimated_time_minutes integer DEFAULT 30,
    status public.zone_status DEFAULT 'active'::public.zone_status NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: drivers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drivers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text,
    avatar_url text,
    branch_id uuid,
    national_id text,
    vehicle_type text,
    plate_number text,
    status public.driver_status DEFAULT 'offline'::public.driver_status NOT NULL,
    rating numeric DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    last_active_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: faqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faqs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    category text,
    status public.publish_status DEFAULT 'published'::public.publish_status NOT NULL,
    show_in_faq boolean DEFAULT true NOT NULL,
    show_in_product boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: footer_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.footer_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    logo_url text,
    about_text text,
    phone text,
    email text,
    address text,
    working_hours text,
    copyright_text text,
    app_store_url text,
    google_play_url text,
    social_links jsonb DEFAULT '{}'::jsonb NOT NULL,
    visible_sections jsonb DEFAULT '{"apps": true, "about": true, "links": true, "social": true, "contact": true}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: header_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.header_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    logo_url text,
    show_logo boolean DEFAULT true NOT NULL,
    cta_text text,
    cta_url text,
    contact_phone text,
    show_search boolean DEFAULT true NOT NULL,
    show_cart boolean DEFAULT true NOT NULL,
    show_login boolean DEFAULT true NOT NULL,
    show_branch_selector boolean DEFAULT true NOT NULL,
    show_cta boolean DEFAULT true NOT NULL,
    app_overrides jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: hero_slides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hero_slides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    subtitle text,
    image_url text,
    cta_text text,
    cta_url text,
    platform public.platform_target DEFAULT 'both'::public.platform_target NOT NULL,
    text_color text DEFAULT '#ffffff'::text,
    text_alignment public.text_alignment DEFAULT 'start'::public.text_alignment NOT NULL,
    status public.banner_status DEFAULT 'active'::public.banner_status NOT NULL,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    image_only boolean DEFAULT false NOT NULL
);


--
-- Name: home_section_banners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.home_section_banners (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    section_id uuid,
    "position" public.home_banner_position DEFAULT 'standalone'::public.home_banner_position NOT NULL,
    anchor_section_id uuid,
    image_mobile text,
    image_tablet text,
    image_desktop text,
    title text,
    subtitle text,
    link_type public.home_banner_link_type DEFAULT 'none'::public.home_banner_link_type NOT NULL,
    link_value text,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: home_sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.home_sections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title_ar text DEFAULT ''::text NOT NULL,
    title_en text DEFAULT ''::text,
    section_type public.home_section_type NOT NULL,
    display_style public.home_display_style DEFAULT 'grid'::public.home_display_style NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    category_id uuid,
    manual_product_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    products_limit integer DEFAULT 6 NOT NULL,
    show_view_all boolean DEFAULT true NOT NULL,
    view_all_url text,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    filename text,
    summary jsonb DEFAULT '{}'::jsonb,
    errors jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: integrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.integrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider text NOT NULL,
    name text NOT NULL,
    status public.publish_status DEFAULT 'inactive'::public.publish_status NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_tested_at timestamp with time zone,
    last_test_status public.integration_test_status DEFAULT 'untested'::public.integration_test_status NOT NULL,
    last_test_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: navigation_menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.navigation_menu_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    menu_id uuid NOT NULL,
    title text NOT NULL,
    link_type public.banner_link_type DEFAULT 'page'::public.banner_link_type NOT NULL,
    link_value text,
    parent_id uuid,
    sort_order integer DEFAULT 0 NOT NULL,
    status public.publish_status DEFAULT 'published'::public.publish_status NOT NULL,
    open_in_new_tab boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: navigation_menus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.navigation_menus (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    location public.menu_location NOT NULL,
    status public.publish_status DEFAULT 'published'::public.publish_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    orders_enabled boolean DEFAULT true NOT NULL,
    drivers_enabled boolean DEFAULT true NOT NULL,
    inventory_enabled boolean DEFAULT true NOT NULL,
    integrations_enabled boolean DEFAULT true NOT NULL,
    email_enabled boolean DEFAULT false NOT NULL,
    push_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    message text,
    type text DEFAULT 'info'::text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    action_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid
);


--
-- Name: order_item_addons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_item_addons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_item_id uuid NOT NULL,
    addon_id uuid,
    addon_name text NOT NULL,
    price numeric DEFAULT 0 NOT NULL
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    product_id uuid,
    variant_id uuid,
    product_name text NOT NULL,
    variant_name text,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric DEFAULT 0 NOT NULL,
    total_price numeric DEFAULT 0 NOT NULL,
    notes text,
    product_image text
);


--
-- Name: order_status_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_status_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    old_status public.order_status,
    new_status public.order_status NOT NULL,
    changed_by uuid,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: orders_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_number_seq
    START WITH 10001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_number text DEFAULT ('ORD-'::text || nextval('public.orders_number_seq'::regclass)) NOT NULL,
    customer_id uuid,
    branch_id uuid,
    driver_id uuid,
    order_type public.order_type DEFAULT 'delivery'::public.order_type NOT NULL,
    status public.order_status DEFAULT 'new'::public.order_status NOT NULL,
    payment_method public.payment_method DEFAULT 'cash'::public.payment_method NOT NULL,
    payment_status public.payment_status DEFAULT 'pending'::public.payment_status NOT NULL,
    subtotal numeric DEFAULT 0 NOT NULL,
    vat_amount numeric DEFAULT 0 NOT NULL,
    delivery_fee numeric DEFAULT 0 NOT NULL,
    discount_amount numeric DEFAULT 0 NOT NULL,
    total_amount numeric DEFAULT 0 NOT NULL,
    customer_notes text,
    admin_notes text,
    delivery_address_id uuid,
    coupon_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_name text,
    customer_phone text,
    customer_email text,
    branch_name text,
    coupon_code text,
    delivery_address_snapshot jsonb,
    estimated_preparation_time integer,
    estimated_delivery_time integer
);


--
-- Name: page_blocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.page_blocks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    page_id uuid,
    location text,
    block_type text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content text,
    featured_image text,
    status public.publish_status DEFAULT 'draft'::public.publish_status NOT NULL,
    show_in_header boolean DEFAULT false NOT NULL,
    show_in_footer boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    module text NOT NULL,
    name text NOT NULL,
    description text
);


--
-- Name: product_addons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_addons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    group_id uuid NOT NULL,
    name_ar text NOT NULL,
    name_en text,
    price numeric(10,2) DEFAULT 0 NOT NULL,
    is_available boolean DEFAULT true NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_branches (
    product_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    is_available boolean DEFAULT true NOT NULL
);


--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name_ar text NOT NULL,
    name_en text,
    image_url text,
    icon text,
    parent_id uuid,
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    show_on_home boolean DEFAULT true NOT NULL,
    show_in_app boolean DEFAULT true NOT NULL,
    show_in_store boolean DEFAULT true NOT NULL,
    is_featured boolean DEFAULT false NOT NULL,
    home_product_limit integer DEFAULT 8 NOT NULL
);


--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    name_ar text NOT NULL,
    name_en text,
    price numeric(10,2) DEFAULT 0 NOT NULL,
    calories integer,
    sku text,
    is_available boolean DEFAULT true NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name_ar text NOT NULL,
    name_en text,
    description_ar text,
    description_en text,
    image_url text,
    category_id uuid,
    base_price numeric(10,2) DEFAULT 0 NOT NULL,
    calories integer,
    prep_time_minutes integer,
    is_available boolean DEFAULT true NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    show_in_app boolean DEFAULT true NOT NULL,
    show_in_store boolean DEFAULT true NOT NULL,
    is_featured boolean DEFAULT false NOT NULL,
    is_archived boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    gallery_urls text[] DEFAULT '{}'::text[] NOT NULL,
    discount_price numeric
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    full_name text,
    phone text,
    avatar_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    status public.user_status DEFAULT 'active'::public.user_status NOT NULL,
    last_login_at timestamp with time zone
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_id uuid NOT NULL,
    permission_key text NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: security_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    device text,
    browser text,
    ip_address text,
    user_agent text,
    last_activity_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: seo_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seo_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type public.seo_entity_type NOT NULL,
    entity_id uuid,
    meta_title text,
    meta_description text,
    meta_keywords text,
    slug text,
    canonical_url text,
    og_title text,
    og_description text,
    og_image text,
    twitter_title text,
    twitter_description text,
    twitter_image text,
    robots_index boolean DEFAULT true NOT NULL,
    robots_follow boolean DEFAULT true NOT NULL,
    default_og_image text,
    default_twitter_image text,
    google_verification text,
    sitemap_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: store_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.store_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text,
    logo_url text,
    primary_color text DEFAULT '#ED1C24'::text,
    secondary_color text DEFAULT '#F97316'::text,
    phone text,
    email text,
    address text,
    currency text DEFAULT 'SAR'::text NOT NULL,
    vat_percent numeric(5,2) DEFAULT 15 NOT NULL,
    delivery_fee numeric(10,2) DEFAULT 0 NOT NULL,
    min_order_amount numeric(10,2) DEFAULT 0 NOT NULL,
    business_hours jsonb DEFAULT '{}'::jsonb,
    accepting_orders boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_branches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role public.app_role NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: webhook_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    webhook_id uuid NOT NULL,
    event text NOT NULL,
    payload jsonb,
    response_status integer,
    response_body text,
    attempt_count integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    secret text,
    events text[] DEFAULT '{}'::text[] NOT NULL,
    status public.webhook_status DEFAULT 'active'::public.webhook_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_logs (id, user_id, action, entity, entity_id, payload, created_at, module, description, old_values, new_values, ip_address, user_agent) FROM stdin;
42b83ded-8224-4544-ae68-978d66c99e17	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_settings	store_settings	\N	{"name": "عصير تايم"}	2026-05-07 12:55:13.06159+00	\N	\N	\N	\N	\N	\N
8b24059b-730b-4550-8c02-26f7339801d8	3ccd7385-a949-4ba4-9eb9-32909c1061c0	create_branch	branches	5b7dba03-d5e4-401e-af16-ff426261c5ff	{"name": "الخبر"}	2026-05-07 13:25:31.828806+00	\N	\N	\N	\N	\N	\N
826c929a-38f2-44d5-8dc7-8bc35f1d7d6c	3ccd7385-a949-4ba4-9eb9-32909c1061c0	create_product	products	791e712c-b048-4b8f-8ebf-8f55b116dc20	{"name": "تجربة"}	2026-05-07 15:21:59.831831+00	\N	\N	\N	\N	\N	\N
41875d5e-9367-44bf-bd3f-395c7dc3eed3	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_product	products	2c4645e5-3045-4bbd-8c8b-901496be3ab7	{"name": "فراوله شوكلت 30 حبه"}	2026-05-07 15:22:23.688354+00	\N	\N	\N	\N	\N	\N
b273cea0-35cf-44a2-ac4d-ad84a3482ac3	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6d505b5c-bba0-40d5-b46b-ec04a9a4f6d9	{"name": "فراوله شوكلت 6 حبه"}	2026-05-08 09:56:32.86685+00	\N	\N	\N	\N	\N	\N
f0231aa9-784c-450e-9504-b44c7df5cb07	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2c4645e5-3045-4bbd-8c8b-901496be3ab7	{"name": "فراوله شوكلت 30 حبه"}	2026-05-08 09:58:30.36296+00	\N	\N	\N	\N	\N	\N
b661aac2-e9d8-4ee8-80ee-28ef0c9ff1ef	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2c4645e5-3045-4bbd-8c8b-901496be3ab7	{"name": "فراوله شوكلت 30 حبه"}	2026-05-08 09:58:30.364053+00	\N	\N	\N	\N	\N	\N
663d250e-792c-4782-880b-e74c30a24b01	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3bcc5e6d-c7a5-4f99-ad35-60eba1df0ab6	{"name": "فراوله شوكلت 2 حبه"}	2026-05-08 09:59:26.794644+00	\N	\N	\N	\N	\N	\N
1e4d4a8a-b9d9-497c-a8c1-c1cf72dc1c10	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3bcc5e6d-c7a5-4f99-ad35-60eba1df0ab6	{"name": "فراوله شوكلت 2 حبه"}	2026-05-08 09:59:29.796721+00	\N	\N	\N	\N	\N	\N
03b61820-52d0-41c4-9a47-64a4737ed759	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3bcc5e6d-c7a5-4f99-ad35-60eba1df0ab6	{"name": "فراوله شوكلت 2 حبه"}	2026-05-08 09:59:29.797896+00	\N	\N	\N	\N	\N	\N
10adf685-aa4e-4472-85e0-757df2763ce7	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d4542fad-3ffd-467c-85b3-7e70caec14ee	{"name": "فراوله شوكلت 4 حبه"}	2026-05-08 10:00:12.463811+00	\N	\N	\N	\N	\N	\N
94131b28-0c6d-43cf-b9b7-4fcd9bf545d6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	24153a9d-3a42-4d72-af56-2b4cf0005cc8	{"name": "شوكلت الهبة بيستاشيو"}	2026-05-08 10:02:35.782472+00	\N	\N	\N	\N	\N	\N
9a2004ba-7e60-411a-b0b5-cd7749b1b9dc	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	24153a9d-3a42-4d72-af56-2b4cf0005cc8	{"name": "شوكلت الهبة بيستاشيو"}	2026-05-08 10:02:35.783678+00	\N	\N	\N	\N	\N	\N
52f0cf74-b987-4239-a1b6-83503e467e0b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	24153a9d-3a42-4d72-af56-2b4cf0005cc8	{"name": "شوكلت الهبة بيستاشيو"}	2026-05-08 10:02:36.946718+00	\N	\N	\N	\N	\N	\N
7a366d0d-1500-4e52-b7fe-3c3408c15498	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3bcc5e6d-c7a5-4f99-ad35-60eba1df0ab6	{"name": "فراوله شوكلت 2 حبه"}	2026-05-08 10:02:47.839924+00	\N	\N	\N	\N	\N	\N
99b7c525-4f29-4d92-9dea-afd7a26b4d26	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	cf11c2a8-c403-4200-a194-878483b04543	{"name": "شوكلت الهبه بيكان"}	2026-05-08 10:04:04.488671+00	\N	\N	\N	\N	\N	\N
806fd400-7aa8-4453-a21b-25f6d2b4652b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	b341cb22-da24-4701-8114-9678b70cd599	{"name": "شوكلت الهبة كندر"}	2026-05-08 10:08:32.126703+00	\N	\N	\N	\N	\N	\N
fd8e2d18-62f0-4ce8-b90e-00c46bb1238c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2bc7ef25-2825-4386-9493-5949b653484e	{"name": "كريب بيستاشيو كنافه"}	2026-05-08 10:14:25.530665+00	\N	\N	\N	\N	\N	\N
05e6c6f8-bb61-411d-bb2f-fa95a5c1ca78	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2bc7ef25-2825-4386-9493-5949b653484e	{"name": "كريب بيستاشيو كنافه"}	2026-05-08 10:14:26.389902+00	\N	\N	\N	\N	\N	\N
41a32157-bd90-4d3b-8174-4bb79ff8a228	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0e162232-3842-4d79-a57f-4771b3991ade	{"name": "تكميم بيستاشيو كنافه"}	2026-05-08 10:14:52.720296+00	\N	\N	\N	\N	\N	\N
d3e76aef-578a-47cd-a8c5-2725123bb487	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	00bef6b0-9696-46a7-add1-fcee8f709e7b	{"name": "ميني بانكيك بيستاشيو كنافه"}	2026-05-08 10:16:31.090408+00	\N	\N	\N	\N	\N	\N
e2c673e8-c80f-43a0-8cd1-ebf724d1c015	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	00bef6b0-9696-46a7-add1-fcee8f709e7b	{"name": "ميني بانكيك بيستاشيو كنافه"}	2026-05-08 10:16:31.381374+00	\N	\N	\N	\N	\N	\N
9726ea31-3f74-43aa-9339-25e98a23c7f1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	adec2363-eafe-4b55-88f7-a30712702e2d	{"name": "بوكس فراولة 15حبه"}	2026-05-08 10:21:31.947734+00	\N	\N	\N	\N	\N	\N
e55604eb-a59c-4e28-a262-1fb5f9f5c8e5	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	adec2363-eafe-4b55-88f7-a30712702e2d	{"name": "بوكس فراولة 15حبه"}	2026-05-08 10:21:31.947734+00	\N	\N	\N	\N	\N	\N
5178829d-76b7-4570-90d3-63c750d323d1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	adec2363-eafe-4b55-88f7-a30712702e2d	{"name": "بوكس فراولة 15حبه"}	2026-05-08 10:23:34.49582+00	\N	\N	\N	\N	\N	\N
253c0cb2-a86f-4ab0-bd9c-fc57cddf055d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c13f7d8c-fef4-474d-96c6-4e8ba890912c	{"name": "ميكس بيري صغير"}	2026-05-08 10:26:56.024007+00	\N	\N	\N	\N	\N	\N
f381c408-09d0-4907-a8b1-eed8976ce3bd	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c13f7d8c-fef4-474d-96c6-4e8ba890912c	{"name": "ميكس بيري صغير"}	2026-05-08 10:26:56.935515+00	\N	\N	\N	\N	\N	\N
e79b1960-1d7e-4b2e-bb01-5345aee367f4	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c13f7d8c-fef4-474d-96c6-4e8ba890912c	{"name": "ميكس بيري صغير"}	2026-05-08 10:30:26.216841+00	\N	\N	\N	\N	\N	\N
5afbdad4-59d0-44ea-865c-8221ebc103bd	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c13f7d8c-fef4-474d-96c6-4e8ba890912c	{"name": "ميكس بيري صغير"}	2026-05-08 10:30:27.791026+00	\N	\N	\N	\N	\N	\N
9155c112-b323-499b-aaa4-cc273d3471bf	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c13f7d8c-fef4-474d-96c6-4e8ba890912c	{"name": "ميكس بيري صغير"}	2026-05-08 10:30:27.792427+00	\N	\N	\N	\N	\N	\N
9c57c479-5ef5-4376-92a2-24e43ce78c53	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c13f7d8c-fef4-474d-96c6-4e8ba890912c	{"name": "ميكس بيري صغير"}	2026-05-08 10:30:27.795126+00	\N	\N	\N	\N	\N	\N
e27f35b9-fc1d-4712-b873-00d5b865cfe3	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2857d3c3-28fd-4fe6-868a-ef414c0a420f	{"name": "ميكس بيري كبير"}	2026-05-08 10:30:34.366228+00	\N	\N	\N	\N	\N	\N
2317d760-b78b-4d41-80cb-b42a58e67f90	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2857d3c3-28fd-4fe6-868a-ef414c0a420f	{"name": "ميكس بيري كبير"}	2026-05-08 10:30:34.881401+00	\N	\N	\N	\N	\N	\N
b63f9bf7-1cf5-4756-8d2c-58ff700c43f4	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f90c3589-9613-44be-a0ad-0fbae51bdada	{"name": "بوكس البطريق"}	2026-05-08 10:32:22.232278+00	\N	\N	\N	\N	\N	\N
532195cd-7eeb-4b28-8c2d-7577db36d84b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f90c3589-9613-44be-a0ad-0fbae51bdada	{"name": "بوكس البطريق"}	2026-05-08 10:32:22.230298+00	\N	\N	\N	\N	\N	\N
82d464f5-996f-4cce-8e77-4e0cc821bc42	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f90c3589-9613-44be-a0ad-0fbae51bdada	{"name": "بوكس البطريق"}	2026-05-08 10:32:22.802351+00	\N	\N	\N	\N	\N	\N
6538362b-22a8-463f-b9c3-3a4ea71857e7	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	5b6f7632-16b0-4d9c-a9a3-2bd24de404a4	{"name": "المسافر صفر صغير"}	2026-05-08 10:35:35.214764+00	\N	\N	\N	\N	\N	\N
ffe57d29-f3ea-4ba9-839b-e63e17ce9b3f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	5b6f7632-16b0-4d9c-a9a3-2bd24de404a4	{"name": "المسافر صفر صغير"}	2026-05-08 10:35:35.213278+00	\N	\N	\N	\N	\N	\N
5c3490cd-0eca-4627-9ab4-6132bc5cad1f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	5b6f7632-16b0-4d9c-a9a3-2bd24de404a4	{"name": "المسافر صفر صغير"}	2026-05-08 10:35:35.617851+00	\N	\N	\N	\N	\N	\N
90b73bde-291c-489f-aee7-68efdadea87c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	bf6a1af1-30f8-48f9-97c8-12732d5dc450	{"name": "المسافر صفر كبير"}	2026-05-08 10:36:07.403975+00	\N	\N	\N	\N	\N	\N
43756c1f-7f22-4950-95c1-bcf6868f4f54	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	bf6a1af1-30f8-48f9-97c8-12732d5dc450	{"name": "المسافر صفر كبير"}	2026-05-08 10:36:08.539241+00	\N	\N	\N	\N	\N	\N
d02d4f07-6d94-492e-98cf-499e273abf23	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	bf6a1af1-30f8-48f9-97c8-12732d5dc450	{"name": "المسافر صفر كبير"}	2026-05-08 10:36:08.542493+00	\N	\N	\N	\N	\N	\N
7c6882c9-2655-4d1b-b8e4-6f7a59d9cbd6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	956ec9b0-3b0b-4a29-adda-6542199d90e0	{"name": "ابو ريان 10 قطع"}	2026-05-08 11:18:58.472103+00	\N	\N	\N	\N	\N	\N
a0455f56-4a23-4254-b50f-60d0b9c3aee7	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	956ec9b0-3b0b-4a29-adda-6542199d90e0	{"name": "ابو ريان 10 قطع"}	2026-05-08 11:18:58.989942+00	\N	\N	\N	\N	\N	\N
6f508fb4-d5a4-42af-80f8-6fe2dddfc765	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	956ec9b0-3b0b-4a29-adda-6542199d90e0	{"name": "ابو ريان 10 قطع"}	2026-05-08 11:19:00.732329+00	\N	\N	\N	\N	\N	\N
8b50f0b8-cf2e-4318-96fa-175a01c2a08e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	80fdb0f6-4a57-4bbd-a0e1-f5b5696216c7	{"name": "ابو ريان 6 قطع"}	2026-05-08 11:19:21.010562+00	\N	\N	\N	\N	\N	\N
af91f33a-85a0-40b8-bc2b-e85a7a4c8e3f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	48551444-cbb4-4226-8f1e-1fe9441f2797	{"name": "كندر بيري 5حبات"}	2026-05-08 11:23:55.075922+00	\N	\N	\N	\N	\N	\N
d8afac1e-6024-4a01-8937-bea36162ad75	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	76e26027-271d-4148-8ecc-8a02dfe9c68d	{"name": "ماكنتوش السعادة"}	2026-05-08 11:25:42.104683+00	\N	\N	\N	\N	\N	\N
310babea-8006-460f-9444-065678debc4e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f90c3589-9613-44be-a0ad-0fbae51bdada	{"name": "بوكس البطريق"}	2026-05-08 11:26:39.03687+00	\N	\N	\N	\N	\N	\N
09b7bd37-1302-431a-ba2f-73c6e70a221c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f90c3589-9613-44be-a0ad-0fbae51bdada	{"name": "بوكس البطريق"}	2026-05-08 11:26:39.037527+00	\N	\N	\N	\N	\N	\N
715f1dc9-2bd6-4a21-b47d-23c07ef4005f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	08b275dc-222c-4db0-9d8d-b69b02dbcb83	{"name": "تكميم بستاشيو"}	2026-05-08 11:28:42.126425+00	\N	\N	\N	\N	\N	\N
c2edd80e-109e-4e13-a227-727c9b6bcc6b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d26a88ea-6416-4a68-abd5-f1e322ba4709	{"name": "تكميم نوتيلا"}	2026-05-08 11:29:36.440688+00	\N	\N	\N	\N	\N	\N
34c7da33-3492-4d94-b5b7-e995adc8be8d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	bbae31ac-df6f-4475-b54f-4dc1e225de92	{"name": "تكميم ميكس"}	2026-05-08 11:30:44.128686+00	\N	\N	\N	\N	\N	\N
ba0dd79c-2c9e-47aa-93b8-1acbaa8d3cee	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f06abf8f-b76e-4b40-b3cd-f38c59dc8fd8	{"name": "تكميم باندا"}	2026-05-08 11:31:46.746819+00	\N	\N	\N	\N	\N	\N
34cdd1f1-4e50-4cbd-9a6f-b1d799e653d7	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f06abf8f-b76e-4b40-b3cd-f38c59dc8fd8	{"name": "تكميم باندا"}	2026-05-08 11:31:47.072847+00	\N	\N	\N	\N	\N	\N
c96a9b75-4cd5-4698-a232-8877ed69c7de	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e7f3cecc-3422-4752-a265-d69ef8c68c43	{"name": "تكميم لوتس"}	2026-05-08 11:32:51.189669+00	\N	\N	\N	\N	\N	\N
478216e8-b774-4af3-8b82-3fa3fad43ed6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8c4f4f1d-7626-4c97-bd22-ac001677d4e5	{"name": "تكميم كندر"}	2026-05-08 11:34:21.275962+00	\N	\N	\N	\N	\N	\N
77a51577-1074-42aa-9c0a-e789141a1205	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	b11f08ed-6c62-466b-914f-e16b852dc89a	{"name": "بانكيك اجرام"}	2026-05-08 11:35:47.996041+00	\N	\N	\N	\N	\N	\N
da2c8f9b-c947-4078-b40c-3b4383d64b10	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	86205c10-47cb-4dc8-a818-02d5bcd51d0a	{"name": "وافل كندر"}	2026-05-08 11:36:38.578774+00	\N	\N	\N	\N	\N	\N
94a0839d-208c-4c84-b1b3-e7c57723b5c2	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	52f6cd1e-d5f1-4241-885e-4d2a7617ea57	{"name": "حلا غرقني"}	2026-05-08 11:39:08.233948+00	\N	\N	\N	\N	\N	\N
f82e686c-0876-4afd-83de-2a750d31fdbb	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c2acfacd-5adc-4a13-ab8e-84dd8ffa8918	{"name": "غرقني بيستاشيو"}	2026-05-08 11:39:47.436978+00	\N	\N	\N	\N	\N	\N
07582ae5-c24c-4d8d-98b1-a1facdb73d4c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c2acfacd-5adc-4a13-ab8e-84dd8ffa8918	{"name": "غرقني بيستاشيو"}	2026-05-08 11:39:48.058051+00	\N	\N	\N	\N	\N	\N
3c7193b8-4a06-4251-8bed-2d58ba41e03a	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	108d6793-0f05-40e1-a302-b4385a5cdcea	{"name": "وافل بيستاشيو"}	2026-05-08 11:41:29.005849+00	\N	\N	\N	\N	\N	\N
e40799bd-0c80-448e-86ad-f82cfb5c9820	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	96acb5c7-f699-417a-81ba-5ee2b2a41bce	{"name": "وافل ميكس"}	2026-05-08 11:42:11.104488+00	\N	\N	\N	\N	\N	\N
9777b075-61f0-463d-9c7b-5623f580e89c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	96acb5c7-f699-417a-81ba-5ee2b2a41bce	{"name": "وافل ميكس"}	2026-05-08 11:42:12.430605+00	\N	\N	\N	\N	\N	\N
deb2bf26-6fd6-45aa-84e1-5fbbffb14527	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ada4c01b-2dc8-4e7d-b5a9-ca60f8580aea	{"name": "وافل لوتس"}	2026-05-08 11:43:04.534183+00	\N	\N	\N	\N	\N	\N
2d9776bf-c4a1-4863-bc55-d065deba90ea	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ada4c01b-2dc8-4e7d-b5a9-ca60f8580aea	{"name": "وافل لوتس"}	2026-05-08 11:43:05.021442+00	\N	\N	\N	\N	\N	\N
643e72d2-9c16-47fe-a146-fbfad231a2fa	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ada4c01b-2dc8-4e7d-b5a9-ca60f8580aea	{"name": "وافل لوتس"}	2026-05-08 11:43:05.02329+00	\N	\N	\N	\N	\N	\N
e004464d-1ce5-42d6-bb6a-b712baaaf5e5	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ada4c01b-2dc8-4e7d-b5a9-ca60f8580aea	{"name": "وافل لوتس"}	2026-05-08 11:43:05.024863+00	\N	\N	\N	\N	\N	\N
3add59a6-aefe-4de0-aea4-96ce92d7de9b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	bc2d92f7-09b3-4b74-b720-3a0104e5c13c	{"name": "وافل نوتيلا"}	2026-05-08 11:43:35.21981+00	\N	\N	\N	\N	\N	\N
34402bdb-55ef-461f-af66-1ff9f9d7edfe	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f598dd9d-aa20-4b77-8339-2ae2faed6c20	{"name": "كريب بيستاشيو"}	2026-05-08 11:44:16.796962+00	\N	\N	\N	\N	\N	\N
edb39f49-6b53-4086-9728-d5cd5b0eb310	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	83a86b6e-b544-4fb0-9d05-29348af32992	{"name": "كريب فوتشيني"}	2026-05-08 11:46:46.706503+00	\N	\N	\N	\N	\N	\N
4e28d1e8-de6f-4397-83bf-fd1d49afc2e9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	83a86b6e-b544-4fb0-9d05-29348af32992	{"name": "كريب فوتشيني"}	2026-05-08 11:46:46.706362+00	\N	\N	\N	\N	\N	\N
8835c9d1-1d2c-4e58-9c85-f4416606f0e1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	5b2f29c4-e151-43bf-a737-5bbf7736ad6e	{"name": "كريب كندر"}	2026-05-08 11:47:07.254191+00	\N	\N	\N	\N	\N	\N
a617cc10-58d4-47de-8615-4ff340a25360	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	5b2f29c4-e151-43bf-a737-5bbf7736ad6e	{"name": "كريب كندر"}	2026-05-08 11:47:07.935105+00	\N	\N	\N	\N	\N	\N
e8207587-cb01-40f5-a199-fbf349f8dad8	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	297a457a-8f31-4535-9717-4bcfaa204da1	{"name": "كريب ميكس"}	2026-05-08 11:47:27.851619+00	\N	\N	\N	\N	\N	\N
51468c21-62b1-4e99-a9db-06b262374f16	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e95098e0-34e3-4528-984f-cf62247b6369	{"name": "بانكيك بيستاشيو"}	2026-05-08 11:48:40.789831+00	\N	\N	\N	\N	\N	\N
fe8e0aba-3cd7-42fc-b7f3-aeb5c55ac41e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e95098e0-34e3-4528-984f-cf62247b6369	{"name": "بانكيك بيستاشيو"}	2026-05-08 11:48:40.789872+00	\N	\N	\N	\N	\N	\N
76e5d275-772c-40fc-b565-1c0480ddb93b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	9d9ef61f-b665-438d-8ea7-5433987b03a0	{"name": "كريب نوتيلا"}	2026-05-08 11:49:47.235697+00	\N	\N	\N	\N	\N	\N
85c62918-36c8-4f4a-b118-129aeb70621a	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	9d9ef61f-b665-438d-8ea7-5433987b03a0	{"name": "كريب نوتيلا"}	2026-05-08 11:49:47.244051+00	\N	\N	\N	\N	\N	\N
3a9b2d39-7733-4c2e-a577-657ac8f05a94	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	231b8c33-cc2b-4c3f-8e6d-4c1f8e658afd	{"name": "كريب لوتس"}	2026-05-08 11:50:08.146048+00	\N	\N	\N	\N	\N	\N
3f628df8-097e-4e8c-b129-795e35920852	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	231b8c33-cc2b-4c3f-8e6d-4c1f8e658afd	{"name": "كريب لوتس"}	2026-05-08 11:50:08.150738+00	\N	\N	\N	\N	\N	\N
1793112a-f568-49bb-a1f7-3bdb29f11be9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	231b8c33-cc2b-4c3f-8e6d-4c1f8e658afd	{"name": "كريب لوتس"}	2026-05-08 11:50:08.161137+00	\N	\N	\N	\N	\N	\N
7f0b7aa8-2a0e-41a4-9116-5379d755735f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	5ba77b7c-3cb3-4d53-81d3-f10c2ae41378	{"name": "بانكيك نوتيلا"}	2026-05-08 11:50:48.761837+00	\N	\N	\N	\N	\N	\N
1e97e12e-35a0-4f20-aef3-31ec7e951699	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0d745703-4af7-494c-9cc3-83918e589484	{"name": "بانكيك كندر"}	2026-05-08 11:51:25.60963+00	\N	\N	\N	\N	\N	\N
5538e97e-78b0-4e59-9c82-8e07bc37efcd	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6a3aec12-5855-4e9d-95cf-bd5915384534	{"name": "بانكيك ميكس"}	2026-05-08 11:51:51.950234+00	\N	\N	\N	\N	\N	\N
c46870d1-ddfd-438b-bbed-81a96a072f7d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6a3aec12-5855-4e9d-95cf-bd5915384534	{"name": "بانكيك ميكس"}	2026-05-08 11:51:51.953266+00	\N	\N	\N	\N	\N	\N
2572a641-7168-4374-aea2-9ec74d61486c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6a3aec12-5855-4e9d-95cf-bd5915384534	{"name": "بانكيك ميكس"}	2026-05-08 11:51:51.990709+00	\N	\N	\N	\N	\N	\N
fa12ec87-a333-42b3-ac43-42380c0a04b8	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6a3aec12-5855-4e9d-95cf-bd5915384534	{"name": "بانكيك ميكس"}	2026-05-08 11:51:54.246098+00	\N	\N	\N	\N	\N	\N
a9b9b638-0a32-4b02-a289-716579337d51	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6a3aec12-5855-4e9d-95cf-bd5915384534	{"name": "بانكيك ميكس"}	2026-05-08 11:51:54.247392+00	\N	\N	\N	\N	\N	\N
2667bb2e-547b-44b0-aa3e-95b66a232982	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f36a777b-4ade-4bf1-916f-e59abdf21937	{"name": "بانكيك لوتس"}	2026-05-08 11:52:18.883198+00	\N	\N	\N	\N	\N	\N
57019e8f-be34-4c9e-a7e6-7d94ad5f6318	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ed787e03-926b-4081-9190-82641551941c	{"name": "ميني بانكيك لوتس"}	2026-05-08 11:52:56.113749+00	\N	\N	\N	\N	\N	\N
049d214b-9a20-4f72-94d1-f41b7baabf55	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f32ae406-d761-4024-aee7-073c001e0950	{"name": "ميني بانكيك كندر"}	2026-05-08 11:54:40.131254+00	\N	\N	\N	\N	\N	\N
365e4f76-ea4e-46bf-8784-e35f7e28afc3	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f32ae406-d761-4024-aee7-073c001e0950	{"name": "ميني بانكيك كندر"}	2026-05-08 11:54:41.020709+00	\N	\N	\N	\N	\N	\N
7a21fd07-0c1c-4a0a-8113-67e12cbe7f9f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0d7918aa-854c-4d7f-88fd-950b5a22ec15	{"name": "ميني بانكيك ميكس"}	2026-05-08 11:55:07.994708+00	\N	\N	\N	\N	\N	\N
6dfa9147-8e1f-4e71-af8b-f2a3cfb514ae	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0d7918aa-854c-4d7f-88fd-950b5a22ec15	{"name": "ميني بانكيك ميكس"}	2026-05-08 11:55:08.395548+00	\N	\N	\N	\N	\N	\N
3baee1fc-efa7-4c9a-8b4d-5ce853782c14	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c3159c59-e886-4a85-adc0-2d4fc587305f	{"name": "ميني بانكيك بيستاشيو"}	2026-05-08 11:55:38.203169+00	\N	\N	\N	\N	\N	\N
8e06848b-182d-4471-af08-44129a8d54d6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d4542fad-3ffd-467c-85b3-7e70caec14ee	{"name": "فراوله شوكلت 4 حبه"}	2026-05-08 11:56:49.620028+00	\N	\N	\N	\N	\N	\N
9fa87e05-f7e3-4c47-9cd7-8e543de0a94b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	08b275dc-222c-4db0-9d8d-b69b02dbcb83	{"name": "تكميم بستاشيو"}	2026-05-08 11:57:29.861354+00	\N	\N	\N	\N	\N	\N
a6b071e3-e091-469a-8265-3e68c75a9a43	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	aaa8445b-ec95-4314-95dc-45339ebf0e0f	{"name": "ميني بانكيك نوتيلا"}	2026-05-08 11:59:42.895944+00	\N	\N	\N	\N	\N	\N
eb5d90cd-a67e-44b0-9c88-02cc849479fe	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	72041f30-5af7-445e-88d2-16cc6c080779	{"name": "مخدة بوبو"}	2026-05-08 12:00:43.438436+00	\N	\N	\N	\N	\N	\N
2affe33c-a52d-497d-87f2-56ac7102fe44	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	72041f30-5af7-445e-88d2-16cc6c080779	{"name": "مخدة بوبو"}	2026-05-08 12:00:43.442345+00	\N	\N	\N	\N	\N	\N
e9ce8b17-ad3c-429f-b419-24641d744bb9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a3de313a-d0b0-4efb-86e8-7348beadbe31	{"name": "مخدة الاسطورة"}	2026-05-08 12:03:13.00265+00	\N	\N	\N	\N	\N	\N
de6d3351-2874-4c39-8161-126062621d75	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a3de313a-d0b0-4efb-86e8-7348beadbe31	{"name": "مخدة الاسطورة"}	2026-05-08 12:03:13.004548+00	\N	\N	\N	\N	\N	\N
3f24933e-406e-454e-814d-6aae622e0c94	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a3de313a-d0b0-4efb-86e8-7348beadbe31	{"name": "مخدة الاسطورة"}	2026-05-08 12:03:13.242396+00	\N	\N	\N	\N	\N	\N
4a902057-e4d0-4b28-b9f4-9703db804955	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	be6571c9-ffbc-4e0d-8029-0fb55353912a	{"name": "مخدة فروحة"}	2026-05-08 12:04:22.04043+00	\N	\N	\N	\N	\N	\N
935a933e-94c9-4cca-a3c0-c188bbd600c5	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	39efe31c-93b0-4489-b508-c5860c6f1fec	{"name": "تيراميسو"}	2026-05-08 12:05:11.915736+00	\N	\N	\N	\N	\N	\N
2b5ced55-b6b5-4358-af6d-3debd178a33f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c773a587-c473-4dc7-85f9-6253c54478b6	{"name": "بف بيستاشيو كنافه"}	2026-05-08 12:06:19.58518+00	\N	\N	\N	\N	\N	\N
c6c354e0-40de-498b-8dfa-23058f80db12	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8e5fb9bb-71b2-487f-bb70-10d3f42b698e	{"name": "ميلك شيك سارا"}	2026-05-08 12:08:47.939412+00	\N	\N	\N	\N	\N	\N
31b257d7-aece-4266-9bb7-a419990b86ba	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8e5fb9bb-71b2-487f-bb70-10d3f42b698e	{"name": "ميلك شيك سارا"}	2026-05-08 12:21:40.417939+00	\N	\N	\N	\N	\N	\N
a9e29768-d202-45c8-badb-845803154519	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8e5fb9bb-71b2-487f-bb70-10d3f42b698e	{"name": "ميلك شيك سارا"}	2026-05-08 12:21:41.487359+00	\N	\N	\N	\N	\N	\N
20973895-6d6f-4996-9413-3eead4eadf3f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	23717561-fc70-4c13-88bc-5b6638bdfec8	{"name": "بيستاشيو كنافه ميلك شك"}	2026-05-08 12:23:26.999081+00	\N	\N	\N	\N	\N	\N
c469dabd-1555-4810-ba63-2877ea753bb7	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	23717561-fc70-4c13-88bc-5b6638bdfec8	{"name": "بيستاشيو كنافه ميلك شك"}	2026-05-08 12:23:27.396145+00	\N	\N	\N	\N	\N	\N
dd2c8821-55ac-4987-93a9-9b7de41d39da	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	02641919-9c50-4849-a734-f6dbe6eda00d	{"name": "يم يم أحمر"}	2026-05-08 12:33:42.987449+00	\N	\N	\N	\N	\N	\N
0a737d31-78c1-422c-b0d4-2198ee7329e0	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	02641919-9c50-4849-a734-f6dbe6eda00d	{"name": "يم يم أحمر"}	2026-05-08 12:33:42.988725+00	\N	\N	\N	\N	\N	\N
78682360-480d-4f0c-a367-d35ae1636bbd	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6729eb20-7fe2-4fa3-940a-ff8b6af66fa2	{"name": "بلا بلا"}	2026-05-08 12:34:37.608849+00	\N	\N	\N	\N	\N	\N
d2bb4f77-8ef6-4692-8bc2-f830d0fddea9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6729eb20-7fe2-4fa3-940a-ff8b6af66fa2	{"name": "بلا بلا"}	2026-05-08 12:34:37.611226+00	\N	\N	\N	\N	\N	\N
8303c7a8-fe97-42e5-8d79-0b870d53dc89	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6729eb20-7fe2-4fa3-940a-ff8b6af66fa2	{"name": "بلا بلا"}	2026-05-08 12:34:40.108135+00	\N	\N	\N	\N	\N	\N
919d856e-2230-40e2-9063-a1b5996e3266	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c9def380-6ef8-4959-ada0-7c6ac48e5bc7	{"name": "بوم بوم (كبير)"}	2026-05-08 12:36:25.018356+00	\N	\N	\N	\N	\N	\N
e4c26ae5-b85d-439d-a94e-5a48a5871107	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c9def380-6ef8-4959-ada0-7c6ac48e5bc7	{"name": "بوم بوم (كبير)"}	2026-05-08 12:36:25.018386+00	\N	\N	\N	\N	\N	\N
fcd46229-58a9-400a-8f00-961020baf192	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	cd1dac2a-41d7-4012-9eff-ebc4f29ec88c	{"name": "تانجو كبير"}	2026-05-08 12:37:24.655763+00	\N	\N	\N	\N	\N	\N
08713286-49d7-40bf-9309-838eeb72c368	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	cd1dac2a-41d7-4012-9eff-ebc4f29ec88c	{"name": "تانجو كبير"}	2026-05-08 12:37:24.655575+00	\N	\N	\N	\N	\N	\N
5d1a99e0-c27c-4fb2-8d9f-3246c76c91d3	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8bf41fcf-a433-4963-a5b1-54def2498374	{"name": "تانجو صغير"}	2026-05-08 12:37:45.097558+00	\N	\N	\N	\N	\N	\N
d8f3debb-bae4-451c-95b2-69b492a042f1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8bf41fcf-a433-4963-a5b1-54def2498374	{"name": "تانجو صغير"}	2026-05-08 12:37:45.098216+00	\N	\N	\N	\N	\N	\N
2cb3abd4-ac91-497d-bc8d-09ac04acff4b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8bf41fcf-a433-4963-a5b1-54def2498374	{"name": "تانجو صغير"}	2026-05-08 12:37:45.106021+00	\N	\N	\N	\N	\N	\N
dbe9651a-a9b5-4fc7-b17a-a301ace78906	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8bf41fcf-a433-4963-a5b1-54def2498374	{"name": "تانجو صغير"}	2026-05-08 12:37:48.831767+00	\N	\N	\N	\N	\N	\N
ee776534-b4f4-4bc1-be81-985cf5199413	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8bf41fcf-a433-4963-a5b1-54def2498374	{"name": "تانجو صغير"}	2026-05-08 12:37:48.835821+00	\N	\N	\N	\N	\N	\N
d71184ea-1ded-4eda-8615-4ed3f33eb20d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c538641f-9ed0-4146-b76e-a51791221e10	{"name": "باربي"}	2026-05-08 12:42:23.327001+00	\N	\N	\N	\N	\N	\N
6e206904-4c0b-47f0-8b37-fa50fab3cde5	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c538641f-9ed0-4146-b76e-a51791221e10	{"name": "باربي"}	2026-05-08 12:42:23.999948+00	\N	\N	\N	\N	\N	\N
633009c0-7dce-4a38-9ed1-73597e9fc533	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0190d770-89c5-4f3b-9259-a103ba200944	{"name": "فورت نايت"}	2026-05-08 12:44:51.841106+00	\N	\N	\N	\N	\N	\N
10f1d6c6-14cf-4e58-b29e-20956e8328fc	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	47cf680c-9d63-430d-8743-adf1d0fc1ee2	{"name": "ميلك شايك منجاوي"}	2026-05-08 12:45:24.073662+00	\N	\N	\N	\N	\N	\N
51525691-004f-49ee-9092-1e6752b0bb7e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	47cf680c-9d63-430d-8743-adf1d0fc1ee2	{"name": "ميلك شايك منجاوي"}	2026-05-08 12:45:24.081322+00	\N	\N	\N	\N	\N	\N
e3327eae-a24c-4434-9783-b91789aba5b1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f7990df7-8f9b-4986-bc17-1aa668249016	{"name": "شي ثاني"}	2026-05-08 12:46:14.114831+00	\N	\N	\N	\N	\N	\N
2c281426-6843-4f80-b303-a8e1c873f242	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f7990df7-8f9b-4986-bc17-1aa668249016	{"name": "شي ثاني"}	2026-05-08 12:46:14.126351+00	\N	\N	\N	\N	\N	\N
98b2a090-68c6-420e-973d-324bba55ef2b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f7990df7-8f9b-4986-bc17-1aa668249016	{"name": "شي ثاني"}	2026-05-08 12:46:15.453271+00	\N	\N	\N	\N	\N	\N
728df384-d9c8-4f65-83c9-79c38e0488ae	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	500cc72c-9ed0-4ff2-a242-8897e11a8a4b	{"name": "ستوب واتش"}	2026-05-08 12:47:27.745445+00	\N	\N	\N	\N	\N	\N
c437d0f6-0149-40b5-9aa0-f25b6474870b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	831a6ec0-8174-4f42-8b60-89c0c99e02a4	{"name": "عادل الاسطورة صغير"}	2026-05-08 12:48:30.883106+00	\N	\N	\N	\N	\N	\N
c90caf5b-f255-4d29-adcd-23281cdd779b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	cda07c09-8de6-4a81-b448-9b63c0709c67	{"name": "عادل الاسطورة  كبير"}	2026-05-08 12:48:51.017587+00	\N	\N	\N	\N	\N	\N
7282de3a-aada-4858-9d69-d9327e26e104	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	cda07c09-8de6-4a81-b448-9b63c0709c67	{"name": "عادل الاسطورة  كبير"}	2026-05-08 12:48:51.019331+00	\N	\N	\N	\N	\N	\N
af8acf8f-0ab7-4410-84f3-035a9572cb90	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	cda07c09-8de6-4a81-b448-9b63c0709c67	{"name": "عادل الاسطورة  كبير"}	2026-05-08 12:48:51.025183+00	\N	\N	\N	\N	\N	\N
aa85d931-1403-4535-b8b0-18cccd9a6e53	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	072b8504-927c-4f17-a1d8-12f3a0c3768f	{"name": "سوبر بوبو صغير"}	2026-05-08 12:49:28.464024+00	\N	\N	\N	\N	\N	\N
3ccd6752-f97f-4404-8a58-f1753bc3886b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	072b8504-927c-4f17-a1d8-12f3a0c3768f	{"name": "سوبر بوبو صغير"}	2026-05-08 12:49:28.469944+00	\N	\N	\N	\N	\N	\N
b442790e-65c6-4653-8db2-3b7935675541	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	072b8504-927c-4f17-a1d8-12f3a0c3768f	{"name": "سوبر بوبو صغير"}	2026-05-08 12:49:28.472735+00	\N	\N	\N	\N	\N	\N
da928074-05af-45e9-81e3-34e9a010f1ca	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	072b8504-927c-4f17-a1d8-12f3a0c3768f	{"name": "سوبر بوبو صغير"}	2026-05-08 12:49:28.475111+00	\N	\N	\N	\N	\N	\N
27afdde9-2a67-4bce-930c-5ba91ca8cd41	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	072b8504-927c-4f17-a1d8-12f3a0c3768f	{"name": "سوبر بوبو صغير"}	2026-05-08 12:49:28.840812+00	\N	\N	\N	\N	\N	\N
07c5d0c4-e141-40a0-8639-d56b120c4e17	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3131f6e9-9e4e-403b-8541-352263c968fa	{"name": "سوبر بوبو كبير"}	2026-05-08 12:51:11.420721+00	\N	\N	\N	\N	\N	\N
f8d26941-5522-4d34-9efc-b63524565071	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ab4e1a80-8dce-47b3-9bc6-be9c947f0694	{"name": "فيريرو روشيه كبير"}	2026-05-08 12:55:32.0535+00	\N	\N	\N	\N	\N	\N
ebd237c5-1118-49f5-b424-6de62904e48b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ab4e1a80-8dce-47b3-9bc6-be9c947f0694	{"name": "فيريرو روشيه كبير"}	2026-05-08 12:55:34.788045+00	\N	\N	\N	\N	\N	\N
a17be199-8ecf-4a6f-806e-220c7cb704b2	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ab4e1a80-8dce-47b3-9bc6-be9c947f0694	{"name": "فيريرو روشيه كبير"}	2026-05-08 12:55:34.788001+00	\N	\N	\N	\N	\N	\N
8469d906-de8d-41b1-8115-9647959b3e38	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e7b416b8-4968-4e1f-b755-7baabeaca388	{"name": "ابو قلبين ميلك شيك (حجم واحد) هنجر"}	2026-05-08 12:57:04.788589+00	\N	\N	\N	\N	\N	\N
607dfebc-f6a1-4e79-8a03-6c3092c3ac36	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a5c0f156-08be-4ede-8b99-913da3b0b4f2	{"name": "فشكل"}	2026-05-08 12:57:54.795167+00	\N	\N	\N	\N	\N	\N
b92bcd25-ac6d-4f66-97e7-6225cba7b30f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a5c0f156-08be-4ede-8b99-913da3b0b4f2	{"name": "فشكل"}	2026-05-08 12:57:54.795459+00	\N	\N	\N	\N	\N	\N
b4072196-e395-4cc7-a656-cacb8f683f1f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7425a945-03fa-4ee2-a795-25fa64ba6e20	{"name": "ميلك شيك سيريلاك كبير"}	2026-05-08 12:58:40.504618+00	\N	\N	\N	\N	\N	\N
0cf4db89-dcc5-4d76-ad4b-6c997ddc8dce	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	36bd9451-3386-41b5-b056-e3002dc6bd3e	{"name": "فلم"}	2026-05-08 12:59:39.817888+00	\N	\N	\N	\N	\N	\N
ad319922-38f9-497b-a374-3d769f274453	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	44277ad1-7dab-4bec-a257-acac899d5a5c	{"name": "ميلك شيك بيستاشيو صغير"}	2026-05-08 13:00:11.208887+00	\N	\N	\N	\N	\N	\N
1e2fde0e-86fd-4596-bc10-4e56bc18636c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	02fb481e-1925-4116-a3bb-eaa7cb6f9319	{"name": "ميلك شيك سيريلاك صغير"}	2026-05-08 13:00:29.18718+00	\N	\N	\N	\N	\N	\N
56b54422-db0f-4541-8b95-dc8df0ceeb1b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	02fb481e-1925-4116-a3bb-eaa7cb6f9319	{"name": "ميلك شيك سيريلاك صغير"}	2026-05-08 13:00:30.021435+00	\N	\N	\N	\N	\N	\N
d9368153-e517-408c-b452-d23bb42039a8	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	44277ad1-7dab-4bec-a257-acac899d5a5c	{"name": "ميلك شيك بيستاشيو صغير"}	2026-05-08 13:01:25.969187+00	\N	\N	\N	\N	\N	\N
167a8ee4-b004-469d-b959-f16703196463	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	44277ad1-7dab-4bec-a257-acac899d5a5c	{"name": "ميلك شيك بيستاشيو صغير"}	2026-05-08 13:01:25.969173+00	\N	\N	\N	\N	\N	\N
f11983a7-ea63-410e-b355-0b94c825d4ec	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	44277ad1-7dab-4bec-a257-acac899d5a5c	{"name": "ميلك شيك بيستاشيو صغير"}	2026-05-08 13:01:27.090495+00	\N	\N	\N	\N	\N	\N
ad3bf148-19ea-4711-944d-dafb2ec83d01	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d9f69167-0137-4a88-b85a-a22e03199ab9	{"name": "ميلك شيك بيستاشيو  كبير"}	2026-05-08 13:01:41.431587+00	\N	\N	\N	\N	\N	\N
9478fa0b-42e7-4fcf-8f50-0916da130600	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a9da5852-e8d4-45fb-a654-4f645e5d64d2	{"name": "ميلك شيك كندر كبير"}	2026-05-08 13:23:14.053072+00	\N	\N	\N	\N	\N	\N
eb324e1f-f7f3-4d42-bb95-37339dd8b264	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	81154885-8a22-4bba-aa47-e21cbfd7d5c3	{"name": "ميلك شيك كندر صغير"}	2026-05-08 13:24:15.957764+00	\N	\N	\N	\N	\N	\N
390db554-8bd5-4e05-a9f2-d013e2b844a4	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	39c3b17f-971f-4d40-80d4-47f5b1a1f8e4	{"name": "ميلك شيك لوتس كبير"}	2026-05-08 13:26:20.614262+00	\N	\N	\N	\N	\N	\N
c77cf66e-9ba2-48ee-b24f-e91338849d31	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2e282684-9ed6-49a1-81e3-8803b8733163	{"name": "ميلك شيك نوتيلا كبير"}	2026-05-08 13:27:43.768121+00	\N	\N	\N	\N	\N	\N
d40663e1-18c6-443a-a06b-e0f45ef48a89	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	21974308-7a07-4f0d-b998-96164047f79e	{"name": "ميلك شيك نوتيلا صغير"}	2026-05-08 13:27:55.850284+00	\N	\N	\N	\N	\N	\N
32d8af93-0a0c-4bf0-a8a2-cdbcbe9293c4	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2ca866a2-45c0-479b-847c-c579e0a5b115	{"name": "ميلك شيك لوتس صغير"}	2026-05-08 16:16:18.276375+00	\N	\N	\N	\N	\N	\N
57ae2a08-4986-484f-ba04-bd766ffab7ca	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0797a436-5871-4b8b-9cea-3f7dc1ff2a48	{"name": "ميلك شيك اوريو كبير"}	2026-05-08 16:18:38.141393+00	\N	\N	\N	\N	\N	\N
70529404-c76f-43be-ab37-d1a6fb7a0b34	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4ef8da5f-845b-490d-8702-66095f7ba346	{"name": "ميلك شيك سنيكرز كبير"}	2026-05-08 20:06:39.346291+00	\N	\N	\N	\N	\N	\N
14d5a3c1-ecf2-4e3a-a464-726b993b9a22	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ff859cd0-56c4-4b3e-b77d-16a0a0af5feb	{"name": "ميلك شيك سنيكرز صغير"}	2026-05-08 20:06:49.557067+00	\N	\N	\N	\N	\N	\N
5c50dd99-e287-46e9-8623-658daf1f3161	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f52e2e30-c5fc-4d55-bb5c-dea23f780824	{"name": "ميلك شيك اوريو صغير"}	2026-05-08 20:07:35.107132+00	\N	\N	\N	\N	\N	\N
8bd53ae5-cd21-4b69-9888-34e01bee7649	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	569e262e-bed1-42b2-89c3-e44cb8a084b9	{"name": "ميلك شيك هرمون السعادة (كبير)"}	2026-05-08 20:09:00.800841+00	\N	\N	\N	\N	\N	\N
3e23386c-5173-4650-b8f4-99fa2f45bf8b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4ec00a42-6b60-49f0-898f-5c31e6c06c64	{"name": "كت كات كبير"}	2026-05-08 20:13:38.924505+00	\N	\N	\N	\N	\N	\N
8bf18142-1fbd-4838-9582-7347c496a620	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	40f8b1a9-bb8a-4ec1-b967-6c704cb9ac88	{"name": "ميلك شيك رمان كبير"}	2026-05-08 20:16:48.976434+00	\N	\N	\N	\N	\N	\N
d97a90c6-d63c-4f45-81e1-5d419b2bb639	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	40f8b1a9-bb8a-4ec1-b967-6c704cb9ac88	{"name": "ميلك شيك رمان كبير"}	2026-05-08 20:16:48.975226+00	\N	\N	\N	\N	\N	\N
cfeda852-4aec-4e10-aa30-184ca2629f60	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	40f8b1a9-bb8a-4ec1-b967-6c704cb9ac88	{"name": "ميلك شيك رمان كبير"}	2026-05-08 20:16:48.995713+00	\N	\N	\N	\N	\N	\N
f5d8a12e-fb51-437b-8b27-b2af2ce5c8af	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	40f8b1a9-bb8a-4ec1-b967-6c704cb9ac88	{"name": "ميلك شيك رمان كبير"}	2026-05-08 20:16:49.569415+00	\N	\N	\N	\N	\N	\N
85722d04-e7ce-411c-bcc8-d892e6b1f47e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	40f8b1a9-bb8a-4ec1-b967-6c704cb9ac88	{"name": "ميلك شيك رمان كبير"}	2026-05-08 20:16:49.791062+00	\N	\N	\N	\N	\N	\N
3777461a-3fe3-495e-a4d2-db35966875de	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	40f8b1a9-bb8a-4ec1-b967-6c704cb9ac88	{"name": "ميلك شيك رمان كبير"}	2026-05-08 20:16:49.790532+00	\N	\N	\N	\N	\N	\N
5ec39d4d-80c4-4b59-a9f5-b7d8c03e3407	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c6ca2c91-39fc-4cdf-ad83-ac0410b5b0a8	{"name": "حكايا سليمان"}	2026-05-08 20:17:30.924036+00	\N	\N	\N	\N	\N	\N
6e31558f-4f51-42a1-9444-54b26d03d67f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c6ca2c91-39fc-4cdf-ad83-ac0410b5b0a8	{"name": "حكايا سليمان"}	2026-05-08 20:17:30.927144+00	\N	\N	\N	\N	\N	\N
f8f12969-c8dc-4991-87b2-fd7b96ff1e67	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c6ca2c91-39fc-4cdf-ad83-ac0410b5b0a8	{"name": "حكايا سليمان"}	2026-05-08 20:17:31.476691+00	\N	\N	\N	\N	\N	\N
0b874344-fe08-44ac-9eb2-0009f0412fa4	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c6ca2c91-39fc-4cdf-ad83-ac0410b5b0a8	{"name": "حكايا سليمان"}	2026-05-08 20:17:31.478084+00	\N	\N	\N	\N	\N	\N
f8a81c89-f3ae-4041-b32a-9a188c0b18be	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4ec00a42-6b60-49f0-898f-5c31e6c06c64	{"name": "كت كات كبير"}	2026-05-08 20:18:34.535935+00	\N	\N	\N	\N	\N	\N
5ad002ca-7f9e-4c56-a77f-3e5675919e0c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	361fa567-5bf1-49f7-911f-4dd4c0388dba	{"name": "كت كات صغير"}	2026-05-08 20:19:00.584608+00	\N	\N	\N	\N	\N	\N
f0f0ab52-a899-4bd4-b2a3-cbc5eb10b569	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	69c7e680-b85f-4675-9e4c-66cec39cd440	{"name": "عصير اينشتاين كبير"}	2026-05-08 20:20:04.563778+00	\N	\N	\N	\N	\N	\N
8415ac09-dcb3-4c1a-a7f4-2a18f1f4cf06	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c076a94d-10c1-4b84-9a66-eb9643c05281	{"name": "عصير اينشتاين صغير"}	2026-05-08 20:20:19.313991+00	\N	\N	\N	\N	\N	\N
8b23f5d5-624a-4d1d-a4ff-9be3a6dbf6c9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	68e9b88d-8323-40ea-9174-822df6279d79	{"name": "باندا حجم كبير"}	2026-05-08 20:21:12.258559+00	\N	\N	\N	\N	\N	\N
3947e70c-c5b9-423f-b006-447b554303fc	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a3d18ec2-fb79-4c7a-8c17-3c60169c8bbc	{"name": "عصير عوار قلب كبير"}	2026-05-08 20:23:23.731036+00	\N	\N	\N	\N	\N	\N
a16d3a71-d4ae-47e0-a6ed-44ea26ffb787	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a3d18ec2-fb79-4c7a-8c17-3c60169c8bbc	{"name": "عصير عوار قلب كبير"}	2026-05-08 20:23:23.743309+00	\N	\N	\N	\N	\N	\N
45f9a301-8766-4551-a7c3-d913ea1d296b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a3d18ec2-fb79-4c7a-8c17-3c60169c8bbc	{"name": "عصير عوار قلب كبير"}	2026-05-08 20:23:24.700755+00	\N	\N	\N	\N	\N	\N
32f39503-a760-4d9d-bf9d-af055a40f8d1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3ebd285b-ea40-4141-aecf-ae923ff5edff	{"name": "عصير عوار قلب صغير"}	2026-05-08 20:23:45.625033+00	\N	\N	\N	\N	\N	\N
07406c32-9e92-4e10-91f9-50959bd79094	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d4c2dc5f-7afc-41d8-b14e-7dbbe210d50e	{"name": "فشكل بوبو حجم كبير"}	2026-05-08 20:24:19.985018+00	\N	\N	\N	\N	\N	\N
0581cb2b-9a26-4e4d-928c-84837e70d1c3	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d4c2dc5f-7afc-41d8-b14e-7dbbe210d50e	{"name": "فشكل بوبو حجم كبير"}	2026-05-08 20:24:20.389744+00	\N	\N	\N	\N	\N	\N
bc43b64e-ac23-4c40-bc02-ed9a8aab7530	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d2472a85-4cab-495f-8882-cab0e0fbb48a	{"name": "لولو حجم كبير"}	2026-05-08 20:25:52.664949+00	\N	\N	\N	\N	\N	\N
7931a696-4218-4fc1-b5b3-de9b9727693e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	826da7c3-fa44-4534-ad75-757e585538bf	{"name": "فروحة حجم كبير"}	2026-05-08 20:27:15.798415+00	\N	\N	\N	\N	\N	\N
1889357f-791b-4976-9f68-cad423c012ed	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f4930465-da3d-47f3-896d-bdb64512fa59	{"name": "ميلك شك كراميل حجم كبير"}	2026-05-08 20:28:30.006529+00	\N	\N	\N	\N	\N	\N
06a5cef5-96de-44c1-9da5-3ad7eec11cbb	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	dede6682-f948-4c6f-800e-c20bce082993	{"name": "ميلك شيك كراميل حجم صغير"}	2026-05-08 20:28:40.471243+00	\N	\N	\N	\N	\N	\N
197aecd4-877c-416e-9306-842571722791	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	dede6682-f948-4c6f-800e-c20bce082993	{"name": "ميلك شيك كراميل حجم صغير"}	2026-05-08 20:28:40.474795+00	\N	\N	\N	\N	\N	\N
5b8b2d2c-4418-4dbe-823e-801221c8aaf6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	656dda79-0636-4115-a8e2-7b1b6b356d2d	{"name": "كاسترد كبير"}	2026-05-08 20:29:23.002351+00	\N	\N	\N	\N	\N	\N
9afc9ad8-00d9-4e87-977d-b05c5e58ed58	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c514edd6-181f-4b14-8b28-990d61d85b3c	{"name": "فليك كبير"}	2026-05-08 20:31:03.041639+00	\N	\N	\N	\N	\N	\N
5decff10-39d9-4728-99f2-b866b8b51139	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	eac3b5e0-4cc3-422a-9c7e-cd4a00878d8c	{"name": "فليك صغير"}	2026-05-08 20:32:00.56454+00	\N	\N	\N	\N	\N	\N
99a2a5ba-fe4b-4085-8a4d-7d0058bacc7f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7b35f670-56e3-4226-b74a-885982ae8378	{"name": "كاسترد صغير"}	2026-05-08 20:32:42.130157+00	\N	\N	\N	\N	\N	\N
6d0b9add-cb0d-4a78-a9dc-bc68ff2d416d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	b2f3e26b-14b0-4dfd-ad8b-3bc368bd46f0	{"name": "ملك شك فراوله صغير"}	2026-05-08 20:33:20.47603+00	\N	\N	\N	\N	\N	\N
acd17862-be1b-4c2f-9677-8ec5875df696	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	b2f3e26b-14b0-4dfd-ad8b-3bc368bd46f0	{"name": "ملك شك فراوله صغير"}	2026-05-08 20:33:20.476087+00	\N	\N	\N	\N	\N	\N
3530a363-a6ea-49c2-a4b0-6ed7b539e896	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d56edde5-ff34-45c7-923a-55818cdd5363	{"name": "ملك شك فراوله كبير"}	2026-05-08 20:33:35.204308+00	\N	\N	\N	\N	\N	\N
f3471209-1bd8-45c1-a031-a7c3e0b31251	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d56edde5-ff34-45c7-923a-55818cdd5363	{"name": "ملك شك فراوله كبير"}	2026-05-08 20:33:36.364719+00	\N	\N	\N	\N	\N	\N
bc5a92a8-4812-409b-8c44-4c3ca546a97f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	9ccd96c8-703f-4fee-ab79-dbcbac7a5f87	{"name": "جريني كبير"}	2026-05-08 20:34:21.426338+00	\N	\N	\N	\N	\N	\N
6f29a316-b664-4e8a-8f30-5ad354c6502e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d162e475-d722-4f34-89e0-6aa25c8e7604	{"name": "جريني صغير"}	2026-05-08 20:34:35.722959+00	\N	\N	\N	\N	\N	\N
32b49eb6-c512-42b5-b282-4b8a6656688d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e8e1cc1c-55fe-498d-9089-1e57d7e5e386	{"name": "حفيد اينشتاين كبير"}	2026-05-08 20:35:42.657257+00	\N	\N	\N	\N	\N	\N
e6980c4a-3f92-4b10-8221-a7ce4dc80e30	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4d8af62d-9380-43aa-b9d2-67eb94d2e356	{"name": "رمان ملك شك كبير"}	2026-05-08 20:36:20.194672+00	\N	\N	\N	\N	\N	\N
3faab9ed-b527-4756-936b-f16908bf2645	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	dc08adb0-a1ca-4d24-9896-14952638aa25	{"name": "رمان ملك شك صغير"}	2026-05-08 20:36:37.37089+00	\N	\N	\N	\N	\N	\N
d76cfec8-ed48-4e07-8428-204f43d49c43	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	cd1dac2a-41d7-4012-9eff-ebc4f29ec88c	{"name": "تانجو كبير"}	2026-05-08 20:37:04.981416+00	\N	\N	\N	\N	\N	\N
c0e6a0f7-1716-4883-ab75-07ddca07dde5	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c9def380-6ef8-4959-ada0-7c6ac48e5bc7	{"name": "بوم بوم (كبير)"}	2026-05-08 20:37:56.817246+00	\N	\N	\N	\N	\N	\N
7c482ad5-37fa-4ff8-8ffa-082f029ab2ef	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	02641919-9c50-4849-a734-f6dbe6eda00d	{"name": "يم يم أحمر"}	2026-05-08 20:43:04.496625+00	\N	\N	\N	\N	\N	\N
fff97c2f-3606-4ef9-9e96-395aca2632ee	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7a2d2f64-460f-4aaf-9796-6fc1f7facd76	{"name": "اخر كلام كبير"}	2026-05-08 20:45:36.736483+00	\N	\N	\N	\N	\N	\N
e9be1b22-02c7-4049-8a3f-c242920e127f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7a2d2f64-460f-4aaf-9796-6fc1f7facd76	{"name": "اخر كلام كبير"}	2026-05-08 20:45:36.739391+00	\N	\N	\N	\N	\N	\N
3d044290-c803-43de-a8cd-9ff988c240d8	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0873a3e8-0dfd-4fde-9e54-10b02fddaebc	{"name": "بوكس الموهيتو  12حبه"}	2026-05-08 20:51:03.379734+00	\N	\N	\N	\N	\N	\N
77997399-783b-4d30-87b8-3539f0b1f29d	3ccd7385-a949-4ba4-9eb9-32909c1061c0	order_status_change	orders	5cdcf4db-d57e-46ef-89fa-447999ab6d02	{"to": "accepted", "from": "new", "note": null}	2026-05-09 07:40:17.489144+00	\N	\N	\N	\N	\N	\N
34a0bc4f-d1f2-48c2-babb-39d63e3642b7	3ccd7385-a949-4ba4-9eb9-32909c1061c0	order_status_change	orders	5cdcf4db-d57e-46ef-89fa-447999ab6d02	{"to": "preparing", "from": "accepted", "note": null}	2026-05-09 07:40:24.161687+00	\N	\N	\N	\N	\N	\N
4d4670af-6f29-453b-aebb-02dded975983	3ccd7385-a949-4ba4-9eb9-32909c1061c0	order_status_change	orders	5cdcf4db-d57e-46ef-89fa-447999ab6d02	{"to": "ready", "from": "preparing", "note": null}	2026-05-09 07:40:28.212905+00	\N	\N	\N	\N	\N	\N
96d8e530-f4c8-4be0-9c1d-cbc0132823cd	3ccd7385-a949-4ba4-9eb9-32909c1061c0	order_status_change	orders	5cdcf4db-d57e-46ef-89fa-447999ab6d02	{"to": "delivered", "from": "ready", "note": null}	2026-05-09 07:40:32.305804+00	\N	\N	\N	\N	\N	\N
e6864ae7-9918-4baf-942d-1663a30bc3b7	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_category	product_categories	a710f505-ad95-4f6f-8f4b-fe68055a317b	{"name": "الحلويات"}	2026-05-09 08:52:47.928633+00	\N	\N	\N	\N	\N	\N
b1101cab-0919-4f9d-bf02-7ad18452c1c5	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_category	product_categories	8ac569e9-cb25-405a-826f-8db56372b0d4	{"name": "ميلك شيك"}	2026-05-09 08:58:21.529274+00	\N	\N	\N	\N	\N	\N
1755aa3f-5024-410c-90e4-d78d7f0ed3d1	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_category	product_categories	790aae02-4102-4e41-8487-03f1d8cb3567	{"name": "فلوتنق"}	2026-05-09 09:00:01.139439+00	\N	\N	\N	\N	\N	\N
9f853c44-d7c0-4723-8475-017fc0352312	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_category	product_categories	0db67202-0d4a-4960-a468-83d733478e1d	{"name": "مشروبات الطاقة"}	2026-05-09 09:01:13.686607+00	\N	\N	\N	\N	\N	\N
2a526e72-d87d-4731-a228-22989b58dd34	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_category	product_categories	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	{"name": "آيس كريم"}	2026-05-09 09:02:15.682625+00	\N	\N	\N	\N	\N	\N
638b7008-246c-49fd-b27c-10c439e8f220	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_category	product_categories	a710f505-ad95-4f6f-8f4b-fe68055a317b	{"name": "الحلويات"}	2026-05-09 09:03:59.571648+00	\N	\N	\N	\N	\N	\N
bfd1a188-508c-4c67-a0e8-da9bb42d2ca7	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_category	product_categories	7ef407fe-ba82-4c84-ab55-8aae804af7f8	{"name": "عصائر طازجة"}	2026-05-09 09:05:52.745196+00	\N	\N	\N	\N	\N	\N
02b7383b-f6e2-44b9-b1a4-19b6fb427a4e	3ccd7385-a949-4ba4-9eb9-32909c1061c0	create_category	product_categories	d397ce0e-236e-4913-ae66-81a9f4e2b7ab	{"name": "خلطات خاصة"}	2026-05-09 09:07:29.966113+00	\N	\N	\N	\N	\N	\N
eb66851e-0d82-41b0-97f7-620d4fd7b9bd	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_category	product_categories	a710f505-ad95-4f6f-8f4b-fe68055a317b	{"name": "الحلا"}	2026-05-09 09:07:49.973799+00	\N	\N	\N	\N	\N	\N
cf170fa4-67c1-412f-8314-657614165661	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_category	product_categories	1f599865-0727-4843-86ec-28d5af2aed93	{"name": "جالون"}	2026-05-09 09:11:05.699462+00	\N	\N	\N	\N	\N	\N
e9d37757-7adf-40f1-8da9-13e78c31f3fc	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_category	product_categories	73fce410-bf36-4579-872f-b1b8d55815e5	{"name": "بوكسات"}	2026-05-09 10:05:59.687801+00	\N	\N	\N	\N	\N	\N
088dc1a2-ab99-4c6f-a9a8-83f3344fa49c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_category	product_categories	73fce410-bf36-4579-872f-b1b8d55815e5	{"name": "بوكسات"}	2026-05-09 10:05:59.853996+00	\N	\N	\N	\N	\N	\N
d4e6399d-cede-402b-8b12-72924ad25cd9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	bc2d92f7-09b3-4b74-b720-3a0104e5c13c	{"name": "وافل نوتيلا"}	2026-05-09 11:22:53.022851+00	\N	\N	\N	\N	\N	\N
64868d56-000d-4e88-90aa-ce6c2739b6c6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	21f90ac3-4ad1-47aa-8f6e-957bf17b5618	{"name": "كراك احمر"}	2026-05-09 11:30:23.970021+00	\N	\N	\N	\N	\N	\N
e9c6502c-bd6a-40e5-a9ff-ad9986fadc61	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	21f90ac3-4ad1-47aa-8f6e-957bf17b5618	{"name": "كراك احمر"}	2026-05-09 11:30:24.426075+00	\N	\N	\N	\N	\N	\N
09662d3c-78ef-4dd3-8fbc-8baed61d4020	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d85fac55-be82-4ac8-9596-0817567e9b63	{"name": "كراك أزرق"}	2026-05-09 11:30:57.937061+00	\N	\N	\N	\N	\N	\N
98b4bd48-6c4e-4073-9034-21382dbe9198	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d85fac55-be82-4ac8-9596-0817567e9b63	{"name": "كراك أزرق"}	2026-05-09 11:30:58.411169+00	\N	\N	\N	\N	\N	\N
a2463920-b3b4-4889-819d-31485968bc6e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d85fac55-be82-4ac8-9596-0817567e9b63	{"name": "كراك أزرق"}	2026-05-09 11:31:27.184763+00	\N	\N	\N	\N	\N	\N
c7b76de2-4fe1-41e3-bcba-a3ce171bc4e9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	5e63519e-2a81-42c3-a720-18fb347245ba	{"name": "فلوتنق لوتس صغير"}	2026-05-09 11:31:38.35996+00	\N	\N	\N	\N	\N	\N
8637260a-45de-4d1d-958c-7fcb7da1acc5	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	66db2563-ceaf-47ab-8c41-9fe3bb0ff982	{"name": "فلوتنق لوتس كبير"}	2026-05-09 11:33:59.275928+00	\N	\N	\N	\N	\N	\N
75bd5353-8c22-4fe9-910d-a7fa05e01a4c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3692167a-8bc4-4ba8-931b-7487e06a2f9c	{"name": "ميلك شيك كرك صغير"}	2026-05-09 11:34:28.764148+00	\N	\N	\N	\N	\N	\N
cde19804-bd4b-4bad-abb3-954050ac15e7	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	b2f2ae8d-9287-461c-9110-74d35305af9b	{"name": "ميلك شيك كرك كبير"}	2026-05-09 11:34:44.471638+00	\N	\N	\N	\N	\N	\N
a06b2f40-d527-4fa4-9e65-7930a164b153	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a523f973-acfe-4672-beff-e2fafb4fb762	{"name": "فلوتنج ايبشتاين كبير"}	2026-05-09 11:40:52.015272+00	\N	\N	\N	\N	\N	\N
146a4861-406a-4644-aaa3-41916c4ed34b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1999eff6-0a5a-42ed-83a5-e9e93dbc8a99	{"name": "فلوتنج ايبشتاين صغير"}	2026-05-09 11:41:02.196361+00	\N	\N	\N	\N	\N	\N
f4b16d32-b288-4ab5-a41d-59f1f0a30306	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1999eff6-0a5a-42ed-83a5-e9e93dbc8a99	{"name": "فلوتنج ايبشتاين صغير"}	2026-05-09 11:41:02.200146+00	\N	\N	\N	\N	\N	\N
3e554fae-b434-4fc6-a482-6099a5628aec	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1999eff6-0a5a-42ed-83a5-e9e93dbc8a99	{"name": "فلوتنج ايبشتاين صغير"}	2026-05-09 11:41:02.598987+00	\N	\N	\N	\N	\N	\N
0da3d496-6ead-4db0-9870-5b4f5fee1f4f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4fc4c39a-e894-487d-adc3-b575323e7e26	{"name": "ليمونيد بريز  كبير"}	2026-05-09 11:45:17.011599+00	\N	\N	\N	\N	\N	\N
0968d782-96a9-40d4-a47f-6194ded26521	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	dede6682-f948-4c6f-800e-c20bce082993	{"name": "ميلك شيك كراميل حجم صغير"}	2026-05-09 11:47:15.372469+00	\N	\N	\N	\N	\N	\N
949ccf37-96a6-4018-b04c-d0560488f2be	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	5b98e5ae-a7bb-4154-af99-f11acc992a45	{"name": "فلوتنق بيستاشيو صغير"}	2026-05-09 11:48:11.133035+00	\N	\N	\N	\N	\N	\N
17f0ba78-1c20-4c66-9122-8be9ae66357c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	507f28ff-dd61-48e8-b879-75d020fb876a	{"name": "فلوتنق بيستاشيو كبير"}	2026-05-09 11:48:19.554514+00	\N	\N	\N	\N	\N	\N
f22d89aa-4410-4856-a9be-0b0dc5b06985	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a676558c-c99f-47ac-99f0-cc7e857a7b96	{"name": "فلوتنق كندر كبير"}	2026-05-09 11:49:14.093415+00	\N	\N	\N	\N	\N	\N
51e52e29-eeb7-4f83-a1bd-54846ee3cc97	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f41ee66f-0f44-4de8-a3ec-f3cd2d6f456c	{"name": "فلوتنق كندر صغير"}	2026-05-09 11:49:23.57276+00	\N	\N	\N	\N	\N	\N
2f8431ee-c3a3-4a90-9c54-671a789dbfab	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f41ee66f-0f44-4de8-a3ec-f3cd2d6f456c	{"name": "فلوتنق كندر صغير"}	2026-05-09 11:49:23.956698+00	\N	\N	\N	\N	\N	\N
95ae72a3-1536-480f-826a-cfc3030c083d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	186942a7-59d8-42d5-8320-35225dd67484	{"name": "عصير بطيخ صغير"}	2026-05-09 11:52:16.988046+00	\N	\N	\N	\N	\N	\N
5d4ea05b-7891-4c70-b0e8-dc7866a47124	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	186942a7-59d8-42d5-8320-35225dd67484	{"name": "عصير بطيخ صغير"}	2026-05-09 11:52:17.526987+00	\N	\N	\N	\N	\N	\N
a19ac542-b192-49f5-941a-75c22779d1ad	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	db35d52b-3d87-4849-88ff-3cd45862e521	{"name": "عصير بطيخ كبير"}	2026-05-09 11:52:25.006652+00	\N	\N	\N	\N	\N	\N
4720103a-ed33-4ded-9643-cd827aea8ba6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f3ee1331-ec40-409b-bf77-1000033507e5	{"name": "عصير افوكادو كبير"}	2026-05-09 11:53:08.313426+00	\N	\N	\N	\N	\N	\N
3ef6dfea-d6c6-4602-9c53-38a4db56d015	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f3ee1331-ec40-409b-bf77-1000033507e5	{"name": "عصير افوكادو كبير"}	2026-05-09 11:53:08.761642+00	\N	\N	\N	\N	\N	\N
630c9733-a8ac-41e5-a6a4-317d32df6d3f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	14959cf2-f9bb-4896-82c3-6186c8d7a28d	{"name": "عصير افوكادو عسل مكسرات كبير"}	2026-05-09 11:53:16.326393+00	\N	\N	\N	\N	\N	\N
bddc402f-c6c8-4578-b99a-034a3b1fc5a6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	14959cf2-f9bb-4896-82c3-6186c8d7a28d	{"name": "عصير افوكادو عسل مكسرات كبير"}	2026-05-09 11:53:16.807478+00	\N	\N	\N	\N	\N	\N
b848748b-3a6d-426c-bf30-7f51c778ed92	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6fd7bf21-313e-4681-a5e0-7118f67e5f72	{"name": "آيس كريم نتفه اوريو"}	2026-05-09 11:54:20.743499+00	\N	\N	\N	\N	\N	\N
f7f221a0-1577-4bb0-b3b7-af83b013f9aa	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6fd7bf21-313e-4681-a5e0-7118f67e5f72	{"name": "آيس كريم نتفه اوريو"}	2026-05-09 11:54:20.743768+00	\N	\N	\N	\N	\N	\N
2961eace-0c71-48a2-a1e8-2036f7e45297	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	14959cf2-f9bb-4896-82c3-6186c8d7a28d	{"name": "عصير افوكادو عسل مكسرات كبير"}	2026-05-09 11:54:54.765093+00	\N	\N	\N	\N	\N	\N
f14956b2-9c89-4880-ab02-56e77679f593	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	14959cf2-f9bb-4896-82c3-6186c8d7a28d	{"name": "عصير افوكادو عسل مكسرات كبير"}	2026-05-09 11:55:13.595183+00	\N	\N	\N	\N	\N	\N
34b18f3c-f70b-4b0f-99c1-6432e2e96367	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	14959cf2-f9bb-4896-82c3-6186c8d7a28d	{"name": "عصير افوكادو عسل مكسرات كبير"}	2026-05-09 11:55:13.882556+00	\N	\N	\N	\N	\N	\N
9371ecf2-5cf3-44ef-9dbe-ed31290fbb7f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8e808986-2d37-4d8f-84c1-e8caff12b56d	{"name": "عصير افوكادو صغير"}	2026-05-09 11:55:22.909854+00	\N	\N	\N	\N	\N	\N
2c22c2f3-1b5a-4467-b7a2-27ac1aed2664	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3c2c9916-a684-4555-9901-8e7ce760718c	{"name": "آيس كريم نتفه كندر"}	2026-05-09 11:56:20.218623+00	\N	\N	\N	\N	\N	\N
4482e1d1-d10a-4f41-8c75-8125aacdb5e5	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d80edb5c-5407-4b8b-9e7e-59a1ce4d6339	{"name": "عصير كوكتيل طازج صغير"}	2026-05-09 11:56:30.165324+00	\N	\N	\N	\N	\N	\N
83a76954-43ec-4cac-91d7-e8be4e5a6037	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8d945ca5-ed93-44d6-8ea9-fa53ea2307a2	{"name": "عصير كوكتيل طازج كبير"}	2026-05-09 11:56:38.690161+00	\N	\N	\N	\N	\N	\N
c63bf490-f46f-4316-8819-91ac5574854e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2425aefd-fa67-4cea-80e5-1c41185cb8bf	{"name": "عصير كوكتيل ليون كبير"}	2026-05-09 11:57:20.176982+00	\N	\N	\N	\N	\N	\N
aa8c33ee-9b49-4d87-bc39-b01394f42e39	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	30bda6ac-7ee0-492c-8eb2-0b09dd5bdd71	{"name": "آيس كريم نتفه فريروشيه"}	2026-05-09 11:57:22.841067+00	\N	\N	\N	\N	\N	\N
521ab863-e55e-4240-ac3e-355775a162c0	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7ef8b36b-4c09-4d49-a9ae-3a2b50174338	{"name": "عصير فينيسيا كبير"}	2026-05-09 11:57:48.206923+00	\N	\N	\N	\N	\N	\N
5e4f0ab7-d1dd-4f5b-b9a4-fb87170392ad	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d792c086-16c2-4d68-9a8f-15818c388270	{"name": "عصير فينيسيا صغير"}	2026-05-09 11:57:55.164871+00	\N	\N	\N	\N	\N	\N
8367163e-fa18-424d-9ecc-d19500a3609e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	22efbb04-a64c-40aa-8f61-ada101c357fc	{"name": "ابو قلبين عصير طازج (حجم واحد)"}	2026-05-09 11:59:17.555442+00	\N	\N	\N	\N	\N	\N
dd3ca043-7e08-43f6-96a0-b033f14a0bf3	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	b9783732-0df9-4f3c-8c1f-3349dfd39fea	{"name": "آيس كريم نتفه بابلز"}	2026-05-09 11:59:32.52528+00	\N	\N	\N	\N	\N	\N
87fbecb5-5336-43a4-abfd-0eb31d1a4ca1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7ef8b36b-4c09-4d49-a9ae-3a2b50174338	{"name": "عصير فينيسيا كبير"}	2026-05-09 11:59:47.924238+00	\N	\N	\N	\N	\N	\N
5020f642-ce05-4564-a957-2d5fc36ec4d9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d792c086-16c2-4d68-9a8f-15818c388270	{"name": "عصير فينيسيا صغير"}	2026-05-09 11:59:55.882888+00	\N	\N	\N	\N	\N	\N
57cb0e24-83eb-4763-af12-da26fe7cc31f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e9297b9e-e701-432d-8f96-f5f6bc358a8e	{"name": "آيس كريم نتفه بيستاشيو"}	2026-05-09 12:00:15.062922+00	\N	\N	\N	\N	\N	\N
c03a56f3-91fa-4fc5-82de-a638d9937c81	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	14959cf2-f9bb-4896-82c3-6186c8d7a28d	{"name": "عصير افوكادو عسل مكسرات كبير"}	2026-05-09 12:00:16.881398+00	\N	\N	\N	\N	\N	\N
83519dca-3bc3-42bc-90e1-7c8718d28300	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2e492e5b-b26d-4c2c-b34d-b44663d1e73b	{"name": "عصير امبراطور كبير"}	2026-05-09 12:00:47.518565+00	\N	\N	\N	\N	\N	\N
77de481d-f189-4ff6-9d2e-87981a45cc68	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	843f3a1f-fe40-4cef-86ea-74d9b522bc83	{"name": "عصير امبراطور صغير"}	2026-05-09 12:00:55.362515+00	\N	\N	\N	\N	\N	\N
1c6be82e-0c13-4528-9ac6-d65f739ba45e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c6fd0b3f-ab9b-4df4-993d-abc9ef4e532b	{"name": "آيس كريم نتفه لوتس"}	2026-05-09 12:01:27.097329+00	\N	\N	\N	\N	\N	\N
b1015f3f-a2fa-4657-b8c4-bbec237bb8f9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c46ebfbc-b402-461e-b284-967390771499	{"name": "عصير كوكتيل ليون صغير"}	2026-05-09 12:01:40.291328+00	\N	\N	\N	\N	\N	\N
22345352-26b7-4a8d-9b94-483011be8435	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	582738e8-de3e-40e6-8fe5-54bfd294eeaa	{"name": "آيس كريم نتفه فانيلا"}	2026-05-09 12:02:03.652229+00	\N	\N	\N	\N	\N	\N
72c327bd-ecf6-4163-8bea-8222ea7bdee9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	855d023e-ce5e-40a6-839b-a55ef6b94591	{"name": "عصير رجيم كبير"}	2026-05-09 12:02:09.319619+00	\N	\N	\N	\N	\N	\N
e0addba7-e2bb-42d9-a7d7-c344c86a2765	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	855d023e-ce5e-40a6-839b-a55ef6b94591	{"name": "عصير رجيم كبير"}	2026-05-09 12:02:09.320892+00	\N	\N	\N	\N	\N	\N
8e87be89-0f6d-4652-8f24-2c7f35b9739c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	855d023e-ce5e-40a6-839b-a55ef6b94591	{"name": "عصير رجيم كبير"}	2026-05-09 12:02:09.647635+00	\N	\N	\N	\N	\N	\N
cfe61df9-92c6-4950-b303-d22872977ac9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1401266e-a324-4b2e-a244-b1c822795129	{"name": "عصير رجيم صغير"}	2026-05-09 12:02:17.166644+00	\N	\N	\N	\N	\N	\N
dd784686-1e9d-4375-9abb-424c8f46d20d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1401266e-a324-4b2e-a244-b1c822795129	{"name": "عصير رجيم صغير"}	2026-05-09 12:02:17.608961+00	\N	\N	\N	\N	\N	\N
2bdd97ec-eb99-419f-8b29-6632bbac1de1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	17c55e6a-f7a1-4bc0-bb84-c19cde701014	{"name": "عصير رمان طازج صغير"}	2026-05-09 12:02:54.221761+00	\N	\N	\N	\N	\N	\N
bd371f2a-8c46-404a-afda-946e5994b831	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	17c55e6a-f7a1-4bc0-bb84-c19cde701014	{"name": "عصير رمان طازج صغير"}	2026-05-09 12:02:54.221676+00	\N	\N	\N	\N	\N	\N
b29af58a-a2cf-4b3f-9e6e-9024babb0624	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	17c55e6a-f7a1-4bc0-bb84-c19cde701014	{"name": "عصير رمان طازج صغير"}	2026-05-09 12:02:54.571796+00	\N	\N	\N	\N	\N	\N
38ab2e09-aa03-4368-9751-1a162ab8cdc1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e623d950-d53b-4440-8ad7-8bc630a98553	{"name": "عصير رمان طازج كبير"}	2026-05-09 12:03:04.211804+00	\N	\N	\N	\N	\N	\N
b19e9a0c-19a4-48c1-b7ff-20bf489c13cf	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	bf250d4f-d3a9-43e8-ab01-528bd1796ddd	{"name": "عصير فراولة كبير"}	2026-05-09 12:03:20.96804+00	\N	\N	\N	\N	\N	\N
c88542c7-13e1-41d7-bc78-f3355b40e1c8	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	bf250d4f-d3a9-43e8-ab01-528bd1796ddd	{"name": "عصير فراولة كبير"}	2026-05-09 12:03:21.408401+00	\N	\N	\N	\N	\N	\N
fbc01294-b5a5-4ae2-ad86-fbff5b4e7d36	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3de4f16a-bcc7-44f7-b699-ae1212fc9310	{"name": "عصير الفراولة الصغير"}	2026-05-09 12:03:27.229644+00	\N	\N	\N	\N	\N	\N
602f1319-cdda-42f3-9c7d-01ba034cde98	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3de4f16a-bcc7-44f7-b699-ae1212fc9310	{"name": "عصير الفراولة الصغير"}	2026-05-09 12:03:27.728456+00	\N	\N	\N	\N	\N	\N
b125618c-55fe-457d-bf5f-9274125638dd	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4d26445d-7374-4116-b31b-2625644a4997	{"name": "عصير فيتامين واحد ونص لتر"}	2026-05-09 12:04:19.910907+00	\N	\N	\N	\N	\N	\N
99951023-5457-4662-a94f-417199eebdea	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c9eca6a8-9e3a-4a33-9023-72b8975bed28	{"name": "آيس كريم نتفه سنيكر"}	2026-05-09 12:04:24.159499+00	\N	\N	\N	\N	\N	\N
fc4668fc-e441-475b-bfa8-0fb22de34688	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	9a00ac35-352c-4888-be92-32edca63c5eb	{"name": "عصير برتقال جالون 1.5 لتر"}	2026-05-09 12:07:11.014177+00	\N	\N	\N	\N	\N	\N
1a6d55c5-da6c-45d3-94b3-bd6037c3706e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4ed1ef6d-07bb-4a1c-bb92-1fa72e9c011c	{"name": "عصير بيري سموذي جالون 1.5 لتر"}	2026-05-09 12:07:48.685419+00	\N	\N	\N	\N	\N	\N
fbd9ea80-074b-44b4-b3fa-208fd60eb2fc	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a90fdbaf-4d42-45df-bf38-c6bb2605a64f	{"name": "عصير عوار قلب جالون 1.5 لتر"}	2026-05-09 12:08:56.616587+00	\N	\N	\N	\N	\N	\N
52e1a62c-009c-4c33-acc1-aec5de63e15e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ad77a20e-a6b7-4e39-9a41-049c45c192a5	{"name": "عصير شمندر صغير"}	2026-05-09 12:11:36.082139+00	\N	\N	\N	\N	\N	\N
629cc29c-69c2-4919-ae3d-c655952ad1b6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ad77a20e-a6b7-4e39-9a41-049c45c192a5	{"name": "عصير شمندر صغير"}	2026-05-09 12:11:36.096318+00	\N	\N	\N	\N	\N	\N
3b85ad18-6cbb-437d-bc44-27f773711290	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ad77a20e-a6b7-4e39-9a41-049c45c192a5	{"name": "عصير شمندر صغير"}	2026-05-09 12:11:36.552862+00	\N	\N	\N	\N	\N	\N
23f20562-4e0d-44b5-abbc-551e71d8cf61	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	124428a3-167f-42de-854e-bea023df866c	{"name": "عصير مانجا فرغلي صغير"}	2026-05-09 12:12:04.846936+00	\N	\N	\N	\N	\N	\N
b9c84a37-9c2d-439d-98bc-461178b8b073	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	124428a3-167f-42de-854e-bea023df866c	{"name": "عصير مانجا فرغلي صغير"}	2026-05-09 12:12:05.145602+00	\N	\N	\N	\N	\N	\N
a5276957-708f-458e-a630-e8e09549fb20	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c80859c0-9788-42f9-8ed1-902b807302a3	{"name": "ايس كريم نتفه نوتلا"}	2026-05-09 12:12:54.981391+00	\N	\N	\N	\N	\N	\N
2719993b-48c5-44c3-85a5-40264f91cdc8	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ad77a20e-a6b7-4e39-9a41-049c45c192a5	{"name": "عصير شمندر صغير"}	2026-05-09 12:12:56.360748+00	\N	\N	\N	\N	\N	\N
f43e7b02-a9d1-4246-8e68-0677dfc360c0	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ad77a20e-a6b7-4e39-9a41-049c45c192a5	{"name": "عصير شمندر صغير"}	2026-05-09 12:12:56.382169+00	\N	\N	\N	\N	\N	\N
1d133bba-6cb4-4ffc-91c1-b599d0e2d308	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ad77a20e-a6b7-4e39-9a41-049c45c192a5	{"name": "عصير شمندر صغير"}	2026-05-09 12:12:56.798677+00	\N	\N	\N	\N	\N	\N
7619683f-01e3-41a6-a660-dc730e355150	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	61e0ccc4-17ed-4813-9f5f-c24e1e0d6db9	{"name": "ايس كريم سيريلاك حجم صغير"}	2026-05-09 12:14:24.681278+00	\N	\N	\N	\N	\N	\N
2969b8b1-4dee-4fb6-82fd-5cef26c0a64f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ad77a20e-a6b7-4e39-9a41-049c45c192a5	{"name": "عصير شمندر صغير"}	2026-05-09 12:14:26.468582+00	\N	\N	\N	\N	\N	\N
694be1a0-13cd-414b-b7fc-aa99ede17662	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ad77a20e-a6b7-4e39-9a41-049c45c192a5	{"name": "عصير شمندر صغير"}	2026-05-09 12:14:26.615645+00	\N	\N	\N	\N	\N	\N
0fd03cb4-b63a-4c0b-980c-c309e13be94f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	66c50d86-b670-475b-90f1-35d27276889c	{"name": "عصير فيتامين كبير"}	2026-05-09 12:14:36.228939+00	\N	\N	\N	\N	\N	\N
fd55efc7-4b9d-4c38-a248-bf26f59f2785	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	618b7eb0-fe3b-40fb-b6ab-e4ebb2446fc7	{"name": "ايس كريم رمان كبير"}	2026-05-09 12:14:52.531333+00	\N	\N	\N	\N	\N	\N
bb30e87d-6c09-4f08-b0c6-d98b1768d322	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	681c974e-7fcd-444f-8b84-6b96936ecbdf	{"name": "ايس كريم منجاوي كبير"}	2026-05-09 12:15:56.449786+00	\N	\N	\N	\N	\N	\N
085c40cc-3754-43a5-9c43-f317838161e4	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	20ab5437-4e16-4492-833b-d10a6b783e78	{"name": "عصير كوكتيل طبقات كبير"}	2026-05-09 12:16:07.050445+00	\N	\N	\N	\N	\N	\N
e4a460d1-7b69-4c92-93b9-f3e8e9fc0242	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	28dc5c4b-1404-49ce-a038-cdeb76eebfa7	{"name": "هافانا ايس كريم  صغير"}	2026-05-09 12:16:22.308078+00	\N	\N	\N	\N	\N	\N
0082f017-5f7e-4987-8b60-0ae35b6cce51	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e4ab0761-394b-4a1e-8ef2-3ddb77e30c6d	{"name": "عصير موز حليب كبير"}	2026-05-09 12:16:46.868049+00	\N	\N	\N	\N	\N	\N
21f0f5bb-b67a-4d8b-9ab3-bc67ea6113a7	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	b1299783-45d6-40df-9060-86a766082247	{"name": "ايس كريم انشتاين كبير"}	2026-05-09 12:17:02.695143+00	\N	\N	\N	\N	\N	\N
20dc634a-3020-4612-b819-7a30baaeabe6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	50e65725-d5f4-47bc-b074-fef8d56705c9	{"name": "ايس كريم بابلز صغير"}	2026-05-09 12:17:13.402816+00	\N	\N	\N	\N	\N	\N
f43eda67-b63a-4709-84da-9f87e113566d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	71c61c6a-3091-4991-9336-0a06d5d7885e	{"name": "ايس كريم بابلز كبير"}	2026-05-09 12:17:23.243601+00	\N	\N	\N	\N	\N	\N
dfb8f578-bc09-4c92-b411-0315f7d7bf2b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6104fe48-9e63-4f4f-a417-4e611fec1fa1	{"name": "ايس كريم منجاوي صغير"}	2026-05-09 12:17:33.474841+00	\N	\N	\N	\N	\N	\N
ba1693e4-38c8-4ff8-ac89-2fbe9a35f097	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f6cb0009-44aa-4325-859c-c7a76761075d	{"name": "ايس كريم انشتاين صغير"}	2026-05-09 12:17:44.400549+00	\N	\N	\N	\N	\N	\N
af32c9e6-b3a4-4ef7-a062-e351d1dc3abc	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d54efd0e-c618-4118-87ee-0887f30f4479	{"name": "ايس كريم هافانا كبير"}	2026-05-09 12:17:53.330329+00	\N	\N	\N	\N	\N	\N
b2435c30-4f02-4ed3-90ab-c8b873e8b6df	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0c690ec4-f0b0-488a-bcad-313f52095494	{"name": "ايس كريم روشية كبير"}	2026-05-09 12:18:29.66638+00	\N	\N	\N	\N	\N	\N
112b43c2-6234-44e8-bf4d-d463d9589135	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	bd976b07-bd8e-4c33-aaa2-7daa4c6602eb	{"name": "ايس كريم روشية صغير"}	2026-05-09 12:18:35.814888+00	\N	\N	\N	\N	\N	\N
cd0bd484-377c-4b1c-aced-a36fb9de88ea	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	57e75755-d9d7-4bab-a7f2-284f5a4f2cf6	{"name": "ايس كريم شعر بنات كبير"}	2026-05-09 12:18:58.64631+00	\N	\N	\N	\N	\N	\N
85aa96b9-fe30-40ed-b838-05c796986cdf	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f4fcf151-662a-4fd7-998a-27ec42fd31bf	{"name": "ايس كريم شعر بنات صغير"}	2026-05-09 12:19:08.464715+00	\N	\N	\N	\N	\N	\N
da4fd308-5326-4333-a920-087ab3423c88	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	657aa28d-5d51-498c-bab1-86a867b3771c	{"name": "ايس كريم فانلا كبير"}	2026-05-09 12:19:17.593994+00	\N	\N	\N	\N	\N	\N
dd01f135-35f5-4a79-ba1d-f47aef3c761e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	91a3f449-366c-4e51-8bae-7e4eaf17abe5	{"name": "ايس كريم فانلا صغير"}	2026-05-09 12:19:29.041062+00	\N	\N	\N	\N	\N	\N
9de1e7ff-0c2a-42f6-9b84-3e7e0e99e9ba	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ebe8ccce-eb36-4dbe-baf5-26ed78c225b1	{"name": "ايس كريم اشقراني كبير"}	2026-05-09 12:19:58.530571+00	\N	\N	\N	\N	\N	\N
bb4c4bb1-6eb5-4349-9b88-4083dfe79e88	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c05a8bfe-ddd7-4112-8047-6e5a9036e852	{"name": "ايس كريم بيستاشيو كبير"}	2026-05-09 12:20:15.709067+00	\N	\N	\N	\N	\N	\N
186be56e-32ae-4681-8c2a-a8ed6df6b906	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ed85c2b4-4376-4f3f-84c1-222dd90253b6	{"name": "ايس كريم رافيلو لوتس كبير"}	2026-05-09 12:21:00.214511+00	\N	\N	\N	\N	\N	\N
35edcee4-61bc-4caf-855c-69294bad798d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a44bc3b5-9928-41c8-b62c-40cad4ec011d	{"name": "ايس كريم كندر كبير"}	2026-05-09 12:21:28.671506+00	\N	\N	\N	\N	\N	\N
d660de87-ab9f-4bd0-be6f-004cf5bdecca	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	75ef537a-caf1-44cb-bd8b-de51117212bc	{"name": "ايس كريم رمان صغير"}	2026-05-09 12:21:38.341108+00	\N	\N	\N	\N	\N	\N
032af1b1-207c-4f6e-81fd-efcbc0f9c082	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	803c8478-a388-43af-bfa5-65a554ccc1cf	{"name": "ايس كريم سنيكرز صغير"}	2026-05-09 12:21:48.77432+00	\N	\N	\N	\N	\N	\N
d71f3d02-0596-4a54-abaf-26fed78a59a0	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	803c8478-a388-43af-bfa5-65a554ccc1cf	{"name": "ايس كريم سنيكرز صغير"}	2026-05-09 12:21:49.094255+00	\N	\N	\N	\N	\N	\N
006813a5-3508-4ad2-b0ba-9d68e98f50eb	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1bf52a4a-2a74-417e-83c4-16055c871672	{"name": "ايس كريم كرسبي لوتس صغير"}	2026-05-09 12:22:07.95254+00	\N	\N	\N	\N	\N	\N
797cf82e-22c0-4f0b-9c4a-d8f059197bf1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	af622da9-4e41-4645-812b-a8abf1c0e267	{"name": "ايس كريم كندر صغير"}	2026-05-09 12:22:21.287801+00	\N	\N	\N	\N	\N	\N
1a105e62-f2ea-40a1-855d-f07bc1edbd63	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	b5997bd0-f207-49f4-a21b-4d42c4fd1238	{"name": "ايس كريم كندر لوتس كبير"}	2026-05-09 12:22:43.939054+00	\N	\N	\N	\N	\N	\N
3dcbe089-81c4-4586-8353-315e27c77b78	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	693bad02-1f3f-4a7e-adaa-c955130bf022	{"name": "ايس كريم نوتيلا كبير"}	2026-05-09 12:27:03.02826+00	\N	\N	\N	\N	\N	\N
79229b14-9a82-4c9f-b6bc-87d0f70ac7b1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	85b58a18-8dcb-4f61-9eaa-31725b3fbb63	{"name": "ايس كريم كندر لوتس صغير"}	2026-05-09 12:27:30.616224+00	\N	\N	\N	\N	\N	\N
28888ebf-a892-4c51-bee6-e72ec2a3ce5d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	25fd0fe7-dd82-4e26-8623-24c2f5f9678e	{"name": "ايس كريم لوتس صغير"}	2026-05-09 12:28:54.894632+00	\N	\N	\N	\N	\N	\N
0a205803-efea-4901-9139-e9631e347a9d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	68b7621e-705a-4ffc-a4b5-1f4799ee09a7	{"name": "ايس كريم اوريو كبير"}	2026-05-09 12:29:05.817178+00	\N	\N	\N	\N	\N	\N
70b4e970-6b59-470f-b982-a1132753bd10	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3142d42d-b04c-491a-95fa-7cbcac185338	{"name": "ايس كريم رافيلو لوتس صغير"}	2026-05-09 12:35:58.898268+00	\N	\N	\N	\N	\N	\N
d4e64f61-7eb0-45d6-8968-ef1a90a55f7e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	20ab5437-4e16-4492-833b-d10a6b783e78	{"name": "عصير كوكتيل طبقات كبير"}	2026-05-09 12:36:13.571106+00	\N	\N	\N	\N	\N	\N
4c730322-230d-4a75-b23a-57522b7aab90	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	20ab5437-4e16-4492-833b-d10a6b783e78	{"name": "عصير كوكتيل طبقات كبير"}	2026-05-09 12:36:15.345894+00	\N	\N	\N	\N	\N	\N
97554d5f-a468-429a-87b7-2b976362398a	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6e024d62-4190-42af-a186-98a6c7415c72	{"name": "ايس كريم زعفران صغير"}	2026-05-09 12:37:27.261463+00	\N	\N	\N	\N	\N	\N
8d57269b-02b3-4d57-83b1-98190f3063dc	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6ad49923-6fa5-4fd0-a1d2-dc5a318f5923	{"name": "ايس كريم زعفران كبير"}	2026-05-09 12:37:41.14685+00	\N	\N	\N	\N	\N	\N
00983e16-6307-4ff7-830c-f81999bb2ed9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ca8315b4-8855-4a97-8f1a-fb5c301fb5f2	{"name": "ايس كريم سنيكرز كبير"}	2026-05-09 12:38:15.760573+00	\N	\N	\N	\N	\N	\N
aea0f99a-6ef5-404c-84b3-951d4607801e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	537b58a7-01bd-46e2-bb84-1bfefdd9984d	{"name": "عصير أناناس صغير"}	2026-05-09 12:38:30.865676+00	\N	\N	\N	\N	\N	\N
9c5c2ba1-55a2-4895-8ac2-be526a585b1d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ebae1ced-3d08-4a6f-86c1-e9da2ecff3fd	{"name": "ايس كريم كرسبي لوتس كبير"}	2026-05-09 12:39:10.855381+00	\N	\N	\N	\N	\N	\N
8a6f053f-1e74-42d1-8ec8-d843f429f9b5	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0000dfc4-42b5-4008-957e-afa3569b612f	{"name": "عصير الملك كبير"}	2026-05-09 12:39:31.551372+00	\N	\N	\N	\N	\N	\N
1f77d804-2af0-4d59-bf39-510daacc6080	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0000dfc4-42b5-4008-957e-afa3569b612f	{"name": "عصير الملك كبير"}	2026-05-09 12:39:31.551716+00	\N	\N	\N	\N	\N	\N
09d20a01-1b32-43b3-a6f6-82e21159ec39	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c9eca6a8-9e3a-4a33-9023-72b8975bed28	{"name": "آيس كريم نتفه سنيكر"}	2026-05-09 12:40:21.514482+00	\N	\N	\N	\N	\N	\N
144a5dad-f5ce-4d4d-bba7-dbb3bbff5dd2	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	803c8478-a388-43af-bfa5-65a554ccc1cf	{"name": "ايس كريم سنيكرز صغير"}	2026-05-09 12:40:29.186495+00	\N	\N	\N	\N	\N	\N
b6dbda1d-3e2b-4699-beae-83f14b92468d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ca8315b4-8855-4a97-8f1a-fb5c301fb5f2	{"name": "ايس كريم سنيكرز كبير"}	2026-05-09 12:40:34.249016+00	\N	\N	\N	\N	\N	\N
60a49d31-4e64-43b1-9f4d-f45c79f206a7	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	da835d98-dd02-4ab0-9ca7-3393e227f128	{"name": "عصير برتقال كبير"}	2026-05-09 12:40:57.517068+00	\N	\N	\N	\N	\N	\N
06b3b950-b33d-468a-9ba2-6c2af1d9d3fc	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	da835d98-dd02-4ab0-9ca7-3393e227f128	{"name": "عصير برتقال كبير"}	2026-05-09 12:40:57.530573+00	\N	\N	\N	\N	\N	\N
e344f9dc-af60-4a54-b9fb-2a58495f4b65	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	da835d98-dd02-4ab0-9ca7-3393e227f128	{"name": "عصير برتقال كبير"}	2026-05-09 12:40:57.53078+00	\N	\N	\N	\N	\N	\N
2aa15748-7ded-4d88-b811-2060d0caf1bb	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	da835d98-dd02-4ab0-9ca7-3393e227f128	{"name": "عصير برتقال كبير"}	2026-05-09 12:40:59.162241+00	\N	\N	\N	\N	\N	\N
fa5bcfc3-7f02-4220-af88-aeda25f97d5d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	da835d98-dd02-4ab0-9ca7-3393e227f128	{"name": "عصير برتقال كبير"}	2026-05-09 12:40:59.16525+00	\N	\N	\N	\N	\N	\N
3c619a11-61fd-4961-8b75-7a31a1926fa3	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4640d78b-f59c-4cdd-a8b8-aaf5b7e3fd0d	{"name": "ايس كريم لوتس كبير"}	2026-05-09 12:41:05.152787+00	\N	\N	\N	\N	\N	\N
2a21ae8a-23d3-43ed-b77d-469692e69ce4	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	fa78d34f-4fb8-42c0-ac10-aa057aa4b1d5	{"name": "ايس كريم نوتيلا صغير"}	2026-05-09 12:41:13.57065+00	\N	\N	\N	\N	\N	\N
b9b25b3f-3eed-47a9-bc31-6ab8d906004f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4ada9b5d-b5cb-4189-97da-2180c6d0d8c2	{"name": "ايس كريم اشقراني صغير"}	2026-05-09 12:41:22.460327+00	\N	\N	\N	\N	\N	\N
fd6536fa-d521-47d1-89c6-26af1903dc23	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7ca6bbe5-2f92-4c80-9150-f245e4f7a085	{"name": "عصير جزر كبير"}	2026-05-09 12:41:32.707509+00	\N	\N	\N	\N	\N	\N
06d62a48-7c71-4fd8-a5ca-ac146ca56ca9	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7ca6bbe5-2f92-4c80-9150-f245e4f7a085	{"name": "عصير جزر كبير"}	2026-05-09 12:41:32.706237+00	\N	\N	\N	\N	\N	\N
ea054736-4509-4c83-a6e3-ead4998243c1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7ca6bbe5-2f92-4c80-9150-f245e4f7a085	{"name": "عصير جزر كبير"}	2026-05-09 12:41:33.786865+00	\N	\N	\N	\N	\N	\N
93ef6a45-66b7-49db-9483-20d4b785e862	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7ca6bbe5-2f92-4c80-9150-f245e4f7a085	{"name": "عصير جزر كبير"}	2026-05-09 12:41:33.78782+00	\N	\N	\N	\N	\N	\N
d536e387-8bc4-46f0-a1d3-b5607c238083	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1ace3cad-af93-4a32-88ed-89d36053f346	{"name": "ايس كريم اوريو صغير"}	2026-05-09 12:41:45.213754+00	\N	\N	\N	\N	\N	\N
03462bdf-6f89-4076-9cfe-e2c46f7a6b2a	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0aa53bee-eb51-41e0-a07a-cbbebbea8be3	{"name": "ايس كريم بيستاشيو صغير"}	2026-05-09 12:42:12.255621+00	\N	\N	\N	\N	\N	\N
6165b856-d5dc-4c31-a4e8-09fd9f3583d4	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8ba110aa-b669-414d-91db-b575b0559e2c	{"name": "عصير كيوي كبير"}	2026-05-09 12:42:56.029778+00	\N	\N	\N	\N	\N	\N
3150a566-6d9a-4596-9d5c-772510d30e92	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8ba110aa-b669-414d-91db-b575b0559e2c	{"name": "عصير كيوي كبير"}	2026-05-09 12:42:57.515291+00	\N	\N	\N	\N	\N	\N
60174406-90ff-49ff-89e0-1d501f4c4242	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8ba110aa-b669-414d-91db-b575b0559e2c	{"name": "عصير كيوي كبير"}	2026-05-09 12:42:57.514113+00	\N	\N	\N	\N	\N	\N
0b094cb0-89f1-4d91-9850-151a1db5116b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8ba110aa-b669-414d-91db-b575b0559e2c	{"name": "عصير كيوي كبير"}	2026-05-09 12:42:57.522041+00	\N	\N	\N	\N	\N	\N
5cb72800-bb32-4c13-a8d2-e14d9e1e1364	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8ba110aa-b669-414d-91db-b575b0559e2c	{"name": "عصير كيوي كبير"}	2026-05-09 12:42:57.517662+00	\N	\N	\N	\N	\N	\N
d7914d24-9dba-4492-a21f-9ddca68cce30	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8ba110aa-b669-414d-91db-b575b0559e2c	{"name": "عصير كيوي كبير"}	2026-05-09 12:43:26.338245+00	\N	\N	\N	\N	\N	\N
75dbb591-3ff8-4b35-afc0-95dc8ee7bef4	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8ba110aa-b669-414d-91db-b575b0559e2c	{"name": "عصير كيوي كبير"}	2026-05-09 12:43:26.692538+00	\N	\N	\N	\N	\N	\N
abddbed5-3e97-447a-917f-90a2303ac34f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	db8eb433-59b4-4e39-851b-43c63131295a	{"name": "عصير ليمون نعناع كبير"}	2026-05-09 12:44:19.583113+00	\N	\N	\N	\N	\N	\N
f28937d5-d5e4-4859-85ab-3aed997729eb	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0000dfc4-42b5-4008-957e-afa3569b612f	{"name": "عصير الملك كبير"}	2026-05-09 12:46:32.596113+00	\N	\N	\N	\N	\N	\N
ec8e2410-8d6b-444a-9365-9fa75e1a8742	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	0000dfc4-42b5-4008-957e-afa3569b612f	{"name": "عصير الملك كبير"}	2026-05-09 12:46:33.207083+00	\N	\N	\N	\N	\N	\N
ac07ff53-81a1-46a6-b32a-0a0798991ebf	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	953d46e5-2a2e-46ec-bd06-35aef49ab1f4	{"name": "عصير أناناس كبير"}	2026-05-09 12:47:19.281948+00	\N	\N	\N	\N	\N	\N
475d45a2-75e4-4181-b6d3-a64f7753b727	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	9bd93881-20fd-4c7d-8bdf-bdeaa795d08b	{"name": "عصير جزر صغير"}	2026-05-09 12:47:43.645587+00	\N	\N	\N	\N	\N	\N
f392921c-0304-4638-8cc2-f8882618b322	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	33cd46ce-aa65-4532-b940-8e71706f4ea9	{"name": "عصير برتقال صغير"}	2026-05-09 12:47:58.63504+00	\N	\N	\N	\N	\N	\N
d707d579-cee6-40e6-8539-3150c3f1612a	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ce824a76-a9e8-44b9-93f6-726043472047	{"name": "عصير الملك صغير"}	2026-05-09 12:48:06.56324+00	\N	\N	\N	\N	\N	\N
85cf6f30-9afd-4714-9910-d239a2258af4	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1e71898c-f7d8-4e76-b091-3f3731c0cd05	{"name": "عصير معاريس صغير"}	2026-05-09 12:48:36.881265+00	\N	\N	\N	\N	\N	\N
8f36f8a9-2f36-4f01-829b-08b7fef45e7a	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1e71898c-f7d8-4e76-b091-3f3731c0cd05	{"name": "عصير معاريس صغير"}	2026-05-09 12:48:36.885608+00	\N	\N	\N	\N	\N	\N
717009b2-54b0-43a6-bb7a-158622615103	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	103463a6-61b9-4e7d-ab2d-d4880c7b0ea8	{"name": "عصير معاريس كبير"}	2026-05-09 12:48:53.324415+00	\N	\N	\N	\N	\N	\N
cd7934a6-0d23-4415-9334-8d7ae080878e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4d85685c-1754-457e-ae23-48159c9d7496	{"name": "عصير تفاح كبير"}	2026-05-09 12:52:23.400613+00	\N	\N	\N	\N	\N	\N
cb0d9e9e-8653-4846-a5a6-7a7142656dfa	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	67a9f959-1b2b-4db8-b369-19a7ea38b989	{"name": "عصير شمندر كبير"}	2026-05-09 12:53:05.978905+00	\N	\N	\N	\N	\N	\N
12529b48-fa1c-43ad-9d19-993d58b61961	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ce824a76-a9e8-44b9-93f6-726043472047	{"name": "عصير الملك صغير"}	2026-05-09 12:53:15.936511+00	\N	\N	\N	\N	\N	\N
1850077c-5984-4688-be25-39ece323a8e3	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	67a9f959-1b2b-4db8-b369-19a7ea38b989	{"name": "عصير شمندر كبير"}	2026-05-09 12:53:50.718696+00	\N	\N	\N	\N	\N	\N
a91b48c9-b909-4c41-b806-57eb2a2a42d6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f3343d76-ac2f-4f24-97d4-76533338560d	{"name": "عصير فيتامين صغير"}	2026-05-09 12:54:01.361936+00	\N	\N	\N	\N	\N	\N
f2845934-64ff-4ee3-994a-c19e524f0a62	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	38777a6b-1480-4a78-a49f-a465b7ffa8ae	{"name": "عصير كوكتيل سبيشل صغير"}	2026-05-09 12:54:43.749173+00	\N	\N	\N	\N	\N	\N
5fd50c26-3049-4681-9352-bedde3a08c6b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a1cacfaa-66b9-4088-8049-37bc8814454b	{"name": "مياه نوفا"}	2026-05-09 12:54:50.765401+00	\N	\N	\N	\N	\N	\N
0978a3aa-21de-4d08-ad8b-635302cd7362	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	bd2195e6-6e9e-414a-ab5b-7590bf235f89	{"name": "عصير كوكتيل طبقات صغير"}	2026-05-09 12:55:18.46762+00	\N	\N	\N	\N	\N	\N
70413cac-9d58-4160-bca3-590934c72a0d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	fcfa0aa0-0779-4f24-b17e-18ed67871c30	{"name": "عصير كيوي صغير"}	2026-05-09 12:55:47.53588+00	\N	\N	\N	\N	\N	\N
22e75d2e-9984-486f-8810-5a7197f37f8a	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d8d41dda-5318-4892-9797-d8b0bf49198c	{"name": "عصير ليمون نعناع صغير"}	2026-05-09 12:55:58.662713+00	\N	\N	\N	\N	\N	\N
4ab16518-3a3e-40f0-a162-42d6e757c2db	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c9a68acd-b206-4f13-8a12-34366a8a5015	{"name": "عصير مانجا فرغلي كبير"}	2026-05-09 12:56:40.060139+00	\N	\N	\N	\N	\N	\N
0e77d659-2375-42fd-bb12-90d661823862	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1a87eb3e-1eb5-472f-88ac-304ded574eaf	{"name": "عصير كوكتيل سبيشل كبير"}	2026-05-09 12:57:02.274616+00	\N	\N	\N	\N	\N	\N
64b63502-5400-435d-88b2-4672ddcf2276	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1a87eb3e-1eb5-472f-88ac-304ded574eaf	{"name": "عصير كوكتيل سبيشل كبير"}	2026-05-09 12:57:02.276074+00	\N	\N	\N	\N	\N	\N
e1a47d9e-0d2b-4b27-9d94-82c25d952327	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1a87eb3e-1eb5-472f-88ac-304ded574eaf	{"name": "عصير كوكتيل سبيشل كبير"}	2026-05-09 12:57:02.277443+00	\N	\N	\N	\N	\N	\N
c623770f-4e89-4c0e-bbf9-aa2a4baf1a96	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1a87eb3e-1eb5-472f-88ac-304ded574eaf	{"name": "عصير كوكتيل سبيشل كبير"}	2026-05-09 12:57:02.280216+00	\N	\N	\N	\N	\N	\N
d40ad279-f90d-4642-baf6-b9fc407af295	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1a87eb3e-1eb5-472f-88ac-304ded574eaf	{"name": "عصير كوكتيل سبيشل كبير"}	2026-05-09 12:57:03.005926+00	\N	\N	\N	\N	\N	\N
b121f52d-9ff9-488d-bcab-1466c873dab2	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	38777a6b-1480-4a78-a49f-a465b7ffa8ae	{"name": "عصير كوكتيل سبيشل صغير"}	2026-05-09 12:57:11.185628+00	\N	\N	\N	\N	\N	\N
2338de93-f095-41f4-814a-aba8b3f91d8b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	38777a6b-1480-4a78-a49f-a465b7ffa8ae	{"name": "عصير كوكتيل سبيشل صغير"}	2026-05-09 12:57:11.750595+00	\N	\N	\N	\N	\N	\N
3df1bf9d-2472-4909-8761-34a82f2bf535	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	fcf4482a-1d92-432c-8a55-b5598b978576	{"name": "عصير موز حليب صغير"}	2026-05-09 12:57:28.151294+00	\N	\N	\N	\N	\N	\N
1f3516c4-5c5f-410c-af2b-ce88a08c0229	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	b2f3e26b-14b0-4dfd-ad8b-3bc368bd46f0	{"name": "ملك شك فراوله صغير"}	2026-05-09 12:58:35.021168+00	\N	\N	\N	\N	\N	\N
a98bb0b3-9858-4ddc-a710-8fa3dccd3c3d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4d551b90-f749-4c6f-9466-c8557c367aaa	{"name": "صمدي كبير"}	2026-05-09 13:00:09.038843+00	\N	\N	\N	\N	\N	\N
cd574225-e07b-4c8f-bd8a-2ecd55952388	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	cbce3b00-7d54-4874-b49e-b408af0933b3	{"name": "سلطة فواكه كبير"}	2026-05-09 13:01:31.243402+00	\N	\N	\N	\N	\N	\N
adacffe2-9ede-4892-9e05-2529a59b2cda	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f66859be-e3dc-4f4f-8d7e-26ccdd63c667	{"name": "سلطة فواكه صغير"}	2026-05-09 13:01:38.80145+00	\N	\N	\N	\N	\N	\N
aefac0a4-4742-4cbc-94e6-c78411951ed4	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d63ac1d1-db0c-4588-af5b-c9fb968c97c8	{"name": "سنفوري قوي كبير"}	2026-05-09 13:02:39.333125+00	\N	\N	\N	\N	\N	\N
c5b969c3-f2d9-407d-a7a3-ca6f1bd0e944	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	b01f9b8c-3605-411c-836f-e8d3f50a6b74	{"name": "في أ يي بي كبير"}	2026-05-09 13:03:06.939031+00	\N	\N	\N	\N	\N	\N
04a5571b-b9e7-48ac-989e-f2b3867dfcd2	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e9e6bc52-d08e-4f7f-a35d-3dd3bbd447b7	{"name": "ابن بطوطة كبير"}	2026-05-09 13:03:49.087839+00	\N	\N	\N	\N	\N	\N
8e3b4d7e-1be8-4372-b2c5-270330a9137c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e9e6bc52-d08e-4f7f-a35d-3dd3bbd447b7	{"name": "ابن بطوطة كبير"}	2026-05-09 13:03:49.301234+00	\N	\N	\N	\N	\N	\N
136d8440-002d-439f-8aaa-b1d994a38f1c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e9e6bc52-d08e-4f7f-a35d-3dd3bbd447b7	{"name": "ابن بطوطة كبير"}	2026-05-09 13:03:49.517296+00	\N	\N	\N	\N	\N	\N
0ecdbd1d-a3e9-412c-90a4-c53bb1583558	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	fb0ea950-23be-466b-9818-a28df3e92913	{"name": "عصيرتفاح صغير"}	2026-05-09 13:06:06.079492+00	\N	\N	\N	\N	\N	\N
1a7fc2f3-ed8a-42b8-bc25-c1ea2e1598a5	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f72ae679-8690-4b50-9e33-65d991edc169	{"name": "شمام كبير"}	2026-05-09 13:08:55.079871+00	\N	\N	\N	\N	\N	\N
8d4b0fb7-8a76-4b2e-9e4a-8754d35ef11f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	fb9a7ac7-283b-407c-a990-b539572f2e47	{"name": "شمام صغير"}	2026-05-09 13:09:09.109543+00	\N	\N	\N	\N	\N	\N
03dc74ee-de04-4108-81b3-3144b08bada3	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ebcceb29-cac5-40b2-9698-ed3dfea39aad	{"name": "انتعاش صغير"}	2026-05-09 13:11:20.162923+00	\N	\N	\N	\N	\N	\N
c01d66d9-609e-49b0-aff9-058666feda86	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ebcceb29-cac5-40b2-9698-ed3dfea39aad	{"name": "انتعاش صغير"}	2026-05-09 13:11:20.173271+00	\N	\N	\N	\N	\N	\N
d87fa99b-f889-4130-b484-f804a1f43bd0	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ebcceb29-cac5-40b2-9698-ed3dfea39aad	{"name": "انتعاش صغير"}	2026-05-09 13:11:20.342684+00	\N	\N	\N	\N	\N	\N
d70575fa-353e-4b9f-8fc1-14b60f368825	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ebcceb29-cac5-40b2-9698-ed3dfea39aad	{"name": "انتعاش صغير"}	2026-05-09 13:11:20.670856+00	\N	\N	\N	\N	\N	\N
9a9c83b6-1ad7-4420-b3c5-595c54577f7d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a0b590d5-5f4d-4091-a53b-5d05b5264302	{"name": "انتعاش كبير"}	2026-05-09 13:11:31.171739+00	\N	\N	\N	\N	\N	\N
e882e4e0-1ccd-4bc3-b2a5-0cc74fe62440	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a0b590d5-5f4d-4091-a53b-5d05b5264302	{"name": "انتعاش كبير"}	2026-05-09 13:11:31.175114+00	\N	\N	\N	\N	\N	\N
ef145da2-65b1-446d-a679-1ca2157963ed	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7a2d2f64-460f-4aaf-9796-6fc1f7facd76	{"name": "اخر كلام كبير"}	2026-05-09 13:17:48.945451+00	\N	\N	\N	\N	\N	\N
dac0a3c1-e893-46db-a8d5-135f80cdff64	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7a2d2f64-460f-4aaf-9796-6fc1f7facd76	{"name": "اخر كلام كبير"}	2026-05-09 13:17:49.413866+00	\N	\N	\N	\N	\N	\N
022f1c82-4360-4503-85ed-9cbb284a096b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	442113f1-ef3b-4dab-a4fd-0fc0cc904185	{"name": "عصاير ميني عصائر فرش 12 حبه"}	2026-05-09 13:27:47.181112+00	\N	\N	\N	\N	\N	\N
c4d27939-e47c-44b3-909d-69c5676fd1cd	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	442113f1-ef3b-4dab-a4fd-0fc0cc904185	{"name": "عصاير ميني عصائر فرش 12 حبه"}	2026-05-09 13:27:47.517036+00	\N	\N	\N	\N	\N	\N
d66ee5e4-28ce-4c57-bad2-e0e4458c0022	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	442113f1-ef3b-4dab-a4fd-0fc0cc904185	{"name": "عصاير ميني عصائر فرش 12 حبه"}	2026-05-09 13:28:15.097271+00	\N	\N	\N	\N	\N	\N
bc0784b5-ec4d-46fa-8054-7ecef7e97f4c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f8b18842-0e91-4d7a-b6b9-f62019f341fc	{"name": "عصاير ميني ملك شك 12حبه"}	2026-05-09 13:30:47.351647+00	\N	\N	\N	\N	\N	\N
253365a8-ee05-4264-90bb-f5ee99b22abe	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	442113f1-ef3b-4dab-a4fd-0fc0cc904185	{"name": "عصاير ميني عصائر فرش 12 حبه"}	2026-05-09 13:31:00.260654+00	\N	\N	\N	\N	\N	\N
55484311-413e-42e0-b60b-09b33284ee62	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	dada251f-298f-4791-9173-29e6beeb26e6	{"name": "فلوتنق نوتيلا كبير"}	2026-05-09 13:40:33.663418+00	\N	\N	\N	\N	\N	\N
354b8626-c17d-45be-9029-10e2f6217d10	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f021be88-5769-4534-913b-d3317ec711e1	{"name": "فلوتنق نوتيلا صغير"}	2026-05-09 13:40:41.952293+00	\N	\N	\N	\N	\N	\N
d47cba4d-3ee2-46c0-8ffc-39d6715bc5ae	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	9201bb61-f293-4bb5-be3f-2ab51726e98f	{"name": "فلوتنق فليك صغير"}	2026-05-09 13:41:05.022893+00	\N	\N	\N	\N	\N	\N
c1862c98-740c-4867-a1d1-f9baf889bb9f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3cbf1870-4016-468f-a567-ca4a8e41bdbd	{"name": "فلوتنق فليك كبير"}	2026-05-09 13:41:13.508274+00	\N	\N	\N	\N	\N	\N
8ff00662-ec07-451f-a9d6-5a3b829be0aa	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f41ee66f-0f44-4de8-a3ec-f3cd2d6f456c	{"name": "فلوتنق كندر صغير"}	2026-05-09 13:41:34.630551+00	\N	\N	\N	\N	\N	\N
9438d02d-4f46-45ae-9d12-6d1ed1180382	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a676558c-c99f-47ac-99f0-cc7e857a7b96	{"name": "فلوتنق كندر كبير"}	2026-05-09 13:41:43.106781+00	\N	\N	\N	\N	\N	\N
ee298fe5-9857-42d6-aadc-47210a4260e8	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4cddeadc-e850-48fc-b727-accf30b7c8d2	{"name": "فلوتنق كيت كات صغير"}	2026-05-09 13:42:01.217286+00	\N	\N	\N	\N	\N	\N
9a32f73f-6493-4a27-b67e-d7b0cb169a07	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ff070430-eb14-4384-82fd-477e5c8af74b	{"name": "فلوتنق كيت كات كبير"}	2026-05-09 13:42:12.209886+00	\N	\N	\N	\N	\N	\N
fe35fa93-c9a3-49e4-a2b4-33479d8dabd5	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	952ed8c2-6cd2-4754-9737-89bf81bdd953	{"name": "فلوتنق رمان صغير"}	2026-05-09 13:42:35.434051+00	\N	\N	\N	\N	\N	\N
828dc7cd-9c78-4e98-8223-fce3139d5a5a	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	14830915-d1cf-4125-9700-ba6751d3bc56	{"name": "فلوتنق رمان كبير"}	2026-05-09 13:42:42.622504+00	\N	\N	\N	\N	\N	\N
caf9eea8-d703-4bb2-93e9-301e5b1c5a5c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	66db2563-ceaf-47ab-8c41-9fe3bb0ff982	{"name": "فلوتنق لوتس كبير"}	2026-05-09 13:42:57.502456+00	\N	\N	\N	\N	\N	\N
65bf4bb1-0258-4a78-a064-400a5f5cab49	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	5e63519e-2a81-42c3-a720-18fb347245ba	{"name": "فلوتنق لوتس صغير"}	2026-05-09 13:43:05.094756+00	\N	\N	\N	\N	\N	\N
c72ce055-a2bb-4f61-9059-83af8d48d1d8	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2c4645e5-3045-4bbd-8c8b-901496be3ab7	{"name": "فراوله شوكلت 30 حبه"}	2026-05-09 13:45:20.405155+00	\N	\N	\N	\N	\N	\N
17444d9c-ccc3-437a-b6b8-318c18e38152	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	234d28a1-445d-421f-9799-7f1ba5633742	{"name": "ايس كريم بوكس صغير 7 حبات"}	2026-05-09 14:10:08.877372+00	\N	\N	\N	\N	\N	\N
33c416fe-5f0f-47b9-8712-39b7f1a10d19	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c658969d-49a8-424e-9ce5-040678d68d49	{"name": "عصير عوار قلب جالون 1 لتر"}	2026-05-09 14:14:41.273972+00	\N	\N	\N	\N	\N	\N
6a6bba42-5620-4205-b04d-b6568e4dca2a	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	5b214798-f84b-48b2-b692-1b6fedaff53e	{"name": "على شانى كبير"}	2026-05-09 14:30:27.693395+00	\N	\N	\N	\N	\N	\N
15e94ff0-5b6d-45f5-ba55-da466c0be441	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a6d917a6-5395-449f-8cab-06687fe772f1	{"name": "على شانى صغير"}	2026-05-09 14:30:38.663368+00	\N	\N	\N	\N	\N	\N
4bc268e5-0713-4de4-b9ff-ecc7ea137f79	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	53a4ffb3-3588-4138-a020-c9a7053edd9e	{"name": "عصير برتقال جالون 1 لتر"}	2026-05-09 14:35:01.528553+00	\N	\N	\N	\N	\N	\N
ced45b57-9a2e-44a7-bbe0-d0b76c1f5496	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	48de04c2-ec88-47ba-aca2-466f397df5db	{"name": "عصير جريني جالون 1.5 لتر"}	2026-05-09 14:50:43.363811+00	\N	\N	\N	\N	\N	\N
4ae6be3d-e2a3-46c7-ad1a-46b351cfafdb	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8b3cbb65-5437-4f10-b2d2-af8a2d220817	{"name": "عصير موز حليب جالون 1.5 لتر"}	2026-05-09 14:51:02.774159+00	\N	\N	\N	\N	\N	\N
ecae5f41-943c-4b93-a5ed-7aab3d119720	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	60b7fa49-e56c-48fd-9cf6-8debd8b94c3d	{"name": "عصير امبراطور جالون 1.5 لتر"}	2026-05-09 14:51:19.933905+00	\N	\N	\N	\N	\N	\N
009e2f33-73bd-4999-bd4c-1d9b40b54c15	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	51c737c2-89f1-4924-88b0-fa9fdd234777	{"name": "عصير ليمون نعناع جالون 1.5 لتر"}	2026-05-09 14:51:37.731662+00	\N	\N	\N	\N	\N	\N
5995c997-f72e-4e2e-bbfe-44cc9a976994	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7ae61e2b-a8b0-4b32-8a7e-15e2cb9f32f3	{"name": "فيتامين 1 لتر جالون"}	2026-05-09 14:51:48.152033+00	\N	\N	\N	\N	\N	\N
f41d04dc-0382-4224-9d59-d2438659beb6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	620058d9-a93b-4a74-8b6e-ec6c2ce05820	{"name": "عصير فينيسيا جالون 1 لتر"}	2026-05-09 14:51:56.802541+00	\N	\N	\N	\N	\N	\N
9711c229-b9f5-4e3f-aca4-0b8a8fa33a62	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f7bd809f-fee9-4be4-ba3d-9f76cce1ea10	{"name": "عصير جريب فروت جالون 1.5 لتر"}	2026-05-09 14:52:24.903683+00	\N	\N	\N	\N	\N	\N
5628a49c-0ef1-4902-8dc7-3559e2cecd97	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	48de04c2-ec88-47ba-aca2-466f397df5db	{"name": "عصير جريني جالون 1.5 لتر"}	2026-05-09 14:52:36.679533+00	\N	\N	\N	\N	\N	\N
dafaf3f3-2f07-4e4c-a9e8-36c1203ca3b7	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7ae61e2b-a8b0-4b32-8a7e-15e2cb9f32f3	{"name": "فيتامين 1 لتر جالون"}	2026-05-09 14:52:50.852864+00	\N	\N	\N	\N	\N	\N
639b1a39-9168-4ca4-85e8-639df06189fc	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	620058d9-a93b-4a74-8b6e-ec6c2ce05820	{"name": "عصير فينيسيا جالون 1 لتر"}	2026-05-09 14:52:59.9204+00	\N	\N	\N	\N	\N	\N
0bd3244b-dd5f-42e7-b990-27fab59ce50b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a74ae284-a3f1-425d-b80e-11e2a12d84ef	{"name": "عصير تفاح جالون 1.5 لتر"}	2026-05-09 14:53:19.378704+00	\N	\N	\N	\N	\N	\N
f6fedf46-cccf-4354-93cf-cf83b90f30a0	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3993f7c5-2e3a-46d4-b2e6-fdcd2f2c7969	{"name": "عصير كيوي جالون 1.5 لتر"}	2026-05-09 14:53:33.535479+00	\N	\N	\N	\N	\N	\N
99d73978-deae-4c39-b6cc-e811ec7f1f6b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	669ad8e6-017a-4ee2-a409-02aa6b76e012	{"name": "عصير جريني جالون 1 لتر"}	2026-05-09 14:54:01.205903+00	\N	\N	\N	\N	\N	\N
fcf5a901-b642-4929-918c-e94054b843d0	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	cb2cef01-a8e0-4d4a-9f15-4ca877543d6d	{"name": "عصير جريب فروت جالون 1 لتر"}	2026-05-09 14:54:09.983942+00	\N	\N	\N	\N	\N	\N
2154afa4-a8d2-4baa-a321-be10c788c49e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	9e776e05-a039-4416-8778-a723849f85e0	{"name": "عصير جزر جالون 1 لتر"}	2026-05-09 14:54:18.910249+00	\N	\N	\N	\N	\N	\N
c1d9c1a9-d089-45cf-8dcc-6f488c8f4166	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	51c737c2-89f1-4924-88b0-fa9fdd234777	{"name": "عصير ليمون نعناع جالون 1.5 لتر"}	2026-05-09 14:54:41.044391+00	\N	\N	\N	\N	\N	\N
acb1d206-8f3b-4407-b62a-82efcdb81d32	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8b3cbb65-5437-4f10-b2d2-af8a2d220817	{"name": "عصير موز حليب جالون 1.5 لتر"}	2026-05-09 14:54:48.490542+00	\N	\N	\N	\N	\N	\N
a8634f9c-b6e9-4f69-81b9-ceb764604450	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8cddc43b-3e3b-4f8e-8adb-b1c7895540d7	{"name": "عصير بطيخ جالون 1.5 لتر"}	2026-05-09 14:54:57.92459+00	\N	\N	\N	\N	\N	\N
94b11674-ba26-416d-b6fd-a7c4ba76316c	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	62c4b0b5-007c-4556-9d8a-2755faffd38f	{"name": "عصير شمام جالون 1.5 لتر"}	2026-05-09 14:55:06.424966+00	\N	\N	\N	\N	\N	\N
31a5acd7-cf56-4278-b281-8414dca7f24f	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ed90e4a0-38e1-4f04-8d93-fc431f74427e	{"name": "عصير اناناس جالون 1.5 لتر"}	2026-05-09 14:55:18.91854+00	\N	\N	\N	\N	\N	\N
5f730d05-549e-4f1b-926e-807628858421	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f97bb60f-8a9c-4f09-8fee-bc0b0762a3d5	{"name": "عصير مانجا فرغلي جالون 1.5 لتر"}	2026-05-09 14:55:26.302827+00	\N	\N	\N	\N	\N	\N
89ae5d67-177d-42e7-82c7-0cc29d7006ff	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	7cf1ea8a-85f0-48de-9992-5864bd59c911	{"name": "عصير رمان جالون 1.5 لتر"}	2026-05-09 14:55:34.55572+00	\N	\N	\N	\N	\N	\N
c0798474-5bab-407f-8c8b-9fc5739d9dfe	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	e1fbc14f-ce6c-4d30-8884-b72807f4683a	{"name": "عصير كوكتيل طازج جالون 1.5 لتر"}	2026-05-09 14:55:42.072945+00	\N	\N	\N	\N	\N	\N
2029882b-0ec4-4917-b8fc-a0fcb0d2d260	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6df65545-4892-4fee-93eb-83693bb6e53a	{"name": "عصير اينشتاين جالون 1.5 لتر"}	2026-05-09 14:56:04.437576+00	\N	\N	\N	\N	\N	\N
3ca1b4e6-39cd-4cc3-953f-1b12aef6d973	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a5e2df46-d477-438f-b589-85861cc021f5	{"name": "عصير كوكتيل جالون 1.5 لتر"}	2026-05-09 14:56:32.839293+00	\N	\N	\N	\N	\N	\N
a07b7c7d-b56f-415e-a7cb-ea9f73fba598	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4c28b012-4055-4e3a-a8fe-5706639760d2	{"name": "عصير رجيم جالون 1.5 لتر"}	2026-05-09 14:56:43.161011+00	\N	\N	\N	\N	\N	\N
12a96a3a-1c9c-4d5f-bc56-17f8dbe49cca	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	60aa52c0-e46f-42fd-839a-5cecf3ccd814	{"name": "عصير الفجر جالون 1.5 لتر"}	2026-05-09 14:56:52.775223+00	\N	\N	\N	\N	\N	\N
6dae9ae4-a3ff-47e1-9c3d-634024ff8a79	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	6022b7c4-d761-4e45-b4d5-640d344c8cfd	{"name": "عصير كوكتيل سبيشل مكس جالون 1.5 لتر"}	2026-05-09 14:57:02.546417+00	\N	\N	\N	\N	\N	\N
b9d242e9-856a-4d01-ab6d-0c207052d353	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	581037f9-f385-4bf4-bad9-32e1aa709b40	{"name": "عصير فينيسيا جالون 1.5 لتر"}	2026-05-09 14:57:12.520455+00	\N	\N	\N	\N	\N	\N
12ea0513-7205-49b1-b619-d22f3a443fdf	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	967d7bd5-4d6e-4751-afc9-e6de8b4252ad	{"name": "عصير كوكتيل سبيشل مكس جالون 1 لتر"}	2026-05-09 14:57:22.104537+00	\N	\N	\N	\N	\N	\N
f4fe1eef-0b18-45fb-a2dc-77d722cfb85b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	39e9dec5-5b83-4da6-9773-7f7765c00554	{"name": "عصير رجيم جالون 1 لتر"}	2026-05-09 14:57:29.736461+00	\N	\N	\N	\N	\N	\N
c413747f-eeef-41bf-b7ff-e5df76e67231	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	ceadb326-e6b0-40bf-b9e9-32ceaff19239	{"name": "عصير كوكتيل جالون 1 لتر"}	2026-05-09 14:57:38.902169+00	\N	\N	\N	\N	\N	\N
ad0d3bbe-9686-4695-8222-182871224bed	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	9c962687-44c3-4fbe-8a0d-b62359e16898	{"name": "جزر جالون 1.5 لتر"}	2026-05-09 14:58:00.009702+00	\N	\N	\N	\N	\N	\N
3ac55d96-6447-437b-919a-6d7317bc332a	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4b89f94e-a9da-45bb-aaef-1fd4d6c0dc69	{"name": "عصير بيري سموذي جالون 1 لتر"}	2026-05-09 14:58:08.231789+00	\N	\N	\N	\N	\N	\N
726c45e5-9824-4223-9642-cfd742358d58	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	b8962dec-968e-40f6-bf0c-58402ce5b984	{"name": "عصير اينشتاين جالون 1 لتر"}	2026-05-09 14:58:18.095266+00	\N	\N	\N	\N	\N	\N
281946ca-bb7a-4d0b-98f5-628f3522e95a	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d39a7941-c711-49f4-b3f2-a5c93aa068df	{"name": "عصير امبراطور جالون 1 لتر"}	2026-05-09 14:58:34.234248+00	\N	\N	\N	\N	\N	\N
02913f97-570e-4e82-a8c3-f3d907286373	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	93a94960-104f-4492-8334-9f4fbcf363a1	{"name": "عصير موز حليب جالون 1 لتر"}	2026-05-09 14:58:46.877688+00	\N	\N	\N	\N	\N	\N
9d04ee70-bdcc-4a3d-afb4-52816aadcfef	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3597dc92-70a6-4dbc-b0b6-7b49bf8aff70	{"name": "عصير ليمون نعناع جالون 1 لتر"}	2026-05-09 14:58:56.058028+00	\N	\N	\N	\N	\N	\N
03943d90-a31e-4768-9078-00d6b675a295	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	fb864943-7021-4a4b-a533-e195614c3b86	{"name": "عصير تفاح جالون 1 لتر"}	2026-05-09 14:59:08.362521+00	\N	\N	\N	\N	\N	\N
4424522d-d925-428d-9944-fe76ec1d4eec	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	456b02df-a2cd-40f7-8f33-7cc9851a19da	{"name": "عصير كيوي جالون 1 لتر"}	2026-05-09 14:59:17.769156+00	\N	\N	\N	\N	\N	\N
29538d4a-b48d-4c6e-b880-0ee503d4b5c1	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	fc30bbec-f832-492e-bc0e-4a42331a0c6f	{"name": "عصير بطيخ جالون 1 لتر"}	2026-05-09 14:59:29.922197+00	\N	\N	\N	\N	\N	\N
39113b34-ae1f-4b29-bdb0-b7db56d4053e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	21528d80-2739-4ef6-b5c5-b00a3e53533d	{"name": "عصير شمام جالون 1 لتر"}	2026-05-09 14:59:49.557808+00	\N	\N	\N	\N	\N	\N
5a69b318-8f79-4092-8d86-f5c0c6d07c56	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	a9d377f7-7d7c-4a5c-94dd-1b313b46630f	{"name": "عصير اناناس جالون 1 لتر"}	2026-05-09 15:00:08.113616+00	\N	\N	\N	\N	\N	\N
fb578f8b-fc94-4e78-963e-e0035bd16936	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	79ce1db4-6c9c-487a-8e55-07e6f03c5041	{"name": "عصير مانجا فرغلي جالون 1 لتر"}	2026-05-09 15:00:20.878436+00	\N	\N	\N	\N	\N	\N
d0454697-3984-4058-8c78-fa6b1d829baf	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	41b3ed9f-006c-41c3-a823-514d0120a410	{"name": "عصير رمان جالون 1 لتر"}	2026-05-09 15:00:29.547492+00	\N	\N	\N	\N	\N	\N
a626b098-6b47-4c01-bf5c-faf549f35ece	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	17041e22-1070-4161-93b5-460402ade031	{"name": "عصير الفجر جالون 1 لتر"}	2026-05-09 15:00:46.44024+00	\N	\N	\N	\N	\N	\N
6bafc0ae-c1d2-44fa-b57b-ba97fd790d60	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1af87d44-1467-4cf6-bccb-276cbb9549f8	{"name": "عصير كوكتيل طازج جالون 1 لتر"}	2026-05-09 15:01:02.357988+00	\N	\N	\N	\N	\N	\N
a46e7288-b5f4-46fc-9a8c-6e605b9ead40	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	33249d27-2dd1-4da5-ac3d-8b088f1df268	{"name": "ميلك سيك سريلاك جالون 1.5 لتر"}	2026-05-09 15:03:24.303014+00	\N	\N	\N	\N	\N	\N
467749b4-c07d-4f15-827a-6aab1d623efc	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8764f8fb-f648-4fde-a3f0-f18e8a9f5adc	{"name": "ميلك شيك سنيكرز جالون 1.5 لتر"}	2026-05-09 16:33:11.960364+00	\N	\N	\N	\N	\N	\N
c4785e72-adda-409b-a385-bb55d697a0fa	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	8764f8fb-f648-4fde-a3f0-f18e8a9f5adc	{"name": "ميلك شيك سنيكرز جالون 1.5 لتر"}	2026-05-09 16:33:12.144452+00	\N	\N	\N	\N	\N	\N
39dc3b53-7796-4152-94a3-c7e5958c02fb	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	3798e73f-7bb0-4583-8b44-9f113a87a7b7	{"name": "ميلك شيك لوتس جالون 1.5 لتر"}	2026-05-09 16:33:59.08878+00	\N	\N	\N	\N	\N	\N
21f37336-5526-4af4-9529-5f1edc23424e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	1fcff925-149d-4f18-83e8-f44fdd7a70e1	{"name": "ميلك شيك نوتيلا جالون 1.5 لتر"}	2026-05-09 16:34:42.674859+00	\N	\N	\N	\N	\N	\N
b29dac16-d33f-45e1-b36f-cca00a578fdb	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4dc50d6f-5a0a-40f0-a184-5cf56da402bd	{"name": "ميلك شيك كندر جالون 1.5 لتر"}	2026-05-09 16:34:56.025895+00	\N	\N	\N	\N	\N	\N
29dc6591-814d-4300-a555-ab5668d71243	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	4dc50d6f-5a0a-40f0-a184-5cf56da402bd	{"name": "ميلك شيك كندر جالون 1.5 لتر"}	2026-05-09 16:34:56.458698+00	\N	\N	\N	\N	\N	\N
23dc6d9e-c972-4c3f-8d33-b12d45775373	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	fe76ac1b-9fa7-45ef-a440-8d95f7d8c11f	{"name": "ميلك شيك اوريو جالون 1.5 لتر"}	2026-05-09 16:35:38.884849+00	\N	\N	\N	\N	\N	\N
9722f73b-02e6-44af-bd65-95060c2a775e	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	fe76ac1b-9fa7-45ef-a440-8d95f7d8c11f	{"name": "ميلك شيك اوريو جالون 1.5 لتر"}	2026-05-09 16:35:39.350128+00	\N	\N	\N	\N	\N	\N
3a17ba34-c1ef-4e06-9bbd-3b8c47b6ee96	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	2616ce0e-862c-41a1-a906-b4dac86defda	{"name": "ميلك شيك بيستاشيو جالون 1.5 لتر"}	2026-05-09 16:36:33.486981+00	\N	\N	\N	\N	\N	\N
4ee3b7e6-eb56-4dc2-b08c-64d89396d989	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	96f05114-26cb-4a6d-881d-d05c64b0a553	{"name": "ميلك شيك سيريلاك جالون 1 لتر"}	2026-05-09 16:36:48.981036+00	\N	\N	\N	\N	\N	\N
ed6b7b7e-6421-4934-be67-642fb8394603	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	96f05114-26cb-4a6d-881d-d05c64b0a553	{"name": "ميلك شيك سيريلاك جالون 1 لتر"}	2026-05-09 16:36:48.98286+00	\N	\N	\N	\N	\N	\N
698e06ed-c68c-4572-8faa-e7e6b1a1d8e6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	96f05114-26cb-4a6d-881d-d05c64b0a553	{"name": "ميلك شيك سيريلاك جالون 1 لتر"}	2026-05-09 16:36:49.888324+00	\N	\N	\N	\N	\N	\N
3b0c9444-1159-412c-89de-7fd7a31faa86	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	96f05114-26cb-4a6d-881d-d05c64b0a553	{"name": "ميلك شيك سيريلاك جالون 1 لتر"}	2026-05-09 16:36:49.893952+00	\N	\N	\N	\N	\N	\N
0a887f37-55b8-4752-9aae-245945bd820b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	9ada2892-3fc7-4da8-9116-d31e3893f3d5	{"name": "ميلك شيك كندر جالون 1 لتر"}	2026-05-09 16:37:06.714166+00	\N	\N	\N	\N	\N	\N
a353743b-a60f-489e-b647-c11d89dbd21d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	67d7cc89-2101-47bb-9ec9-90b32acd3111	{"name": "ميلك شيك نوتيلا جالون 1 لتر"}	2026-05-09 16:37:24.562668+00	\N	\N	\N	\N	\N	\N
746282ca-fcf2-4d62-9f99-77b2d7dd954d	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	67d7cc89-2101-47bb-9ec9-90b32acd3111	{"name": "ميلك شيك نوتيلا جالون 1 لتر"}	2026-05-09 16:37:24.565417+00	\N	\N	\N	\N	\N	\N
c27be452-344b-4f75-9f3a-0ec20218cdba	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	67d7cc89-2101-47bb-9ec9-90b32acd3111	{"name": "ميلك شيك نوتيلا جالون 1 لتر"}	2026-05-09 16:37:24.929026+00	\N	\N	\N	\N	\N	\N
9133850b-4390-4c99-a231-4f70c2becb48	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	395ff3cc-7bf3-4b48-80e7-3de456249d3b	{"name": "ميلك شيك سنيكرز جالون 1 لتر"}	2026-05-09 16:37:41.788076+00	\N	\N	\N	\N	\N	\N
00260cd4-694f-4017-bbba-b236f572d2c2	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f2aea970-615a-4a0e-92df-0e64f8820cbc	{"name": "ميلك شيك اوريو جالون 1 لتر"}	2026-05-09 16:38:57.368524+00	\N	\N	\N	\N	\N	\N
73660578-f28f-40fa-999c-8b0dad7fe1d8	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f2aea970-615a-4a0e-92df-0e64f8820cbc	{"name": "ميلك شيك اوريو جالون 1 لتر"}	2026-05-09 16:38:57.382635+00	\N	\N	\N	\N	\N	\N
2353534f-53a6-45f8-a760-ec7eb1a5cd59	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c7cf9ebc-9598-47ac-84e1-01403f07958d	{"name": "ميلك شيك كرك جالون 1 لتر"}	2026-05-09 16:39:15.379974+00	\N	\N	\N	\N	\N	\N
2929cead-794a-4a67-ac06-9f1e34ba0bee	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c7cf9ebc-9598-47ac-84e1-01403f07958d	{"name": "ميلك شيك كرك جالون 1 لتر"}	2026-05-09 16:39:15.38405+00	\N	\N	\N	\N	\N	\N
60bb8ae1-3aa0-4f01-8c8b-7fbdbd980492	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	c7cf9ebc-9598-47ac-84e1-01403f07958d	{"name": "ميلك شيك كرك جالون 1 لتر"}	2026-05-09 16:39:15.697306+00	\N	\N	\N	\N	\N	\N
084a2cb1-6a3b-48c1-bbec-12d3a2d6be5b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f5edbacf-2830-466e-a940-784aeb9a82e1	{"name": "ميلك شيك كرك جالون 1.5 لتر"}	2026-05-09 16:39:23.817107+00	\N	\N	\N	\N	\N	\N
559160fa-d939-42c5-8fd0-8f127c7bed77	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	f5edbacf-2830-466e-a940-784aeb9a82e1	{"name": "ميلك شيك كرك جالون 1.5 لتر"}	2026-05-09 16:39:24.156711+00	\N	\N	\N	\N	\N	\N
aa1423aa-a776-4748-a671-9a8436b38e06	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	77f2be94-d8c2-472a-a92f-e9929f15a000	{"name": "ميلك شيك لوتس جالون 1 لتر"}	2026-05-09 16:40:19.531349+00	\N	\N	\N	\N	\N	\N
dacefcef-7ca8-4e4f-a144-df3cba307dda	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	77f2be94-d8c2-472a-a92f-e9929f15a000	{"name": "ميلك شيك لوتس جالون 1 لتر"}	2026-05-09 16:40:20.05018+00	\N	\N	\N	\N	\N	\N
48a47302-749a-427a-b497-ec4dc601c490	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	987d3778-2298-41b4-bfab-b462ade8750b	{"name": "ميلك شيك بيستاشيو جالون 1 لتر"}	2026-05-09 16:41:10.440575+00	\N	\N	\N	\N	\N	\N
d512b47e-29b2-4743-91af-670383e80304	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	987d3778-2298-41b4-bfab-b462ade8750b	{"name": "ميلك شيك بيستاشيو جالون 1 لتر"}	2026-05-09 16:41:10.452528+00	\N	\N	\N	\N	\N	\N
3a4d028e-ba4f-4282-9866-98fc71535bd6	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	987d3778-2298-41b4-bfab-b462ade8750b	{"name": "ميلك شيك بيستاشيو جالون 1 لتر"}	2026-05-09 16:41:10.867994+00	\N	\N	\N	\N	\N	\N
c6a71336-7677-4860-90b5-dbb4dac7bd62	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d4a8a892-3105-4346-ac10-b0475c05916e	{"name": "كراك أخضر"}	2026-05-09 16:44:39.117082+00	\N	\N	\N	\N	\N	\N
9468b759-19c7-4533-aa72-e90a8ec10ca8	42ddbd9d-c350-4ac3-9c08-24d499702bc4	update_product	products	d4a8a892-3105-4346-ac10-b0475c05916e	{"name": "كراك أخضر"}	2026-05-09 16:44:39.60961+00	\N	\N	\N	\N	\N	\N
d22d8399-45ab-4d1b-a3aa-9db3235e1c3a	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_customer	customers	ab2053e8-a834-47e5-915f-3c48a8ff61a3	{}	2026-05-10 09:15:45.709441+00	\N	\N	\N	\N	\N	\N
35876697-765a-49bd-a616-f157cfc969b7	3ccd7385-a949-4ba4-9eb9-32909c1061c0	create_driver	drivers	a0da9e6b-bc07-40a6-b06d-9907bee8279a	{}	2026-05-10 09:16:50.234585+00	\N	\N	\N	\N	\N	\N
c6d08d4e-a427-4c9d-9913-0dcdb7361882	3ccd7385-a949-4ba4-9eb9-32909c1061c0	create_zone	delivery_zones	0f030440-b781-4c52-b44d-10a1f8b9a81e	{}	2026-05-10 09:17:52.830977+00	\N	\N	\N	\N	\N	\N
b4012ba6-c15d-4095-821c-e9d9b9f64d68	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_zone	delivery_zones	0f030440-b781-4c52-b44d-10a1f8b9a81e	{}	2026-05-10 09:18:08.742725+00	\N	\N	\N	\N	\N	\N
4a580e6d-b1f0-4ffd-9c43-0e091c8e4b12	3ccd7385-a949-4ba4-9eb9-32909c1061c0	create_coupon	coupons	2a21faaa-9ac8-4891-90b6-8ab3a497251e	{}	2026-05-10 09:19:30.40539+00	\N	\N	\N	\N	\N	\N
51474238-9513-441b-9ec3-f3bb36d7e216	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_coupon	coupons	2a21faaa-9ac8-4891-90b6-8ab3a497251e	{}	2026-05-10 09:19:44.08017+00	\N	\N	\N	\N	\N	\N
ce9e02ed-870c-4f98-86c6-a5ecaa335d2f	3ccd7385-a949-4ba4-9eb9-32909c1061c0	update_coupon	coupons	2a21faaa-9ac8-4891-90b6-8ab3a497251e	{}	2026-05-10 09:19:55.84526+00	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: addon_group_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.addon_group_links (id, group_id, product_id, category_id) FROM stdin;
\.


--
-- Data for Name: addon_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.addon_groups (id, name_ar, name_en, is_required, min_select, max_select, display_order, created_at, updated_at) FROM stdin;
01fd3f31-6d00-48e1-b7c3-04a636d42495	الإضافات	Extras	f	0	10	1	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_settings (id, app_name, app_store_url, google_play_url, current_version, minimum_version, force_update, maintenance_mode, maintenance_message, push_settings, home_layout, updated_at) FROM stdin;
\.


--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.banners (id, title, subtitle, image_url, cta_text, cta_url, link_type, link_value, placement, platform, status, start_date, end_date, sort_order, created_at, updated_at, image_only) FROM stdin;
1bc7b2e3-fea7-43b2-b9f1-ad2cdb554eb4			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/banners/1330153c-fdb5-41e3-b68a-91701d20d17a.jpg			none		home	both	active	\N	\N	4	2026-05-09 08:45:05.477139+00	2026-05-09 08:45:05.477139+00	t
601a28a4-54c5-450c-b668-664366ff1b66			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/banners/ce517306-0bd5-4959-b78c-8aaa98e5be1a.jpg			none		home	both	active	\N	\N	3	2026-05-07 16:59:06.681191+00	2026-05-09 09:53:35.430951+00	t
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branches (id, name, phone, address, latitude, longitude, business_hours, is_active, accepts_orders, delivery_radius_km, delivery_fee, min_order_amount, display_order, created_at, updated_at) FROM stdin;
5b7dba03-d5e4-401e-af16-ff426261c5ff	الخبر	0512345678	شارع الملك فهد	\N	\N	{}	t	t	10.00	10.00	50.00	1	2026-05-07 13:25:31.263946+00	2026-05-07 13:25:31.263946+00
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_messages (id, name, phone, email, message, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: coupon_usages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coupon_usages (id, coupon_id, customer_id, order_id, discount_amount, created_at) FROM stdin;
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coupons (id, name, code, discount_type, discount_value, minimum_order, maximum_discount, start_date, end_date, usage_limit, usage_per_customer, status, branch_id, product_ids, category_ids, used_count, created_at, updated_at) FROM stdin;
2a21faaa-9ac8-4891-90b6-8ab3a497251e	new	NEW232	fixed	10	50	30	2026-05-10 00:00:00+00	2026-05-13 00:00:00+00	1	1	active	5b7dba03-d5e4-401e-af16-ff426261c5ff	{}	{}	0	2026-05-10 09:19:29.909613+00	2026-05-10 09:19:55.398416+00
\.


--
-- Data for Name: customer_addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_addresses (id, customer_id, title, city, district, street, building, landmark, latitude, longitude, is_default, created_at, floor, apartment, driver_notes) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, phone, email, status, notes, created_at, updated_at, last_login_at) FROM stdin;
40719f6e-bcf9-4ecd-beb3-37b063568404	عبدالرحمن	0553136586	\N	active	\N	2026-05-07 16:11:51.378451+00	2026-05-09 13:18:30.04558+00	2026-05-09 13:18:30.04558+00
ab2053e8-a834-47e5-915f-3c48a8ff61a3	Ali ahmed Warsame	55548862191	\N	active	\N	2026-05-10 08:52:16.805648+00	2026-05-10 09:15:44.450435+00	2026-05-10 08:52:17.42205+00
c0f8caee-fd0c-438c-9e65-12ea1b27963c	Ali Warsame	+252618862191	\N	active	\N	2026-05-12 08:36:56.789456+00	2026-05-12 08:36:57.524471+00	2026-05-12 08:36:57.524471+00
\.


--
-- Data for Name: delivery_zones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.delivery_zones (id, branch_id, name, delivery_fee, minimum_order, estimated_time_minutes, status, sort_order, notes, created_at, updated_at) FROM stdin;
0f030440-b781-4c52-b44d-10a1f8b9a81e	5b7dba03-d5e4-401e-af16-ff426261c5ff	new	15	3	30	active	0	\N	2026-05-10 09:17:51.893123+00	2026-05-10 09:18:07.873991+00
\.


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drivers (id, name, phone, email, avatar_url, branch_id, national_id, vehicle_type, plate_number, status, rating, is_active, notes, last_active_at, created_at, updated_at) FROM stdin;
a0da9e6b-bc07-40a6-b06d-9907bee8279a	ahmed 	5654566654556	\N	\N	5b7dba03-d5e4-401e-af16-ff426261c5ff	\N	moto	456gfd	available	0	t	\N	\N	2026-05-10 09:16:49.732729+00	2026-05-10 09:16:49.732729+00
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faqs (id, question, answer, category, status, show_in_faq, show_in_product, sort_order, created_at, updated_at) FROM stdin;
554ca16f-53a2-4e6f-bb8d-ef8a442e5a22	سؤال 	جواب	عام	published	t	t	0	2026-05-10 09:48:34.007879+00	2026-05-10 09:48:34.007879+00
\.


--
-- Data for Name: footer_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.footer_settings (id, logo_url, about_text, phone, email, address, working_hours, copyright_text, app_store_url, google_play_url, social_links, visible_sections, updated_at) FROM stdin;
2cb5075c-4562-4f4c-a339-d14045d988fd	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/footer/cb3ae709-ae7f-4ccf-a6b3-f96c2b737476.svg	عصير تايم وجهتك المميزة للاستمتاع بالعصائر الطازجة، الآيس كريم، الكريب، والوافل، المحضّرة بعناية من أجود المكونات والفواكه الموسمية لنقدّم لك مذاقًا لذيذًا وجودة تستحق التجربة.	05XXXXXXXX	info@aseertimeastern.com	الدمام	24 ساعة	جميع الحقوق محفوظة لشركة وقت العصير 2026	https://aseertimeastern.com	https://aseertimeastern.com	{"tiktok": "https://tiktok.com/@39ertime", "twitter": "https://x.com/39ertime", "facebook": "https://facebook.com/39ertime", "snapchat": "https://snapchat.com/add/39ertime", "instagram": "https://instagram.com/39ertime"}	{"apps": true, "about": true, "links": true, "social": true, "contact": true}	2026-05-09 08:25:51.683742+00
\.


--
-- Data for Name: header_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.header_settings (id, logo_url, show_logo, cta_text, cta_url, contact_phone, show_search, show_cart, show_login, show_branch_selector, show_cta, app_overrides, updated_at) FROM stdin;
8888a158-bda0-4340-9f8f-b94fccbd996b	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/header/7a8a8bfb-5c69-41af-9217-4641b268e55b.svg	t	اطلب الآن	/menu		t	t	t	t	t	{}	2026-05-10 09:36:24.784639+00
\.


--
-- Data for Name: hero_slides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hero_slides (id, title, subtitle, image_url, cta_text, cta_url, platform, text_color, text_alignment, status, start_date, end_date, sort_order, created_at, updated_at, image_only) FROM stdin;
cde7c698-b0e0-425d-af83-3cbb47864685	الرئيسية		https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/hero/3d168fe8-9590-4c74-9bf8-5cb18e49c9e0.jpg			both	#ffffff	start	active	\N	\N	2	2026-05-09 08:18:05.47216+00	2026-05-10 09:31:17.713241+00	t
281a4835-2f30-4a96-a9b9-9764d00c00b6	اهلا وسهلا 	اهلا وسهلا	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/hero/53a6f356-7067-454b-9980-60c3b1a8eaf0.png	زر 		both	#ffffff	start	active	\N	\N	3	2026-05-10 09:33:13.504658+00	2026-05-10 09:33:13.504658+00	f
03b3c81d-32e0-48e4-9633-e332d9e1fc11	الريسية		https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/hero/bec7358c-d1f1-4801-8757-648c48b88371.jpg			both	#ffffff	start	active	\N	\N	1	2026-05-07 17:06:31.007656+00	2026-05-10 09:33:58.759507+00	t
\.


--
-- Data for Name: home_section_banners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.home_section_banners (id, section_id, "position", anchor_section_id, image_mobile, image_tablet, image_desktop, title, subtitle, link_type, link_value, start_date, end_date, is_active, sort_order, created_at, updated_at) FROM stdin;
da94024f-36ad-424a-ac6e-e8cb7001dbfb	0cba381f-7265-4ebc-9444-37caeb4bc63e	standalone	\N	\N	\N	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/5a89223e-8158-4376-b6f8-6096f1ef26d2.jpg	بنر الحلا	\N	category	https://juice-dash-builder.lovable.app/menu/a710f505-ad95-4f6f-8f4b-fe68055a317b?q=	\N	\N	t	0	2026-05-09 09:34:59.675932+00	2026-05-09 09:35:08.144258+00
0e59b8b7-6caf-496c-9e01-54db696c8564	ec519950-f2ec-4b6b-aca6-58ede1657a8e	standalone	\N	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/8d0db5b6-0f27-483c-8661-1581159c75b6.jpg	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/fd8cb3e4-94c3-4363-bb2f-2ffa90cc67b4.jpg	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/8701a9dc-c474-4f0c-818a-493f3c1b4b45.jpg	\N	\N	none	\N	\N	\N	t	0	2026-05-09 09:42:27.764694+00	2026-05-09 09:42:27.764694+00
cfb52a73-48bc-474a-aadb-0c77a216629e	ec519950-f2ec-4b6b-aca6-58ede1657a8e	standalone	\N	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/84faca6a-d896-4adf-a207-c5656653c89e.jpg	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/2b0c43b3-0331-418a-85a5-2761672c552e.jpg	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/b85db6a0-4827-4a1b-873c-491a6a6f1a17.jpg	\N	\N	none	\N	\N	\N	t	0	2026-05-09 09:43:06.479294+00	2026-05-09 09:43:24.12932+00
331d9b68-f746-4167-8a2f-db635828a1c7	ec519950-f2ec-4b6b-aca6-58ede1657a8e	standalone	\N	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/fbf373d5-0a89-4973-96dd-eb27e22392de.jpg	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/fc2d59bf-43ab-43db-877e-a88ba4a79024.jpg	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/5b017077-a94d-45eb-bbaa-891798d0852e.jpg	\N	\N	none	\N	\N	\N	t	0	2026-05-09 09:43:39.668825+00	2026-05-09 09:44:23.983634+00
68d8c8fd-bd39-4661-beec-9596721311b9	ec519950-f2ec-4b6b-aca6-58ede1657a8e	standalone	\N	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/1557942e-f218-46f1-bd72-62d922c47e88.jpg	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/438667a7-a920-4f48-93e8-8bc498c30530.jpg	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/55ab5a2d-fd60-4cf2-9e62-49a0867a00ec.jpg	\N	\N	none	\N	\N	\N	t	0	2026-05-09 09:44:51.758845+00	2026-05-09 09:44:51.758845+00
ab838ed1-b5d5-48aa-be9e-49cdb1af8dc3	c689c36c-7552-49bf-bb4d-fba1366a0336	standalone	\N	\N	\N	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/home-banners/159c996e-ecf8-4656-8e91-19ede7c55620.jpg	\N	\N	none	\N	\N	\N	t	0	2026-05-09 09:49:12.154136+00	2026-05-09 09:49:12.154136+00
\.


--
-- Data for Name: home_sections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.home_sections (id, title_ar, title_en, section_type, display_style, sort_order, is_active, category_id, manual_product_ids, products_limit, show_view_all, view_all_url, settings, created_at, updated_at) FROM stdin;
f937b5ad-a469-4809-912e-2cff2ac000e4	هيرو	hero	hero_carousel	grid	0	t	\N	{}	6	t	\N	{}	2026-05-09 09:25:47.471761+00	2026-05-10 09:42:58.002329+00
68dde305-f5c3-46af-8513-a5dc1bcaaea5	أقسام التطبيق	App Sections	categories_section	grid	1	t	\N	{}	6	t	\N	{}	2026-05-09 09:26:23.493193+00	2026-05-10 09:42:58.027049+00
6732df19-a994-4dba-ab31-a56e82f1438a	الأكثر طلبا	Best Choice	products_carousel	carousel	2	t	\N	{80fdb0f6-4a57-4bbd-a0e1-f5b5696216c7,e7b416b8-4968-4e1f-b755-7baabeaca388,bf6a1af1-30f8-48f9-97c8-12732d5dc450,bd976b07-bd8e-4c33-aaa2-7daa4c6602eb,75ef537a-caf1-44cb-bd8b-de51117212bc,a44bc3b5-9928-41c8-b62c-40cad4ec011d,85b58a18-8dcb-4f61-9eaa-31725b3fbb63}	50	t	\N	{}	2026-05-09 09:26:53.207905+00	2026-05-10 09:42:58.027062+00
b197b7b8-7aba-4b88-a5aa-5e392aeacacd	العصائر الطازجة	Fresh Juices	products_grid	carousel	3	t	7ef407fe-ba82-4c84-ab55-8aae804af7f8	{}	50	t	\N	{}	2026-05-09 09:30:11.753424+00	2026-05-10 09:42:58.030997+00
9e5d31f4-9d72-4f4e-bf73-6c7e3cefb3cb	الحلا		category_products	carousel	5	t	a710f505-ad95-4f6f-8f4b-fe68055a317b	{}	50	t	\N	{}	2026-05-09 09:35:33.454041+00	2026-05-10 09:42:58.040257+00
0cba381f-7265-4ebc-9444-37caeb4bc63e			single_banner	grid	4	t	\N	{}	6	t	\N	{}	2026-05-09 09:34:35.511174+00	2026-05-10 09:42:58.040465+00
15ca5747-633a-48ae-848b-d633c39681b2	عروضنا	offers	products_carousel	vertical_list	6	t	d397ce0e-236e-4913-ae66-81a9f4e2b7ab	{5b6f7632-16b0-4d9c-a9a3-2bd24de404a4,e7b416b8-4968-4e1f-b755-7baabeaca388}	20	t	\N	{}	2026-05-09 09:39:08.19551+00	2026-05-10 09:42:58.042328+00
4342f36d-a353-4ee7-8650-c6b8756d556c	ايس كريم		products_carousel	carousel	11	t	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	{}	50	t	\N	{}	2026-05-09 09:49:48.475004+00	2026-05-10 09:42:58.046752+00
96ea06cf-f8ac-439b-8baa-63e247fc995e	اختيار عصير تايم		featured_products	featured_large	8	t	8ac569e9-cb25-405a-826f-8db56372b0d4	{}	50	t	\N	{}	2026-05-09 09:46:30.250521+00	2026-05-10 09:42:58.046324+00
81ea1ca3-3720-47d2-bb99-ac8785c5fd39	المنيو		categories_section	grid	9	t	\N	{}	6	t	\N	{}	2026-05-09 09:48:25.589553+00	2026-05-10 09:42:58.045544+00
c689c36c-7552-49bf-bb4d-fba1366a0336			single_banner	grid	10	t	\N	{}	6	t	\N	{}	2026-05-09 09:48:58.245398+00	2026-05-10 09:42:58.047408+00
ec519950-f2ec-4b6b-aca6-58ede1657a8e			banner_grid	grid	7	t	\N	{}	6	t	\N	{}	2026-05-09 09:41:42.389529+00	2026-05-10 09:42:58.045268+00
\.


--
-- Data for Name: import_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_logs (id, user_id, filename, summary, errors, created_at) FROM stdin;
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.integrations (id, provider, name, status, config, last_tested_at, last_test_status, last_test_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: navigation_menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.navigation_menu_items (id, menu_id, title, link_type, link_value, parent_id, sort_order, status, open_in_new_tab, created_at, updated_at) FROM stdin;
b05e721b-39a8-4f93-b210-b1c1d3bc042f	c3a93a45-60f5-4a47-b894-c6a632e2acfe	الشروط والأحكام	page	terms	\N	10	published	f	2026-05-09 08:32:00.807725+00	2026-05-09 08:32:00.807725+00
aaaa0636-8773-485d-b505-f77a578d2f21	c3a93a45-60f5-4a47-b894-c6a632e2acfe	سياسة الخصوصية	page	privacy	\N	20	published	f	2026-05-09 08:32:00.807725+00	2026-05-09 08:32:00.807725+00
458770ed-fdc1-4a8d-8847-fa07b5ccadb0	c3a93a45-60f5-4a47-b894-c6a632e2acfe	سياسة الاسترجاع	page	refund	\N	30	published	f	2026-05-09 08:32:00.807725+00	2026-05-09 08:32:00.807725+00
f7395e91-e73c-43b4-b2c7-b0cee16763c8	c3a93a45-60f5-4a47-b894-c6a632e2acfe	سياسة التوصيل	page	shipping	\N	40	published	f	2026-05-09 08:32:00.807725+00	2026-05-09 08:32:00.807725+00
dd876223-8473-4c20-9915-4a3a2935eb9d	c3a93a45-60f5-4a47-b894-c6a632e2acfe	سياسة الكوكيز	page	cookies	\N	50	published	f	2026-05-09 08:32:00.807725+00	2026-05-09 08:32:00.807725+00
\.


--
-- Data for Name: navigation_menus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.navigation_menus (id, name, location, status, created_at, updated_at) FROM stdin;
d7f197b0-2f5a-4938-a64b-bf8f70e71b57	الرئيسية	header	published	2026-05-07 14:23:22.71283+00	2026-05-07 14:23:22.71283+00
39272971-9315-4c06-bf44-2516def7bcac	المينو	header	published	2026-05-07 14:23:33.339267+00	2026-05-07 14:23:33.339267+00
81d7d93f-96d3-4c6a-9b8e-532395462854	فروعنا	header	published	2026-05-07 14:23:45.848764+00	2026-05-07 14:23:45.848764+00
ef886887-c777-47cd-8889-8b0d96254f25	تواصل معنا	header	published	2026-05-07 14:23:53.949934+00	2026-05-07 14:23:53.949934+00
c3a93a45-60f5-4a47-b894-c6a632e2acfe	من نحن	footer	published	2026-05-09 08:26:10.285309+00	2026-05-09 08:26:10.285309+00
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_settings (id, user_id, orders_enabled, drivers_enabled, inventory_enabled, integrations_enabled, email_enabled, push_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, title, message, type, is_read, action_url, created_at, user_id) FROM stdin;
723eede7-e545-4a40-ae10-54e330e97301	طلب جديد	تم استلام طلب رقم ORD-10001	order_new	f	/dashboard/orders/5cdcf4db-d57e-46ef-89fa-447999ab6d02	2026-05-07 16:11:51.378451+00	\N
\.


--
-- Data for Name: order_item_addons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_item_addons (id, order_item_id, addon_id, addon_name, price) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, product_id, variant_id, product_name, variant_name, quantity, unit_price, total_price, notes, product_image) FROM stdin;
e281ab66-55a4-4848-9202-76d847b3130a	5cdcf4db-d57e-46ef-89fa-447999ab6d02	2c4645e5-3045-4bbd-8c8b-901496be3ab7	\N	فراوله شوكلت 30 حبه	\N	1	195	195	\N	\N
\.


--
-- Data for Name: order_status_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_status_logs (id, order_id, old_status, new_status, changed_by, note, created_at) FROM stdin;
13388e86-b818-466f-ad69-467f42bbd106	5cdcf4db-d57e-46ef-89fa-447999ab6d02	\N	new	3ccd7385-a949-4ba4-9eb9-32909c1061c0	\N	2026-05-07 16:11:51.378451+00
a1393bf4-e848-4231-8aba-96328cb7ece7	5cdcf4db-d57e-46ef-89fa-447999ab6d02	new	accepted	3ccd7385-a949-4ba4-9eb9-32909c1061c0	\N	2026-05-09 07:40:16.903848+00
77d241d8-667e-4063-9b38-3fa923835c13	5cdcf4db-d57e-46ef-89fa-447999ab6d02	new	accepted	3ccd7385-a949-4ba4-9eb9-32909c1061c0	\N	2026-05-09 07:40:16.903848+00
2bbdb05a-08b5-4e23-9c4b-1e24a9bca6b2	5cdcf4db-d57e-46ef-89fa-447999ab6d02	accepted	preparing	3ccd7385-a949-4ba4-9eb9-32909c1061c0	\N	2026-05-09 07:40:23.879639+00
d0849e5a-7a12-44b9-a469-6da996088d98	5cdcf4db-d57e-46ef-89fa-447999ab6d02	accepted	preparing	3ccd7385-a949-4ba4-9eb9-32909c1061c0	\N	2026-05-09 07:40:23.879639+00
d59acbbe-590c-479d-9137-435d368a2dc6	5cdcf4db-d57e-46ef-89fa-447999ab6d02	preparing	ready	3ccd7385-a949-4ba4-9eb9-32909c1061c0	\N	2026-05-09 07:40:27.908376+00
edace09c-e0ae-4cbc-bb1f-d20b9dd02c22	5cdcf4db-d57e-46ef-89fa-447999ab6d02	preparing	ready	3ccd7385-a949-4ba4-9eb9-32909c1061c0	\N	2026-05-09 07:40:27.908376+00
9e216264-3d8a-4c32-b850-57dea01fc752	5cdcf4db-d57e-46ef-89fa-447999ab6d02	ready	delivered	3ccd7385-a949-4ba4-9eb9-32909c1061c0	\N	2026-05-09 07:40:31.727422+00
c3c111be-771d-41af-827f-0ae12c7bdab3	5cdcf4db-d57e-46ef-89fa-447999ab6d02	ready	delivered	3ccd7385-a949-4ba4-9eb9-32909c1061c0	\N	2026-05-09 07:40:31.727422+00
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, order_number, customer_id, branch_id, driver_id, order_type, status, payment_method, payment_status, subtotal, vat_amount, delivery_fee, discount_amount, total_amount, customer_notes, admin_notes, delivery_address_id, coupon_id, created_at, updated_at, customer_name, customer_phone, customer_email, branch_name, coupon_code, delivery_address_snapshot, estimated_preparation_time, estimated_delivery_time) FROM stdin;
5cdcf4db-d57e-46ef-89fa-447999ab6d02	ORD-10001	40719f6e-bcf9-4ecd-beb3-37b063568404	5b7dba03-d5e4-401e-af16-ff426261c5ff	\N	pickup	delivered	cash	pending	195	29.25	0	0	224.25	\N	\N	\N	\N	2026-05-07 16:11:51.378451+00	2026-05-09 07:40:31.727422+00	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: page_blocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.page_blocks (id, page_id, location, block_type, sort_order, is_active, settings, created_at, updated_at) FROM stdin;
4deca44f-8482-4fc1-8855-cc166869e85c	\N	home	image_text	2	t	{}	2026-05-08 09:55:11.572113+00	2026-05-08 09:55:11.572113+00
5c60320f-df53-4294-a782-129791fa2725	\N	home	vision_mission	3	t	{}	2026-05-08 09:55:15.663334+00	2026-05-08 09:55:15.663334+00
205b2fe2-236d-4f44-bdd9-9264b0123eb4	\N	home	why_us	4	t	{}	2026-05-08 09:55:18.303595+00	2026-05-08 09:55:18.303595+00
756b0ab3-9feb-44f2-85af-fe797c56262d	\N	home	stats	1	t	{}	2026-05-08 03:52:30.897028+00	2026-05-09 09:12:01.491652+00
522bbca0-5e8e-455f-876d-9ca197316b79	\N	home	cards	0	t	{}	2026-05-08 03:52:51.998416+00	2026-05-09 09:12:01.500502+00
cea5d145-118d-4d20-acdd-9a7c8fc38a1b	\N	home	offers	5	t	{}	2026-05-08 09:55:26.289675+00	2026-05-10 09:48:06.888419+00
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pages (id, title, slug, content, featured_image, status, show_in_header, show_in_footer, sort_order, created_at, updated_at) FROM stdin;
47b70512-cdb6-4619-8c6f-47b768e23ea4	سياسة الخصوصية	privacy	نحن في عصير تايم نحترم خصوصيتك ونلتزم بحماية بياناتك الشخصية وفق أنظمة المملكة العربية السعودية.\n\n1) البيانات التي نجمعها\n- بيانات الحساب: الاسم، الجوال، البريد الإلكتروني.\n- بيانات الطلب: العناوين، تفاصيل الطلبات، طرق الدفع.\n- بيانات الاستخدام: عنوان IP، نوع الجهاز، صفحات الزيارة.\n\n2) كيف نستخدم بياناتك\n- معالجة الطلبات والتوصيل وخدمة العملاء.\n- تحسين تجربة المستخدم وتطوير خدماتنا.\n- إرسال إشعارات الطلبات والعروض (يمكنك إيقافها).\n\n3) مشاركة البيانات\nلا نبيع بياناتك. قد نشاركها مع شركاء التوصيل والدفع بالقدر اللازم لتنفيذ الخدمة فقط.\n\n4) أمن البيانات\nنطبق إجراءات تقنية وتنظيمية مناسبة لحماية بياناتك من الوصول غير المصرح به.\n\n5) حقوقك\nيحق لك طلب الاطلاع على بياناتك أو تصحيحها أو حذفها بمراسلتنا.\n\n6) ملفات تعريف الارتباط (Cookies)\nراجع "سياسة ملفات تعريف الارتباط" لمعرفة المزيد.	\N	published	f	t	20	2026-05-09 08:32:00.807725+00	2026-05-09 08:32:00.807725+00
ca809b47-92eb-4242-a54d-4bd71e4a3382	سياسة الاسترجاع والاستبدال	refund	نسعى لتقديم منتجات بأعلى جودة، وفي حال وجود مشكلة في طلبك تطبّق السياسة التالية:\n\n1) المنتجات الغذائية الطازجة\nنظرًا لطبيعة المشروبات والعصائر الطازجة، لا يمكن استرجاعها بعد التسليم إلا في حالات:\n- وصول المنتج تالفًا أو غير مطابق للطلب.\n- وجود خطأ من جانبنا في تجهيز الطلب.\n\n2) خطوات تقديم الشكوى\n- التواصل معنا خلال 30 دقيقة من استلام الطلب عبر "تواصل معنا".\n- إرفاق صورة للمنتج ورقم الطلب.\n\n3) الحلول المتاحة\n- إعادة تجهيز الطلب مجانًا، أو\n- استرداد المبلغ كاملًا أو جزئيًا حسب الحالة.\n\n4) مدة الاسترداد\nيتم استرداد المبلغ خلال 5–10 أيام عمل لنفس وسيلة الدفع المستخدمة.	\N	published	f	t	30	2026-05-09 08:32:00.807725+00	2026-05-09 08:32:00.807725+00
a927de47-ab37-4ce3-b073-26a343235e95	سياسة التوصيل	shipping	نوفّر خدمة التوصيل لعدد من المناطق وفق الشروط التالية:\n\n1) مناطق التوصيل\nيتم تحديد مناطق التوصيل حسب الفرع المختار وقد تختلف الرسوم والوقت حسب المنطقة.\n\n2) رسوم التوصيل\n- يتم احتسابها تلقائيًا عند إتمام الطلب وفقًا للمنطقة.\n- قد تطبق رسوم إضافية للطلبات الأقل من الحد الأدنى.\n\n3) وقت التوصيل\n- المدة المتوقعة 30–60 دقيقة حسب المنطقة وحجم الطلب.\n- قد تتأثر المدة في أوقات الذروة أو الطقس.\n\n4) الاستلام من الفرع\nيمكنك اختيار "استلام من الفرع" مجانًا عند إتمام الطلب.	\N	published	f	t	40	2026-05-09 08:32:00.807725+00	2026-05-09 08:32:00.807725+00
2c6b3230-30d5-47d9-af3f-306d125f3899	سياسة ملفات تعريف الارتباط	cookies	نستخدم ملفات تعريف الارتباط (Cookies) لتحسين تجربتك على الموقع.\n\n1) ما هي Cookies\nملفات صغيرة تُحفظ على جهازك تساعدنا في تذكّر تفضيلاتك وتحليل استخدام الموقع.\n\n2) أنواع الكوكيز التي نستخدمها\n- ضرورية: لتشغيل السلة والحساب.\n- وظيفية: لتذكر اللغة والفرع المختار.\n- تحليلية: لفهم سلوك الزوار وتحسين الخدمة.\n\n3) إدارتها\nيمكنك التحكم في الكوكيز من إعدادات متصفحك. تعطيلها قد يؤثر على بعض الميزات.	\N	published	f	t	50	2026-05-09 08:32:00.807725+00	2026-05-09 08:32:00.807725+00
16e5ec1b-c5d7-48d5-b9ee-52ac696c28a2	الشروط والأحكام	terms	مرحبًا بك في متجر عصير تايم. باستخدامك لموقعنا أو تطبيقنا فأنت توافق على الشروط والأحكام التالية.\n\n1) قبول الشروط\nيُعدّ استخدامك للخدمة موافقةً صريحة على هذه الشروط. إن لم توافق فيرجى عدم استخدام الخدمة.\n\n2) الطلبات والدفع\n- جميع الأسعار شاملة لضريبة القيمة المضافة ما لم يُذكر خلاف ذلك.\n- يحق لنا رفض أو إلغاء أي طلب لأسباب تشغيلية أو أمنية.\n- وسائل الدفع المتاحة موضحة في صفحة إتمام الطلب.\n\n3) التوصيل والاستلام\n- يلتزم العميل بتوفير عنوان توصيل صحيح ورقم تواصل فعّال.\n- مدة التوصيل تقديرية وقد تتأثر بظروف خارجة عن إرادتنا.\n\n4) المسؤولية\nلا نتحمل المسؤولية عن أي ضرر غير مباشر ناتج عن استخدام الخدمة في حدود ما يسمح به النظام.\n\n5) تعديل الشروط\nيحق لنا تعديل هذه الشروط في أي وقت وسيتم نشر النسخة المحدثة على هذه الصفحة.\n\nللاستفسار: تواصل معنا عبر صفحة "تواصل معنا".	\N	published	t	t	10	2026-05-09 08:32:00.807725+00	2026-05-10 09:39:57.162146+00
98e5918a-c217-48ca-949c-bbaec8df00ed	من نحن	about	\nفي عصير تايم نؤمن أن الطعم المميز يبدأ من جودة المكونات ودقة التحضير. لذلك انفردنا بطريقة خاصة في صناعة الآيس كريم، العصائر، الكريب، والوافل، تقوم على اختيار العناصر والمواد بعناية فائقة للحصول على قوام كريمي متجانس وتركيبة مثالية تمنحكم طعمًا لذيذًا ومتوازنًا يناسب جميع الأذواق.\n\nنحرص على أن يعيش زوارنا تجربة مختلفة، يستطيعون من خلالها تذوق نكهة ورائحة كل مكوّن بوضوح. ولهذا السبب نختار موادنا الخام الأولية بجودة عالية، ونستخدم الفواكه الطازجة الموسمية لضمان أفضل مذاق وأعلى مستوى من الجودة في كل طلب.	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/pages/76812124-b6dc-4753-a354-48b8499b697b.svg	draft	f	t	0	2026-05-09 08:21:07.195527+00	2026-05-10 09:40:39.338253+00
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, key, module, name, description) FROM stdin;
b5d2a9c8-1664-483e-9d47-6eefec548666	dashboard.view	dashboard	عرض الصفحة الرئيسية	\N
4f6f50a2-b1bf-4440-ae20-4c59a8a748d4	orders.view	orders	عرض الطلبات	\N
230ceade-402c-4f8b-8d51-4ad19b0f28a5	orders.detail	orders	عرض تفاصيل الطلب	\N
255a037a-f148-43eb-b684-1a26e6471c22	orders.status	orders	تعديل حالة الطلب	\N
1073ed01-2cbc-4a9a-87b1-1dd68d9d28c4	orders.cancel	orders	إلغاء الطلب	\N
75c4b694-216f-4bd0-8835-569156a3c01e	orders.assign_driver	orders	تعيين سائق	\N
604f145c-fd1c-44ea-bf2a-1c7023452bf0	orders.print	orders	طباعة الفاتورة	\N
67cf3302-50cc-4a08-a165-754a2a8bee8a	products.view	products	عرض المنتجات	\N
43f8262a-272a-413d-8629-d41c58368037	products.create	products	إضافة منتج	\N
b08dea0c-968e-43d8-86bc-01eebfb1297a	products.edit	products	تعديل منتج	\N
4af4940b-3fc5-484a-84e5-bd0f0c91e319	products.delete	products	حذف منتج	\N
69a82270-6a98-487e-b550-7f177d88206e	products.toggle	products	تفعيل/تعطيل منتج	\N
fd2087e2-529d-4be5-ad58-9227b1ffddad	products.import	products	استيراد Excel	\N
5a656ae2-3b76-4316-b859-68109ee5a4df	categories.view	categories	عرض الأقسام	\N
9deae1bb-ff68-49fd-9b34-c8ad74364433	categories.create	categories	إضافة قسم	\N
90e20729-452b-4413-bc0f-16ed42f924de	categories.edit	categories	تعديل قسم	\N
a19713f4-b5a2-428a-969a-c8af923fbc3a	categories.delete	categories	حذف قسم	\N
e1bec974-41e6-4103-a6b2-c0fbcbe80964	addons.view	addons	عرض الإضافات	\N
2ef3eb2e-0ff0-4f2d-a098-8496a2e163c2	addons.create	addons	إضافة إضافة	\N
eec5643b-773b-44cf-a0f0-b9a95f91dfe4	addons.edit	addons	تعديل إضافة	\N
a09749f9-a025-4e72-94ac-fda9354ebe8a	addons.delete	addons	حذف إضافة	\N
feb61725-d370-4e96-b82e-aed3a78a9000	branches.view	branches	عرض الفروع	\N
4701fd4d-4ae7-4984-9b26-55d05441eee0	branches.create	branches	إضافة فرع	\N
f6ee57f5-4db9-40dd-9844-5fbe59d0b4b6	branches.edit	branches	تعديل فرع	\N
6eff1688-fbd6-44e0-919e-703e3d6d193f	branches.toggle	branches	تعطيل فرع	\N
5d7142eb-637a-4b60-a2cc-bbd23ecbdde0	drivers.view	drivers	عرض السائقين	\N
52e8cc91-d5bd-4e40-a33f-97682b410c59	drivers.create	drivers	إضافة سائق	\N
62def2fa-6266-412e-ac53-11defd37325e	drivers.edit	drivers	تعديل سائق	\N
fe42728b-a0e7-4ffe-bd9c-2228e881ac1e	drivers.toggle	drivers	تعطيل سائق	\N
a01b833f-992c-4873-b4ee-1c8d889d24fe	customers.view	customers	عرض العملاء	\N
b4e48fa7-7074-44a8-8d6a-698a454497ff	customers.edit	customers	تعديل العميل	\N
20fcda77-44fd-462d-a080-7217ef607314	customers.block	customers	حظر العميل	\N
368b0b21-6377-447c-87a6-32f73f1dac32	coupons.view	coupons	عرض الكوبونات	\N
efc04d8a-dd0a-49d7-a45c-a4f0cca91453	coupons.create	coupons	إضافة كوبون	\N
74a2d0e4-9965-4825-9f75-6ae003aa9274	coupons.edit	coupons	تعديل كوبون	\N
0e2741f5-1990-4a51-9d94-05eb53c73ceb	coupons.toggle	coupons	تعطيل كوبون	\N
9d5ea7ca-8d08-4b51-9b00-d4ba484fca8a	banners.view	banners	عرض البنرات	\N
fb31d919-23a6-4482-94d8-3a0499a6225e	banners.manage	banners	إدارة البنرات والهيرو	\N
bd3edb9a-50ca-4971-ace8-a71cc98d7480	content.pages	content	إدارة الصفحات	\N
58dc03e3-83d4-4fca-bb57-390e3299a951	content.header	content	إدارة الهيدر	\N
69f4f18e-3746-40ca-a134-06c4f392112f	content.footer	content	إدارة الفوتر	\N
0cef0109-5f7b-40d0-9959-816b44559298	content.menus	content	إدارة المنيو	\N
32ae66bc-00b4-4564-b7b0-64e3b44c673f	content.faq	content	إدارة FAQ	\N
a8faf6e2-e879-4140-a6ce-9f2508ce91ac	seo.view	seo	عرض SEO	\N
57904a88-6b11-4c88-981e-c2fcba72aa3d	seo.edit	seo	تعديل SEO	\N
386a9bf8-e004-4b2c-974c-c7526c8686cb	integrations.view	integrations	عرض التكاملات	\N
8f813b32-2b6b-4f18-b87e-66f897b1a15e	integrations.edit	integrations	تعديل مفاتيح التكامل	\N
90f7d6be-fb04-48c9-82b8-8f853b113ace	integrations.test	integrations	اختبار الاتصال	\N
0e006170-fbe4-438f-9e7e-01ed1d563fde	reports.view	reports	عرض التقارير	\N
74b938ec-2c31-4253-8d8e-08fd40b49a39	reports.export_excel	reports	تصدير Excel	\N
6e56d4d9-4da3-42e9-abb6-6e9cfd733515	reports.export_pdf	reports	تصدير PDF	\N
ddb8e2cc-129e-436b-b5f8-83340d5f3473	settings.view	settings	عرض إعدادات المتجر	\N
7ba46ad7-22d0-40f4-be48-09f8e13ecc3a	settings.edit	settings	تعديل إعدادات المتجر	\N
ccfbdbae-640a-4955-b162-b9af5a79dc63	settings.app	settings	إعدادات التطبيق	\N
6709d927-d037-4717-ac97-bc91de8ae20e	users.view	users	عرض المستخدمين	\N
1c59ed7b-c2e0-4d17-950f-966aaaff8447	users.create	users	إضافة مستخدم	\N
c592332b-da94-40ef-ae0b-ea35a1214511	users.edit	users	تعديل مستخدم	\N
999009ed-302d-4f3e-bc77-19a2c8165e58	users.permissions	users	إدارة الصلاحيات	\N
3409787a-5a4e-41b0-a9ee-364b376a5eb5	activity.view	activity	عرض سجل النشاط	\N
\.


--
-- Data for Name: product_addons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_addons (id, group_id, name_ar, name_en, price, is_available, display_order, created_at, updated_at) FROM stdin;
b4cf5685-5726-4224-9337-83d1a0255b01	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافه افوكادو	Avacado Juice Extra	2.00	t	0	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
06ba2d62-21b4-4f51-8f3e-fed24712d0d5	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافه كيوي	Kiwi Juice Extra	2.00	t	1	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
ec9253aa-355f-48e0-b830-8c71d93052ab	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافة عصير شمندر	Betroot Juice Extra	2.00	t	2	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
eba4ea24-b9f0-475a-b23d-95a5c83ded98	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافه عصير بطيخ	Water Melon Extra	2.00	t	3	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
b132ae20-5cf3-474d-9abf-e61f1ac05a33	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافة عصير فراوله	Strawbeery Juice Extra	2.00	t	4	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
943b10e0-9019-42bd-8b62-4c08472a68ac	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافه عصير ليموت	Lemon Juice Extra	2.00	t	5	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
6829662f-e3f1-40dc-9f26-2ab27a9bb12f	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافه عصير رومان	Pomegranate Juice Extra	2.00	t	6	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
91dc3329-24ec-4223-bb07-7c1d35a74083	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافه عصير اناناس	Pineapple Juice Extra	2.00	t	7	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
b58ea110-8937-4721-8ebd-a5166c60ef91	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافه عصير تفاح	Apple Juice Extra	2.00	t	8	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
2e457f3b-7dbd-4096-a259-c11df4ee0b5d	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافة منجا	Mango Juice Extra	2.00	t	9	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
51ccc557-4b05-489f-ad2f-c7ba94e7a4b3	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافة موز	Banana Juice Extra	2.00	t	10	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
4c43785f-c189-43ab-a49a-c5480c75ce0e	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافة جزر	Carrot Juice Extra	2.00	t	11	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
60851277-4d07-4ba0-b7e3-c699a71918c6	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضاة شمام	Melon Juice Extra	2.00	t	12	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
0847617e-8a43-4517-b5be-c4c798866449	01fd3f31-6d00-48e1-b7c3-04a636d42495	اضافة برتقان	Orange Juice Extra	2.00	t	13	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
d2257c43-f2eb-4ddb-a62a-c97df11d1a12	01fd3f31-6d00-48e1-b7c3-04a636d42495	صوص شوكلت ابيض	White Chocolate Sauce	5.00	t	14	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
e6babf87-96f6-43c3-a314-c444cb458d05	01fd3f31-6d00-48e1-b7c3-04a636d42495	صوص لوتس	Lotus Sauce	5.00	t	15	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
15b850ef-b760-4bbf-9686-5e22d4a3d5f1	01fd3f31-6d00-48e1-b7c3-04a636d42495	صوص شوكلت اسود	Black Chocolate Sauce	5.00	t	16	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
a0f44aec-fd86-4481-a2f8-d0df7a1de22b	01fd3f31-6d00-48e1-b7c3-04a636d42495	صوص كندر	Kinder Sauce	5.00	t	17	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
e4776c20-1226-492c-a4c4-c4862a47f0c6	01fd3f31-6d00-48e1-b7c3-04a636d42495	صوص بيستاشيو	Pistachio Sauce	5.00	t	18	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
06bfe608-4303-405b-8710-5c6929d51ff9	01fd3f31-6d00-48e1-b7c3-04a636d42495	صوص اوريو	Oreo Sauce	5.00	t	19	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
b9721c42-8229-4c7b-bc27-915645241e57	01fd3f31-6d00-48e1-b7c3-04a636d42495	صوص نوتيلا	Nutella Sauce	5.00	t	20	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
4d5de2d8-a7f8-408d-9b68-8fea9e586de4	01fd3f31-6d00-48e1-b7c3-04a636d42495	بابلز	Bubbles	5.00	t	21	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
3db7f645-99e9-473e-9f63-093a77d6f480	01fd3f31-6d00-48e1-b7c3-04a636d42495	شعر بنات ازرق	Blue cotton candy	5.00	t	22	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
a9d0e875-b42a-4a86-9a8e-cfacf725a115	01fd3f31-6d00-48e1-b7c3-04a636d42495	اصابع كندر	Kinder Fingers	5.00	t	23	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
85e1945c-c1c3-484a-961d-ea27a3807aaa	01fd3f31-6d00-48e1-b7c3-04a636d42495	عسل	Honey	2.00	t	24	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
aa72e250-1458-4971-8e59-b0f621151ad1	01fd3f31-6d00-48e1-b7c3-04a636d42495	ايس كريم فانيلا	Vanilla Ice-Cream	4.00	t	25	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
2f266abc-d234-4987-b97a-bf30422c8d10	01fd3f31-6d00-48e1-b7c3-04a636d42495	مكسرات	Nuts	5.00	t	26	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
a6a18129-06c7-452a-85b3-f78df6b0e6d9	01fd3f31-6d00-48e1-b7c3-04a636d42495	شرائح ليمون نعناع	Lemon Mint Slides	2.00	t	27	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
7ca41be7-2fc6-4f21-9162-d41ceda78582	01fd3f31-6d00-48e1-b7c3-04a636d42495	موز	Banana	2.00	t	28	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
6f793659-93be-48a1-a3ed-7a0ab9d3ba7f	01fd3f31-6d00-48e1-b7c3-04a636d42495	بودر لوتس	Powder Lotus	5.00	t	29	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
ee5be0a1-0d99-4208-a163-ab9500380161	01fd3f31-6d00-48e1-b7c3-04a636d42495	فراولة	Strawberry	4.00	t	30	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
2289059f-df56-45ce-9b76-aea846ba9a09	01fd3f31-6d00-48e1-b7c3-04a636d42495	قطع رافيلو	Raffaello	5.00	t	31	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
2ac8216f-16f6-4470-9bc9-1a60fc2dec74	01fd3f31-6d00-48e1-b7c3-04a636d42495	قطع فريرو روشيه	Ferrero Rocher	5.00	t	32	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
5773b786-32e0-4145-b353-ec8b4bed1d26	01fd3f31-6d00-48e1-b7c3-04a636d42495	شعربنات احمر	Red cotton candy	5.00	t	33	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
35ed0e4d-1766-4aac-bb67-4c6193fc376e	01fd3f31-6d00-48e1-b7c3-04a636d42495	كريسبي	Crispy	5.00	t	34	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
d05aabb2-ca85-4126-9ff5-8c0861c012aa	01fd3f31-6d00-48e1-b7c3-04a636d42495	ايس كريم ساندوتش	Sandwich Ice-Cream	5.00	t	35	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
b1f2e891-7675-4ac9-8e55-c49282e681c4	01fd3f31-6d00-48e1-b7c3-04a636d42495	اكسترا سيريلاك	Extra Serelak	3.00	t	36	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
7a04ec6d-96bd-4745-8d87-344cfd243117	01fd3f31-6d00-48e1-b7c3-04a636d42495	عبوة مني جوس	Mini juice Bottel	13.00	t	37	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00
\.


--
-- Data for Name: product_branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_branches (product_id, branch_id, is_available) FROM stdin;
\.


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_categories (id, name_ar, name_en, image_url, icon, parent_id, display_order, is_active, created_at, updated_at, show_on_home, show_in_app, show_in_store, is_featured, home_product_limit) FROM stdin;
8ac569e9-cb25-405a-826f-8db56372b0d4	ميلك شيك	Milkshake	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/categories/32d88505-fb5f-4022-bd9a-8012f94e2da9.jpg		\N	2	t	2026-05-07 12:59:13.873213+00	2026-05-09 08:58:21.154275+00	t	t	t	f	8
790aae02-4102-4e41-8487-03f1d8cb3567	فلوتنق	Floating	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/categories/3770ee7d-646b-42e5-8a45-357776647eb1.jpg		\N	8	t	2026-05-07 12:59:13.873213+00	2026-05-09 09:00:00.766635+00	t	t	t	f	8
0db67202-0d4a-4960-a468-83d733478e1d	مشروبات الطاقة	Energy Drinks	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/categories/8f6d02e3-ead9-429e-bd8e-8a83263839ae.jpg		\N	4	t	2026-05-07 12:59:13.873213+00	2026-05-09 09:01:13.149976+00	t	t	t	f	8
2c220e2c-dd8a-480a-aac8-8d105b2bce2f	آيس كريم	Ice Cream	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/categories/f1a69d1c-3824-4c3f-8d9e-17631bc12c28.jpg		\N	6	t	2026-05-07 12:59:13.873213+00	2026-05-09 09:02:15.240276+00	t	t	t	f	8
7ef407fe-ba82-4c84-ab55-8aae804af7f8	عصائر طازجة	Fresh Juices	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/categories/dbe41268-de3f-406e-bec1-a2f58db6b2b8.jpg		\N	5	t	2026-05-07 12:59:13.873213+00	2026-05-09 09:05:52.268368+00	t	t	t	f	8
d397ce0e-236e-4913-ae66-81a9f4e2b7ab	خلطات خاصة	Special Mixs	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/categories/07f7bf5c-2dcd-48b6-aeb6-b0f3f7aa328d.jpg		\N	4	t	2026-05-09 09:07:29.501342+00	2026-05-09 09:07:29.501342+00	t	t	t	f	8
a710f505-ad95-4f6f-8f4b-fe68055a317b	الحلا	Sweets	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/categories/f9fce23a-f239-4300-adf2-168607a60277.jpg		\N	1	t	2026-05-07 12:59:13.873213+00	2026-05-09 09:07:49.659767+00	t	t	t	f	8
1f599865-0727-4843-86ec-28d5af2aed93	جالون	Gallon	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/categories/c8d2c3c4-8cb7-4e37-86b0-7d88d8e892ae.jpg		\N	7	t	2026-05-07 12:59:13.873213+00	2026-05-09 09:11:05.281669+00	t	t	t	f	8
73fce410-bf36-4579-872f-b1b8d55815e5	بوكسات	Boxes	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/categories/e8240f9e-6af4-4359-bc61-7cf49fb1aceb.jpg		\N	3	t	2026-05-07 12:59:13.873213+00	2026-05-09 10:05:59.574774+00	t	t	t	f	8
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variants (id, product_id, name_ar, name_en, price, calories, sku, is_available, display_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name_ar, name_en, description_ar, description_en, image_url, category_id, base_price, calories, prep_time_minutes, is_available, display_order, show_in_app, show_in_store, is_featured, is_archived, created_at, updated_at, gallery_urls, discount_price) FROM stdin;
bc2d92f7-09b3-4b74-b720-3a0104e5c13c	وافل نوتيلا	Waffle Nutella			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/6d06b16b-9755-4068-9cfa-fbda92b4544e.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	35.00	651	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:22:52.319225+00	{}	\N
3692167a-8bc4-4ba8-931b-7487e06a2f9c	ميلك شيك كرك صغير	Karak S Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/cf48dade-f82f-4ded-b889-4be290daac81.png	8ac569e9-cb25-405a-826f-8db56372b0d4	16.00	646	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:34:28.410531+00	{}	\N
30b24ba1-ad62-4958-8024-f76d7b905c36	شوكلت الهبة لوتس	Lotus Chocolate	شوكلت كنافه لوتس	Lotus Kunafa Chocolate	\N	a710f505-ad95-4f6f-8f4b-fe68055a317b	39.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
08b275dc-222c-4db0-9d8d-b69b02dbcb83	تكميم بستاشيو	Takmim pistachio			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/2ebbb442-7b92-4328-881a-d3caa1b53e66.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	20.00	556	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:57:29.568127+00	{}	\N
24153a9d-3a42-4d72-af56-2b4cf0005cc8	شوكلت الهبة بيستاشيو	Pistachio Chocolate	شوكلت كنافه بيستاشيو	Chocolate Kunafa Pistachio	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/de283fac-82f4-413d-91a7-01dc955ef917.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	39.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:02:36.214089+00	{}	\N
cf11c2a8-c403-4200-a194-878483b04543	شوكلت الهبه بيكان	Chocolate Pecan	شوكلت كنافه بيكان	Chocolate Kunafa Pecan	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1837ca50-3467-4e96-b997-9a493e633a2f.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	39.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:04:04.15625+00	{}	\N
0e162232-3842-4d79-a57f-4771b3991ade	تكميم بيستاشيو كنافه	Pistachio Kunafa Sleeve			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/589e5e7f-fc49-4e2c-a4f0-4f87af33f3b2.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	25.00	190	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:14:52.281604+00	{}	\N
c13f7d8c-fef4-474d-96c6-4e8ba890912c	ميكس بيري صغير	Mix Berry Small			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/528f52f9-8f22-4e4e-85ab-39af6f727221.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	20.00	122	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:30:26.708949+00	{}	\N
2857d3c3-28fd-4fe6-868a-ef414c0a420f	ميكس بيري كبير	Mix Berry Large			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e20b6a4a-b581-4cd3-979a-0af134cafbd3.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	90.00	972	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:30:34.520118+00	{}	\N
5b6f7632-16b0-4d9c-a9a3-2bd24de404a4	المسافر صفر صغير	Al Mosafer Sfir S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/4565c033-b183-49d0-8349-cc263a78067a.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	20.00	860	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:35:35.257861+00	{}	\N
956ec9b0-3b0b-4a29-adda-6542199d90e0	ابو ريان 10 قطع	Bo Ryan 10 Pieces			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5a820b84-d22c-4c8d-aca0-f5ecb71e38d2.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	39.00	206	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:18:58.994123+00	{}	\N
80fdb0f6-4a57-4bbd-a0e1-f5b5696216c7	ابو ريان 6 قطع	Bo Ryan 6 Pieces			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/716d96b1-03e6-47be-b7b0-a2e528b8ff66.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	22.00	182	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:19:20.090706+00	{}	\N
76e26027-271d-4148-8ecc-8a02dfe9c68d	ماكنتوش السعادة	Happy Macintosh			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/32e205a0-ef13-4a1e-b994-c9f12f2a4e91.jpg	a710f505-ad95-4f6f-8f4b-fe68055a317b	120.00	181	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:25:41.663666+00	{}	\N
d26a88ea-6416-4a68-abd5-f1e322ba4709	تكميم نوتيلا	Takmim Nutella			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e88d859f-53c2-445c-8e9b-79dd066c3f12.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	17.00	651	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:29:36.007074+00	{}	\N
e7f3cecc-3422-4752-a265-d69ef8c68c43	تكميم لوتس	Takmim Lotas			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1158d14b-aaee-45ef-8093-91dfe24e0903.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	17.00	600	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:32:50.281923+00	{}	\N
8c4f4f1d-7626-4c97-bd22-ac001677d4e5	تكميم كندر	Takmim kinder			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/a6ca45bc-ee6e-492f-be6e-42760346012c.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	17.00	425	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:34:20.168438+00	{}	\N
52f6cd1e-d5f1-4241-885e-4d2a7617ea57	حلا غرقني	Gharegni			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b780b186-0d86-4189-838f-8e2d7e25d504.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	33.00	112	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:39:07.619965+00	{}	\N
108d6793-0f05-40e1-a302-b4385a5cdcea	وافل بيستاشيو	Waffle Pestachio			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/d6e9de0f-e19c-4ba7-b6b5-0a3824c46b61.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	41.00	556	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:41:28.572406+00	{}	\N
f598dd9d-aa20-4b77-8339-2ae2faed6c20	كريب بيستاشيو	Crepe Pestachio			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/13b31574-9f70-49a1-b3a1-1ce8fb070b8c.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	37.00	177	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:44:16.395872+00	{}	\N
297a457a-8f31-4535-9717-4bcfaa204da1	كريب ميكس	Crepe Mix			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/dcf07010-7777-44cd-9ae1-ee0963fcf8db.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	37.00	177	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:47:26.662068+00	{}	\N
5b2f29c4-e151-43bf-a737-5bbf7736ad6e	كريب كندر	Crepe Kinder			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/67db38fd-f498-49c7-a375-ec5aff0eaf6d.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	33.00	177	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:47:07.252944+00	{}	\N
231b8c33-cc2b-4c3f-8e6d-4c1f8e658afd	كريب لوتس	Crepe Lotus			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/871de5cc-04e2-4e64-a3c5-4724b99057bf.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	31.00	177	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:50:07.614273+00	{}	\N
5ba77b7c-3cb3-4d53-81d3-f10c2ae41378	بانكيك نوتيلا	Nutella Pan Cake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/cd909d5e-f021-436c-9635-57d6658daa41.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	37.00	651	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:50:47.795021+00	{}	\N
f36a777b-4ade-4bf1-916f-e59abdf21937	بانكيك لوتس	Lotus Pan Cake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/4485533d-e0af-4257-a687-a14b180240a1.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	35.00	600	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:52:18.594161+00	{}	\N
c3159c59-e886-4a85-adc0-2d4fc587305f	ميني بانكيك بيستاشيو	Pestachio Mini Pan Cake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/64be7bda-0923-4288-acc4-23f4a43dacf2.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	39.00	737	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:55:37.497794+00	{}	\N
0d7918aa-854c-4d7f-88fd-950b5a22ec15	ميني بانكيك ميكس	Mix Mini Pan Cake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/92da4aa9-0efb-4193-8577-38dec99dfaca.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	39.00	832	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:55:07.988487+00	{}	\N
d85fac55-be82-4ac8-9596-0817567e9b63	كراك أزرق	Crak Blue			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/c519a807-adab-427a-8488-57d8834f7b4c.png	8ac569e9-cb25-405a-826f-8db56372b0d4	26.00	580	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:31:26.834647+00	{}	\N
21f90ac3-4ad1-47aa-8f6e-957bf17b5618	كراك احمر	Crak Red			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5be77c79-b3e9-4269-91ff-f9be58101abe.png	8ac569e9-cb25-405a-826f-8db56372b0d4	26.00	600	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:30:23.927522+00	{}	\N
843f3a1f-fe40-4cef-86ea-74d9b522bc83	عصير امبراطور صغير	Emperor S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/a9e1031e-52c5-4a1f-b39e-7f67e57d9596.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	14.00	360	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:00:55.103657+00	{}	\N
be6571c9-ffbc-4e0d-8029-0fb55353912a	مخدة فروحة	Makhadet Farohaa			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/df945a57-06a2-44af-a3aa-6c30161c44ac.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	33.00	182	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:04:21.097446+00	{}	\N
39efe31c-93b0-4489-b508-c5860c6f1fec	تيراميسو	Tiramiso			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/3ddc03cf-d76e-44c8-a7c0-b10cb3b0db39.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	31.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:05:11.471222+00	{}	\N
8bf41fcf-a433-4963-a5b1-54def2498374	تانجو صغير	Tango Small			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/75f60e89-708a-4d4c-8a9e-335aaead85df.png	8ac569e9-cb25-405a-826f-8db56372b0d4	18.00	618	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:37:45.104337+00	{}	\N
23717561-fc70-4c13-88bc-5b6638bdfec8	بيستاشيو كنافه ميلك شك	Pistachio Kunafa Milkshake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b71fbdfa-0e79-469b-8392-0109549e8179.png	8ac569e9-cb25-405a-826f-8db56372b0d4	26.00	1391	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:23:26.996046+00	{}	\N
c9def380-6ef8-4959-ada0-7c6ac48e5bc7	بوم بوم (كبير)	Bom Bom L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/51f9b3c1-d25f-4a39-ace0-2f781e9cdf39.png	8ac569e9-cb25-405a-826f-8db56372b0d4	23.00	621	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:37:56.54301+00	{}	\N
0190d770-89c5-4f3b-9259-a103ba200944	فورت نايت	Roblox			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/2547626b-e27d-4484-ba0a-012d15412b7a.png	8ac569e9-cb25-405a-826f-8db56372b0d4	22.00	620	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:44:51.39768+00	{}	\N
500cc72c-9ed0-4ff2-a242-8897e11a8a4b	ستوب واتش	Stop Watch			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/df986282-e24a-45b0-8348-13d320b9e8c6.png	8ac569e9-cb25-405a-826f-8db56372b0d4	21.00	652	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:47:25.978787+00	{}	\N
831a6ec0-8174-4f42-8b60-89c0c99e02a4	عادل الاسطورة صغير	Adel L Milk Shake S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/0416bf96-8fe9-451f-a052-84d0009fb4ef.png	8ac569e9-cb25-405a-826f-8db56372b0d4	17.00	825	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:48:30.569779+00	{}	\N
3131f6e9-9e4e-403b-8541-352263c968fa	سوبر بوبو كبير	Super Popo Milk Shake L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e8c2012a-0e04-44f2-8d86-acf7e77ad635.png	8ac569e9-cb25-405a-826f-8db56372b0d4	21.00	920	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:51:10.971367+00	{}	\N
e7b416b8-4968-4e1f-b755-7baabeaca388	ابو قلبين ميلك شيك (حجم واحد) هنجر	Abu Qalbin  Milk Shake (one size)			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b1180ec9-6dc8-446f-ad26-8b91015f1599.png	8ac569e9-cb25-405a-826f-8db56372b0d4	26.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:57:04.057171+00	{}	\N
7425a945-03fa-4ee2-a795-25fa64ba6e20	ميلك شيك سيريلاك كبير	Cerelac L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/ab8ef3ec-1cde-4ef0-a09a-0ddd36a9ce7f.png	8ac569e9-cb25-405a-826f-8db56372b0d4	19.00	907	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:58:39.845379+00	{}	\N
36bd9451-3386-41b5-b056-e3002dc6bd3e	فلم	Filam			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/c26fdf6a-5809-43b3-9711-ea4807267fbe.png	8ac569e9-cb25-405a-826f-8db56372b0d4	21.00	685	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:59:39.393994+00	{}	\N
d9f69167-0137-4a88-b85a-a22e03199ab9	ميلك شيك بيستاشيو  كبير	Jojo L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/30ef65cf-dbd7-41fa-9d8d-b98e182a8a97.png	8ac569e9-cb25-405a-826f-8db56372b0d4	23.00	1391	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 13:01:41.064682+00	{}	\N
a9da5852-e8d4-45fb-a654-4f645e5d64d2	ميلك شيك كندر كبير	Kinder L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/84385eda-01a3-48b5-8ec2-cb3ee6100a8c.png	8ac569e9-cb25-405a-826f-8db56372b0d4	19.00	955	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 13:23:13.208735+00	{}	\N
39c3b17f-971f-4d40-80d4-47f5b1a1f8e4	ميلك شيك لوتس كبير	Lotus L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/20d6face-5085-4920-8044-edf1fa294016.png	8ac569e9-cb25-405a-826f-8db56372b0d4	19.00	816	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 13:26:20.273415+00	{}	\N
21974308-7a07-4f0d-b998-96164047f79e	ميلك شيك نوتيلا صغير	Nutella S Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1be7bc2d-322a-4537-b037-32ccf631e7d5.png	8ac569e9-cb25-405a-826f-8db56372b0d4	17.00	883	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 13:27:54.998805+00	{}	\N
0797a436-5871-4b8b-9cea-3f7dc1ff2a48	ميلك شيك اوريو كبير	Oreo L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5b891d47-5830-4ca4-a831-5fa02ed4517a.png	8ac569e9-cb25-405a-826f-8db56372b0d4	18.00	925	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 16:18:37.683617+00	{}	\N
ff859cd0-56c4-4b3e-b77d-16a0a0af5feb	ميلك شيك سنيكرز صغير	Sneackers S Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/09a8707d-1bc9-44de-a2c7-843337732ba1.png	8ac569e9-cb25-405a-826f-8db56372b0d4	17.00	827	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:06:48.644982+00	{}	\N
569e262e-bed1-42b2-89c3-e44cb8a084b9	ميلك شيك هرمون السعادة (كبير)	Hermon al saada L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1bf00d8d-1f7c-445c-a967-b9e6c62a94cd.png	8ac569e9-cb25-405a-826f-8db56372b0d4	22.00	823	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:09:00.461754+00	{}	\N
361fa567-5bf1-49f7-911f-4dd4c0388dba	كت كات صغير	Kit Kat S Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/ae689ebe-8d68-4975-93a7-9055e31d444e.png	8ac569e9-cb25-405a-826f-8db56372b0d4	17.00	589	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:18:59.752271+00	{}	\N
c6ca2c91-39fc-4cdf-ad83-ac0410b5b0a8	حكايا سليمان	Hekaya Suleiman Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1d8427c8-b7c1-4ef8-83ad-4c5f152a3f05.png	8ac569e9-cb25-405a-826f-8db56372b0d4	22.00	581	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:17:30.950412+00	{}	\N
c076a94d-10c1-4b84-9a66-eb9643c05281	عصير اينشتاين صغير	Einstein S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/ca5c6953-a081-4c8a-9427-56253425bc3e.png	8ac569e9-cb25-405a-826f-8db56372b0d4	16.00	716	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:20:17.477883+00	{}	\N
4fc4c39a-e894-487d-adc3-b575323e7e26	ليمونيد بريز  كبير	Pour lemonade L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/dba65116-d0c5-4b99-9132-6859fcc7bf4c.png	0db67202-0d4a-4960-a468-83d733478e1d	14.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:45:16.008219+00	{}	\N
dede6682-f948-4c6f-800e-c20bce082993	ميلك شيك كراميل حجم صغير	MILK SHAKE CARMAL S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f260513b-56e7-4c34-8e78-9e207f2d63ea.png	8ac569e9-cb25-405a-826f-8db56372b0d4	17.00	697	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:47:14.785163+00	{}	\N
657aa28d-5d51-498c-bab1-86a867b3771c	ايس كريم فانلا كبير	Vanila Ice Cream L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/09115996-91df-4cfa-a949-149cbdcd9435.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	15.00	350	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:19:17.218877+00	{}	\N
fcfa0aa0-0779-4f24-b17e-18ed67871c30	عصير كيوي صغير	Kiwi S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e4939adc-b46a-4e7e-97fa-eb961e2ed874.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	15.00	81	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:55:46.443426+00	{}	\N
14830915-d1cf-4125-9700-ba6751d3bc56	فلوتنق رمان كبير	Pomegarnate L Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1bcbca02-b3ff-4166-b77b-35861d187074.png	790aae02-4102-4e41-8487-03f1d8cb3567	29.00	990	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:42:42.158615+00	{}	\N
442113f1-ef3b-4dab-a4fd-0fc0cc904185	عصاير ميني عصائر فرش 12 حبه	Mini JuicesFresh juice12 piece			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/669c859d-0ef2-48e4-9539-96de8936b5d3.png	73fce410-bf36-4579-872f-b1b8d55815e5	140.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:30:59.909053+00	{}	\N
8075259e-3431-4bd0-8a82-e82f88d9933c	موهيتو بيريز  كبير	Mojito Perez  L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	18.00	\N	5	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
6bf18126-d4d3-4d73-baaf-47dcfaa90d3c	كردكديه رازبيري سيرب  كبير	hibiscus raspberry ser  L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	10.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
2ec08593-8019-41a1-bb8a-c66c37321fc4	رقي ليمونيد كبير	WATERMELON LEMONADA  L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	15.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
9410a1b7-2333-47a9-bb47-d05ffb88d46c	كود ريد توت ازرق صغير	Code Red Blueberry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	16.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
5563ed60-6c89-4bc5-87e5-490d7fc71f86	كود ريد فرولا صغير	Code Red strawberry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	16.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
349653b6-c674-4713-9e54-78a8413ff6f6	كود ريد بطيخ صغير	Code Red Watermelon S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	16.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
3b9f5dcd-a956-476f-9af4-b7c71646ce65	كود ريد كرز صغير	Code Red Cherry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	16.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
b29182ef-83a3-47c1-9f42-aeb9f05e7c0e	كود ريد كرز كبير	Code Red Cherry L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	18.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
e73dcdaf-ec01-4c06-9cb2-fd8a0bbf9cd1	كود ريد بطيخ كبير	Code Red Watermelon L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	18.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
590c182b-62e3-4c7b-b6c7-e158e2c19335	كود ريد توت ازرق كبير	Code Red blueberry L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	18.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
29bbffc3-8fd6-47c6-8b74-81546f6bdc4e	كود ريد فرولا كبير	code Red Strawberry L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	18.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
ea753816-7df9-4a70-aa05-a3816c693e71	ردبل نكهة بطيخ كبير	Redbull Watermilon L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	21.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
043ee175-f018-4b93-b2da-b4600c1e6386	ردبل نكهةبطيخ صغير	Redbull Watermilon S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	19.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
bed904d9-f509-4dee-9ec6-43a1fb6b7b72	ردبل بلاك بيري صغير	Redbull Black Berry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	19.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
19e6c10a-2503-4dbe-8a12-f2d834cb3cf7	ردبل شعر بنات صغير	Redbull Cotton Candy S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	19.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
a7d2e519-273f-4623-8b2d-572a2bfb7162	رد بل تفاح أخضر  صغير	Redbull Green Apple S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	19.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
edfcb638-a758-4f96-9cae-236ff1fd62c9	رد بل تفاح أخضر  كبير	Redbull Green Apple L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	21.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
daa98fe5-bca9-4368-8bb6-9275a043791c	ردبل التوت الأحمر كبير	Redbull Red Berry L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	21.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
73c03a44-a789-4f6b-9414-570b764dc166	ردبل شعر بنات كبير	Redbull Cotton Candy L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	21.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
5d82b27f-30bb-47d6-a47a-a6952747dd8f	ردبل توت ازرق صغير	Redbull Blue Berry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	19.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
3ebd285b-ea40-4141-aecf-ae923ff5edff	عصير عوار قلب صغير	Awar qalb S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/bb8a55c8-ecb5-4ca0-8ef4-4ae982121436.png	8ac569e9-cb25-405a-826f-8db56372b0d4	13.00	553	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:23:44.738579+00	{}	\N
d2472a85-4cab-495f-8882-cab0e0fbb48a	لولو حجم كبير	Lulu   L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/fee9699a-1f0c-4bc6-b77b-0ba961273191.png	8ac569e9-cb25-405a-826f-8db56372b0d4	21.00	986	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:25:52.324631+00	{}	\N
656dda79-0636-4115-a8e2-7b1b6b356d2d	كاسترد كبير	Custard L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1c6813e4-8262-4800-b44b-6b409eb13581.png	8ac569e9-cb25-405a-826f-8db56372b0d4	18.00	646	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:29:22.62802+00	{}	\N
eac3b5e0-4cc3-422a-9c7e-cd4a00878d8c	فليك صغير	Flake S Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f810db37-9444-4327-8886-fa69a2c74b3a.png	8ac569e9-cb25-405a-826f-8db56372b0d4	17.00	620	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:32:00.085425+00	{}	\N
9ccd96c8-703f-4fee-ab79-dbcbac7a5f87	جريني كبير	Greeni L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/177c4d7c-406d-4054-bf3f-a6a628feb5b8.png	8ac569e9-cb25-405a-826f-8db56372b0d4	18.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:34:21.036197+00	{}	\N
d162e475-d722-4f34-89e0-6aa25c8e7604	جريني صغير	Greeni S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/7d505989-3ab3-419a-a90f-1fba53c39846.png	8ac569e9-cb25-405a-826f-8db56372b0d4	16.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:34:34.411031+00	{}	\N
4d8af62d-9380-43aa-b9d2-67eb94d2e356	رمان ملك شك كبير				https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1d734b50-e366-46ea-b4ec-ef9ad0d4883c.png	8ac569e9-cb25-405a-826f-8db56372b0d4	21.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:36:19.957924+00	{}	\N
0873a3e8-0dfd-4fde-9e54-10b02fddaebc	بوكس الموهيتو  12حبه	Mojito box12 piece			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f2452074-53df-44ab-989a-f329ba09d176.jpg	73fce410-bf36-4579-872f-b1b8d55815e5	140.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:51:02.951516+00	{}	\N
ad2a6d2c-b2e3-4af2-a1e6-90e6fd5056c8	سموزي رقي كبير	Smoothies WATERMELON L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	15.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
bf7ad68b-6d6d-4388-bed9-2a141008910f	كود ريد تفاح كبير	code red Apple L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	18.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
88b8f1c6-6b37-476a-b460-3dfb9b424c55	ردبل التوت الأحمر صغير	Redbull Red Berry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	19.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
7b713d62-03e4-4ed8-9c72-528c3cd7a0dc	ردبل توت ازرق كبير	Redbull Blue Berry L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	21.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
af9b4b7b-06b3-46a0-88cf-f6c3cdeccefe	سفن اب كرز صغير	7up Cherry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
14f9255e-787e-4ae0-b7f5-ec11fbc76d27	سفن اب كرز كبير	7up Cherry L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	14.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
c35884c0-8c75-4323-958a-8f20fde5c8b1	سفن اب الفراولة صغير	7up Strawberry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
7d9e6b19-cd56-48ae-a7c6-c0b6fcb4c5cc	سفن اب فحم صغير	7up Fahem S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
3ba5dcca-39f3-4b6f-b460-0662cc48038b	سفن اب فحم كبير	7up Fahem L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	14.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
40bf6c65-e874-4737-ae11-2bccf08b8b12	ردبل كرز صغير	Redbull Cherry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	19.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
51b0945b-991f-428e-abf1-96941618145d	ردبل فحم كبير	Redbull Fahem L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	21.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
7ac93781-2b4b-476c-9355-6beab800bd94	ردبل كرز كبير	Redbull Cherry L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	21.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
c0e93da9-58a1-4e9d-b191-75940aa0406b	ردبل فحم صغير	Redbull Fahem S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	19.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
1a925fdc-5d18-4a26-9d74-dd6aa3a74246	ردبل الفراولة صغير	Redbull Strawberry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	19.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
8e808986-2d37-4d8f-84c1-e8caff12b56d	عصير افوكادو صغير	AvocadoS			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/9b97739c-9b69-4eda-ba93-ac4899922598.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	18.00	589	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:55:22.592861+00	{}	\N
fe37beef-fac5-4c95-9711-24af883d67ed	ردبل الفراولة كبير	Redbull Strawberry L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	21.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
186942a7-59d8-42d5-8320-35225dd67484	عصير بطيخ صغير	Watermelon S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/9c9ba25c-437e-4e72-ba96-9066a00ea9dc.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	12.00	72	5	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:52:16.999463+00	{}	\N
db35d52b-3d87-4849-88ff-3cd45862e521	عصير بطيخ كبير	Watermelon L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/fb7261f1-9aca-4f8d-a3a1-58bf3b224cd5.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	14.00	92	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:52:24.6045+00	{}	\N
1bf44583-ffe0-4a2a-9331-769ff48c7547	سفن اب بطيخ كبير	7up Watermilon L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	14.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
ec0edfb2-2fba-48bc-89bf-a570c8782894	سفن اب الفراولة كبير	7up Strawberry L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	14.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
f10a38c0-1bf7-4b31-bc05-db4449f7dee0	سفن اب بطيخ صغير	7up Watermilon S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
47ec2265-b23c-4936-925d-bebbd7184ae2	سفن اب شعر بنات كبير	7up Cotton Candy L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	14.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
65615338-0f5c-4675-85c7-d7b4e72ecf0b	سفن اب شعر بنات صغير	7up Cotton Candy S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
73144729-7a5e-41fd-98ac-14a9fa3b2288	سفن اب تفاح أخضر صغير	7upGreen Apple S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
6d32fb82-7a59-4c10-bdf5-ab1344e1971a	سفن اب توت ازرق كبير صغير	7up Blue Berry L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
90a798e5-7060-43bc-acab-6879e26814a5	سفن اب بلاك بيري صغير	7up Black Berry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
8977eceb-6dea-4fca-b035-3a5a6f5b7c54	سفن اب توت ازرق صغير	7up Blue Berry S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
b2b8a53f-acf2-4e34-b8f2-85e23736f5fc	سفن اب التوت الأحمر كبير	7up Red Berry L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	14.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
2e492e5b-b26d-4c2c-b34d-b44663d1e73b	عصير امبراطور كبير	Emperor L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/2372710f-e479-41b9-beb4-8dba41e3c1f4.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	16.00	499	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:00:47.22734+00	{}	\N
f3ee1331-ec40-409b-bf77-1000033507e5	عصير افوكادو كبير	Avocado L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/ddc70ffd-9ee1-441a-9f4d-788ec3341618.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	20.00	753	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:53:08.392915+00	{}	\N
d80edb5c-5407-4b8b-9e7e-59a1ce4d6339	عصير كوكتيل طازج صغير	Fresh cocktail S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/c22dd951-c3cf-4d7d-a6ec-c0e88122f8e7.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	17.00	243	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:56:29.873819+00	{}	\N
8d945ca5-ed93-44d6-8ea9-fa53ea2307a2	عصير كوكتيل طازج كبير	Fresh cocktail L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e83f818d-1f4c-424f-bcee-dc64b3f7050c.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	19.00	311	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:56:38.395598+00	{}	\N
2425aefd-fa67-4cea-80e5-1c41185cb8bf	عصير كوكتيل ليون كبير	Cocktail lion L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5274f067-3bc0-41d7-9fe2-3e79ff9f4573.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	16.00	690	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:57:19.786369+00	{}	\N
d792c086-16c2-4d68-9a8f-15818c388270	عصير فينيسيا صغير	Phoenicia S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f0aa4151-1dbd-4fd6-ad3c-f3308c905772.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	16.00	446	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:59:55.592064+00	{}	\N
14959cf2-f9bb-4896-82c3-6186c8d7a28d	عصير افوكادو عسل مكسرات كبير	Avocado/Honey/Nuts L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/ea389ae5-4891-4af8-ada7-67fa634d3da7.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	23.00	730	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:00:16.521914+00	{}	\N
22efbb04-a64c-40aa-8f61-ada101c357fc	ابو قلبين عصير طازج (حجم واحد)	Abu Qalbin Fresh Juice (one size)			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/9648c198-e2fa-41be-93e9-3c74a683a0a9.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	26.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:59:17.058141+00	{}	\N
7ef8b36b-4c09-4d49-a9ae-3a2b50174338	عصير فينيسيا كبير	Phoenicia L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/aa375033-1773-417b-9f2f-3b57fc7d7ca1.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	18.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:59:47.537634+00	{}	\N
ebe8ccce-eb36-4dbe-baf5-26ed78c225b1	ايس كريم اشقراني كبير	Ashgarani L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1c90b01e-25e4-4483-9e8f-d9ae1fca655a.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	30.00	502	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:19:58.293332+00	{}	\N
a6d917a6-5395-449f-8cab-06687fe772f1	على شانى صغير	Ala Shani S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/6b9efc2c-a7d0-485b-9c51-761502566888.png	0db67202-0d4a-4960-a468-83d733478e1d	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:30:38.34122+00	{}	\N
c9a68acd-b206-4f13-8a12-34366a8a5015	عصير مانجا فرغلي كبير	Farghali mango L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/3793240a-7f30-486e-9c38-24648094fef2.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	17.00	600	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:56:39.777582+00	{}	\N
6fd7bf21-313e-4681-a5e0-7118f67e5f72	آيس كريم نتفه اوريو	Natfa Oreo ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/d196f1bb-bb84-431c-ae64-6b74d442ddb3.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	16.00	320	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:54:20.213803+00	{}	\N
3c2c9916-a684-4555-9901-8e7ce760718c	آيس كريم نتفه كندر	Natfa Kinder ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/432df1d7-689b-49bc-8575-80278111d037.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	16.00	300	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:56:19.48246+00	{}	\N
30bda6ac-7ee0-492c-8eb2-0b09dd5bdd71	آيس كريم نتفه فريروشيه	Ferrero Rocher ice cream Natfa			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/a9962b20-11cd-4f87-b8ff-902310a4fcda.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	16.00	280	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:57:22.535919+00	{}	\N
b9783732-0df9-4f3c-8c1f-3349dfd39fea	آيس كريم نتفه بابلز	Natfa Bubbles ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/667d707c-1ffc-4aec-9bfb-52910d035bc3.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	16.00	310	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:59:32.288935+00	{}	\N
e9297b9e-e701-432d-8f96-f5f6bc358a8e	آيس كريم نتفه بيستاشيو	Natfa Pestachio ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f4dc7f6c-7db5-4533-afe1-3f5a5aa1404d.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	16.00	320	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:00:14.620222+00	{}	\N
c6fd0b3f-ab9b-4df4-993d-abc9ef4e532b	آيس كريم نتفه لوتس	Natfa LOTAS ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1d9a3b8d-3f8a-4a2d-ad90-cb5743598b9c.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	16.00	310	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:01:26.845549+00	{}	\N
c46ebfbc-b402-461e-b284-967390771499	عصير كوكتيل ليون صغير	Cocktail lion S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/3e8fb784-fc2b-4aa7-a4de-48d30338fa84.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	14.00	540	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:01:39.932119+00	{}	\N
582738e8-de3e-40e6-8fe5-54bfd294eeaa	آيس كريم نتفه فانيلا	Natfa ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/6edb34c4-2d4f-4b99-8cb3-ee5e23a200d0.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	9.00	210	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:02:02.985521+00	{}	\N
c80859c0-9788-42f9-8ed1-902b807302a3	ايس كريم نتفه نوتلا	ice cream Nutella  Natfa			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/23f7066a-170d-4a96-b2b4-5b7b2b8a84f4.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	16.00	330	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:12:54.658691+00	{}	\N
17c55e6a-f7a1-4bc0-bb84-c19cde701014	عصير رمان طازج صغير	pomegranate Fresh Small			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b12c9b7d-771d-42c2-81b5-fb467b33624b.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	19.00	540	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:02:54.221794+00	{}	\N
855d023e-ce5e-40a6-839b-a55ef6b94591	عصير رجيم كبير	Rygime L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/77d812f4-aa0f-42c2-ae8f-f36f66aa0b87.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	18.00	240	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:02:09.329876+00	{}	\N
e623d950-d53b-4440-8ad7-8bc630a98553	عصير رمان طازج كبير	pomegranate fresh Large			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/6a69a97f-100d-4982-b2c6-6080c76b1012.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	21.00	720	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:03:03.835876+00	{}	\N
1401266e-a324-4b2e-a244-b1c822795129	عصير رجيم صغير	Rygime S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/179aa85c-ed6e-4f05-ab7e-91b4ab0b59d5.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	16.00	160	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:02:17.290968+00	{}	\N
61e0ccc4-17ed-4813-9f5f-c24e1e0d6db9	ايس كريم سيريلاك حجم صغير	Ice Cream Sirilak S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/df199012-7287-47e7-81e1-f98114ac5140.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	23.00	470	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:14:24.347449+00	{}	\N
bf250d4f-d3a9-43e8-ab01-528bd1796ddd	عصير فراولة كبير	Strawberry Large			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/72fd7b27-8017-4de1-9e9a-aa8ded8a6915.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	19.00	190	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:03:20.96842+00	{}	\N
618b7eb0-fe3b-40fb-b6ab-e4ebb2446fc7	ايس كريم رمان كبير	Pomegranate L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5ad4e749-d2d3-47fd-9396-1706089103c4.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	27.00	435	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:14:52.098307+00	{}	\N
3de4f16a-bcc7-44f7-b699-ae1212fc9310	عصير الفراولة الصغير	Strawberry Small			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/2a53fa79-47f5-427f-af45-78251b394f47.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	17.00	140	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:03:27.235115+00	{}	\N
85b58a18-8dcb-4f61-9eaa-31725b3fbb63	ايس كريم كندر لوتس صغير	Kinder lotus S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f008e81c-6611-4513-abdb-879c169fef89.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	26.00	771	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:27:30.255986+00	{}	\N
c9eca6a8-9e3a-4a33-9023-72b8975bed28	آيس كريم نتفه سنيكر	Natfa Sneackers ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/223463ed-67fd-47e0-9dd8-dcb97aa4b11d.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	16.00	270	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:40:21.24134+00	{}	\N
d63ac1d1-db0c-4588-af5b-c9fb968c97c8	سنفوري قوي كبير				https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/943deece-af92-42af-bfa5-e4a0154f9cbc.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	25.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:02:38.977644+00	{}	\N
b01f9b8c-3605-411c-836f-e8d3f50a6b74	في أ يي بي كبير				https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/16f779d2-e651-416f-96df-71084b095506.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	27.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:03:06.64099+00	{}	\N
234d28a1-445d-421f-9799-7f1ba5633742	ايس كريم بوكس صغير 7 حبات	Small ice cream box7 piece			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/97cdf643-8d0c-4cfd-8265-3a4db8637ce3.png	73fce410-bf36-4579-872f-b1b8d55815e5	140.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:10:08.111542+00	{}	\N
9e776e05-a039-4416-8778-a723849f85e0	عصير جزر جالون 1 لتر	Carrot galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5298c2eb-5f3f-4000-a834-e3e759cbe7a8.png	1f599865-0727-4843-86ec-28d5af2aed93	26.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:54:18.641942+00	{}	\N
3597dc92-70a6-4dbc-b0b6-7b49bf8aff70	عصير ليمون نعناع جالون 1 لتر	Lemon mint galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f848d329-c891-4a1c-a14b-b421c90052ab.png	1f599865-0727-4843-86ec-28d5af2aed93	23.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:58:55.757792+00	{}	\N
4d26445d-7374-4116-b31b-2625644a4997	عصير فيتامين واحد ونص لتر	Galon Vitamine One and a half liters			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/0f6bff90-0c88-4269-9db6-01296031b69e.png	1f599865-0727-4843-86ec-28d5af2aed93	48.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:04:19.553224+00	{}	\N
9a00ac35-352c-4888-be92-32edca63c5eb	عصير برتقال جالون 1.5 لتر	Orange Galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/d1d69e3b-8f08-4c59-82fd-7bb6fb82fb9b.png	1f599865-0727-4843-86ec-28d5af2aed93	40.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:07:10.523147+00	{}	\N
4ed1ef6d-07bb-4a1c-bb92-1fa72e9c011c	عصير بيري سموذي جالون 1.5 لتر	Berry smoothi  galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/68d7d45e-08ac-4888-9e33-b684763fcbf5.png	1f599865-0727-4843-86ec-28d5af2aed93	45.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:07:48.278121+00	{}	\N
a90fdbaf-4d42-45df-bf38-c6bb2605a64f	عصير عوار قلب جالون 1.5 لتر	Awar qalb galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/223c814e-b4af-40d3-922a-cede62d8d2f7.png	1f599865-0727-4843-86ec-28d5af2aed93	46.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:08:56.264848+00	{}	\N
681c974e-7fcd-444f-8b84-6b96936ecbdf	ايس كريم منجاوي كبير	Manjaou L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/19092b94-4dc7-4ea8-b120-60c8f912bcce.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	19.00	435	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:15:55.955323+00	{}	\N
28dc5c4b-1404-49ce-a038-cdeb76eebfa7	هافانا ايس كريم  صغير	HAVANA Ice Cream S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f9921742-2d43-4320-8afe-790cc5fb33fd.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	21.00	362	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:16:21.917595+00	{}	\N
b1299783-45d6-40df-9060-86a766082247	ايس كريم انشتاين كبير	Einstein L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/998a9453-3168-49f2-905b-b3c7841405e6.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	26.00	595	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:17:02.431941+00	{}	\N
50e65725-d5f4-47bc-b074-fef8d56705c9	ايس كريم بابلز صغير	Bubbles S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e1a8c448-54a6-457f-8dab-5e5db20f6231.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	22.00	369	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:17:13.119029+00	{}	\N
71c61c6a-3091-4991-9336-0a06d5d7885e	ايس كريم بابلز كبير	Bubbles L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f9948fc4-0916-4c4f-b03c-d40a29c6495d.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	26.00	519	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:17:22.800936+00	{}	\N
6104fe48-9e63-4f4f-a417-4e611fec1fa1	ايس كريم منجاوي صغير	Manjaou S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e4258487-425b-4679-aed2-8571d70634ef.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	15.00	330	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:17:33.026846+00	{}	\N
f6cb0009-44aa-4325-859c-c7a76761075d	ايس كريم انشتاين صغير	Einstein S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/253763f8-c557-450a-bde1-082dd699bbd5.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	22.00	458	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:17:44.136999+00	{}	\N
d54efd0e-c618-4118-87ee-0887f30f4479	ايس كريم هافانا كبير	HAVANA Icecream L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/fa818971-43bc-4e39-ae20-2fc5209d2859.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	26.00	483	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:17:53.091116+00	{}	\N
0c690ec4-f0b0-488a-bcad-313f52095494	ايس كريم روشية كبير	Ice cream Ferrero Rocher  L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/3c76b709-1349-465d-b0c2-ca9fd29d9420.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	32.00	770	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:18:29.398121+00	{}	\N
bd976b07-bd8e-4c33-aaa2-7daa4c6602eb	ايس كريم روشية صغير	Ice Cream Ferrero Rocher S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e83b5f57-8f59-4ccb-98d9-4186c9f41e63.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	28.00	541	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:18:35.588839+00	{}	\N
57e75755-d9d7-4bab-a7f2-284f5a4f2cf6	ايس كريم شعر بنات كبير	Cotton Candy Ice Cream L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/208bbefc-6184-489d-8b89-d5ab9b820ca2.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	23.00	483	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:18:58.315813+00	{}	\N
f4fcf151-662a-4fd7-998a-27ec42fd31bf	ايس كريم شعر بنات صغير	Cotton Candy Ice cream S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/7a0ceb03-1d49-423c-9ae6-68159a37731c.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	19.00	362	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:19:08.086967+00	{}	\N
91a3f449-366c-4e51-8bae-7e4eaf17abe5	ايس كريم فانلا صغير	Vanila Ice Cream S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/af9d2d02-6e28-4dd7-8365-493a16f3b6f7.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	13.00	270	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:19:28.7874+00	{}	\N
3142d42d-b04c-491a-95fa-7cbcac185338	ايس كريم رافيلو لوتس صغير	Rafaello Lotus S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/edd960c2-a39d-489c-99f9-95641d44d79d.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	24.00	629	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:35:58.433886+00	{}	\N
33249d27-2dd1-4da5-ac3d-8b088f1df268	ميلك سيك سريلاك جالون 1.5 لتر	Cerelac galon 1.5 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/7ad29619-d643-44c0-ad57-e1432c15aba1.png	1f599865-0727-4843-86ec-28d5af2aed93	52.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 15:03:23.12796+00	{}	\N
8b3cbb65-5437-4f10-b2d2-af8a2d220817	عصير موز حليب جالون 1.5 لتر	Banana milk galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/fbad23fb-a957-4ded-bed0-c35e5134b8e0.png	1f599865-0727-4843-86ec-28d5af2aed93	34.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:54:48.232763+00	{}	\N
a74ae284-a3f1-425d-b80e-11e2a12d84ef	عصير تفاح جالون 1.5 لتر	Apple galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/503d49f6-885b-4e3c-b850-3bf514425171.png	1f599865-0727-4843-86ec-28d5af2aed93	40.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:53:18.906273+00	{}	\N
51c737c2-89f1-4924-88b0-fa9fdd234777	عصير ليمون نعناع جالون 1.5 لتر	Lemon mint galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/0b8a5db9-8b59-420c-b05b-33c65e8776fb.png	1f599865-0727-4843-86ec-28d5af2aed93	34.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:54:40.761448+00	{}	\N
1fcff925-149d-4f18-83e8-f44fdd7a70e1	ميلك شيك نوتيلا جالون 1.5 لتر	Nutella galon 1.5 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/2e1ea887-915a-487c-84f4-19e0412fd176.png	1f599865-0727-4843-86ec-28d5af2aed93	51.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:34:42.358763+00	{}	\N
669ad8e6-017a-4ee2-a409-02aa6b76e012	عصير جريني جالون 1 لتر	Greeni galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/dbef9c76-8fd1-467e-98aa-925f580e1938.png	1f599865-0727-4843-86ec-28d5af2aed93	35.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:54:00.944394+00	{}	\N
cb2cef01-a8e0-4d4a-9f15-4ca877543d6d	عصير جريب فروت جالون 1 لتر	Grapefruit galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e0184b51-a374-4539-ab06-845678013320.png	1f599865-0727-4843-86ec-28d5af2aed93	26.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:54:09.730638+00	{}	\N
8cddc43b-3e3b-4f8e-8adb-b1c7895540d7	عصير بطيخ جالون 1.5 لتر	Watermelon galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b7b88381-aade-4581-a473-acf25206bd50.png	1f599865-0727-4843-86ec-28d5af2aed93	40.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:54:57.648545+00	{}	\N
ed90e4a0-38e1-4f04-8d93-fc431f74427e	عصير اناناس جالون 1.5 لتر	Pineapple galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/acc1c620-44a4-4dd9-b11e-b4fc61b2babb.png	1f599865-0727-4843-86ec-28d5af2aed93	43.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:55:18.466253+00	{}	\N
7cf1ea8a-85f0-48de-9992-5864bd59c911	عصير رمان جالون 1.5 لتر	Pomegranate Galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/8309fe12-0cdb-4a50-b2ef-98e14a067a47.png	1f599865-0727-4843-86ec-28d5af2aed93	55.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:55:34.324794+00	{}	\N
6df65545-4892-4fee-93eb-83693bb6e53a	عصير اينشتاين جالون 1.5 لتر	Einstein galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/6ab15f85-5e36-4d7c-aac6-180754b5f214.png	1f599865-0727-4843-86ec-28d5af2aed93	52.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:56:04.168044+00	{}	\N
a5e2df46-d477-438f-b589-85861cc021f5	عصير كوكتيل جالون 1.5 لتر	Mixed Cocktail galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/38b87677-df4e-4cd2-aed6-35f6e007f1eb.png	1f599865-0727-4843-86ec-28d5af2aed93	43.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:56:32.576493+00	{}	\N
60aa52c0-e46f-42fd-839a-5cecf3ccd814	عصير الفجر جالون 1.5 لتر	Daybreak galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/ee3a6243-f0db-4bde-a01e-ab8da2c38b15.png	1f599865-0727-4843-86ec-28d5af2aed93	40.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:56:52.515146+00	{}	\N
581037f9-f385-4bf4-bad9-32e1aa709b40	عصير فينيسيا جالون 1.5 لتر	Phoenicia galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/84fae2cd-50cf-4551-92d7-d00b480dc26d.png	1f599865-0727-4843-86ec-28d5af2aed93	43.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:57:12.273002+00	{}	\N
39e9dec5-5b83-4da6-9773-7f7765c00554	عصير رجيم جالون 1 لتر	Rygime galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/2860e406-72b7-4b1e-a074-9b4fe8e74457.png	1f599865-0727-4843-86ec-28d5af2aed93	29.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:57:29.480012+00	{}	\N
9c962687-44c3-4fbe-8a0d-b62359e16898	جزر جالون 1.5 لتر	Carrots galon 1.5 ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e6d4267d-08a5-4892-8cf3-061e35e23d43.png	1f599865-0727-4843-86ec-28d5af2aed93	39.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:57:59.676556+00	{}	\N
b8962dec-968e-40f6-bf0c-58402ce5b984	عصير اينشتاين جالون 1 لتر	Einstein galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/3f506816-6b86-47d3-8122-4988b55c916e.png	1f599865-0727-4843-86ec-28d5af2aed93	35.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:58:17.663331+00	{}	\N
93a94960-104f-4492-8334-9f4fbcf363a1	عصير موز حليب جالون 1 لتر	Banana milk galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/153b5ea8-ff6e-4c58-a7dd-778e1c17d4b1.png	1f599865-0727-4843-86ec-28d5af2aed93	23.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:58:46.618445+00	{}	\N
fb864943-7021-4a4b-a533-e195614c3b86	عصير تفاح جالون 1 لتر	Apple galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5198e800-321d-4b74-bc56-b1062d2d8c35.png	1f599865-0727-4843-86ec-28d5af2aed93	27.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:59:08.095222+00	{}	\N
fc30bbec-f832-492e-bc0e-4a42331a0c6f	عصير بطيخ جالون 1 لتر	Watermelon galon Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/19d6041c-38f6-4d31-9e4c-c98742fd25d1.png	1f599865-0727-4843-86ec-28d5af2aed93	27.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:59:29.617834+00	{}	\N
a9d377f7-7d7c-4a5c-94dd-1b313b46630f	عصير اناناس جالون 1 لتر	Pineapple galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/2d7a15a4-a0b7-47a2-92ef-c2bf6d104b6c.png	1f599865-0727-4843-86ec-28d5af2aed93	29.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 15:00:07.828175+00	{}	\N
41b3ed9f-006c-41c3-a823-514d0120a410	عصير رمان جالون 1 لتر	Pomegranate Galon One Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/06a57b98-9cd3-46aa-8612-155c9cab6cd7.png	1f599865-0727-4843-86ec-28d5af2aed93	37.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 15:00:29.299779+00	{}	\N
1af87d44-1467-4cf6-bccb-276cbb9549f8	عصير كوكتيل طازج جالون 1 لتر	Fresh cocktail galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e916eeb2-b6b9-4e2c-b9d1-8760b7efe2c9.png	1f599865-0727-4843-86ec-28d5af2aed93	35.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 15:01:02.116959+00	{}	\N
2616ce0e-862c-41a1-a906-b4dac86defda	ميلك شيك بيستاشيو جالون 1.5 لتر	Jojo galon 1.5 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/0bf931a9-d1c2-4f8a-86a6-21fdf5c3689a.png	1f599865-0727-4843-86ec-28d5af2aed93	69.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:36:33.160432+00	{}	\N
fe76ac1b-9fa7-45ef-a440-8d95f7d8c11f	ميلك شيك اوريو جالون 1.5 لتر	Oreo galon 1.5 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/93c5e23d-b8ad-47a3-9222-2495e870bd39.png	1f599865-0727-4843-86ec-28d5af2aed93	49.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:35:38.955105+00	{}	\N
9ada2892-3fc7-4da8-9116-d31e3893f3d5	ميلك شيك كندر جالون 1 لتر	Kinder galon 1 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/8a2ea69c-9531-4e10-84fd-94da9cb25730.png	1f599865-0727-4843-86ec-28d5af2aed93	34.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:37:06.443671+00	{}	\N
395ff3cc-7bf3-4b48-80e7-3de456249d3b	ميلك شيك سنيكرز جالون 1 لتر	Sneackers galon 1 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/7b6ca4f2-719f-4821-97e7-53e47a60e819.png	1f599865-0727-4843-86ec-28d5af2aed93	33.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:37:41.389636+00	{}	\N
77f2be94-d8c2-472a-a92f-e9929f15a000	ميلك شيك لوتس جالون 1 لتر	Lotus galon 1 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e0eb0167-026f-4443-b7fa-35ea52f83d69.png	1f599865-0727-4843-86ec-28d5af2aed93	34.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:40:19.704145+00	{}	\N
a523f973-acfe-4672-beff-e2fafb4fb762	فلوتنج ايبشتاين كبير	Einstein L Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/00b70517-281d-4931-81e4-dd3dbdff3e80.png	790aae02-4102-4e41-8487-03f1d8cb3567	30.00	654	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:40:51.528288+00	{}	\N
507f28ff-dd61-48e8-b879-75d020fb876a	فلوتنق بيستاشيو كبير	Pestachio L Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5e0917f3-105a-4820-8f50-eceeaa25891b.png	790aae02-4102-4e41-8487-03f1d8cb3567	30.00	1046	10	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:48:19.207546+00	{}	\N
6ad49923-6fa5-4fd0-a1d2-dc5a318f5923	ايس كريم زعفران كبير	Safron L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e9e36669-e173-4872-bd42-ca8e248a836d.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	29.00	502	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:37:40.844966+00	{}	\N
1999eff6-0a5a-42ed-83a5-e9e93dbc8a99	فلوتنج ايبشتاين صغير	Einstein S Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5f89a879-32a8-46f0-96f2-ca5cf536090f.png	790aae02-4102-4e41-8487-03f1d8cb3567	27.00	525	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:41:02.197189+00	{}	\N
5b98e5ae-a7bb-4154-af99-f11acc992a45	فلوتنق بيستاشيو صغير	Pestachio S Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/7b1ec7ba-0a34-4f75-b632-72a4caddbe5e.png	790aae02-4102-4e41-8487-03f1d8cb3567	27.00	758	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:48:10.776213+00	{}	\N
b2f3e26b-14b0-4dfd-ad8b-3bc368bd46f0	ملك شك فراوله صغير				https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/a2165014-bb0c-4e4a-8baa-36ff1d9d71d5.png	8ac569e9-cb25-405a-826f-8db56372b0d4	17.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:58:34.70063+00	{}	\N
2c4645e5-3045-4bbd-8c8b-901496be3ab7	فراوله شوكلت 30 حبه	Strawberry Chocolate Box Large_30 PCS	فراوله شوكلت	Strawberry Chocolat	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/97074b3c-c2f0-4f84-92f4-a361a204b854.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	195.00	\N	10	t	0	t	t	t	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:45:19.796185+00	{}	\N
22f39e9a-52c4-45d2-85aa-c64e20193c80	فلوتنق فراولة كبير	Strawberry L Floating	\N	\N	\N	790aae02-4102-4e41-8487-03f1d8cb3567	29.00	804	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-07 12:59:13.873213+00	{}	\N
c658969d-49a8-424e-9ce5-040678d68d49	عصير عوار قلب جالون 1 لتر	Awar qalb galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/607e2dd2-c682-48ce-a37b-f5084f886a19.png	1f599865-0727-4843-86ec-28d5af2aed93	31.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:14:40.813801+00	{}	\N
62c4b0b5-007c-4556-9d8a-2755faffd38f	عصير شمام جالون 1.5 لتر	Melon galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/ba67d513-bf8a-4356-b436-7e09c5dc8df1.png	1f599865-0727-4843-86ec-28d5af2aed93	40.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:55:06.180821+00	{}	\N
7ae61e2b-a8b0-4b32-8a7e-15e2cb9f32f3	فيتامين 1 لتر جالون	Galon Vitamine one litre			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/7e49ca36-a5e9-47dc-965b-8688020eeb46.png	1f599865-0727-4843-86ec-28d5af2aed93	32.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:52:50.588317+00	{}	\N
456b02df-a2cd-40f7-8f33-7cc9851a19da	عصير كيوي جالون 1 لتر	Kiwi galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b9403a35-9ffc-45ba-9973-d32c86605db6.png	1f599865-0727-4843-86ec-28d5af2aed93	27.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:59:17.497329+00	{}	\N
791e712c-b048-4b8f-8ebf-8f55b116dc20	تجربة	Test	تجربة	Test		a710f505-ad95-4f6f-8f4b-fe68055a317b	10.00	126	30	t	1	t	t	t	f	2026-05-07 15:21:59.248966+00	2026-05-07 15:21:59.248966+00	{}	\N
6d505b5c-bba0-40d5-b46b-ec04a9a4f6d9	فراوله شوكلت 6 حبه	Strawberry chocolate 6 pieces	فراوله شوكلت	Strawberry Chocolat	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/2063821b-2e8e-493a-9138-8f464a80cdb3.jpg	a710f505-ad95-4f6f-8f4b-fe68055a317b	47.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 09:56:32.29595+00	{}	\N
48551444-cbb4-4226-8f1e-1fe9441f2797	كندر بيري 5حبات	Kinder Berry			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/473cd763-a9ae-4104-bdcc-53dbaf5b73b0.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	19.00	124	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:23:54.713219+00	{}	\N
3bcc5e6d-c7a5-4f99-ad35-60eba1df0ab6	فراوله شوكلت 2 حبه	Strawberry chocolate 2 pieces	فراوله شوكلت	Strawberry Chocolat	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/0da14f30-47c4-4851-8ea0-0b6fd3c7a6da.jpg	a710f505-ad95-4f6f-8f4b-fe68055a317b	25.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:02:47.006952+00	{}	\N
b341cb22-da24-4701-8114-9678b70cd599	شوكلت الهبة كندر	Kinder Chocolate	شوكلت كنافه كندر	Kinder chocolate kunafa	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f111eee5-f703-4642-acc7-2cf62341c03a.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	39.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:08:31.760183+00	{}	\N
2bc7ef25-2825-4386-9493-5949b653484e	كريب بيستاشيو كنافه	Pistachio Kunafa Crepe			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/7a392800-2b2e-448b-9e2e-71b0ba097731.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	25.00	177	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:14:25.50425+00	{}	\N
00bef6b0-9696-46a7-add1-fcee8f709e7b	ميني بانكيك بيستاشيو كنافه	Mini pancakes pistachio kunafa			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/25f5cbb0-b085-447c-a38b-ba69197a283f.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	40.00	737	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:16:31.10383+00	{}	\N
adec2363-eafe-4b55-88f7-a30712702e2d	بوكس فراولة 15حبه	Strawberry Box Medium_15 PCS	فراوله شوكلت	Strawberry Chocolat	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f8d941c1-b141-45d1-8005-f73bcfe7c22a.jpg	a710f505-ad95-4f6f-8f4b-fe68055a317b	105.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:23:34.08679+00	{}	\N
bf6a1af1-30f8-48f9-97c8-12732d5dc450	المسافر صفر كبير	Al Mosafer Sfir L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/d99a5329-e091-4277-b223-4a875a4834f2.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	25.00	962	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 10:36:07.836448+00	{}	\N
f90c3589-9613-44be-a0ad-0fbae51bdada	بوكس البطريق	BATREEQ BOX			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/db22b0d1-c5eb-4127-a766-8928162f7d79.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	39.00	475	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:26:38.259893+00	{}	\N
bbae31ac-df6f-4475-b54f-4dc1e225de92	تكميم ميكس	Takmeem Mix			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/4f9f2059-c5df-4606-b563-3474101e048b.jpg	a710f505-ad95-4f6f-8f4b-fe68055a317b	19.00	965	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:30:43.198067+00	{}	\N
f06abf8f-b76e-4b40-b3cd-f38c59dc8fd8	تكميم باندا	تكميم باندا- BAND Takmim			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/6314afda-8705-4f5e-bf0d-f33805ca06c3.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	22.00	553	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:31:46.768582+00	{}	\N
b11f08ed-6c62-466b-914f-e16b852dc89a	بانكيك اجرام	Egram Pan Cake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b6d79c80-066d-439f-ae0f-cf54c41916fe.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	49.00	322	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:35:47.531905+00	{}	\N
86205c10-47cb-4dc8-a818-02d5bcd51d0a	وافل كندر	Waffle Kinder			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/9551fe24-a8db-43f7-9ef7-f8ad8ea63dd5.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	37.00	425	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:36:38.206569+00	{}	\N
c2acfacd-5adc-4a13-ab8e-84dd8ffa8918	غرقني بيستاشيو	Gharegni Pistachio			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/9fa3b77e-b3e6-45af-9181-bc581f12f2a9.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	37.00	112	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:39:47.43363+00	{}	\N
96acb5c7-f699-417a-81ba-5ee2b2a41bce	وافل ميكس	Waffle Mix			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/8363f136-a034-4379-a3cb-387cdeaf3027.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	44.00	962	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:42:11.549757+00	{}	\N
ada4c01b-2dc8-4e7d-b5a9-ca60f8580aea	وافل لوتس	Waffle Lotus			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5e4827bd-4bf2-495d-9b65-3e0c1f007f39.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	33.00	600	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:43:04.657161+00	{}	\N
83a86b6e-b544-4fb0-9d05-29348af32992	كريب فوتشيني	Fettuccine Crepe			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/eed602fc-f4a7-4a73-a8ba-18219dcb7c7d.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	39.00	190	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:46:45.721637+00	{}	\N
e95098e0-34e3-4528-984f-cf62247b6369	بانكيك بيستاشيو	Pestachio Pan Cake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/eb8642e4-0a9f-4bf0-a6c7-527e44a99808.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	39.00	556	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:48:38.733173+00	{}	\N
9d9ef61f-b665-438d-8ea7-5433987b03a0	كريب نوتيلا	Crepe Nutella			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1f6aa9fa-8eb9-40e1-bc42-a8de716b7882.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	31.00	177	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:49:46.747645+00	{}	\N
0d745703-4af7-494c-9cc3-83918e589484	بانكيك كندر	Kinder Pan Cake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/102556b9-50bd-4fd7-8d1a-e2e93d34130f.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	39.00	425	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:51:24.865157+00	{}	\N
6729eb20-7fe2-4fa3-940a-ff8b6af66fa2	بلا بلا	Blah Blah			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/7c6ed965-86ed-498a-916a-99f244a0e9a2.png	8ac569e9-cb25-405a-826f-8db56372b0d4	23.00	620	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:34:37.965403+00	{}	\N
c538641f-9ed0-4146-b76e-a51791221e10	باربي	Barbei			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/cfc35838-2ac4-4b51-af2d-e591f214f50f.png	8ac569e9-cb25-405a-826f-8db56372b0d4	22.00	613	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:42:23.327005+00	{}	\N
6a3aec12-5855-4e9d-95cf-bd5915384534	بانكيك ميكس	Mix Pan Cake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/afc49590-7380-403c-8314-77b12fb5cd35.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	44.00	675	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:51:51.990538+00	{}	\N
ed787e03-926b-4081-9190-82641551941c	ميني بانكيك لوتس	Lotus  Mini Pan Cake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/3dbb5ece-0af5-409b-91af-b5453a4e409a.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	5.00	781	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:52:55.359406+00	{}	\N
f32ae406-d761-4024-aee7-073c001e0950	ميني بانكيك كندر	Kinder  Mini Pan Cake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/c831be10-8775-455c-94d5-e704957d42c4.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	37.00	606	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:54:40.135296+00	{}	\N
d4542fad-3ffd-467c-85b3-7e70caec14ee	فراوله شوكلت 4 حبه	Strawberry chocolate 4 pieces	فراوله شوكلت	Strawberry Chocolat	https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/2843fce7-b914-4f1c-9c93-730d332ddbe7.jpg	a710f505-ad95-4f6f-8f4b-fe68055a317b	32.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:56:48.933456+00	{}	\N
aaa8445b-ec95-4314-95dc-45339ebf0e0f	ميني بانكيك نوتيلا	Nutella Mini Pan Cake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f8a23822-4ef4-4782-8043-cb6b5489ee4e.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	36.00	832	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 11:59:42.510953+00	{}	\N
72041f30-5af7-445e-88d2-16cc6c080779	مخدة بوبو	Makhdet Bobo			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/4536d542-bc5a-4626-98c2-2c3987c2ce7d.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	30.00	182	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:00:42.535144+00	{}	\N
a3de313a-d0b0-4efb-86e8-7348beadbe31	مخدة الاسطورة	Makhdat Alastora			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/c47ea7c7-b6a1-48fa-8a6d-a65e87fd3704.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	30.00	182	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:03:12.639594+00	{}	\N
c773a587-c473-4dc7-85f9-6253c54478b6	بف بيستاشيو كنافه	Buff Pistachio Kunafa			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/ee755391-6209-4cba-ae51-83efe9f101c8.png	a710f505-ad95-4f6f-8f4b-fe68055a317b	35.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:06:18.878703+00	{}	\N
8e5fb9bb-71b2-487f-bb70-10d3f42b698e	ميلك شيك سارا	Sara milkshake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/7fd7df45-47a5-4663-8c09-2b320bc3295a.png	8ac569e9-cb25-405a-826f-8db56372b0d4	20.00	605	5	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:21:40.546631+00	{}	\N
47cf680c-9d63-430d-8743-adf1d0fc1ee2	ميلك شايك منجاوي	milk shake mingawe			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/cb645d27-2391-4e7a-863a-83105bd75088.png	8ac569e9-cb25-405a-826f-8db56372b0d4	22.00	582	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:45:23.426826+00	{}	\N
f7990df7-8f9b-4986-bc17-1aa668249016	شي ثاني	Shi Thani			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e8bf96d8-3ca3-403e-9455-667d65c10197.png	8ac569e9-cb25-405a-826f-8db56372b0d4	22.00	468	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:46:14.577241+00	{}	\N
cda07c09-8de6-4a81-b448-9b63c0709c67	عادل الاسطورة  كبير	Adel L Milk Shake L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/986bdb5b-6a56-4389-a9db-a963de2c2a91.png	8ac569e9-cb25-405a-826f-8db56372b0d4	21.00	940	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:48:50.460649+00	{}	\N
ab4e1a80-8dce-47b3-9bc6-be9c947f0694	فيريرو روشيه كبير	Ferrero Rocher L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/0cbd792c-f604-41a8-acff-804b63f85208.png	8ac569e9-cb25-405a-826f-8db56372b0d4	23.00	823	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:55:32.527375+00	{}	\N
072b8504-927c-4f17-a1d8-12f3a0c3768f	سوبر بوبو صغير	Super Popo Milk Shake S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/453eccc4-9dd7-4a24-a24c-7f12a9e2f2c4.png	8ac569e9-cb25-405a-826f-8db56372b0d4	17.00	815	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:49:28.523713+00	{}	\N
a5c0f156-08be-4ede-8b99-913da3b0b4f2	فشكل	Fishkal			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e3741b3e-af46-4e0d-b4be-66af68a9024d.png	8ac569e9-cb25-405a-826f-8db56372b0d4	21.00	689	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 12:57:53.852366+00	{}	\N
ebae1ced-3d08-4a6f-86c1-e9da2ecff3fd	ايس كريم كرسبي لوتس كبير	Lotus crispy L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/a44f6b71-b3eb-405a-b14c-a827c1813a2e.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	29.00	846	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:39:10.590857+00	{}	\N
02fb481e-1925-4116-a3bb-eaa7cb6f9319	ميلك شيك سيريلاك صغير	Cerelac S Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/41f22945-d7d8-4d18-a6e6-205286a18ce5.png	8ac569e9-cb25-405a-826f-8db56372b0d4	17.00	697	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 13:00:29.185986+00	{}	\N
c514edd6-181f-4b14-8b28-990d61d85b3c	فليك كبير	Flake L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/53504a1d-2a67-44da-a886-7610e83a0895.png	8ac569e9-cb25-405a-826f-8db56372b0d4	19.00	810	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:31:02.648157+00	{}	\N
44277ad1-7dab-4bec-a257-acac899d5a5c	ميلك شيك بيستاشيو صغير	Jojo S Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/9a56bb97-a812-428d-9ed5-60edba290b9e.png	8ac569e9-cb25-405a-826f-8db56372b0d4	18.00	1069	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 13:01:26.389793+00	{}	\N
81154885-8a22-4bba-aa47-e21cbfd7d5c3	ميلك شيك كندر صغير	Kinder S Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/3e8d3bf8-835b-4b5b-96ff-908c33cada97.png	8ac569e9-cb25-405a-826f-8db56372b0d4	17.00	734	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 13:24:15.274115+00	{}	\N
2e282684-9ed6-49a1-81e3-8803b8733163	ميلك شيك نوتيلا كبير	Nutella L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/0fbb9dc5-d135-4e89-81de-e7f7994521b6.png	8ac569e9-cb25-405a-826f-8db56372b0d4	19.00	1149	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 13:27:43.397945+00	{}	\N
2ca866a2-45c0-479b-847c-c579e0a5b115	ميلك شيك لوتس صغير	Lotus S Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f308b8fc-7f47-4d4a-b51d-3a501717cc55.png	8ac569e9-cb25-405a-826f-8db56372b0d4	17.00	627	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 16:16:17.789596+00	{}	\N
4ef8da5f-845b-490d-8702-66095f7ba346	ميلك شيك سنيكرز كبير	Sneackers L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/17e611d7-1cd3-473d-a1d7-04ea55d17403.png	8ac569e9-cb25-405a-826f-8db56372b0d4	19.00	1076	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:06:38.66528+00	{}	\N
f52e2e30-c5fc-4d55-bb5c-dea23f780824	ميلك شيك اوريو صغير	Oreo S Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/8853bb60-3b0a-40ce-93ac-cbb7549ecf0f.png	8ac569e9-cb25-405a-826f-8db56372b0d4	16.00	711	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:07:34.503497+00	{}	\N
7b35f670-56e3-4226-b74a-885982ae8378	كاسترد صغير	Custard S Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/0e241bcf-c1cb-4bbf-92d2-bd09acc44765.png	8ac569e9-cb25-405a-826f-8db56372b0d4	16.00	841	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:32:41.738238+00	{}	\N
d56edde5-ff34-45c7-923a-55818cdd5363	ملك شك فراوله كبير	Strawberry L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/32cfd7e8-d952-4f66-89f8-cf3fa7b98c8f.png	8ac569e9-cb25-405a-826f-8db56372b0d4	19.00	1252	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:33:35.65109+00	{}	\N
e8e1cc1c-55fe-498d-9089-1e57d7e5e386	حفيد اينشتاين كبير				https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/7f03baf1-b1b6-47bf-b222-3e8e9d15a534.png	8ac569e9-cb25-405a-826f-8db56372b0d4	22.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:35:42.317055+00	{}	\N
40f8b1a9-bb8a-4ec1-b967-6c704cb9ac88	ميلك شيك رمان كبير	Pomegranate L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/01c0adfc-efd7-40ae-956f-d4a289c8c6ed.png	8ac569e9-cb25-405a-826f-8db56372b0d4	21.00	827	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:16:49.210562+00	{}	\N
4ec00a42-6b60-49f0-898f-5c31e6c06c64	كت كات كبير	Kit Kat L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/60eaa394-477e-4b88-9a5f-58db48802480.png	8ac569e9-cb25-405a-826f-8db56372b0d4	19.00	753	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:18:33.881092+00	{}	\N
69c7e680-b85f-4675-9e4c-66cec39cd440	عصير اينشتاين كبير	Einstein L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/16fd363c-97a3-423f-8e95-fe11490024ac.png	8ac569e9-cb25-405a-826f-8db56372b0d4	18.00	932	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:20:03.567503+00	{}	\N
68e9b88d-8323-40ea-9174-822df6279d79	باندا حجم كبير	Panda  L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/c7a7124f-4a71-41d9-aff9-cd6567d410d7.png	8ac569e9-cb25-405a-826f-8db56372b0d4	21.00	585	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:21:11.732652+00	{}	\N
dc08adb0-a1ca-4d24-9896-14952638aa25	رمان ملك شك صغير				https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/63b046a3-90e3-4867-b2c5-0681d5ef11aa.png	8ac569e9-cb25-405a-826f-8db56372b0d4	18.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:36:36.442231+00	{}	\N
a3d18ec2-fb79-4c7a-8c17-3c60169c8bbc	عصير عوار قلب كبير	Awar qalb L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/d8b528e7-1d62-45fc-b594-9cab9deff65d.png	8ac569e9-cb25-405a-826f-8db56372b0d4	15.00	720	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:23:23.779782+00	{}	\N
d4c2dc5f-7afc-41d8-b14e-7dbbe210d50e	فشكل بوبو حجم كبير	Fashkal Bobo L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1adb1667-53b7-4be5-a204-b645ccf9e638.png	8ac569e9-cb25-405a-826f-8db56372b0d4	21.00	689	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:24:20.090391+00	{}	\N
826da7c3-fa44-4534-ad75-757e585538bf	فروحة حجم كبير	Farouha L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/c700e84a-8196-4856-b9f1-63ad1d28a7ea.png	8ac569e9-cb25-405a-826f-8db56372b0d4	21.00	585	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:27:15.065649+00	{}	\N
f4930465-da3d-47f3-896d-bdb64512fa59	ميلك شك كراميل حجم كبير	Milk Shake Carmel L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/693de6c6-71c2-4100-882b-e19e1ce6cfdf.png	8ac569e9-cb25-405a-826f-8db56372b0d4	20.00	907	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:28:29.645032+00	{}	\N
cd1dac2a-41d7-4012-9eff-ebc4f29ec88c	تانجو كبير	Tango Large			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/d937e2b7-212e-4199-850d-052fc5c6b254.png	8ac569e9-cb25-405a-826f-8db56372b0d4	20.00	815	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:37:04.376121+00	{}	\N
02641919-9c50-4849-a734-f6dbe6eda00d	يم يم أحمر	Red Yum Yum			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/cbcd06de-1ec8-4d70-81c1-a523d4aebf4b.png	8ac569e9-cb25-405a-826f-8db56372b0d4	23.00	620	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-08 20:43:04.095275+00	{}	\N
4ada9b5d-b5cb-4189-97da-2180c6d0d8c2	ايس كريم اشقراني صغير	Ashgarani S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/a6d87899-6cfb-41b2-94a5-155cebd0ede8.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	26.00	381	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:41:22.120454+00	{}	\N
4d551b90-f749-4c6f-9466-c8557c367aaa	صمدي كبير	Samadi L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/717b4887-6c50-4f9e-bdcf-51efdea35044.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	25.00	499	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:00:08.639098+00	{}	\N
e9e6bc52-d08e-4f7f-a35d-3dd3bbd447b7	ابن بطوطة كبير	Ibn battaotah L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e49e9d1c-92a3-4a61-876e-e95cbc7ae501.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	20.00	414	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:03:49.282777+00	{}	\N
5b214798-f84b-48b2-b692-1b6fedaff53e	على شانى كبير	Ala Shani L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/8d785dc9-f29a-4f30-a77c-2f9353cc8fae.png	0db67202-0d4a-4960-a468-83d733478e1d	14.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:30:27.345384+00	{}	\N
f97bb60f-8a9c-4f09-8fee-bc0b0762a3d5	عصير مانجا فرغلي جالون 1.5 لتر	Farghali mango galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/29b4d43c-a630-4c3f-a6d8-9fb8fce2bd89.png	1f599865-0727-4843-86ec-28d5af2aed93	49.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:55:26.048726+00	{}	\N
e628809c-2cf0-44bb-a348-fc5316afc34c	كود ريد تفاح صغير	Code Red Apple S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	16.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
12a42867-047e-4763-a6fd-54db38b90071	كود ريد رمان صغير	Code Red pomegranate S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	16.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
ad77a20e-a6b7-4e39-9a41-049c45c192a5	عصير شمندر صغير	Beetroot Small			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/d252d0e4-7967-4e30-9246-ae7cdf697e1e.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	13.00	157	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:14:26.349576+00	{}	\N
c05a8bfe-ddd7-4112-8047-6e5a9036e852	ايس كريم بيستاشيو كبير	Pestachio L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/2d12c35b-25a7-465d-890d-8b8f37b94fa7.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	30.00	1025	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:20:15.342967+00	{}	\N
0aa53bee-eb51-41e0-a07a-cbbebbea8be3	ايس كريم بيستاشيو صغير	Pistachio S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b8944da7-2584-483a-aed8-615423b7af47.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	26.00	717	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:42:11.747459+00	{}	\N
fb0ea950-23be-466b-9818-a28df3e92913	عصيرتفاح صغير	Apple S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/6485eae6-34ac-460a-ab70-b7f48aac61f0.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	12.00	409	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:06:05.599142+00	{}	\N
53a4ffb3-3588-4138-a020-c9a7053edd9e	عصير برتقال جالون 1 لتر	Orange galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/a6e8734b-c9c0-4500-a905-cf068f2b778b.png	1f599865-0727-4843-86ec-28d5af2aed93	27.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:35:00.981269+00	{}	\N
e1fbc14f-ce6c-4d30-8884-b72807f4683a	عصير كوكتيل طازج جالون 1.5 لتر	Fresh cocktail galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/79968d77-bf5f-49b9-99a6-f2c9c7db15be.png	1f599865-0727-4843-86ec-28d5af2aed93	52.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:55:41.811397+00	{}	\N
21528d80-2739-4ef6-b5c5-b00a3e53533d	عصير شمام جالون 1 لتر	Melon galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5d77b529-ed2e-43e0-98dc-215918702a7e.png	1f599865-0727-4843-86ec-28d5af2aed93	27.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:59:49.283368+00	{}	\N
96f05114-26cb-4a6d-881d-d05c64b0a553	ميلك شيك سيريلاك جالون 1 لتر	Cerelac galon 1 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/75802655-4544-4068-bfa3-e0af6c028144.png	1f599865-0727-4843-86ec-28d5af2aed93	35.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:36:48.984772+00	{}	\N
7d7bdc24-5561-497f-825c-a37799ba9a63	ردبل رمان كبير	Redbull Pomegranet L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	21.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
d1680d29-aac2-412e-b701-69ad67e6cde4	موهيتو رقي كبير	WATERMELON MOJITO  L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	15.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
124428a3-167f-42de-854e-bea023df866c	عصير مانجا فرغلي صغير	Farghali mango S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/4b23cdb4-5945-4c69-871f-c7c9e2e2f93d.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	15.00	460	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:12:04.842249+00	{}	\N
ed85c2b4-4376-4f3f-84c1-222dd90253b6	ايس كريم رافيلو لوتس كبير	Rafaello Lotus L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/507f7167-3574-4058-af35-1b7378390647.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	28.00	980	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:20:59.965238+00	{}	\N
a44bc3b5-9928-41c8-b62c-40cad4ec011d	ايس كريم كندر كبير	Kinder L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/0c9c4c3e-c2fa-41a5-8b2a-9a61861d14f9.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	28.00	970	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:21:28.373994+00	{}	\N
33cd46ce-aa65-4532-b940-8e71706f4ea9	عصير برتقال صغير	Orange S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/60ec2794-5dbe-4bad-9abd-e7059052c79b.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	12.00	67	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:47:58.290548+00	{}	\N
ebcceb29-cac5-40b2-9698-ed3dfea39aad	انتعاش صغير	Refresh Small			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/39c572d9-50aa-475e-84a5-90a14e632d0c.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	14.00	166	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:11:20.318464+00	{}	\N
48de04c2-ec88-47ba-aca2-466f397df5db	عصير جريني جالون 1.5 لتر	Greeni galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/da51672f-117f-40e0-81ea-e024d5a3ded1.png	1f599865-0727-4843-86ec-28d5af2aed93	52.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:52:36.37655+00	{}	\N
4c28b012-4055-4e3a-a8fe-5706639760d2	عصير رجيم جالون 1.5 لتر	Rygime galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/60fe86ad-35b8-419c-8fee-f22e37aa41b9.png	1f599865-0727-4843-86ec-28d5af2aed93	43.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:56:42.898712+00	{}	\N
ceadb326-e6b0-40bf-b9e9-32ceaff19239	عصير كوكتيل جالون 1 لتر	Mixed Cocktail galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/a79312b5-546e-48aa-af84-949e3d56a56b.png	1f599865-0727-4843-86ec-28d5af2aed93	29.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:57:38.658715+00	{}	\N
79ce1db4-6c9c-487a-8e55-07e6f03c5041	عصير مانجا فرغلي جالون 1 لتر	Farghali mango galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/9a9541b4-acde-4824-a277-eef40e630f0b.png	1f599865-0727-4843-86ec-28d5af2aed93	33.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 15:00:20.594761+00	{}	\N
67d7cc89-2101-47bb-9ec9-90b32acd3111	ميلك شيك نوتيلا جالون 1 لتر	Nutella galon 1 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/52c3abca-0f89-4531-ae05-3ff58c74eae9.png	1f599865-0727-4843-86ec-28d5af2aed93	34.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:37:24.635239+00	{}	\N
66c50d86-b670-475b-90f1-35d27276889c	عصير فيتامين كبير	Vitamine L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/26d9eb31-3c8f-4b41-9f39-bc1fcfd15fdb.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	19.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:14:35.844948+00	{}	\N
75ef537a-caf1-44cb-bd8b-de51117212bc	ايس كريم رمان صغير	Pomegranate S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f1dba074-754c-4b34-bf08-ebe75c869e03.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	23.00	330	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:21:37.928669+00	{}	\N
1e71898c-f7d8-4e76-b091-3f3731c0cd05	عصير معاريس صغير	Maaris S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b4359e3c-b247-4c2e-b762-519f264a3a4e.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	16.00	220	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:48:36.544783+00	{}	\N
a0b590d5-5f4d-4091-a53b-5d05b5264302	انتعاش كبير	Refresh Large			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/309c2450-12d0-481c-86b1-b069126151ce.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	16.00	212	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:11:30.864992+00	{}	\N
ff070430-eb14-4384-82fd-477e5c8af74b	فلوتنق كيت كات كبير	KitKat L Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e1402c45-36c6-400c-a978-42a5c683b6a2.png	790aae02-4102-4e41-8487-03f1d8cb3567	29.00	1106	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:42:11.897993+00	{}	\N
66db2563-ceaf-47ab-8c41-9fe3bb0ff982	فلوتنق لوتس كبير	Lotus L Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/dc73b4dc-ced0-4c03-a1cf-b038e5e923b4.png	790aae02-4102-4e41-8487-03f1d8cb3567	29.00	816	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:42:56.941266+00	{}	\N
60b7fa49-e56c-48fd-9cf6-8debd8b94c3d	عصير امبراطور جالون 1.5 لتر	Emperor galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/9cf20e9d-16d8-4fc9-ae96-e58c86f05c06.png	1f599865-0727-4843-86ec-28d5af2aed93	40.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:51:19.556972+00	{}	\N
6022b7c4-d761-4e45-b4d5-640d344c8cfd	عصير كوكتيل سبيشل مكس جالون 1.5 لتر	Special Cocktail mix 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/12f78a77-2ac3-4e86-8a51-ecab2e119dc0.png	1f599865-0727-4843-86ec-28d5af2aed93	49.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:57:02.290471+00	{}	\N
17041e22-1070-4161-93b5-460402ade031	عصير الفجر جالون 1 لتر	Daybreak galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/96445f52-fbd3-4209-bc26-b9d1e6eab131.png	1f599865-0727-4843-86ec-28d5af2aed93	27.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 15:00:46.189494+00	{}	\N
f2aea970-615a-4a0e-92df-0e64f8820cbc	ميلك شيك اوريو جالون 1 لتر	Oreo galon 1 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e7f403d3-c6a7-4f14-a136-41a49bc98f66.png	1f599865-0727-4843-86ec-28d5af2aed93	33.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:38:56.957593+00	{}	\N
f5edbacf-2830-466e-a940-784aeb9a82e1	ميلك شيك كرك جالون 1.5 لتر	Karak galon  1.5 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5b73ff30-dcdb-40be-84e8-e40e212299c8.png	1f599865-0727-4843-86ec-28d5af2aed93	49.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:39:23.809357+00	{}	\N
e4ab0761-394b-4a1e-8ef2-3ddb77e30c6d	عصير موز حليب كبير	Banana milk L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/ee8c1744-0280-4beb-a1f0-38f7de4ab40b.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	14.00	424	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:16:46.509009+00	{}	\N
20ab5437-4e16-4492-833b-d10a6b783e78	عصير كوكتيل طبقات كبير	Cocktail levels L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/df7e9985-65c5-4412-a42b-9d36776e989b.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	15.00	368	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:36:12.076333+00	{}	\N
803c8478-a388-43af-bfa5-65a554ccc1cf	ايس كريم سنيكرز صغير	Sneackers S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/c81c187f-6a8e-4a85-8522-f1b23a5cf99b.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	23.00	479	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:40:28.937758+00	{}	\N
67a9f959-1b2b-4db8-b369-19a7ea38b989	عصير شمندر كبير	Beetroot Large			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/216160bb-331c-479c-9606-e8eb1b7430e1.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	15.00	210	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:53:50.235717+00	{}	\N
7a2d2f64-460f-4aaf-9796-6fc1f7facd76	اخر كلام كبير	Final words L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/4ee35be5-da17-41c4-a4af-34f01d8963c3.png	8ac569e9-cb25-405a-826f-8db56372b0d4	22.00	823	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:17:49.110637+00	{}	\N
f7bd809f-fee9-4be4-ba3d-9f76cce1ea10	عصير جريب فروت جالون 1.5 لتر	Grapefruit galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/79a474bd-6da8-4f05-856b-584d7fd615e6.png	1f599865-0727-4843-86ec-28d5af2aed93	39.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:52:24.633741+00	{}	\N
967d7bd5-4d6e-4751-afc9-e6de8b4252ad	عصير كوكتيل سبيشل مكس جالون 1 لتر	Special Cocktail mix one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/86186605-f55e-4af7-bfc3-ea822805956d.png	1f599865-0727-4843-86ec-28d5af2aed93	33.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:57:21.817118+00	{}	\N
8764f8fb-f648-4fde-a3f0-f18e8a9f5adc	ميلك شيك سنيكرز جالون 1.5 لتر	Sneackers galon 1.5 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/18e3ad85-4060-485d-b9f5-45eb9bbb9d09.png	1f599865-0727-4843-86ec-28d5af2aed93	49.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:33:11.871788+00	{}	\N
c7cf9ebc-9598-47ac-84e1-01403f07958d	ميلك شيك كرك جالون 1 لتر	Karak galon 1 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/910a1b13-19c8-4dca-8757-f448a49e0de2.png	1f599865-0727-4843-86ec-28d5af2aed93	33.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:39:15.381574+00	{}	\N
1bf52a4a-2a74-417e-83c4-16055c871672	ايس كريم كرسبي لوتس صغير	Lotus crispy S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/a577c713-60f4-4511-9556-ea14667ab4dd.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	25.00	674	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:22:07.670305+00	{}	\N
af622da9-4e41-4645-812b-a8abf1c0e267	ايس كريم كندر صغير	Kinder S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/39240309-1c76-4e53-83bd-2a4da2295891.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	24.00	685	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:22:21.027371+00	{}	\N
952ed8c2-6cd2-4754-9737-89bf81bdd953	فلوتنق رمان صغير	Pomegarnate S Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/3f4033d4-8322-4376-a6d8-b2125373d1a8.png	790aae02-4102-4e41-8487-03f1d8cb3567	26.00	565	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:42:35.048123+00	{}	\N
620058d9-a93b-4a74-8b6e-ec6c2ce05820	عصير فينيسيا جالون 1 لتر	Phoenicia galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1b36da38-327f-4105-9567-d175e95832c7.png	1f599865-0727-4843-86ec-28d5af2aed93	29.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:52:59.63435+00	{}	\N
4b89f94e-a9da-45bb-aaef-1fd4d6c0dc69	عصير بيري سموذي جالون 1 لتر	Berry smoothi  galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/0d67b46d-df7b-49ce-9427-b06358b7abfe.png	1f599865-0727-4843-86ec-28d5af2aed93	30.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:58:07.9784+00	{}	\N
3798e73f-7bb0-4583-8b44-9f113a87a7b7	ميلك شيك لوتس جالون 1.5 لتر	Lotus galon 1.5 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/3de58a82-b3e5-400a-a764-11f09c059135.png	1f599865-0727-4843-86ec-28d5af2aed93	51.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:33:58.579839+00	{}	\N
db552e67-12f2-4cdc-a61a-27289b6202ef	جق جق صغير	Jq Jq Small	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	16.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
f930aee4-36fb-42de-a794-baa8e0eea3af	ردبل رمان صغير	Redbull Pomegranet S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	19.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
8df0d059-1ba0-48df-8458-68b36b5f224e	سفن اب رمان كبير	7up Pomegranet L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	14.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
987d3778-2298-41b4-bfab-b462ade8750b	ميلك شيك بيستاشيو جالون 1 لتر	Jojo galon 1 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e27563e2-af13-4c56-83ae-392fcb8b577f.png	1f599865-0727-4843-86ec-28d5af2aed93	46.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:41:10.521899+00	{}	\N
8ba110aa-b669-414d-91db-b575b0559e2c	عصير كيوي كبير	Kiwi L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/62fc4654-6d94-4e47-aeaa-d705214e8eb6.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	17.00	104	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:43:26.374376+00	{}	\N
db8eb433-59b4-4e39-851b-43c63131295a	عصير ليمون نعناع كبير	Lemon mint L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e672c0f9-f9f0-44ba-ad77-6f364a4bd608.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	14.00	424	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:44:19.238489+00	{}	\N
b5997bd0-f207-49f4-a21b-4d42c4fd1238	ايس كريم كندر لوتس كبير	Kinder lotus L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/9c93859d-df4f-477b-ba66-244bd4f67857.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	30.00	915	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:22:43.640328+00	{}	\N
693bad02-1f3f-4a7e-adaa-c955130bf022	ايس كريم نوتيلا كبير	Nutella L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/6fdea55c-66ff-4322-bfa1-4a7a8daa0fd7.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	26.00	873	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:27:02.26439+00	{}	\N
537b58a7-01bd-46e2-bb84-1bfefdd9984d	عصير أناناس صغير	pineapple S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f4ea9017-2544-4527-a6fb-48bcca1dc4d1.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	14.00	120	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:38:30.461965+00	{}	\N
0000dfc4-42b5-4008-957e-afa3569b612f	عصير الملك كبير	The King L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/2fd4da2b-603e-492d-90bc-cf463596fbff.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	19.00	598	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:46:32.783518+00	{}	\N
f3343d76-ac2f-4f24-97d4-76533338560d	عصير فيتامين صغير	Vitamine S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/a7f490b6-0491-4027-9007-9988f8898ef2.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	17.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:54:00.841184+00	{}	\N
cbce3b00-7d54-4874-b49e-b408af0933b3	سلطة فواكه كبير	Fruit Salad L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/aeea9935-8bad-4a3c-aa55-db45a6f12227.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	19.00	362	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:01:30.893293+00	{}	\N
f72ae679-8690-4b50-9e33-65d991edc169	شمام كبير	Melon - L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b4ecb944-f776-44ae-b209-0bb61bce66d6.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	14.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:08:54.616482+00	{}	\N
da835d98-dd02-4ab0-9ca7-3393e227f128	عصير برتقال كبير	Orange L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/20fa93ca-fac2-4579-a386-016c67b7a2d0.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	14.00	86	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:40:57.624098+00	{}	\N
f8b18842-0e91-4d7a-b6b9-f62019f341fc	عصاير ميني ملك شك 12حبه	Mini Juices Milkshake12 piece			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/3c3bb1df-8053-4313-97f3-34695ee248c6.png	73fce410-bf36-4579-872f-b1b8d55815e5	140.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:30:46.837085+00	{}	\N
3cbf1870-4016-468f-a567-ca4a8e41bdbd	فلوتنق فليك كبير	Flake L Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/52fa2a97-aa32-4200-adf7-5bf4cf608049.png	790aae02-4102-4e41-8487-03f1d8cb3567	29.00	1106	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:41:13.199373+00	{}	\N
7ca6bbe5-2f92-4c80-9150-f245e4f7a085	عصير جزر كبير	Carrot L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/6fe6f742-f53a-4a08-ae31-90475b008c42.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	14.00	46	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:41:32.86243+00	{}	\N
4cddeadc-e850-48fc-b727-accf30b7c8d2	فلوتنق كيت كات صغير	Kitkat S Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/236c64cf-a5c6-4190-bc39-1bffb0da7f47.png	790aae02-4102-4e41-8487-03f1d8cb3567	26.00	850	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:42:00.945609+00	{}	\N
f903bd0c-be9f-488e-8d77-7765512a997f	كود ريد رمان كبير	Code Red pomegranate L	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	18.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
e8668048-bd4a-49e1-88da-cce1a842dfb7	جق جق كبير	Jq Jq Large	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	18.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
aa640221-1b4a-4371-b7b3-17fc0102da8d	سفن اب رمان صغير	7up Pomegranet S	\N	\N	\N	0db67202-0d4a-4960-a468-83d733478e1d	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 08:30:04.930145+00	{}	\N
25fd0fe7-dd82-4e26-8623-24c2f5f9678e	ايس كريم لوتس صغير	Lotus S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/35286982-f670-4033-899e-fb9ec839b944.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	24.00	677	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:28:54.628387+00	{}	\N
a676558c-c99f-47ac-99f0-cc7e857a7b96	فلوتنق كندر كبير	Kinder L Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/137cd1d1-5660-4ece-ba4d-335c90e6a216.png	790aae02-4102-4e41-8487-03f1d8cb3567	30.00	892	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:41:42.672324+00	{}	\N
68b7621e-705a-4ffc-a4b5-1f4799ee09a7	ايس كريم اوريو كبير	Oreo L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/432d7a9f-1955-44ab-a232-f98ebed12861.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	24.00	830	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:29:05.574881+00	{}	\N
6e024d62-4190-42af-a186-98a6c7415c72	ايس كريم زعفران صغير	Safron S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/c7a33ca6-60fc-4262-8fa9-af858865e034.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	25.00	381	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:37:26.907472+00	{}	\N
4640d78b-f59c-4cdd-a8b8-aaf5b7e3fd0d	ايس كريم لوتس كبير	Lotus L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/7d70db8f-c5dd-400f-ac88-191a8a67a309.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	28.00	876	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:41:04.78587+00	{}	\N
ca8315b4-8855-4a97-8f1a-fb5c301fb5f2	ايس كريم سنيكرز كبير	Sneackers L Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b2bc9abd-29e8-425f-acc4-5a5ff7a3d9d0.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	25.00	611	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:40:33.975553+00	{}	\N
fa78d34f-4fb8-42c0-ac10-aa057aa4b1d5	ايس كريم نوتيلا صغير	Nutella S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/0ad7a476-c467-49e3-9b67-50ede332d221.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	21.00	654	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:41:13.171898+00	{}	\N
1ace3cad-af93-4a32-88ed-89d36053f346	ايس كريم اوريو صغير	Oreo S Ice cream			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/d801ab26-c1e5-4f13-9df7-5fc2548c23e8.png	2c220e2c-dd8a-480a-aac8-8d105b2bce2f	20.00	630	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:41:44.982762+00	{}	\N
953d46e5-2a2e-46ec-bd06-35aef49ab1f4	عصير أناناس كبير	pineapple L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/16b97af8-bb3c-45e4-8609-51da95c18b41.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	16.00	166	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:47:18.801234+00	{}	\N
9bd93881-20fd-4c7d-8bdf-bdeaa795d08b	عصير جزر صغير	Carrot S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/81817159-ed5b-44d0-a860-4fa9578d2793.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	12.00	36	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:47:43.293805+00	{}	\N
38777a6b-1480-4a78-a49f-a465b7ffa8ae	عصير كوكتيل سبيشل صغير	Special Cocktail S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f45b0d29-a28e-49fb-a586-166d9eaffc99.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	16.00	333	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:57:11.312473+00	{}	\N
103463a6-61b9-4e7d-ab2d-d4880c7b0ea8	عصير معاريس كبير	Maaris L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b9f84326-58b1-4226-b6f1-603173bc3977.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	18.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:48:53.011124+00	{}	\N
4d85685c-1754-457e-ae23-48159c9d7496	عصير تفاح كبير	Apple L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/22400cb9-8434-41a5-837c-7784c07230b7.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	14.00	523	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:52:22.896174+00	{}	\N
ce824a76-a9e8-44b9-93f6-726043472047	عصير الملك صغير	The King S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/24fd35b8-f38c-43f6-a1ee-fec70e24ab6d.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	17.00	468	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:53:15.344991+00	{}	\N
a1cacfaa-66b9-4088-8049-37bc8814454b	مياه نوفا	Nova Water			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/72684cdc-3eb6-48ed-9851-82114e185cac.png	0db67202-0d4a-4960-a468-83d733478e1d	1.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:54:50.518234+00	{}	\N
d8d41dda-5318-4892-9797-d8b0bf49198c	عصير ليمون نعناع صغير	Lemon mint S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/1fdeb78d-ba78-40ed-8c23-9a60f7291330.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	12.00	346	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:55:58.337258+00	{}	\N
fcf4482a-1d92-432c-8a55-b5598b978576	عصير موز حليب صغير	Banana milk S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/88c9192f-e0cf-4ade-ab61-5025da98e52f.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	12.00	346	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:57:27.730959+00	{}	\N
f66859be-e3dc-4f4f-8d7e-26ccdd63c667	سلطة فواكه صغير	Fruit Salad S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/f0a535d1-39a0-495e-a43d-d3f7c5b12758.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	17.00	283	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:01:38.245004+00	{}	\N
fb9a7ac7-283b-407c-a990-b539572f2e47	شمام صغير	Melon - S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/505e6f2f-d928-4b09-89e4-bb6eb1a3549d.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	12.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:09:08.629611+00	{}	\N
f021be88-5769-4534-913b-d3317ec711e1	فلوتنق نوتيلا صغير	Nutilla S Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5e585450-09c7-41e7-9d3b-20e7b6a6858f.png	790aae02-4102-4e41-8487-03f1d8cb3567	26.00	844	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:40:41.623026+00	{}	\N
f41ee66f-0f44-4de8-a3ec-f3cd2d6f456c	فلوتنق كندر صغير	Kinder S Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/d47e59c1-98f6-4b03-b42c-c4c5ee8db92a.png	790aae02-4102-4e41-8487-03f1d8cb3567	27.00	729	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:41:34.182227+00	{}	\N
5e63519e-2a81-42c3-a720-18fb347245ba	فلوتنق لوتس صغير	Lotus S Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/41161654-0f79-4565-a70e-2e92518aeaaa.png	790aae02-4102-4e41-8487-03f1d8cb3567	26.00	627	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:43:04.568367+00	{}	\N
b2f2ae8d-9287-461c-9110-74d35305af9b	ميلك شيك كرك كبير	Karak L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/b44ce132-013b-43fa-bddc-b16e96c7f149.png	8ac569e9-cb25-405a-826f-8db56372b0d4	18.00	840	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 11:34:43.808376+00	{}	\N
bd2195e6-6e9e-414a-ab5b-7590bf235f89	عصير كوكتيل طبقات صغير	Cocktail levels S			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/4466cffb-bc34-43af-9473-9030dc2e5a37.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	13.00	288	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:55:17.763473+00	{}	\N
1a87eb3e-1eb5-472f-88ac-304ded574eaf	عصير كوكتيل سبيشل كبير	Special Cocktail L			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/756f84ee-39ca-421c-b8aa-99d1a286f58e.png	7ef407fe-ba82-4c84-ab55-8aae804af7f8	18.00	426	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 12:57:02.341804+00	{}	\N
dada251f-298f-4791-9173-29e6beeb26e6	فلوتنق نوتيلا كبير	Nutilla L Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/5e4c999f-5233-4ad1-9f8c-562342a4135c.png	790aae02-4102-4e41-8487-03f1d8cb3567	29.00	910	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:40:33.011734+00	{}	\N
9201bb61-f293-4bb5-be3f-2ab51726e98f	فلوتنق فليك صغير	Flake S Floating			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/829cdbe5-1bd1-4b5c-b794-3d0afb4fd125.png	790aae02-4102-4e41-8487-03f1d8cb3567	26.00	850	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 13:41:04.630342+00	{}	\N
3993f7c5-2e3a-46d4-b2e6-fdcd2f2c7969	عصير كيوي جالون 1.5 لتر	Kiwi galon 1.5 Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/d3a7c893-fa25-4e68-b118-dc4e04ef1ecf.png	1f599865-0727-4843-86ec-28d5af2aed93	40.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:53:33.250758+00	{}	\N
d39a7941-c711-49f4-b3f2-a5c93aa068df	عصير امبراطور جالون 1 لتر	Emperor galon one Ltr			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/d4b1bf01-bac2-42e1-9daf-ddcbcba6b6fc.png	1f599865-0727-4843-86ec-28d5af2aed93	27.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 14:58:33.971838+00	{}	\N
4dc50d6f-5a0a-40f0-a184-5cf56da402bd	ميلك شيك كندر جالون 1.5 لتر	Kinder galon 1.5 L Milk Shake			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/e40fa3e6-5abc-4bed-98fd-3492fa9eb271.png	1f599865-0727-4843-86ec-28d5af2aed93	51.00	\N	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:34:56.112966+00	{}	\N
d4a8a892-3105-4346-ac10-b0475c05916e	كراك أخضر	Crak Green			https://edldkzykzvcrfvjbgzbb.supabase.co/storage/v1/object/public/store-assets/products/c1d1fa97-1809-46cd-98d3-60aa4ed31005.png	8ac569e9-cb25-405a-826f-8db56372b0d4	26.00	620	\N	t	0	t	t	f	f	2026-05-07 12:59:13.873213+00	2026-05-09 16:44:39.117562+00	{}	\N
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id, full_name, phone, avatar_url, created_at, updated_at, status, last_login_at) FROM stdin;
3ccd7385-a949-4ba4-9eb9-32909c1061c0	المعتصم	\N	\N	2026-05-07 12:52:27.300176+00	2026-05-07 12:52:27.300176+00	active	\N
42ddbd9d-c350-4ac3-9c08-24d499702bc4	مشهور عبدالرحمن	\N	\N	2026-05-07 14:16:52.369633+00	2026-05-07 14:16:52.433556+00	active	\N
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, role_id, permission_key) FROM stdin;
757bd3bb-9a2e-4219-a6c8-00f15e934895	c91a7855-d95d-423e-96bc-89e45c860f43	dashboard.view
6a40d5c4-4c55-44dd-b0d4-83a21d09efe4	c91a7855-d95d-423e-96bc-89e45c860f43	orders.view
1e971cb7-40db-4f75-ae6f-9e0bd29ad1c1	c91a7855-d95d-423e-96bc-89e45c860f43	orders.detail
d15197ed-2bd3-4cdc-bcb8-f324403bbde7	c91a7855-d95d-423e-96bc-89e45c860f43	orders.status
d3b20c7b-8a5f-4c28-9039-2f85b68a52f4	c91a7855-d95d-423e-96bc-89e45c860f43	orders.cancel
e221e3fb-897c-40e9-8511-437500398915	c91a7855-d95d-423e-96bc-89e45c860f43	orders.assign_driver
c1e8ad15-af7f-4828-a06b-201ea7f67abf	c91a7855-d95d-423e-96bc-89e45c860f43	orders.print
0e2cd7b8-39e7-436f-bd47-1d81775cc2d8	c91a7855-d95d-423e-96bc-89e45c860f43	products.view
4a4e1506-8062-4699-8c4d-aef51ec55959	c91a7855-d95d-423e-96bc-89e45c860f43	products.create
fc9b599c-31d6-480f-87f6-4edb8bf5b0d7	c91a7855-d95d-423e-96bc-89e45c860f43	products.edit
9c6bf439-65e4-4d07-bc01-ef0c0c4983c5	c91a7855-d95d-423e-96bc-89e45c860f43	products.delete
3670677f-060c-4992-ac06-98355e143d44	c91a7855-d95d-423e-96bc-89e45c860f43	products.toggle
e7d59c19-1336-4495-a011-df49ad8dfcaf	c91a7855-d95d-423e-96bc-89e45c860f43	products.import
f4e4857a-e87d-4d37-bbc3-d1880c2ec91b	c91a7855-d95d-423e-96bc-89e45c860f43	categories.view
38b358cb-0c9f-4067-a9b1-5d1ad93c0c13	c91a7855-d95d-423e-96bc-89e45c860f43	categories.create
b0032d7a-a236-4632-9341-ecc7e3536f6c	c91a7855-d95d-423e-96bc-89e45c860f43	categories.edit
78cc519d-6b23-415b-a19f-f539d95b162a	c91a7855-d95d-423e-96bc-89e45c860f43	categories.delete
c633df9c-3596-46de-9167-464c11235a48	c91a7855-d95d-423e-96bc-89e45c860f43	addons.view
88e1ff74-b383-4be3-a0bc-220fc08ad475	c91a7855-d95d-423e-96bc-89e45c860f43	addons.create
136ab1a5-10d0-4679-914a-6420b6bc0d4c	c91a7855-d95d-423e-96bc-89e45c860f43	addons.edit
b356033e-aa53-40a6-bebe-726d83e4a043	c91a7855-d95d-423e-96bc-89e45c860f43	addons.delete
fb52377d-ffd5-4645-b74b-ece02e80537f	c91a7855-d95d-423e-96bc-89e45c860f43	branches.view
d37206a8-eab3-4d92-93dd-1a13b5f53bee	c91a7855-d95d-423e-96bc-89e45c860f43	branches.create
80eda0f9-2bef-4d36-98f1-84d91ac9456b	c91a7855-d95d-423e-96bc-89e45c860f43	branches.edit
b19d5698-9a04-4c5c-a8f4-ace548e6afa3	c91a7855-d95d-423e-96bc-89e45c860f43	branches.toggle
0280567b-3d49-474a-ad48-b4cd8e550965	c91a7855-d95d-423e-96bc-89e45c860f43	drivers.view
017b9bce-82b4-4d10-b562-1eb847a96b95	c91a7855-d95d-423e-96bc-89e45c860f43	drivers.create
7ba5ed34-8f77-49ca-9e2f-643299895081	c91a7855-d95d-423e-96bc-89e45c860f43	drivers.edit
fc5611e0-660d-4072-92c3-3beaa8d36de9	c91a7855-d95d-423e-96bc-89e45c860f43	drivers.toggle
f13d74e4-7d43-4b77-af2d-e17ce5ff07cd	c91a7855-d95d-423e-96bc-89e45c860f43	customers.view
16a57498-60df-42eb-b8b5-219b45b2f8d8	c91a7855-d95d-423e-96bc-89e45c860f43	customers.edit
92d1fa6d-2957-4ef8-9594-831f3648efc7	c91a7855-d95d-423e-96bc-89e45c860f43	customers.block
6baeb1bc-452f-41d1-9b64-01279af61770	c91a7855-d95d-423e-96bc-89e45c860f43	coupons.view
73531e80-66b5-4d03-9be7-9ffcbf7922f8	c91a7855-d95d-423e-96bc-89e45c860f43	coupons.create
a93fb458-493c-4faf-8e81-8402b8eb4297	c91a7855-d95d-423e-96bc-89e45c860f43	coupons.edit
339f8b6f-496d-40f9-af63-1cc7b674e15a	c91a7855-d95d-423e-96bc-89e45c860f43	coupons.toggle
69944b68-bad7-4331-8daa-83c00b99bfd4	c91a7855-d95d-423e-96bc-89e45c860f43	banners.view
63832b52-1d77-42d4-9284-0b27881d785f	c91a7855-d95d-423e-96bc-89e45c860f43	banners.manage
eb0a8c15-dd00-462e-b985-e2a31550b68d	c91a7855-d95d-423e-96bc-89e45c860f43	content.pages
723ae0dc-0f9b-4c47-ba05-045dd4ce1f58	c91a7855-d95d-423e-96bc-89e45c860f43	content.header
21d16dae-cb7b-4fe4-921d-1e2e11b0ac97	c91a7855-d95d-423e-96bc-89e45c860f43	content.footer
6bf7ee1d-caba-47d0-861f-b173a294cdb3	c91a7855-d95d-423e-96bc-89e45c860f43	content.menus
acd4d746-85f2-4c04-a54c-8e23a443159a	c91a7855-d95d-423e-96bc-89e45c860f43	content.faq
7b9ef408-db43-4d95-a56a-bd588be39e3c	c91a7855-d95d-423e-96bc-89e45c860f43	seo.view
2222c9cf-39ee-4a59-9346-86549f23b0f2	c91a7855-d95d-423e-96bc-89e45c860f43	seo.edit
038f466c-cc0e-4fb5-ae97-63158c733722	c91a7855-d95d-423e-96bc-89e45c860f43	integrations.view
d44d326b-5310-454d-9eee-8f640e643191	c91a7855-d95d-423e-96bc-89e45c860f43	integrations.edit
d8e1f5a0-5901-4771-8959-9fb1fe5c0766	c91a7855-d95d-423e-96bc-89e45c860f43	integrations.test
ec1e3e50-054b-4c2f-9dee-6957f8d9d68a	c91a7855-d95d-423e-96bc-89e45c860f43	reports.view
7fd0ceb4-0350-44d1-9200-c55edf9b0eb4	c91a7855-d95d-423e-96bc-89e45c860f43	reports.export_excel
c97949fc-e0e3-404c-a9cc-5e8395f17501	c91a7855-d95d-423e-96bc-89e45c860f43	reports.export_pdf
5b21b276-31a4-413d-9f61-cbc02308eb69	c91a7855-d95d-423e-96bc-89e45c860f43	settings.view
5bf3c57e-0055-4a03-9add-8e57a4fbfe30	c91a7855-d95d-423e-96bc-89e45c860f43	settings.edit
cf12dbf4-ba57-42c3-84eb-247048a049a2	c91a7855-d95d-423e-96bc-89e45c860f43	settings.app
1c8292dc-2287-4ef8-a568-96d6b72d9323	c91a7855-d95d-423e-96bc-89e45c860f43	users.view
2c910601-5f9a-44bf-b865-c09d67eeb5b3	c91a7855-d95d-423e-96bc-89e45c860f43	users.create
ade0ca8d-621e-4019-aee4-04b935c33b40	c91a7855-d95d-423e-96bc-89e45c860f43	users.edit
c83df598-dc82-4b54-bcb3-b07004b9eba5	c91a7855-d95d-423e-96bc-89e45c860f43	users.permissions
8b648ba4-2225-405d-936e-2f95a0e8b8d5	c91a7855-d95d-423e-96bc-89e45c860f43	activity.view
829706de-4d62-4960-8288-87b59fc7d1d3	73891be4-b9a5-45b1-938f-ca2c5fa02e70	dashboard.view
beaf6387-d24d-4836-89cc-6217d8601735	73891be4-b9a5-45b1-938f-ca2c5fa02e70	orders.view
917fc3d3-5c57-449a-afd8-a22c32a0281d	73891be4-b9a5-45b1-938f-ca2c5fa02e70	orders.detail
94b23236-2c0a-4e39-aff0-4aeeba7859a3	73891be4-b9a5-45b1-938f-ca2c5fa02e70	orders.status
f3ff256e-bfc2-4c6a-91d9-8f6d98650ddd	73891be4-b9a5-45b1-938f-ca2c5fa02e70	orders.cancel
2d00af80-b866-445b-91c0-d3df38888ead	73891be4-b9a5-45b1-938f-ca2c5fa02e70	orders.assign_driver
a82a9508-342e-4aee-bab9-26a3baddf2d1	73891be4-b9a5-45b1-938f-ca2c5fa02e70	orders.print
7ecafaa6-e08a-44a5-bc0f-20ddf8b1c65c	73891be4-b9a5-45b1-938f-ca2c5fa02e70	products.view
ac54c509-1ddb-495b-965d-9994e7e988b6	73891be4-b9a5-45b1-938f-ca2c5fa02e70	products.create
6ba3b2f0-254e-490a-9c95-75fcc4c4f927	73891be4-b9a5-45b1-938f-ca2c5fa02e70	products.edit
7c2ad964-e9db-4f60-afdf-fd7ab6e23050	73891be4-b9a5-45b1-938f-ca2c5fa02e70	products.delete
548e643d-438f-4cf5-a8d0-52cb76c64ca6	73891be4-b9a5-45b1-938f-ca2c5fa02e70	products.toggle
0abd6332-ca49-4899-bc6c-ad4c5881307c	73891be4-b9a5-45b1-938f-ca2c5fa02e70	products.import
def400bd-f740-400c-867d-2462f170b32f	73891be4-b9a5-45b1-938f-ca2c5fa02e70	categories.view
c72fb820-d0be-429a-b581-2d5485868a77	73891be4-b9a5-45b1-938f-ca2c5fa02e70	categories.create
32bc1f4d-6649-4909-a90d-3b4f1b0d12ec	73891be4-b9a5-45b1-938f-ca2c5fa02e70	categories.edit
105ccefc-5285-4a6b-9711-a860429966f6	73891be4-b9a5-45b1-938f-ca2c5fa02e70	categories.delete
b468d90a-64b8-4f7c-bf75-68c7bf9284ac	73891be4-b9a5-45b1-938f-ca2c5fa02e70	addons.view
8c87a1c8-b1a3-4d88-b23c-372bb5325fd8	73891be4-b9a5-45b1-938f-ca2c5fa02e70	addons.create
9e95efb9-5c14-443d-843b-101dafcb1847	73891be4-b9a5-45b1-938f-ca2c5fa02e70	addons.edit
ccc12ae6-5725-4989-a83d-2c41954c598b	73891be4-b9a5-45b1-938f-ca2c5fa02e70	addons.delete
393738c5-5470-46da-bdb6-a9e777a298ed	73891be4-b9a5-45b1-938f-ca2c5fa02e70	branches.view
bd492da2-34c7-47b2-bf4a-3a93c0de9f70	73891be4-b9a5-45b1-938f-ca2c5fa02e70	branches.create
dd4c0162-c439-441d-970a-5e1463265e44	73891be4-b9a5-45b1-938f-ca2c5fa02e70	branches.edit
3731ba39-9566-4b8c-979c-9735e10b9f15	73891be4-b9a5-45b1-938f-ca2c5fa02e70	branches.toggle
0862dba2-5468-4ebb-a1f0-5b3bf92f5f75	73891be4-b9a5-45b1-938f-ca2c5fa02e70	drivers.view
61006a7c-2c46-4b7b-b4ce-c9b481dfa78f	73891be4-b9a5-45b1-938f-ca2c5fa02e70	drivers.create
7c17a3b2-3879-49cb-b0c0-c48df38dfa9a	73891be4-b9a5-45b1-938f-ca2c5fa02e70	drivers.edit
ea67def5-16ff-4f8e-a32d-61cbf0fea887	73891be4-b9a5-45b1-938f-ca2c5fa02e70	drivers.toggle
cf2e3b59-7e34-4690-b7b3-ca93de673c67	73891be4-b9a5-45b1-938f-ca2c5fa02e70	customers.view
58acc8c1-1226-4b0e-b650-43f4365022e5	73891be4-b9a5-45b1-938f-ca2c5fa02e70	customers.edit
df5f707f-0d6d-429f-a5c4-0d9da876bdeb	73891be4-b9a5-45b1-938f-ca2c5fa02e70	customers.block
dcdaf012-0a1e-4828-a566-58df0750a635	73891be4-b9a5-45b1-938f-ca2c5fa02e70	coupons.view
956cc09e-2cae-44fa-97d4-9eee1bff4f5d	73891be4-b9a5-45b1-938f-ca2c5fa02e70	coupons.create
8084be66-04d1-425b-8c24-2a996d6f0d9c	73891be4-b9a5-45b1-938f-ca2c5fa02e70	coupons.edit
aa18c6cb-c5b8-4b72-8ec8-ef70f8d01baa	73891be4-b9a5-45b1-938f-ca2c5fa02e70	coupons.toggle
e10fc778-041e-4c01-bb3d-8fb609d30a72	73891be4-b9a5-45b1-938f-ca2c5fa02e70	banners.view
8f55c0ea-e562-4023-b44f-87c736235ff6	73891be4-b9a5-45b1-938f-ca2c5fa02e70	banners.manage
727b2d48-5773-4d37-aa17-46047d043d3c	73891be4-b9a5-45b1-938f-ca2c5fa02e70	content.pages
fd22bde6-b765-47af-ab0e-0308d1ded42a	73891be4-b9a5-45b1-938f-ca2c5fa02e70	content.header
b593f52a-746e-4e32-950f-3a12d75f0c10	73891be4-b9a5-45b1-938f-ca2c5fa02e70	content.footer
99a32d8c-5d1e-405a-8624-3b047ac94ceb	73891be4-b9a5-45b1-938f-ca2c5fa02e70	content.menus
d644fac1-c088-4aa3-ac61-990149b20487	73891be4-b9a5-45b1-938f-ca2c5fa02e70	content.faq
99476bc4-9da9-4330-852f-c2e4c2135911	73891be4-b9a5-45b1-938f-ca2c5fa02e70	seo.view
6a9d6673-7329-4503-b211-c2cbc7e0ee46	73891be4-b9a5-45b1-938f-ca2c5fa02e70	seo.edit
830624cb-779d-4558-a958-23fa02697f83	73891be4-b9a5-45b1-938f-ca2c5fa02e70	integrations.view
fab44826-3ae3-4b6c-9a54-de9f749f69f6	73891be4-b9a5-45b1-938f-ca2c5fa02e70	reports.view
e8ee9de9-64eb-479e-86c8-9147b8df522e	73891be4-b9a5-45b1-938f-ca2c5fa02e70	reports.export_excel
f58a9eba-99b1-41e3-8fbc-abce93f3fca4	73891be4-b9a5-45b1-938f-ca2c5fa02e70	reports.export_pdf
f5f74998-6215-4349-94dd-45329027d166	73891be4-b9a5-45b1-938f-ca2c5fa02e70	settings.view
4fd4a53f-29ca-4e54-a6b2-8519f10bee51	73891be4-b9a5-45b1-938f-ca2c5fa02e70	settings.edit
fa06e10b-66e3-4b8e-b6ba-4294056d746c	73891be4-b9a5-45b1-938f-ca2c5fa02e70	settings.app
4492f147-ea30-48ed-bd90-0be683810e8b	73891be4-b9a5-45b1-938f-ca2c5fa02e70	users.view
b5127f46-ab15-4f32-a4c7-7e7b2633b630	73891be4-b9a5-45b1-938f-ca2c5fa02e70	users.edit
fa0989e8-f6f4-428f-8270-58a4f12a523d	73891be4-b9a5-45b1-938f-ca2c5fa02e70	activity.view
2ad42341-4fdf-4ac1-9126-469c71d557d1	dc302327-f175-4e86-b628-6a320eacb776	dashboard.view
d9fa2d19-499e-45a4-945b-44b121d4774f	dc302327-f175-4e86-b628-6a320eacb776	orders.view
1a771299-78aa-4b37-8744-cdcd641d8eff	dc302327-f175-4e86-b628-6a320eacb776	orders.detail
751df4df-86cb-421d-b0fc-bbd2d822122c	dc302327-f175-4e86-b628-6a320eacb776	orders.status
211b08f7-6be9-4433-8a38-984f01c57514	dc302327-f175-4e86-b628-6a320eacb776	orders.assign_driver
b62ccf91-d228-4e54-a29c-ab51db570759	dc302327-f175-4e86-b628-6a320eacb776	orders.print
fbd38ecb-e907-4900-bc81-edee2261d8a1	dc302327-f175-4e86-b628-6a320eacb776	products.view
7e8cb02a-5009-4e9c-bc6d-fe53d902bc19	dc302327-f175-4e86-b628-6a320eacb776	categories.view
117e73f6-3c60-4cf2-8bc9-7b7f8bc6cc11	dc302327-f175-4e86-b628-6a320eacb776	addons.view
91b815c8-ac52-4da9-a931-00cc8cf263a7	dc302327-f175-4e86-b628-6a320eacb776	branches.view
879f6d7d-9216-4f8f-bd2c-5888b46cea41	dc302327-f175-4e86-b628-6a320eacb776	drivers.view
402c8ff6-b92f-41fc-bc72-3725a6ddf311	dc302327-f175-4e86-b628-6a320eacb776	customers.view
66542744-8bb5-495b-91e5-5124e7b06fe4	dc302327-f175-4e86-b628-6a320eacb776	coupons.view
649b42db-f5aa-4285-8379-df3be1b24ace	dc302327-f175-4e86-b628-6a320eacb776	banners.view
3a9db362-3fe1-4b32-af15-5194848e5da3	dc302327-f175-4e86-b628-6a320eacb776	reports.view
4bf71c46-eb8f-4780-b28b-b0fb482c7d08	dc302327-f175-4e86-b628-6a320eacb776	activity.view
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, key, name, description, is_system, created_at, updated_at) FROM stdin;
c91a7855-d95d-423e-96bc-89e45c860f43	admin	مسؤول	صلاحيات كاملة على النظام	t	2026-05-07 14:26:50.518592+00	2026-05-07 14:26:50.518592+00
73891be4-b9a5-45b1-938f-ca2c5fa02e70	manager	مدير	إدارة المتجر والعمليات	t	2026-05-07 14:26:50.518592+00	2026-05-07 14:26:50.518592+00
dc302327-f175-4e86-b628-6a320eacb776	staff	موظف	صلاحيات تشغيلية محدودة	t	2026-05-07 14:26:50.518592+00	2026-05-07 14:26:50.518592+00
\.


--
-- Data for Name: security_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.security_sessions (id, user_id, device, browser, ip_address, user_agent, last_activity_at, created_at) FROM stdin;
8fc67b52-e230-426c-9530-48d72be0179b	42ddbd9d-c350-4ac3-9c08-24d499702bc4	Mobile	Safari/604.1	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1	2026-05-08 09:56:02.607885+00	2026-05-08 09:56:02.607885+00
c2d03c2b-1faa-49a9-9925-ce276669c3f7	3ccd7385-a949-4ba4-9eb9-32909c1061c0	Desktop	Safari/537.36	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	2026-05-10 09:55:11.131434+00	2026-05-10 09:55:11.131434+00
\.


--
-- Data for Name: seo_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seo_settings (id, entity_type, entity_id, meta_title, meta_description, meta_keywords, slug, canonical_url, og_title, og_description, og_image, twitter_title, twitter_description, twitter_image, robots_index, robots_follow, default_og_image, default_twitter_image, google_verification, sitemap_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: store_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.store_settings (id, name, logo_url, primary_color, secondary_color, phone, email, address, currency, vat_percent, delivery_fee, min_order_amount, business_hours, accepting_orders, created_at, updated_at) FROM stdin;
3e845e39-1b64-40cb-8474-227d3fd41f44	عصير تايم		#ED1C24	#F97316	0512345678	eastern@aseertimeestern.com	الدمام	SAR	15.00	10.00	50.00	{}	t	2026-05-07 12:55:12.532124+00	2026-05-07 12:55:12.532124+00
\.


--
-- Data for Name: user_branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_branches (id, user_id, branch_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role, created_at) FROM stdin;
802b39af-2b0d-460c-8655-e7fc6ea80cc9	3ccd7385-a949-4ba4-9eb9-32909c1061c0	admin	2026-05-07 12:52:27.300176+00
24e7ba18-92f6-4d3e-a5a2-ccf5c94948e5	42ddbd9d-c350-4ac3-9c08-24d499702bc4	admin	2026-05-07 14:16:52.499382+00
\.


--
-- Data for Name: webhook_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_logs (id, webhook_id, event, payload, response_status, response_body, attempt_count, created_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks (id, name, url, secret, events, status, created_at, updated_at) FROM stdin;
\.


--
-- Name: orders_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_number_seq', 10005, true);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: addon_group_links addon_group_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addon_group_links
    ADD CONSTRAINT addon_group_links_pkey PRIMARY KEY (id);


--
-- Name: addon_groups addon_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addon_groups
    ADD CONSTRAINT addon_groups_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: coupon_usages coupon_usages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupon_usages
    ADD CONSTRAINT coupon_usages_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_code_key UNIQUE (code);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: customer_addresses customer_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_addresses
    ADD CONSTRAINT customer_addresses_pkey PRIMARY KEY (id);


--
-- Name: customers customers_phone_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_phone_key UNIQUE (phone);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: delivery_zones delivery_zones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_zones
    ADD CONSTRAINT delivery_zones_pkey PRIMARY KEY (id);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: footer_settings footer_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.footer_settings
    ADD CONSTRAINT footer_settings_pkey PRIMARY KEY (id);


--
-- Name: header_settings header_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.header_settings
    ADD CONSTRAINT header_settings_pkey PRIMARY KEY (id);


--
-- Name: hero_slides hero_slides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_slides
    ADD CONSTRAINT hero_slides_pkey PRIMARY KEY (id);


--
-- Name: home_section_banners home_section_banners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_section_banners
    ADD CONSTRAINT home_section_banners_pkey PRIMARY KEY (id);


--
-- Name: home_sections home_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_sections
    ADD CONSTRAINT home_sections_pkey PRIMARY KEY (id);


--
-- Name: import_logs import_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_logs
    ADD CONSTRAINT import_logs_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_provider_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_provider_key UNIQUE (provider);


--
-- Name: navigation_menu_items navigation_menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.navigation_menu_items
    ADD CONSTRAINT navigation_menu_items_pkey PRIMARY KEY (id);


--
-- Name: navigation_menus navigation_menus_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.navigation_menus
    ADD CONSTRAINT navigation_menus_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_user_id_key UNIQUE (user_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_item_addons order_item_addons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons
    ADD CONSTRAINT order_item_addons_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_status_logs order_status_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_status_logs
    ADD CONSTRAINT order_status_logs_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_number_key UNIQUE (order_number);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: page_blocks page_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_blocks
    ADD CONSTRAINT page_blocks_pkey PRIMARY KEY (id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_key UNIQUE (slug);


--
-- Name: permissions permissions_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_key_key UNIQUE (key);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: product_addons product_addons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_addons
    ADD CONSTRAINT product_addons_pkey PRIMARY KEY (id);


--
-- Name: product_branches product_branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_branches
    ADD CONSTRAINT product_branches_pkey PRIMARY KEY (product_id, branch_id);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_role_id_permission_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_permission_key_key UNIQUE (role_id, permission_key);


--
-- Name: roles roles_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_key_key UNIQUE (key);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: security_sessions security_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_sessions
    ADD CONSTRAINT security_sessions_pkey PRIMARY KEY (id);


--
-- Name: seo_settings seo_settings_entity_type_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_settings
    ADD CONSTRAINT seo_settings_entity_type_entity_id_key UNIQUE (entity_type, entity_id);


--
-- Name: seo_settings seo_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seo_settings
    ADD CONSTRAINT seo_settings_pkey PRIMARY KEY (id);


--
-- Name: store_settings store_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_settings
    ADD CONSTRAINT store_settings_pkey PRIMARY KEY (id);


--
-- Name: user_branches user_branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_pkey PRIMARY KEY (id);


--
-- Name: user_branches user_branches_user_id_branch_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_user_id_branch_id_key UNIQUE (user_id, branch_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_key UNIQUE (user_id, role);


--
-- Name: webhook_logs webhook_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: activity_logs_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activity_logs_created_idx ON public.activity_logs USING btree (created_at DESC);


--
-- Name: idx_home_banners_active_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_home_banners_active_order ON public.home_section_banners USING btree (is_active, sort_order);


--
-- Name: idx_home_banners_anchor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_home_banners_anchor ON public.home_section_banners USING btree (anchor_section_id);


--
-- Name: idx_home_sections_active_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_home_sections_active_order ON public.home_sections USING btree (is_active, sort_order);


--
-- Name: idx_page_blocks_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_page_blocks_location ON public.page_blocks USING btree (location, sort_order) WHERE (location IS NOT NULL);


--
-- Name: idx_page_blocks_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_page_blocks_page ON public.page_blocks USING btree (page_id, sort_order);


--
-- Name: orders_branch_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_branch_idx ON public.orders USING btree (branch_id);


--
-- Name: orders_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_created_idx ON public.orders USING btree (created_at DESC);


--
-- Name: orders_customer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_customer_idx ON public.orders USING btree (customer_id);


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- Name: product_categories_name_ar_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_categories_name_ar_unique ON public.product_categories USING btree (lower(name_ar));


--
-- Name: products_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_category_idx ON public.products USING btree (category_id);


--
-- Name: products_name_ar_category_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_name_ar_category_unique ON public.products USING btree (lower(name_ar), category_id);


--
-- Name: coupons coupons_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER coupons_updated_at BEFORE UPDATE ON public.coupons FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: customers customers_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER customers_updated_at BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: drivers drivers_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER drivers_updated_at BEFORE UPDATE ON public.drivers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: orders orders_status_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_status_trigger AFTER INSERT OR UPDATE OF status ON public.orders FOR EACH ROW EXECUTE FUNCTION public.log_order_status_change();


--
-- Name: orders orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: addon_groups trg_addon_groups_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_addon_groups_updated BEFORE UPDATE ON public.addon_groups FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: app_settings trg_appsettings_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_appsettings_updated BEFORE UPDATE ON public.app_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: banners trg_banners_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_banners_updated BEFORE UPDATE ON public.banners FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: branches trg_branches_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_branches_updated BEFORE UPDATE ON public.branches FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_categories trg_categories_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_categories_updated BEFORE UPDATE ON public.product_categories FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: faqs trg_faqs_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_faqs_updated BEFORE UPDATE ON public.faqs FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: footer_settings trg_footer_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_footer_updated BEFORE UPDATE ON public.footer_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: header_settings trg_header_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_header_updated BEFORE UPDATE ON public.header_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: hero_slides trg_hero_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_hero_updated BEFORE UPDATE ON public.hero_slides FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: home_section_banners trg_home_banners_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_home_banners_updated BEFORE UPDATE ON public.home_section_banners FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: home_sections trg_home_sections_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_home_sections_updated BEFORE UPDATE ON public.home_sections FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: integrations trg_integrations_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_integrations_updated BEFORE UPDATE ON public.integrations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: navigation_menu_items trg_navitems_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_navitems_updated BEFORE UPDATE ON public.navigation_menu_items FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: navigation_menus trg_navmenus_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_navmenus_updated BEFORE UPDATE ON public.navigation_menus FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: orders trg_orders_status_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_orders_status_change AFTER INSERT OR UPDATE OF status ON public.orders FOR EACH ROW EXECUTE FUNCTION public.log_order_status_change();


--
-- Name: page_blocks trg_page_blocks_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_page_blocks_updated BEFORE UPDATE ON public.page_blocks FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: pages trg_pages_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_pages_updated BEFORE UPDATE ON public.pages FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_addons trg_product_addons_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_product_addons_updated BEFORE UPDATE ON public.product_addons FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: products trg_products_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_products_updated BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: profiles trg_profiles_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: seo_settings trg_seo_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_seo_updated BEFORE UPDATE ON public.seo_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: store_settings trg_store_settings_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_store_settings_updated BEFORE UPDATE ON public.store_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: product_variants trg_variants_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_variants_updated BEFORE UPDATE ON public.product_variants FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: webhooks trg_webhooks_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_webhooks_updated BEFORE UPDATE ON public.webhooks FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: delivery_zones zones_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zones_updated_at BEFORE UPDATE ON public.delivery_zones FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: addon_group_links addon_group_links_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addon_group_links
    ADD CONSTRAINT addon_group_links_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE CASCADE;


--
-- Name: addon_group_links addon_group_links_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addon_group_links
    ADD CONSTRAINT addon_group_links_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.addon_groups(id) ON DELETE CASCADE;


--
-- Name: addon_group_links addon_group_links_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addon_group_links
    ADD CONSTRAINT addon_group_links_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: coupon_usages coupon_usages_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupon_usages
    ADD CONSTRAINT coupon_usages_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.coupons(id) ON DELETE CASCADE;


--
-- Name: coupon_usages coupon_usages_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupon_usages
    ADD CONSTRAINT coupon_usages_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: coupons coupons_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: customer_addresses customer_addresses_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_addresses
    ADD CONSTRAINT customer_addresses_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: delivery_zones delivery_zones_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_zones
    ADD CONSTRAINT delivery_zones_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- Name: drivers drivers_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: home_section_banners home_section_banners_anchor_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_section_banners
    ADD CONSTRAINT home_section_banners_anchor_section_id_fkey FOREIGN KEY (anchor_section_id) REFERENCES public.home_sections(id) ON DELETE SET NULL;


--
-- Name: home_section_banners home_section_banners_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_section_banners
    ADD CONSTRAINT home_section_banners_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.home_sections(id) ON DELETE CASCADE;


--
-- Name: home_sections home_sections_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_sections
    ADD CONSTRAINT home_sections_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- Name: import_logs import_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_logs
    ADD CONSTRAINT import_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: navigation_menu_items navigation_menu_items_menu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.navigation_menu_items
    ADD CONSTRAINT navigation_menu_items_menu_id_fkey FOREIGN KEY (menu_id) REFERENCES public.navigation_menus(id) ON DELETE CASCADE;


--
-- Name: navigation_menu_items navigation_menu_items_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.navigation_menu_items
    ADD CONSTRAINT navigation_menu_items_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.navigation_menu_items(id) ON DELETE CASCADE;


--
-- Name: order_item_addons order_item_addons_addon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons
    ADD CONSTRAINT order_item_addons_addon_id_fkey FOREIGN KEY (addon_id) REFERENCES public.product_addons(id) ON DELETE SET NULL;


--
-- Name: order_item_addons order_item_addons_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_item_addons
    ADD CONSTRAINT order_item_addons_order_item_id_fkey FOREIGN KEY (order_item_id) REFERENCES public.order_items(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: order_items order_items_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE SET NULL;


--
-- Name: order_status_logs order_status_logs_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_status_logs
    ADD CONSTRAINT order_status_logs_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders orders_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: orders orders_coupon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_coupon_id_fkey FOREIGN KEY (coupon_id) REFERENCES public.coupons(id) ON DELETE SET NULL;


--
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: orders orders_delivery_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_delivery_address_id_fkey FOREIGN KEY (delivery_address_id) REFERENCES public.customer_addresses(id) ON DELETE SET NULL;


--
-- Name: orders orders_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: page_blocks page_blocks_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.page_blocks
    ADD CONSTRAINT page_blocks_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: product_addons product_addons_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_addons
    ADD CONSTRAINT product_addons_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.addon_groups(id) ON DELETE CASCADE;


--
-- Name: product_branches product_branches_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_branches
    ADD CONSTRAINT product_branches_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- Name: product_branches product_branches_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_branches
    ADD CONSTRAINT product_branches_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_categories product_categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_key_fkey FOREIGN KEY (permission_key) REFERENCES public.permissions(key) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_branches user_branches_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_branches
    ADD CONSTRAINT user_branches_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webhook_logs webhook_logs_webhook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES public.webhooks(id) ON DELETE CASCADE;


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: addon_group_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.addon_group_links ENABLE ROW LEVEL SECURITY;

--
-- Name: addon_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.addon_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles admins manage roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins manage roles" ON public.user_roles USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: user_roles admins read all roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins read all roles" ON public.user_roles FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: permissions admins write permissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins write permissions" ON public.permissions USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: role_permissions admins write role_permissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins write role_permissions" ON public.role_permissions USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: roles admins write roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins write roles" ON public.roles USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: user_branches admins write user_branches; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins write user_branches" ON public.user_branches USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: contact_messages anyone insert contact; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "anyone insert contact" ON public.contact_messages FOR INSERT WITH CHECK ((((char_length(name) >= 2) AND (char_length(name) <= 100)) AND ((char_length(phone) >= 6) AND (char_length(phone) <= 20)) AND ((char_length(message) >= 2) AND (char_length(message) <= 2000))));


--
-- Name: app_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs auth insert activity_logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth insert activity_logs" ON public.activity_logs FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: addon_group_links auth read addon_group_links; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read addon_group_links" ON public.addon_group_links FOR SELECT TO authenticated USING (true);


--
-- Name: addon_groups auth read addon_groups; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read addon_groups" ON public.addon_groups FOR SELECT TO authenticated USING (true);


--
-- Name: branches auth read branches; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read branches" ON public.branches FOR SELECT TO authenticated USING (true);


--
-- Name: product_categories auth read categories; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read categories" ON public.product_categories FOR SELECT TO authenticated USING (true);


--
-- Name: permissions auth read permissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read permissions" ON public.permissions FOR SELECT TO authenticated USING (true);


--
-- Name: product_addons auth read product_addons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read product_addons" ON public.product_addons FOR SELECT TO authenticated USING (true);


--
-- Name: product_branches auth read product_branches; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read product_branches" ON public.product_branches FOR SELECT TO authenticated USING (true);


--
-- Name: products auth read products; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read products" ON public.products FOR SELECT TO authenticated USING (true);


--
-- Name: role_permissions auth read role_permissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read role_permissions" ON public.role_permissions FOR SELECT TO authenticated USING (true);


--
-- Name: roles auth read roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read roles" ON public.roles FOR SELECT TO authenticated USING (true);


--
-- Name: store_settings auth read settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read settings" ON public.store_settings FOR SELECT TO authenticated USING (true);


--
-- Name: product_variants auth read variants; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "auth read variants" ON public.product_variants FOR SELECT TO authenticated USING (true);


--
-- Name: banners; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.banners ENABLE ROW LEVEL SECURITY;

--
-- Name: branches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.branches ENABLE ROW LEVEL SECURITY;

--
-- Name: contact_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: coupon_usages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.coupon_usages ENABLE ROW LEVEL SECURITY;

--
-- Name: coupons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;

--
-- Name: customer_addresses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customer_addresses ENABLE ROW LEVEL SECURITY;

--
-- Name: customers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

--
-- Name: delivery_zones; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.delivery_zones ENABLE ROW LEVEL SECURITY;

--
-- Name: drivers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.drivers ENABLE ROW LEVEL SECURITY;

--
-- Name: faqs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.faqs ENABLE ROW LEVEL SECURITY;

--
-- Name: footer_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.footer_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: header_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.header_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: hero_slides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hero_slides ENABLE ROW LEVEL SECURITY;

--
-- Name: home_section_banners; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.home_section_banners ENABLE ROW LEVEL SECURITY;

--
-- Name: home_sections; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.home_sections ENABLE ROW LEVEL SECURITY;

--
-- Name: import_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.import_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: integrations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.integrations ENABLE ROW LEVEL SECURITY;

--
-- Name: coupon_usages managers insert coupon usages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers insert coupon usages" ON public.coupon_usages FOR INSERT WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: import_logs managers insert import_logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers insert import_logs" ON public.import_logs FOR INSERT WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: activity_logs managers read activity_logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read activity_logs" ON public.activity_logs FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: customer_addresses managers read addresses; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read addresses" ON public.customer_addresses FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: profiles managers read all profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read all profiles" ON public.profiles FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: contact_messages managers read contact; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read contact" ON public.contact_messages FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: coupon_usages managers read coupon usages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read coupon usages" ON public.coupon_usages FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: coupons managers read coupons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read coupons" ON public.coupons FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: customers managers read customers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read customers" ON public.customers FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: drivers managers read drivers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read drivers" ON public.drivers FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: import_logs managers read import_logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read import_logs" ON public.import_logs FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: integrations managers read integrations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read integrations" ON public.integrations FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: notifications managers read notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read notifications" ON public.notifications FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: order_item_addons managers read order_item_addons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read order_item_addons" ON public.order_item_addons FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: order_items managers read order_items; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read order_items" ON public.order_items FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: order_status_logs managers read order_status_logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read order_status_logs" ON public.order_status_logs FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: orders managers read orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read orders" ON public.orders FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: user_branches managers read user_branches; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read user_branches" ON public.user_branches FOR SELECT USING ((public.is_manager(auth.uid()) OR (auth.uid() = user_id)));


--
-- Name: webhook_logs managers read webhook logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read webhook logs" ON public.webhook_logs FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: webhooks managers read webhooks; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read webhooks" ON public.webhooks FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: delivery_zones managers read zones; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers read zones" ON public.delivery_zones FOR SELECT USING (public.is_manager(auth.uid()));


--
-- Name: contact_messages managers update contact; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers update contact" ON public.contact_messages FOR UPDATE USING (public.is_manager(auth.uid()));


--
-- Name: addon_group_links managers write addon_group_links; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write addon_group_links" ON public.addon_group_links USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: addon_groups managers write addon_groups; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write addon_groups" ON public.addon_groups USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: customer_addresses managers write addresses; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write addresses" ON public.customer_addresses USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: app_settings managers write app settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write app settings" ON public.app_settings USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: banners managers write banners; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write banners" ON public.banners USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: branches managers write branches; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write branches" ON public.branches USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: product_categories managers write categories; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write categories" ON public.product_categories USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: coupons managers write coupons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write coupons" ON public.coupons USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: customers managers write customers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write customers" ON public.customers USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: drivers managers write drivers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write drivers" ON public.drivers USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: faqs managers write faqs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write faqs" ON public.faqs USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: footer_settings managers write footer; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write footer" ON public.footer_settings USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: header_settings managers write header; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write header" ON public.header_settings USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: hero_slides managers write hero; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write hero" ON public.hero_slides USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: home_section_banners managers write home_banners; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write home_banners" ON public.home_section_banners USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: home_sections managers write home_sections; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write home_sections" ON public.home_sections USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: integrations managers write integrations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write integrations" ON public.integrations USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: navigation_menu_items managers write menu items; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write menu items" ON public.navigation_menu_items USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: navigation_menus managers write menus; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write menus" ON public.navigation_menus USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: notifications managers write notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write notifications" ON public.notifications USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: order_item_addons managers write order_item_addons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write order_item_addons" ON public.order_item_addons USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: order_items managers write order_items; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write order_items" ON public.order_items USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: order_status_logs managers write order_status_logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write order_status_logs" ON public.order_status_logs USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: orders managers write orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write orders" ON public.orders USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: page_blocks managers write page_blocks; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write page_blocks" ON public.page_blocks USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: pages managers write pages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write pages" ON public.pages USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: product_addons managers write product_addons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write product_addons" ON public.product_addons USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: product_branches managers write product_branches; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write product_branches" ON public.product_branches USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: products managers write products; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write products" ON public.products USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: seo_settings managers write seo; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write seo" ON public.seo_settings USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: store_settings managers write settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write settings" ON public.store_settings USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: product_variants managers write variants; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write variants" ON public.product_variants USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: webhook_logs managers write webhook logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write webhook logs" ON public.webhook_logs USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: webhooks managers write webhooks; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write webhooks" ON public.webhooks USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: delivery_zones managers write zones; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "managers write zones" ON public.delivery_zones USING (public.is_manager(auth.uid())) WITH CHECK (public.is_manager(auth.uid()));


--
-- Name: navigation_menu_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.navigation_menu_items ENABLE ROW LEVEL SECURITY;

--
-- Name: navigation_menus; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.navigation_menus ENABLE ROW LEVEL SECURITY;

--
-- Name: notification_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notification_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: order_item_addons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_item_addons ENABLE ROW LEVEL SECURITY;

--
-- Name: order_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

--
-- Name: order_status_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_status_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

--
-- Name: page_blocks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.page_blocks ENABLE ROW LEVEL SECURITY;

--
-- Name: pages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pages ENABLE ROW LEVEL SECURITY;

--
-- Name: permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: product_addons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.product_addons ENABLE ROW LEVEL SECURITY;

--
-- Name: product_branches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.product_branches ENABLE ROW LEVEL SECURITY;

--
-- Name: product_categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.product_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: product_variants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.product_variants ENABLE ROW LEVEL SECURITY;

--
-- Name: products; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: banners public read active banners; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read active banners" ON public.banners FOR SELECT USING ((status = 'active'::public.banner_status));


--
-- Name: branches public read active branches; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read active branches" ON public.branches FOR SELECT USING ((is_active = true));


--
-- Name: coupons public read active coupons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read active coupons" ON public.coupons FOR SELECT USING ((status = 'active'::public.coupon_status));


--
-- Name: hero_slides public read active hero; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read active hero" ON public.hero_slides FOR SELECT USING ((status = 'active'::public.banner_status));


--
-- Name: home_section_banners public read active home_banners; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read active home_banners" ON public.home_section_banners FOR SELECT USING ((is_active = true));


--
-- Name: home_sections public read active home_sections; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read active home_sections" ON public.home_sections FOR SELECT USING ((is_active = true));


--
-- Name: page_blocks public read active page_blocks; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read active page_blocks" ON public.page_blocks FOR SELECT USING ((is_active = true));


--
-- Name: addon_group_links public read addon_group_links; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read addon_group_links" ON public.addon_group_links FOR SELECT USING (true);


--
-- Name: addon_groups public read addon_groups; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read addon_groups" ON public.addon_groups FOR SELECT USING (true);


--
-- Name: app_settings public read app settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read app settings" ON public.app_settings FOR SELECT USING (true);


--
-- Name: delivery_zones public read delivery_zones; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read delivery_zones" ON public.delivery_zones FOR SELECT USING ((status = 'active'::public.zone_status));


--
-- Name: footer_settings public read footer; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read footer" ON public.footer_settings FOR SELECT USING (true);


--
-- Name: header_settings public read header; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read header" ON public.header_settings FOR SELECT USING (true);


--
-- Name: navigation_menu_items public read menu items; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read menu items" ON public.navigation_menu_items FOR SELECT USING ((status = 'published'::public.publish_status));


--
-- Name: navigation_menus public read menus; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read menus" ON public.navigation_menus FOR SELECT USING ((status = 'published'::public.publish_status));


--
-- Name: product_addons public read product_addons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read product_addons" ON public.product_addons FOR SELECT USING ((is_available = true));


--
-- Name: product_branches public read product_branches; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read product_branches" ON public.product_branches FOR SELECT USING (true);


--
-- Name: faqs public read published faqs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read published faqs" ON public.faqs FOR SELECT USING ((status = 'published'::public.publish_status));


--
-- Name: pages public read published pages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read published pages" ON public.pages FOR SELECT USING ((status = 'published'::public.publish_status));


--
-- Name: seo_settings public read seo; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read seo" ON public.seo_settings FOR SELECT USING (true);


--
-- Name: product_categories public read store categories; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read store categories" ON public.product_categories FOR SELECT USING (((show_in_store = true) AND (is_active = true)));


--
-- Name: products public read store products; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read store products" ON public.products FOR SELECT USING (((show_in_store = true) AND (is_archived = false)));


--
-- Name: store_settings public read store_settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read store_settings" ON public.store_settings FOR SELECT USING (true);


--
-- Name: product_variants public read variants; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "public read variants" ON public.product_variants FOR SELECT USING (true);


--
-- Name: role_permissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;

--
-- Name: security_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.security_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: seo_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.seo_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: store_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: user_branches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_branches ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: notification_settings users own notif settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "users own notif settings" ON public.notification_settings USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: security_sessions users own sessions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "users own sessions" ON public.security_sessions USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: profiles users read own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "users read own profile" ON public.profiles FOR SELECT USING ((auth.uid() = id));


--
-- Name: user_roles users read own roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "users read own roles" ON public.user_roles FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: profiles users update own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "users update own profile" ON public.profiles FOR UPDATE USING ((auth.uid() = id));


--
-- Name: webhook_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhook_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: webhooks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhooks ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict ih74VFQMwuPKGqbW9EXPsXpaVFtLqVKc9uLW16bk9jHcabGQUluaWAehRqOvz4Q

